package com.smc.service.query.impl;

import com.google.common.collect.Lists;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.model.page.Param;
import com.smc.dataobject.query.SysAccountButtonConfiguration;
import com.smc.dataobject.query.SysAccountRowColorRulesConfiguration;
import com.smc.dataobject.query.SysAccountTableFieldConfiguration;
import com.smc.dataobject.query.SysTableFieldConfiguration;
import com.smc.mapper.query.SysAccountTableFieldConfigurationDao;
import com.smc.mapper.query.SysTableFieldConfigurationDao;
import com.smc.service.query.FieldDynamicConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Author: C02039 wjh
 * @Date: 2022/7/21  16:29
 */
@Service
public class FieldDynamicConfigServiceImpl implements FieldDynamicConfigService {
    //员工编号级别配置字段
    @Autowired
    SysAccountTableFieldConfigurationDao sysAccounttablefieldconfigurationDao;
    //字段基础表
    @Autowired
    SysTableFieldConfigurationDao sysTablefieldconfigurationDao;

    /**
     * 将字符串的首字母转小写
     *
     * @param str 需要转换的字符串
     * @return
     */
    private static String lowerFirst(String str) {
        char[] cs = str.toCharArray();
        cs[0] += 32;
        return String.valueOf(cs);
    }

    /**
     * 保存操作
     *
     * @param record
     * @return
     */
    @Override
    public int save(Object record) {
        return 0;
    }

    /**
     * 删除操作
     *
     * @param record
     * @return
     */
    @Override
    public int delete(Object record) {
        return 0;
    }

    /**
     * 批量删除操作
     *
     * @param records
     */
    @Override
    public int delete(List records) {
        return 0;
    }

    /**
     * 根据ID查询
     *
     * @param id
     * @return
     */
    @Override
    public Object findById(Long id) {
        return null;
    }

    /**
     * 分页查询
     * 这里统一封装了分页请求和结果，避免直接引入具体框架的分页对象, 如MyBatis或JPA的分页对象
     * 从而避免因为替换ORM框架而导致服务层、控制层的分页接口也需要变动的情况，替换ORM框架也不会
     * 影响服务层以上的分页接口，起到了解耦的作用
     *
     * @param pageRequest 自定义，统一分页查询请求
     * @return PageResult 自定义，统一分页查询结果
     */
    @Override
    public PageResult findPage(PageRequest pageRequest) {
        return null;
    }

    /**
     * 根据用户名、要查的表名获取 当前用户已经配置的字段
     *
     * @param pageRequest
     * @return
     */
    @Override
    public List<SysAccountTableFieldConfiguration> getUsableFieldByUserIdAndTableName(PageRequest pageRequest) {
        // 创建map 用于存放参数
        HashMap<String, Object> map = generateParams(pageRequest);
        return getUsableFieldByUserIdAndTableNameMethods(map);
    }

    /**
     * 用户某个查询页面 返回可用的字段集合(判断是查询默认值还是 查询自主配置的值)
     *
     * @param map
     * @return
     */
    public List<SysAccountTableFieldConfiguration> getUsableFieldByUserIdAndTableNameMethods(HashMap<String, Object> map) {
        //检查员工配置表中是否有已经启用的配置信息
        int activity1Num = sysAccounttablefieldconfigurationDao.getUsableFieldActivity1ByUserIdAndTableName(map);
        List<SysAccountTableFieldConfiguration> list = new ArrayList<>();
        if (activity1Num > 0) {
            //有配置直接查询员工配置表中信息配置表信息
            list = sysAccounttablefieldconfigurationDao.getUsableFieldByUserIdAndTableName(map);
        } else {
            //没有配置查询主表的默认值
            list = sysAccounttablefieldconfigurationDao.getDefaultFieldByUserIdAndTableName(map);
        }
        for (SysAccountTableFieldConfiguration ATFC : list) {
            //取到首字母
            char c = ATFC.getFieldName().charAt(0);
            //判断首字母是否为大写
            if (Character.isUpperCase(c)) {
                //如果首字母大写 转换为首字母小写
                ATFC.setFieldName(lowerFirst(ATFC.getFieldName()));
            }
            ATFC.setProp(ATFC.getFieldName());
            ATFC.setSortable(ATFC.getFieldName());
        }
        return list;
    }

    /**
     * 根据表名获取 该表有哪些字段可以配置
     * 基础表 用于配置
     *
     * @param tableName
     * @return
     */
    @Override
    public List<SysTableFieldConfiguration> getAllFieldByTableName(String tableName) {
        // 创建map 用于存放参数
//        HashMap<String, Object> map = generateParams(pageRequest);
        List<SysTableFieldConfiguration> list = sysTablefieldconfigurationDao.getAllFieldByTableName(tableName);
        //防止不能回显等问题/全部字段名称都要转为首字母小写
        for (SysTableFieldConfiguration TFC : list) {
            //取到首字母
            char c = TFC.getFieldName().charAt(0);
            //判断首字母是否为大写
            if (Character.isUpperCase(c)) {
                //如果首字母大写 转换为首字母小写
                TFC.setFieldName(lowerFirst(TFC.getFieldName()));
            }
        }
        return list;
    }

    /**
     * List<SysTableFieldConfiguration>
     * 用户自定义配置字段提交
     *
     * @param submitFieldParams
     * @return
     */
    @Override
    public List<SysAccountTableFieldConfiguration> submitFieldConfiguration(Map<String, Object> submitFieldParams) {
        String tableName = (String) submitFieldParams.get("tableName");
        String userName = (String) submitFieldParams.get("userName");
        HashMap<String, Object> map = new HashMap<>();
        map.put("tableName", tableName);
        map.put("userName", userName);

        //获取前台传过来的字段并去重
        List<String> fieldsLists = (List<String>) submitFieldParams.get("fields");
        List<String> distinctFieldsLists = null;
        if (fieldsLists.size() > 0) {
            distinctFieldsLists = fieldsLists.stream().distinct().collect(Collectors.toList());
//        map.put("distinctFieldsLists", distinctFieldsLists);
            //原来给用户正在使用的字段
            List<SysAccountTableFieldConfiguration> sourceUsedListActivity1 = sysAccounttablefieldconfigurationDao.getUsableFieldByUserIdAndTableName(map);
            //原来该用户已经配置的字段  原来启用、非启用
            List<SysAccountTableFieldConfiguration> sourceUsedListActivityO = sysAccounttablefieldconfigurationDao.getFieldByUserIdAndTableName(map);
            List<SysAccountTableFieldConfiguration> updateActivityO = new ArrayList<>();
            List<SysAccountTableFieldConfiguration> updateActivity1 = new ArrayList<>();
            List<SysAccountTableFieldConfiguration> updateList = new ArrayList<>();

            List<SysAccountTableFieldConfiguration> addList = new ArrayList<>();
            //1、启用 =》 停用  配置表中启用的某用户字段 前台没穿 启用要变成停用
            updateActivityO = ListA_B(sourceUsedListActivity1, distinctFieldsLists);
            for (SysAccountTableFieldConfiguration activityO : updateActivityO) {
                activityO.setActivity("0");
                activityO.setTableName(tableName);
                activityO.setUserId(userName);
                activityO.setOperator(userName);
            }
            //2、启用、停用 所有能在配置表中找到的 都重新设置为启用；前台新传过来的，只要在配置表里能找到无论启用、停用 都要把 状态全部置成 =》 启用
            updateActivity1 = ListABEqual(sourceUsedListActivityO, distinctFieldsLists);
            for (SysAccountTableFieldConfiguration activity1 : updateActivity1) {
                activity1.setActivity("1");
                activity1.setTableName(tableName);
                activity1.setUserId(userName);
                activity1.setOperator(userName);
            }
            updateList.addAll(updateActivityO);
            updateList.addAll(updateActivity1);
            //批量更新
            List<List<SysAccountTableFieldConfiguration>> updateLists = Lists.partition(updateList, 40);
            for (List<SysAccountTableFieldConfiguration> updateBatchLists : updateLists) {
                int updateNum = sysTablefieldconfigurationDao.updateBatchUserConfig(updateBatchLists);
            }
            //3、无   =》 启用 除了在配置表中找到的 都要新增
            List<String> addFields = ListB_A(updateList, distinctFieldsLists);
            //在主表中查找 根据中文字段名 表名找要添加的信息 setTableNameChn、setFieldName
            if (addFields.size() > 0) {
                List<SysAccountTableFieldConfiguration> addDataList = sysTablefieldconfigurationDao.getAddDataByTableNameFieldChn(tableName, addFields);
                for (SysAccountTableFieldConfiguration addEntity : addDataList) {
                    addEntity.setUserId(userName);
                    addEntity.setActivity("1");
                    addEntity.setOperator(userName);
                }
                //批量插入员工字段配置表
                List<List<SysAccountTableFieldConfiguration>> insertLists = Lists.partition(addDataList, 40);
                for (List<SysAccountTableFieldConfiguration> insertBatchList : insertLists) {
                    int insertNum = sysTablefieldconfigurationDao.insertBatchUserConfig(insertBatchList);
                }
            }
        } else {
            //某一个表 某员工对应字段全部停用
            //恢复默认 也是一样的原理（把员工配置表中启用的全部变为停用） 调用的是该方法
            sysTablefieldconfigurationDao.updateSYS_AccountTableField0(map);
        }
        //做完修改最后在查一下该用户所能用的字段 用于字段回显
        return getUsableFieldByUserIdAndTableNameMethods(map);
    }

    /**
     * 用户自定义配置字段提交（设置显示字段显示顺序）
     *
     * @param fieldSort
     * @return
     */
    @Override
    public int submitFieldSort(List<SysAccountTableFieldConfiguration> fieldSort) {
        int i = 0;
        for (SysAccountTableFieldConfiguration sortEntity : fieldSort) {
            i++;
            sortEntity.setSort(i);
        }
        return sysAccounttablefieldconfigurationDao.submitFieldSort(fieldSort);
    }

    /**
     * 主配置数据——根据表名、用户名 获取用户在该查询的按钮权限
     * 用于页面中 某个查询按钮权限的控制
     *
     * @param pageRequest
     * @return
     */
    @Override
    public List<SysAccountButtonConfiguration> getButtonPermissionUserIdAndTableName(PageRequest pageRequest) {
        // 创建map 用于存放参数
        HashMap<String, Object> map = generateParams(pageRequest);
        return sysAccounttablefieldconfigurationDao.getButtonPermissionUserIdAndTableName(map);
    }

    /**
     * 主配置数据——根据表名、用户名 获取自定义数据行的颜色
     * 用于页面中 数据展示某一行的颜色控制
     *
     * @param pageRequest
     * @return
     */
    @Override
    public List<SysAccountRowColorRulesConfiguration> getRowColorsByUserIdAndTableName(PageRequest pageRequest) {
        // 创建map 用于存放参数
        HashMap<String, Object> map = generateParams(pageRequest);
//        String rowColorRules = "false";
        List<SysAccountRowColorRulesConfiguration> rowColorRulesList = new ArrayList<>();
        List<SysAccountRowColorRulesConfiguration> rowColorRulesAccountList = sysAccounttablefieldconfigurationDao.getRowColorsByUserIdAndTableName(map);
        List<SysAccountRowColorRulesConfiguration> rowColorRulesDefaultList = sysAccounttablefieldconfigurationDao.getRowColorsByTableName(map);
        if (rowColorRulesAccountList.size() > 0) {
            //查询用户自定义配置（数据行颜色）
            rowColorRulesList.addAll(rowColorRulesAccountList);
            return rowColorRulesList;
        } else if (rowColorRulesDefaultList.size() > 0) {
            //系统颜色配置
            rowColorRulesList.addAll(rowColorRulesDefaultList);
            return rowColorRulesList;
        }
        return rowColorRulesList;
    }

    /**
     * 查询参数生成
     *
     * @param pageRequest
     * @return
     */
    private HashMap<String, Object> generateParams(PageRequest pageRequest) {
        // 创建map 用于存放参数
        HashMap<String, Object> map = new HashMap<>();
        List<Param> params = pageRequest.getParams();
        for (Param param : params) {
            map.put(param.getName(), param.getValue());
        }
        // 获取厂别
        // String plantName = pageRequest.getParamValue("plantName");
        // String plantMark = PlantMarkUtils.convertPlantNameToPlantMark(plantName);
        // map.put("plantMark", plantMark);
        return map;
    }

    //listA - listB
    public List<SysAccountTableFieldConfiguration> ListA_B(List<SysAccountTableFieldConfiguration> listA, List<String> listB) {
        return listA.stream().filter(SysAccounttablefieldconfiguration -> !listB.contains(SysAccounttablefieldconfiguration.getFieldNameChn())).collect(Collectors.toList());
    }

    //listA = listB
    public List<SysAccountTableFieldConfiguration> ListABEqual(List<SysAccountTableFieldConfiguration> listA, List<String> listB) {
        return listA.stream().filter(SysAccounttablefieldconfiguration -> listB.contains(SysAccounttablefieldconfiguration.getFieldNameChn())).collect(Collectors.toList());
    }

    //listB - listA
    public List<String> ListB_A(List<SysAccountTableFieldConfiguration> listA, List<String> listB) {
        List<String> listAIds = listA.stream().map(SysAccountTableFieldConfiguration::getFieldNameChn).collect(Collectors.toList());
        return listB.stream().filter(item -> !listAIds.contains(item)).collect(Collectors.toList());
    }

}
