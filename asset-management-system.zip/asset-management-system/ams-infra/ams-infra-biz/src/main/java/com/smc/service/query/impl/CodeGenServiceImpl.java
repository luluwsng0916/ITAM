package com.smc.service.query.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.smc.common.model.result.ResultBody;
import com.smc.common.mybatis.model.KeyValueParam;
import com.smc.mapper.query.CodeGenMapper;
import com.smc.service.query.CodeGenService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @program: asset-management-system
 * @ClassName CodeGenServiceImpl
 * @description:
 * @author: C31909
 * @create: 2024-08-07 14:08
 * @Version 1.0
 **/
@Service
public class CodeGenServiceImpl implements CodeGenService {

    @Resource
    private CodeGenMapper codeGenMapper;

    @Override
    public ResultBody<List<KeyValueParam<String, String>>> listTables() {
        List<String> list = codeGenMapper.listTables();
        List<KeyValueParam<String, String>> keyValueParams = new ArrayList<>();
        if (CollectionUtil.isEmpty(list)) {
            return ResultBody.failed();
        }
        for (String str : list) {
            KeyValueParam<String, String> param = new KeyValueParam<>();
            param.setKey(str);
            param.setValue(str);
            keyValueParams.add(param);
        }
        return ResultBody.ok().data(keyValueParams);
    }
}
