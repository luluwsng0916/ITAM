package com.smc.mapper.query;

import java.util.List;

/**
 * @author C31909
 */
public interface CodeGenMapper {
    List<String> listTables();
}
