package com.smc.service.query.impl;

import com.alibaba.excel.EasyExcel;
import com.google.common.collect.Lists;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.mybatis.page.MybatisPageHelper;
import com.smc.convert.MapEntityBeanConverter;
import com.smc.dataobject.query.SysAccountButtonConfiguration;
import com.smc.mapper.query.SysAccountbuttonconfigurationDao;
import com.smc.service.query.SysAccountbuttonconfigurationService;
import com.smc.utils.ParamsUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * 通用查询按钮按钮配置(SysAccountButtonConfiguration)表服务实现类
 *
 * @author 温建华 C02039
 * @since 2023-05-23 13:50:14
 */
@Service("sysAccountbuttonconfigurationService")
public class SysAccountbuttonconfigurationServiceImpl implements SysAccountbuttonconfigurationService {
    @Autowired
    ParamsUtils paramsUtils;
    @Autowired
    private SysAccountbuttonconfigurationDao sysAccountbuttonconfigurationDao;

    /**
     * 查询 不分页
     * @param pageRequest
     * @return
     */
    @Override
    public List<SysAccountButtonConfiguration> getSysAccountButtonConfigurationData(PageRequest pageRequest) {
        //调用  生成 map 参数的方法
        HashMap<String, Object> map = paramsUtils.generateMapParams(pageRequest);

        // 针对Mysql数据库，因为show是mysql的关键字，所以用反引号包围
        String string = map.get("filedParams").toString();
        //获取结果数据
        StringBuilder builder = new StringBuilder();
        String[] fields = string.trim().split(",");
        for (String field : fields) {
            builder.append("`").append(field).append("`").append(",");
        }
        string = builder.substring(0, builder.length() - 1);

        map.put("filedParams", string);
        //获取结果数据
        List<SysAccountButtonConfiguration> resultList = getResultList(map);
        return resultList;
    }

    /**
     * 获取查询结果数据
     */
    private List<SysAccountButtonConfiguration> getResultList(HashMap<String, Object> map) {
        //获取所有已经配置的查询
        List<SysAccountButtonConfiguration> buttonConfigList = sysAccountbuttonconfigurationDao.getSysAccountButtonConfigurationData(map);
        return buttonConfigList;
    }

    /**
     * easyExcel导出 主配置表数据 指定列导出
     *
     * @param pageRequest
     * @param response
     */
    @Override
    public void exportSysAccountbuttonconfiguration(PageRequest pageRequest, HttpServletResponse response) throws IOException {
        //调用  生成 map 参数的方法
        HashMap<String, Object> map = paramsUtils.generateMapParams(pageRequest);
        //用easyexcel方式导出
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
        String fileName = URLEncoder.encode("文件名", "UTF-8");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
        //指定导出的字段
        List<String> distinctUsedFieldList = (List<String>) map.get("distinctUsedFieldList");
        List<SysAccountButtonConfiguration> excelList = getResultList(map);
        EasyExcel.write(response.getOutputStream(), SysAccountButtonConfiguration.class).includeColumnFiledNames(distinctUsedFieldList).sheet("sheet1").doWrite(excelList);
    }

    /**
     * 授权
     *
     * @param map
     * @return
     */
    @Override
    public int bindButtonAuth(Map<String, Object> map) throws Exception {
        List<Map<String, Object>> paramsList = (List<Map<String, Object>>) map.get("params");
        String userId = (String) paramsList.get(1).get("value");
        //获取前台传递的表单信息
        List<Map<String, Object>> buttonAuthMapList = (List<Map<String, Object>>) paramsList.get(3).get("value");
        List<SysAccountButtonConfiguration> buttonAuthList = new ArrayList<>();
        //map 类型转换为实体
        buttonAuthList = MapEntityBeanConverter.convertListMap2ListBean(buttonAuthMapList, SysAccountButtonConfiguration.class);
        //如果不是1 全部给赋值0 （导出权限、查询按钮权限、字段显示权限、字段顺序权限）
        for (SysAccountButtonConfiguration sysAccountButtonConfiguration : buttonAuthList) {
            //把授权对象放入实体
            /**
             * userId 取的是 左上角查询框的userId
             */
            sysAccountButtonConfiguration.setUserId(userId);
            if (!"1".equals(sysAccountButtonConfiguration.getExport())) {
                sysAccountButtonConfiguration.setExport("0");
            }
            if (!"1".equals(sysAccountButtonConfiguration.getQuery())) {
                sysAccountButtonConfiguration.setQuery("0");
            }
            if (!"1".equals(sysAccountButtonConfiguration.getShow())) {
                sysAccountButtonConfiguration.setShow("0");
            }
            if (!"1".equals(sysAccountButtonConfiguration.getSort())) {
                sysAccountButtonConfiguration.setSort("0");
            }
        }
        //判断inset OR update
        //查找数据库中已经存在的值
        List<SysAccountButtonConfiguration> haveList = new ArrayList<>();
        if (buttonAuthList != null && buttonAuthList.size() > 0) {
            List<List<SysAccountButtonConfiguration>> partition = Lists.partition(buttonAuthList, 40);
            for (List<SysAccountButtonConfiguration> list : partition) {
                haveList.addAll(sysAccountbuttonconfigurationDao.checkIsHave(list, userId));
            }
        }
        //前台传入进来的的于数据库中存在的值于对比
        /**
         * 因为是一个userId 所以只要比较 tableName 是否一样就可以判断出 insert OR update
         *
         */
        List<SysAccountButtonConfiguration> insertList = new ArrayList<>();
        //前台传递过来数据 - 数据库中已经存在的数据
        insertList = ListA_B(buttonAuthList, haveList);
        //1、前台传入 数据库中没有的值  插入
        if (insertList != null && insertList.size() > 0) {
            List<List<SysAccountButtonConfiguration>> partition = Lists.partition(insertList, 40);
            for (List<SysAccountButtonConfiguration> list : partition) {
                sysAccountbuttonconfigurationDao.insertSysAccountButtonConfiguration(list);
            }
        }
        //2、前台传入且数据库中存在的值 更新
        List<SysAccountButtonConfiguration> updateList = new ArrayList<>();
        //如果与数据库中的信息（表名、员工编号）相等 用前端传递的信息 更新数据库中信息
        updateList = ListABEqual(buttonAuthList, haveList);
        if (haveList != null && haveList.size() > 0) {
            List<List<SysAccountButtonConfiguration>> partition = Lists.partition(updateList, 40);
            for (List<SysAccountButtonConfiguration> list : partition) {
                sysAccountbuttonconfigurationDao.updateSysAccountButtonConfiguration(list);
            }
        }
        return 0;
    }

    /**
     * 保存操作
     *
     * @param record
     * @return
     */
    @Override
    public int save(Object record) {
        return 0;
    }

    /**
     * 删除操作
     *
     * @param record
     * @return
     */
    @Override
    public int delete(Object record) {
        return 0;
    }

    /**
     * 批量删除操作
     *
     * @param records
     */
    @Override
    public int delete(List records) {
        return 0;
    }

    /**
     * 根据ID查询
     *
     * @param id
     * @return
     */
    @Override
    public Object findById(Long id) {
        return null;
    }

    /**
     * 分页查询
     * 这里统一封装了分页请求和结果，避免直接引入具体框架的分页对象, 如MyBatis或JPA的分页对象
     * 从而避免因为替换ORM框架而导致服务层、控制层的分页接口也需要变动的情况，替换ORM框架也不会
     * 影响服务层以上的分页接口，起到了解耦的作用
     *
     * @param pageRequest 自定义，统一分页查询请求
     * @return PageResult 自定义，统一分页查询结果
     */
    @Override
    public PageResult findPage(PageRequest pageRequest) {
        //调用  生成 map 参数的方法
        HashMap<String, Object> map = paramsUtils.generateMapParams(pageRequest);
        return MybatisPageHelper.findPage(pageRequest, sysAccountbuttonconfigurationDao, "getSysAccountbuttonconfigurationFindPageData", map);
    }


    //listA - listB (按照TableName) 返回 listA
    public List<SysAccountButtonConfiguration> ListA_B(List<SysAccountButtonConfiguration> listA, List<SysAccountButtonConfiguration> listB) {
        List<String> listBTables = listB.stream().map(SysAccountButtonConfiguration::getTableName).collect(Collectors.toList());
        return listA.stream().filter(Entity -> !listBTables.contains(Entity.getTableName())).collect(Collectors.toList());
    }

    //listA = listB (按照TableName) 返回 listA
    public List<SysAccountButtonConfiguration> ListABEqual(List<SysAccountButtonConfiguration> listA, List<SysAccountButtonConfiguration> listB) {
        List<String> listBTables = listB.stream().map(SysAccountButtonConfiguration::getTableName).collect(Collectors.toList());
        return listA.stream().filter(Entity -> listBTables.contains(Entity.getTableName())).collect(Collectors.toList());
    }
}
