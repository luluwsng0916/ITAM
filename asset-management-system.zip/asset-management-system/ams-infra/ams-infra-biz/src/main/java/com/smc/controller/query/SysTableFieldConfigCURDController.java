package com.smc.controller.query;

import com.smc.common.model.http.HttpResult;
import com.smc.common.model.page.PageRequest;
import com.smc.service.query.SysTableFieldConfigCURDService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * 主配置表CURD controller 主要给程序员用
 *
 * @Author: C02039 wjh
 * @Date: 2023/3/1  20:56
 */
@RestController
@RequestMapping(value = "/SysTableFieldConfigCURD")
@CrossOrigin
public class SysTableFieldConfigCURDController {
    @Autowired
    SysTableFieldConfigCURDService sysTableFieldConfigCURDService;

    /**
     * 字段管理——分页查询主配置表数据
     *
     * @param pageRequest
     * @return
     */
    @RequestMapping(value = "/getSysTableFieldConfigFindPageData")
    public HttpResult getSysTableFieldConfigFindPageData(@RequestBody PageRequest pageRequest) {
        return HttpResult.ok(this.sysTableFieldConfigCURDService.findPage(pageRequest));
    }

    /**
     * 字段管理——easyExcel导出 主配置表数据 指定列导出
     *
     * @param pageRequest
     * @return
     */
    @RequestMapping(value = "/exportSysTableFieldConfigData")
    public void exportSysTableFieldConfigData(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        sysTableFieldConfigCURDService.exportSysTableFieldConfigData(pageRequest, response);
    }

    /**
     * 字段管理——主配置表 导入
     *
     * @param multipartFile
     * @param req
     * @return
     * @throws IOException
     */
    @RequestMapping(value = "/importSysTableFieldConfigData")
    public HttpResult commitModelUnitFile(
            @RequestParam(value = "multipartFile", required = false) MultipartFile multipartFile,
            HttpServletRequest req) throws IOException {
        String res = this.sysTableFieldConfigCURDService.importSysTableFieldConfigData(multipartFile, req);
        String successOrErrorCode = res.substring(0, res.indexOf("_"));
        String msg = res.substring(res.lastIndexOf("_") + 1);

        if ("success".equals(successOrErrorCode)) {
            return HttpResult.ok(msg);
        } else {
            return HttpResult.error(msg);
        }
    }

    /**
     * 字段管理——获取字段名下拉菜单
     *
     * @param
     * @return
     */
    @RequestMapping(value = "/getTableNames")
    public HttpResult getTableNames() {
        return HttpResult.ok(this.sysTableFieldConfigCURDService.getTableNames());
    }

    /**
     * 字段管理——单条修改
     *
     * @param map
     * @return
     */
    @RequestMapping(value = "/alterSysTableFieldConfigData")
    public HttpResult alterSysTableFieldConfigData(@RequestBody Map<String, Object> map) {
        return HttpResult.ok(this.sysTableFieldConfigCURDService.alterSysTableFieldConfigData(map));
    }

    @RequestMapping(value = "/insertSysTableFieldConfigAuto")
    public HttpResult insertSysTableFieldConfigAuto(@RequestBody Map<String, Object> map) {
        int num = this.sysTableFieldConfigCURDService.insertSysTableFieldConfigAuto(map);
        if (num > 0) {
            return HttpResult.ok("导入成功!");
        } else if (num == -1) {
            return HttpResult.error("输入的表名在所属数据库中不存在，请检查表名是否正确!");
        } else if (num == -2) {
            return HttpResult.error("当前表名的数据已导入，请勿重复导入!");
        } else if (num == -3) {
            return HttpResult.error("未配置数据库源，请到后台进行配置!");
        } else {
            return HttpResult.error("导入失败!");
        }
    }


    /**
     * 字段管理——单条删除
     *
     * @param map
     * @return
     */
    @RequestMapping(value = "/deleteSysTableFieldConfigData")
    public HttpResult deleteSysTableFieldConfigData(@RequestBody Map<String, Object> map) {
        return HttpResult.ok(this.sysTableFieldConfigCURDService.deleteSysTableFieldConfigData(map));
    }


    @GetMapping(value = "/listTables")
    public HttpResult listTables() {
        return HttpResult.ok(this.sysTableFieldConfigCURDService.listTables());
    }

    @PostMapping(value = "/save")
    public HttpResult saveSysTableFieldConfigData(@RequestBody Map<String, Object> map) {
        int count = sysTableFieldConfigCURDService.saveSysTableFieldConfigData(map);
        if (count > 0) {
            return HttpResult.ok(count);
        }
        return HttpResult.error("字段已存在");
    }

}
