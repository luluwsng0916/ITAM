package com.smc.controller.mdm.model.bo;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName PublicUniversalCodeDeleteBO
 * @description:
 * @author: C31909
 * @create: 2024-07-09 15:47
 * @Version 1.0
 **/
@Data
public class PublicUniversalCodeDeleteBO {
    private Integer id;
    private Integer version;
}
