package com.smc.service.query;

import com.smc.common.model.page.PageRequest;
import com.smc.common.mybatis.model.KeyValueParam;
import com.smc.common.mybatis.service.CurdService;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * 主配置表CURD service 主要给程序员用
 *
 * @Author: C02039 wjh
 * @Date: 2023/3/1  20:56
 */
public interface SysTableFieldConfigCURDService extends CurdService {
    /**
     * easyExcel导出 主配置表数据 指定列导出
     *
     * @param pageRequest
     * @param response
     */
    void exportSysTableFieldConfigData(PageRequest pageRequest, HttpServletResponse response) throws IOException;

    /**
     * 主配置表 导入
     *
     * @param multipartFile
     * @param req
     * @return
     */
    String importSysTableFieldConfigData(MultipartFile multipartFile, HttpServletRequest req);

    int insertSysTableFieldConfigAuto(Map<String, Object> map);
    /**
     * 单条修改
     *
     * @param map
     * @return
     */
    int alterSysTableFieldConfigData(Map<String, Object> map);

    /**
     * 单条删除
     *
     * @param map
     * @return
     */
    int deleteSysTableFieldConfigData(Map<String, Object> map);

    List<String> getTableNames();

    List<KeyValueParam<String,String>> listTables();

    int saveSysTableFieldConfigData(Map<String, Object> map);
}
