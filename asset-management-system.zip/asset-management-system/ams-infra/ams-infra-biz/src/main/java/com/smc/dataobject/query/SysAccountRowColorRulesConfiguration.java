package com.smc.dataobject.query;


import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 通用查询数据行颜色规则用户自定义配置(SysAccountRowColorRulesConfiguration)实体类
 * 数据行颜色规则 主配置 也公用此实体类
 * @author 温建华
 * @since 2023-07-07 13:08:40
 */
@Data
@ColumnWidth(16)
public class SysAccountRowColorRulesConfiguration implements Serializable {
    private static final long serialVersionUID = 452313216824835505L;
    @ExcelProperty("ID")
    private Integer id;
    /**
     * 用户名
     */
    @ExcelProperty("用户名")
    private String userId;
    /**
     * 表名
     */
    @ExcelProperty("表名")
    private String tableName;
    /**
     * 颜色规则语句 （对应回显字段英文对照）
     */
    @ExcelProperty("颜色规则语句 （对应回显字段英文对照）")
    private String rules;
    /**
     * 规则颜色标识 红色：error-row 绿色：success-row 黄色：warning-row  蓝色：primary-row 灰色：info-row
     */
    @ExcelProperty("规则颜色标识")
    private String ruleColors;
    /**
     * 启用标识
     */
    @ExcelProperty("启用标识")
    private String activity;
    /**
     * 1:超级规则 完全按照数据库中语句进行配置 0:不是超级规则 按照配置字段的颜色和字段名进行管理颜色
     */
    @ExcelProperty("超级规则标识")
    private Byte isSuperRules;
    /**
     * 超级规则
     */
    @ExcelProperty("超级规则")
    private String superRules;
    /**
     * 操作时间
     */
    @ExcelProperty("操作时间")
    private Date operationTime;
    /**
     * 操作者
     */
    @ExcelProperty("操作者")
    private String operator;
}

