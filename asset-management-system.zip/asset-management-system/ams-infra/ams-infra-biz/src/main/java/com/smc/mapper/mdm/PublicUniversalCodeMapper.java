package com.smc.mapper.mdm;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smc.dataobject.mdm.PublicUniversalCode;
import io.lettuce.core.dynamic.annotation.Param;

import java.util.List;

/**
 * 字典表
 *
 * @author C31909
 * @since 1.0.0 2024-07-09
 */
public interface PublicUniversalCodeMapper extends BaseMapper<PublicUniversalCode> {

    List<PublicUniversalCode> listAllType();

    void saveBatchUniversalCode(@Param("classifyDesc") String classifyDesc, @Param("list") List<String> list);
}