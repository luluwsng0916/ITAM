package com.smc.mapper.query;

import com.smc.dataobject.query.SysAccountTableFieldConfiguration;
import com.smc.dataobject.query.SysTableFieldConfiguration;
import feign.Param;

import java.util.HashMap;
import java.util.List;

/**
 * (SysTableFieldConfiguration)表数据库访问层
 * 主表
 *
 * @author wjh 自动生成 wjh 自动生成
 * @since 2022-07-21 17:38:35
 */
// @Mapper
public interface SysTableFieldConfigurationDao {
    /**
     * 在主表中获取所有启用的信息
     */
    List<SysTableFieldConfiguration> getAllFieldByTableName(String tableName);

    /**
     * 在主表中查找 根据中文字段名 表名找要添加的信息 setTableNameChn、setFieldName
     *
     * @param tableName
     * @param addFields
     * @return
     */
    List<SysAccountTableFieldConfiguration> getAddDataByTableNameFieldChn(@Param("tableName") String tableName, @Param("addFields") List<String> addFields);

    /**
     * 批量插入员工字段配置表
     *
     * @param list
     * @return
     */
    int insertBatchUserConfig(@Param("list") List<SysAccountTableFieldConfiguration> list);

    /**
     * 批量更新
     *
     * @param list
     * @return
     */
    int updateBatchUserConfig(@Param("list") List<SysAccountTableFieldConfiguration> list);

    /**
     * 某一个表全部停用
     *
     * @param map
     * @return
     */
    int updateSYS_AccountTableField0(HashMap<String, Object> map);
}

