package com.smc.service.query.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.excel.EasyExcel;
import com.google.common.collect.Lists;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.mybatis.model.KeyValueParam;
import com.smc.common.mybatis.page.MybatisPageHelper;
import com.smc.dataobject.query.SysTableFieldConfigCURDEntity;
import com.smc.easyExcel.UploadImportSysTableFieldConfigListener;
import com.smc.mapper.query.SysTableFieldConfigAmsMapper;
import com.smc.mapper.query.SysTableFieldConfigCURDMapper;
import com.smc.service.query.SysTableFieldConfigCURDService;
import com.smc.service.query.easyExcelImpl.EasyExcelImportSysTableFieldConfigServiceImpl;
import com.smc.utils.ParamsUtils;
import com.smc.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 主配置表CURD serviceImpl 主要给程序员用
 *
 * @Author: C02039 wjh
 * @Date: 2023/3/1  20:57
 */
@Service
public class SysTableFieldConfigCURDServiceImpl implements SysTableFieldConfigCURDService {
    @Autowired
    ParamsUtils paramsUtils;
    @Autowired
    SysTableFieldConfigCURDMapper sysTableFieldConfigCURDMapper;
    @Autowired
    EasyExcelImportSysTableFieldConfigServiceImpl easyExcelImportSysTableFieldConfigServiceImpl;


    @Resource
    private SysTableFieldConfigAmsMapper sysTableFieldConfigAmsMapper;

    // @Autowired
    // @Qualifier("pmsNSqlSessionTemplate")
    // private SqlSessionTemplate pmsSqlSessionTemplate;

    // @Autowired
    // @Qualifier("mf30SqlSessionTemplate")
    // private SqlSessionTemplate mfSqlSessionTemplate;

    /**
     * 保存操作
     *
     * @param record
     * @return
     */
    @Override
    public int save(Object record) {
        return 0;
    }

    /**
     * 删除操作
     *
     * @param record
     * @return
     */
    @Override
    public int delete(Object record) {
        return 0;
    }

    /**
     * 批量删除操作
     *
     * @param records
     */
    @Override
    public int delete(List records) {
        return 0;
    }

    /**
     * 根据ID查询
     *
     * @param id
     * @return
     */
    @Override
    public Object findById(Long id) {
        return null;
    }

    /**
     * 分页查询 主配置表数据
     * 这里统一封装了分页请求和结果，避免直接引入具体框架的分页对象, 如MyBatis或JPA的分页对象
     * 从而避免因为替换ORM框架而导致服务层、控制层的分页接口也需要变动的情况，替换ORM框架也不会
     * 影响服务层以上的分页接口，起到了解耦的作用
     *
     * @param pageRequest 自定义，统一分页查询请求
     * @return PageResult 自定义，统一分页查询结果
     */
    @Override
    public PageResult findPage(PageRequest pageRequest) {
        // 调用  生成 map 参数的方法
        HashMap<String, Object> map = paramsUtils.generateMapParams(pageRequest);
        return MybatisPageHelper.findPage(pageRequest, sysTableFieldConfigCURDMapper, "getSysTableFieldConfigFindPageData", map);
    }

    /**
     * easyExcel导出 主配置表数据 指定列导出
     *
     * @param pageRequest
     * @param response
     */
    @Override
    public void exportSysTableFieldConfigData(PageRequest pageRequest, HttpServletResponse response) throws IOException {
        String isFormWork = pageRequest.getParamValue("isFormWork");

        // 调用  生成 map 参数的方法
        HashMap<String, Object> map = paramsUtils.generateMapParams(pageRequest);
        // 用easyexcel方式导出
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
        String fileName = URLEncoder.encode("测试", "UTF-8");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
        // 指定导出的字段
        List<String> distinctUsedFieldList = (List<String>) map.get("distinctUsedFieldList");
        if ("模板".equals(isFormWork)) {
            EasyExcel.write(response.getOutputStream(), SysTableFieldConfigCURDEntity.class).includeColumnFiledNames(distinctUsedFieldList).sheet("字段管理模板").doWrite((Collection<?>) null);
        } else {
            EasyExcel.write(response.getOutputStream(), SysTableFieldConfigCURDEntity.class).includeColumnFiledNames(distinctUsedFieldList).sheet("字段管理主配置表信息").doWrite(sysTableFieldConfigCURDMapper.getSysTableFieldConfigFindPageData(map));
        }
    }

    /**
     * 主配置表 导入
     *
     * @param multipartFile
     * @param req
     * @return
     */
    @Override
    public String importSysTableFieldConfigData(MultipartFile multipartFile, HttpServletRequest req) {
        List<SysTableFieldConfigCURDEntity> sourceExcelDataList = new ArrayList<>();
        String userName = (String) req.getParameter("userName");
        // 获取导入的excel
        sourceExcelDataList = getImportExcelData(multipartFile);
        /**
         * 导入检验
         */
        if (sourceExcelDataList.size() == 0) {
            String msg = "error_导入失败，【表或视图名】不能为空，请检查是都符合规则或者导入excel符合模板要求";
            sourceExcelDataList.clear();
            return msg;
        }
        for (SysTableFieldConfigCURDEntity sourceExcel : sourceExcelDataList) {
            if (sourceExcel.getTableNameChn() == null || "".equals(sourceExcel.getTableNameChn())) {
                String msg = "error_表说明 不可以为空，导入失败";
                sourceExcelDataList.clear();
                return msg;
            }
            if (sourceExcel.getFieldName() == null || "".equals(sourceExcel.getFieldName())) {
                String msg = "error_字段名 不可以为空，导入失败";
                sourceExcelDataList.clear();
                return msg;
            }
            if (sourceExcel.getFieldNameChn() == null || "".equals(sourceExcel.getFieldNameChn())) {
                String msg = "error_字段说明 不可以为空，导入失败";
                sourceExcelDataList.clear();
                return msg;
            }
            if (sourceExcel.getType() == null || "".equals(sourceExcel.getType())) {
                String msg = "error_字段类型 不可以为空，导入失败";
                sourceExcelDataList.clear();
                return msg;
            }
            if (sourceExcel.getActivity() == null || "".equals(sourceExcel.getActivity())) {
                String msg = "error_启用标识 不可以为空，导入失败";
                sourceExcelDataList.clear();
                return msg;
            }

        }
        // 前后去除空格
        for (SysTableFieldConfigCURDEntity sourceExcel : sourceExcelDataList) {
            sourceExcel.setOperator(userName);
            sourceExcel.setTableName(sourceExcel.getTableName().trim());
            sourceExcel.setTableNameChn(sourceExcel.getTableNameChn().trim());
            sourceExcel.setFieldName(sourceExcel.getFieldName().trim());
            sourceExcel.setFieldNameChn(sourceExcel.getFieldNameChn().trim());

            sourceExcel.setType(sourceExcel.getType().trim());
            sourceExcel.setActivity(sourceExcel.getActivity().trim());

            // 前6项为必填项 肯定有值 不用做校验  现在字段可能为空 所以需要校验
            // 是否为默认值
            if (sourceExcel.getIsDefault() != null && !"".equals(sourceExcel.getIsDefault())) {
                sourceExcel.setIsDefault(sourceExcel.getIsDefault().trim());
            } else {
                sourceExcel.setIsDefault("0");
            }
            // 是否需要表尾合计
            if (sourceExcel.getIsTotal() != null && !"".equals(sourceExcel.getIsTotal())) {
                sourceExcel.setIsTotal(sourceExcel.getIsTotal().trim());
            } else {
                sourceExcel.setIsTotal("0");
            }
            // 是否可自行配置
            if (sourceExcel.getIsCustom() != null && !"".equals(sourceExcel.getIsCustom())) {
                sourceExcel.setIsCustom(sourceExcel.getIsCustom().trim());
            } else {
                sourceExcel.setIsCustom("0");
            }
            // 该字段是否为索引
            if (sourceExcel.getIsIdx() != null && !"".equals(sourceExcel.getIsIdx())) {
                sourceExcel.setIsIdx(sourceExcel.getIsIdx().trim());
            } else {
                // 不输入默认为0
                sourceExcel.setIsIdx("0");
            }
            // 位置
            if (sourceExcel.getAlign() != null && !"".equals(sourceExcel.getAlign())) {
                sourceExcel.setAlign(sourceExcel.getAlign().trim());
            } else {
                sourceExcel.setAlign("center");
            }
            // 宽度
            if (sourceExcel.getWidth() != null && !"".equals(sourceExcel.getWidth())) {
                sourceExcel.setWidth(sourceExcel.getWidth().trim());
            } else {
                sourceExcel.setWidth("120px");
            }
            // 排序
            if (sourceExcel.getSort() != null && !"".equals(sourceExcel.getSort())) {
                sourceExcel.setSort(sourceExcel.getSort().trim());
            }
        }
        // 保证每次只能导入一个表的信息
        Map<String, List<SysTableFieldConfigCURDEntity>> groupMapTableName = new HashMap<>();
        List<String> tableNames = sourceExcelDataList.stream().map(SysTableFieldConfigCURDEntity::getTableName).collect(Collectors.toList());
        List<String> distinctTableNames = tableNames.stream().distinct().collect(Collectors.toList());
        if (distinctTableNames.size() > 1) {
            String msg = "error_导入失败，每次只能导入一种【表或视图名】";
            sourceExcelDataList.clear();
            return msg;
        }
        List<String> tableNameChns = sourceExcelDataList.stream().map(SysTableFieldConfigCURDEntity::getTableNameChn).collect(Collectors.toList());
        List<String> distinctTableNameChns = tableNameChns.stream().distinct().collect(Collectors.toList());
        if (distinctTableNameChns.size() > 1) {
            String msg = "error_导入失败，每次只能导入一种【表说明】";
            sourceExcelDataList.clear();
            return msg;
        }
        // 在导入的数据中找到重复的【字段名】 提示报错
        Map<String, List<SysTableFieldConfigCURDEntity>> groupMapFieldName = new HashMap<>();
        groupMapFieldName = sourceExcelDataList.stream().collect(Collectors.groupingBy(SysTableFieldConfigCURDEntity::getFieldName));
        String fieldName = "";
        for (Map.Entry<String, List<SysTableFieldConfigCURDEntity>> map : groupMapFieldName.entrySet()) {
            if (map.getValue() != null) {
                if (map.getValue().size() > 1) {
                    // 处理业务
                    fieldName += map.getKey() + ";";
                }
            }
        }
        if (!"".equals(fieldName)) {
            String msg = "error_导入失败，excel中存在重复字段名【" + fieldName + "】";
            sourceExcelDataList.clear();
            return msg;
        }
        // 在导入的数据中找到重复的【字段说明 】提示报错
        Map<String, List<SysTableFieldConfigCURDEntity>> groupMapFieldNameChn = new HashMap<>();
        groupMapFieldNameChn = sourceExcelDataList.stream().collect(Collectors.groupingBy(SysTableFieldConfigCURDEntity::getFieldNameChn));
        String FieldNameChn = "";
        for (Map.Entry<String, List<SysTableFieldConfigCURDEntity>> map : groupMapFieldNameChn.entrySet()) {
            if (map.getValue() != null) {
                if (map.getValue().size() > 1) {
                    // 处理业务
                    FieldNameChn += map.getKey() + ";";
                }
            }
        }
        if (!"".equals(FieldNameChn)) {
            String msg = "error_导入失败，excel中存在重复字段说明【" + FieldNameChn + "】";
            sourceExcelDataList.clear();
            return msg;
        }

        List<SysTableFieldConfigCURDEntity> addList = new ArrayList<>();
        List<SysTableFieldConfigCURDEntity> updateList = new ArrayList<>();
        if (distinctTableNames.size() == 1) {

            // 根据表名查询该表下已存在的字段
            List<SysTableFieldConfigCURDEntity> nowList = sysTableFieldConfigCURDMapper.getSysTableFieldConfigDataByTableName(tableNames.get(0));
            updateList = ListABEqual(sourceExcelDataList, nowList);
            addList = ListB_A(nowList, sourceExcelDataList);
            sourceExcelDataList.clear();
            // 批量插入
            List<List<SysTableFieldConfigCURDEntity>> addLists = Lists.partition(addList, 40);
            for (List<SysTableFieldConfigCURDEntity> excelAddDataList : addLists) {
                sysTableFieldConfigCURDMapper.insertSysTableFieldConfigBatch(excelAddDataList);
            }
            // 批量更新
            List<List<SysTableFieldConfigCURDEntity>> updateLists = Lists.partition(updateList, 40);
            for (List<SysTableFieldConfigCURDEntity> excelUpdateDataList : updateLists) {
                sysTableFieldConfigCURDMapper.updateSysTableFieldConfigBatch(excelUpdateDataList);
            }
        }
        return "success_导入成功";
    }

    @Override
    public int insertSysTableFieldConfigAuto(Map<String, Object> map) {
        String database = (String) map.get("database");
        String tableName = (String) map.get("tableName");

        List<String> tableNames = sysTableFieldConfigCURDMapper.getAllTableName();
        if (tableNames.contains(tableName)) {
            // sysTableFieldConfigCURDMapper.deleteSysTableFieldConfigByTableName(tableName);
            return -2;
        }
        List<SysTableFieldConfigCURDEntity> list = sysTableFieldConfigAmsMapper.getSysTableFieldConfig(map);
        // if("pms".equalsIgnoreCase(database)) {
        //     SqlSession sqlSession = pmsSqlSessionTemplate.getSqlSessionFactory().openSession();
        //     SysTableFieldConfigPMSMapper mapper = sqlSession.getMapper(SysTableFieldConfigPMSMapper.class);
        //     list = mapper.getSysTableFieldConfig(map);
        // }else if("mf".equalsIgnoreCase(database)) {
        //     SqlSession sqlSession = mfSqlSessionTemplate.getSqlSessionFactory().openSession();
        //     SysTableFieldConfigMfMapper mapper = sqlSession.getMapper(SysTableFieldConfigMfMapper.class);
        //     list = mapper.getSysTableFieldConfig(map);
        // }else if("dec".equalsIgnoreCase(database)) {
        //     SqlSession sqlSession = mfSqlSessionTemplate.getSqlSessionFactory().openSession();
        //     SysTableFieldConfigDecMapper mapper = sqlSession.getMapper(SysTableFieldConfigDecMapper.class);
        //     list = mapper.getSysTableFieldConfig(map);
        // }else{
        //     return -3;
        // }
        if (list.isEmpty()) {
            return -1;
        }
        list.forEach(item -> item.setFieldName(StringUtils.toCamelCase(item.getFieldName())));
        return sysTableFieldConfigCURDMapper.insertSysTableFieldConfigBatch(list);


    }

    /**
     * 单条修改 主配置信息
     *
     * @param map
     * @return
     */
    @Override
    public int alterSysTableFieldConfigData(Map<String, Object> map) {
        String tableName = (String) map.get("tableName");
        String tableNameChn = (String) map.get("tableNameChn");
        String fieldName = (String) map.get("fieldName");
        String fieldNameChn = (String) map.get("fieldNameChn");
        String type = (String) map.get("type");
        String activity = (String) map.get("activity");


        String isTotal = (String) map.get("isTotal");
        String isDefault = (String) map.get("isDefault");
        String isCustom = (String) map.get("isCustom");
        String isIdx = (String) map.get("isIdx");
        String sort = (String) map.get("sort");
        String align = (String) map.get("align");
        String width = (String) map.get("width");
        Integer id = (Integer) map.get("id");
        String isEdit = (String) map.get("isEdit");
        String userName = (String) map.get("userName");


        List<SysTableFieldConfigCURDEntity> editList = new ArrayList<>();
        SysTableFieldConfigCURDEntity sysTableFieldConfigCURDEntity = new SysTableFieldConfigCURDEntity();
        sysTableFieldConfigCURDEntity.setTableName(tableName);
        sysTableFieldConfigCURDEntity.setTableNameChn(tableNameChn);
        sysTableFieldConfigCURDEntity.setFieldName(fieldName);
        sysTableFieldConfigCURDEntity.setFieldNameChn(fieldNameChn);
        sysTableFieldConfigCURDEntity.setType(type);
        sysTableFieldConfigCURDEntity.setActivity(activity);


        sysTableFieldConfigCURDEntity.setIsDefault(isDefault);
        sysTableFieldConfigCURDEntity.setIsTotal(isTotal);
        sysTableFieldConfigCURDEntity.setIsCustom(isCustom);
        sysTableFieldConfigCURDEntity.setIsIdx(isIdx);
        sysTableFieldConfigCURDEntity.setAlign(align);
        sysTableFieldConfigCURDEntity.setSort(sort);
        sysTableFieldConfigCURDEntity.setWidth(width);
        sysTableFieldConfigCURDEntity.setId(id);
        sysTableFieldConfigCURDEntity.setIsEdit(isEdit);

        sysTableFieldConfigCURDEntity.setOperator(userName);

        editList.add(sysTableFieldConfigCURDEntity);

        int num = sysTableFieldConfigCURDMapper.updateSysTableFieldConfigBatch(editList);
        editList.clear();
        return num;

    }

    /**
     * 单条删除
     *
     * @param map
     * @return
     */
    @Override
    public int deleteSysTableFieldConfigData(Map<String, Object> map) {
        String tableName = (String) map.get("tableName");
        String fieldName = (String) map.get("fieldName");
        Integer id = (Integer) map.get("id");
        return sysTableFieldConfigCURDMapper.deleteSysTableFieldConfigData(tableName, fieldName);
    }

    /**
     * 获取字段名下拉菜单
     *
     * @return
     */
    @Override
    public List<String> getTableNames() {
        return sysTableFieldConfigCURDMapper.getTableNames();
    }

    @Override
    public List<KeyValueParam<String, String>> listTables() {
        List<KeyValueParam<String, String>> keyValueParams = new ArrayList<>();
        List<SysTableFieldConfigCURDEntity> list = sysTableFieldConfigCURDMapper.listTables();
        if (CollectionUtil.isEmpty(list)) {
            return null;
        }
        list.forEach(item -> {
            KeyValueParam<String, String> param = new KeyValueParam<String, String>();
            param.setKey(item.getTableName());
            param.setValue(item.getTableNameChn());
            keyValueParams.add(param);
        });
        return keyValueParams;
    }

    @Override
    public int saveSysTableFieldConfigData(Map<String, Object> map) {
        String tableName = (String) map.get("tableName");
        String tableNameChn = (String) map.get("tableNameChn");
        String fieldName = (String) map.get("fieldName");
        String fieldNameChn = (String) map.get("fieldNameChn");
        String type = (String) map.get("type");
        String activity = (String) map.get("activity");


        String isTotal = (String) map.get("isTotal");
        String isDefault = (String) map.get("isDefault");
        String isCustom = (String) map.get("isCustom");
        String isIdx = (String) map.get("isIdx");
        String sort = (String) map.get("sort");
        String align = (String) map.get("align");
        String width = (String) map.get("width");
        Integer id = (Integer) map.get("id");
        String isEdit = (String) map.get("isEdit");
        String userName = (String) map.get("userName");

        SysTableFieldConfigCURDEntity sysTableFieldConfigCURDEntity = new SysTableFieldConfigCURDEntity();
        sysTableFieldConfigCURDEntity.setTableName(tableName);
        sysTableFieldConfigCURDEntity.setTableNameChn(tableNameChn);
        sysTableFieldConfigCURDEntity.setFieldName(fieldName);
        sysTableFieldConfigCURDEntity.setFieldNameChn(fieldNameChn);
        sysTableFieldConfigCURDEntity.setType(type);
        sysTableFieldConfigCURDEntity.setDetailType("1".equals(type) ? "" : "2".equals(type) ? "int" : "3".equals(type) ? "decimal" : "datetime");
        sysTableFieldConfigCURDEntity.setActivity(activity);

        sysTableFieldConfigCURDEntity.setIsDefault(isDefault);
        sysTableFieldConfigCURDEntity.setIsTotal(isTotal);
        sysTableFieldConfigCURDEntity.setIsCustom(isCustom);
        sysTableFieldConfigCURDEntity.setIsIdx(isIdx);
        sysTableFieldConfigCURDEntity.setAlign(align);
        sysTableFieldConfigCURDEntity.setSort(sort);
        sysTableFieldConfigCURDEntity.setWidth(width);
        sysTableFieldConfigCURDEntity.setId(id);
        sysTableFieldConfigCURDEntity.setIsEdit(isEdit);
        sysTableFieldConfigCURDEntity.setOperator(userName);
        sysTableFieldConfigCURDEntity.setOperationTime(new Date());

        List<SysTableFieldConfigCURDEntity> dataByTableName = sysTableFieldConfigCURDMapper.getSysTableFieldConfigDataByTableName(tableName);
        if (CollectionUtil.isNotEmpty(dataByTableName)) {
            for (SysTableFieldConfigCURDEntity tableFieldConfigCURDEntity : dataByTableName) {
                if (tableFieldConfigCURDEntity.getFieldName().equals(sysTableFieldConfigCURDEntity.getFieldName())) {
                    return 0;
                }
            }
        }
        return sysTableFieldConfigCURDMapper.saveSysTableFieldConfigData(sysTableFieldConfigCURDEntity);
    }

    /**
     * 用easyExcel方式大批量获取 excel导入的源数据
     *
     * @param multipartFile
     * @return
     */

    public List<SysTableFieldConfigCURDEntity> getImportExcelData(MultipartFile multipartFile) {
        try {
            if (multipartFile != null) {
                // 导入excel
                EasyExcel.read(multipartFile.getInputStream(), SysTableFieldConfigCURDEntity.class, new UploadImportSysTableFieldConfigListener()).sheet().doRead();
                // 获取excel导入的所有基础数据
                List<SysTableFieldConfigCURDEntity> excelSourceList = EasyExcelImportSysTableFieldConfigServiceImpl.getAllImportExcelData();
                return excelSourceList;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * listA - listB (按照TableName 表说明)返回listA
     *
     * @param listA
     * @param listB
     * @return
     */
    public List<SysTableFieldConfigCURDEntity> ListA_B(List<SysTableFieldConfigCURDEntity> listA, List<SysTableFieldConfigCURDEntity> listB) {
        List<String> listBIdsOR = listB.stream().map(SysTableFieldConfigCURDEntity::getFieldName).collect(Collectors.toList());
        List<String> listBIds = new ArrayList<>();
        for (String s : listBIdsOR) {
            listBIds.add(s.toUpperCase());
        }
//        List<String> listBIds = listB.stream().map(SysTableFieldConfigCURDEntity::getFieldName).collect(Collectors.toList());
        return listA.stream().filter(SysTableFieldConfigCURDEntity -> !listBIds.contains(SysTableFieldConfigCURDEntity.getFieldName().toUpperCase())).collect(Collectors.toList());
    }

    /**
     * listA == listB (按照SerialID 项号)返回listA
     *
     * @param listA
     * @param listB
     * @return
     */
    public List<SysTableFieldConfigCURDEntity> ListABEqual(List<SysTableFieldConfigCURDEntity> listA, List<SysTableFieldConfigCURDEntity> listB) {
        List<String> listBIdsOR = listB.stream().map(SysTableFieldConfigCURDEntity::getFieldName).collect(Collectors.toList());
        List<String> listBIds = new ArrayList<>();
        for (String s : listBIdsOR) {
            listBIds.add(s.toUpperCase());
        }
        return listA.stream().filter(SysTableFieldConfigCURDEntity -> listBIds.contains(SysTableFieldConfigCURDEntity.getFieldName().toUpperCase())).collect(Collectors.toList());
    }

    /**
     * listB - listA (按照SerialID 项号) 返回listB
     *
     * @param listA
     * @param listB
     * @return
     */
    public List<SysTableFieldConfigCURDEntity> ListB_A(List<SysTableFieldConfigCURDEntity> listA, List<SysTableFieldConfigCURDEntity> listB) {
        List<String> listAIdsOR = listA.stream().map(SysTableFieldConfigCURDEntity::getFieldName).collect(Collectors.toList());
        List<String> listAIds = new ArrayList<>();
        for (String s : listAIdsOR) {
            listAIds.add(s.toUpperCase());
        }
        return listB.stream().filter(DomesticBuyOrderArrivalReceiptEntity -> !listAIds.contains(DomesticBuyOrderArrivalReceiptEntity.getFieldName().toUpperCase())).collect(Collectors.toList());
    }
}
