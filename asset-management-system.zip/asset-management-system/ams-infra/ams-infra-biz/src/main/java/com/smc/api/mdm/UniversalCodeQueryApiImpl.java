package com.smc.api.mdm;

import com.smc.api.mdm.dto.PublicUniversalCodeDTO;
import com.smc.dataobject.mdm.PublicUniversalCode;
import com.smc.service.mdm.PublicUniversalCodeService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @program: asset-management-system
 * @ClassName UniversalCodeQueryApiImpl
 * @description:
 * @author: C31909
 * @create: 2024-07-11 11:25
 * @Version 1.0
 **/
@Service
public class UniversalCodeQueryApiImpl implements UniversalCodeQueryApi {

    @Resource
    private PublicUniversalCodeService publicUniversalCodeService;

    @Override
    public List<PublicUniversalCodeDTO> getUniversalCodeByIdList(List<Integer> codeList) {
        List<PublicUniversalCode> list = publicUniversalCodeService.getUniversalCodeByIdList(codeList);
        List<PublicUniversalCodeDTO> universalCodeDTOS = new ArrayList<>();
        if (!list.isEmpty()) {
            list.forEach(item -> universalCodeDTOS.add(toPublicUniversalCodeDTO(item)));
            return universalCodeDTOS;
        }
        return Collections.emptyList();
    }

    @Override
    public List<Integer> getUniversalCodeByDictValue(String classifyDesc, String dictValue) {
        return publicUniversalCodeService.getUniversalCodeByDictValue(classifyDesc, dictValue);
    }

    @Override
    public List<PublicUniversalCodeDTO> listUniversalCodeByDictValue(String codeCategory, List<String> codeValueList) {
        List<PublicUniversalCode> list = publicUniversalCodeService.listUniversalCodeByDictValue(codeCategory, codeValueList);
        List<PublicUniversalCodeDTO> universalCodeDTOS = new ArrayList<>();
        if (!list.isEmpty()) {
            list.forEach(item -> universalCodeDTOS.add(toPublicUniversalCodeDTO(item)));
            return universalCodeDTOS;
        }
        return Collections.emptyList();
    }

    @Override
    public void saveUniversalCode(String codeCategory, List<String> codeValueList) {
        publicUniversalCodeService.saveBatchUniversalCode(codeCategory, codeValueList);
    }

    private PublicUniversalCodeDTO toPublicUniversalCodeDTO(PublicUniversalCode item) {
        return PublicUniversalCodeDTO.builder()
                .id(item.getId())
                .classifyDesc(item.getClassifyDesc())
                .dictValue(item.getDictValue())
                .build();
    }
}
