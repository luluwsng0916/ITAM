package com.smc.dataobject.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * (SysAccountTableFieldConfiguration)实体类
 *
 * @author wjh 自动生成
 * @since 2022-07-21 17:43:55
 */
@Data
public class SysAccountTableFieldConfiguration implements Serializable {
    private static final long serialVersionUID = 835635541220178320L;
    /**
     * 员工配置表的id 用于更改员工自定义配置字段显示顺序
     */
    private Integer id;
    /**
     * 用户名
     */
    private String userId;
    /**
     * 表明
     */
    private String tableName;
    /**
     * 表名说明
     */
    private String tableNameChn;
    /**
     * 字段名
     */
    private String fieldName;
    /**
     * 字段名说明
     */
    private String fieldNameChn;
    /**
     * 启用标识
     */
    private String activity;
    /**
     * 时间戳
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GTM+8")
    private Date operationTime;
    /**
     * 操作者
     */
    private String operator;
    /**
     * 是否可以用户自己配置 1:可以自己配置 0：用户不可以自己配置
     */
    private String isCustom;
    /**
     * 该字段是是否需要计算 1：需要表尾合计计算 0：不需要表尾合计计算 （除了1以外全都不用表尾合计）
     */
    private String isTotal;


    /**
     * 用于前端页面配置 --label
     */
    private String label;
    /**
     * 用于前端页面配置 --字段绑定
     */
    private String prop;
    /**
     * 用于前端页面配置 --排序用(前台页面点小三角排序用的字段_实际就是字段名)
     */
    private String sortable;
    /**
     * 设置用户自定义展示顺序的顺序 序号
     */
    private Integer sort;
    /**
     * 用于前端页面配置 --字段位置
     */
    private String align;
    /**
     * 用于前端页面配置 --字段宽度   eg:90px
     */
    private String width;
    /**
     * 主配置表 启用标识
     */
    private String mainActivity;

    /**
     * 用于前端页面多条件查询 列值的输入框类型判断 --字段类型
     */
    private String type;

    /**
     * 是否可编辑
     */
    private String isEdit;
/**
 */
}

