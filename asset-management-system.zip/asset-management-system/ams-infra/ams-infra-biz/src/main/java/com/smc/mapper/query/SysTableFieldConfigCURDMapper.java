package com.smc.mapper.query;

import com.smc.dataobject.query.SysTableFieldConfigCURDEntity;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 主配置表CURD Mapper  主要给程序员用
 *
 * @Author: C02039 wjh
 * @Date: 2023/3/1  21:01
 */
// @Mapper
public interface SysTableFieldConfigCURDMapper {
    /**
     * 查询主配置表数据
     *
     * @param map
     * @return
     */
    List<SysTableFieldConfigCURDEntity> getSysTableFieldConfigFindPageData(HashMap<String, Object> map);

    /**
     * 根据表名查询该表下已存在的字段
     *
     * @param tableName
     * @return
     */
    List<SysTableFieldConfigCURDEntity> getSysTableFieldConfigDataByTableName(String tableName);

    /**
     * 批量插入
     *
     * @param excelAddDataList
     * @return
     */
    int insertSysTableFieldConfigBatch(List<SysTableFieldConfigCURDEntity> excelAddDataList);

    List<SysTableFieldConfigCURDEntity> getSysTableFieldConfig(Map<String, Object> map);

    /**
     * 批量更新住配置表
     *
     * @param excelUpdateDataList
     * @return
     */
    int updateSysTableFieldConfigBatch(List<SysTableFieldConfigCURDEntity> excelUpdateDataList);

    /**
     * 单条删除主配置表以及 人员配置表中相关信息
     *
     * @param tableName
     * @param fieldName
     * @return
     */
    int deleteSysTableFieldConfigData(String tableName, String fieldName);

    /**
     * 获取字段名下拉菜单
     *
     * @return
     */
    List<String> getTableNames();

    List<String> getAllTableName();

    void deleteSysTableFieldConfigByTableName(String tableName);

    List<SysTableFieldConfigCURDEntity> listTables();

    int saveSysTableFieldConfigData(@Param("item") SysTableFieldConfigCURDEntity sysTableFieldConfigCURDEntity);
}
