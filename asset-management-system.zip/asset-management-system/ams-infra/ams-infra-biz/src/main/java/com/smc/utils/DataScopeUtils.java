package com.smc.utils;

import java.util.HashMap;

import org.springframework.stereotype.Service;

import com.smc.common.model.page.PageRequesScope;

/**
 * 数据权限控制工具类
 * @ClassName: DataScopeUtils
 * @Description: TODO
 * @author C24466
 * @date 2023-03-10 03:08:42
 */
@Service
public class DataScopeUtils {
	
	// 添加关于相应数据权限控制的参数
	public HashMap<String, Object> addDataScopeParams(PageRequesScope pageRequest,HashMap<String, Object> map) {

		map.put("scopeCollections", pageRequest.getScopeCollections());
		return map;

	}

}
