package com.smc.mapper.query;

import com.smc.dataobject.query.SysTableFieldConfigCURDEntity;

import java.util.List;
import java.util.Map;

/**
 * 主配置表CURD Mapper  主要给程序员用
 *
 * @Author: C02039 wjh
 * @Date: 2023/3/1  21:01
 */
// @Mapper
public interface SysTableFieldConfigAmsMapper {

    List<SysTableFieldConfigCURDEntity> getSysTableFieldConfig(Map<String, Object> map);
}
