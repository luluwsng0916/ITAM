package com.smc.mapper.query;

import com.smc.dataobject.query.SysAccountButtonConfiguration;
import com.smc.dataobject.query.SysAccountRowColorRulesConfiguration;
import com.smc.dataobject.query.SysAccountTableFieldConfiguration;
import feign.Param;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * (SysAccountTableFieldConfiguration)表数据库访问层
 * 员工账号级别
 *
 * @author 温建华 C02039
 * @since 2022-07-21 17:43:55
 */
// @Mapper
public interface SysAccountTableFieldConfigurationDao {
    /**
     * 分页查询
     */
    List<SysAccountTableFieldConfiguration> getUsableFieldByUserIdAndTableName(HashMap map);

    /**
     * 原来该用户已经配置的字段  原来启用、非启用
     *
     * @param map
     * @return
     */
    List<SysAccountTableFieldConfiguration> getFieldByUserIdAndTableName(HashMap<String, Object> map);

    /**
     * 用户自定义配置字段提交（设置显示字段显示顺序）
     *
     * @param list
     * @return
     */
    int submitFieldSort(@Param("list") List<SysAccountTableFieldConfiguration> list);

    /**
     * 检查员工配置表中是否有已经启用的配置信息
     *
     * @param map
     * @return
     */
    int getUsableFieldActivity1ByUserIdAndTableName(HashMap<String, Object> map);

    /**
     * 员工配置表中没有启用的 查询主表的默认启用的字段
     *
     * @param map
     * @return
     */
    List<SysAccountTableFieldConfiguration> getDefaultFieldByUserIdAndTableName(HashMap<String, Object> map);

    /**
     * 主配置数据——根据表名、用户名 获取用户在该查询的按钮权限
     * 用于页面中 某个查询按钮权限的控制
     *
     * @param
     * @param map
     * @return
     */
    List<SysAccountButtonConfiguration> getButtonPermissionUserIdAndTableName(HashMap<String, Object> map);

    /**
     *查询用户自定义配置（数据行颜色）
     * @param map
     * @return
     */
    List<SysAccountRowColorRulesConfiguration>  getRowColorsByUserIdAndTableName(HashMap<String, Object> map);
    /**
     *查询系统默认配置（数据行颜色）
     * @param map
     * @return
     */
    List<SysAccountRowColorRulesConfiguration>  getRowColorsByTableName(HashMap<String, Object> map);

    /**
     * 分页查询
     */
    List<SysAccountTableFieldConfiguration> getSysAccounttablefieldconfigurationFindPageData(HashMap map);

    /**
     * 新增数据
     *
     * @param map 中存放 实例对象
     * @return 影响行数
     */
    int addSysAccounttablefieldconfigurationInfo(Map<String, Object> map);

    /**
     * 修改数据
     *
     * @param map 中存放 实例对象
     * @return 影响行数
     */
    int alterSysAccounttablefieldconfigurationById(Map<String, Object> map);

    /**
     * 获取员工配置表中 的表说明信息 用于下拉菜单
     *
     * @return
     */
    List<String> getTableNames();
}

