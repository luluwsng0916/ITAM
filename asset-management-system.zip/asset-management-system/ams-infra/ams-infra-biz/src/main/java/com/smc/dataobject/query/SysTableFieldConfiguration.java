package com.smc.dataobject.query;


import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * (SysTableFieldConfiguration)实体类
 * 　字段可配置主表
 *
 * @author wjh 自动生成
 * @since 2022-07-21 17:38:37
 */
@Data
public class SysTableFieldConfiguration implements Serializable {
    private static final long serialVersionUID = 187212588695372479L;

    private Integer id;

    private String tableName;
    /**
     * 表名说明
     */
    private String tableNameChn;
    /**
     * 字段名
     */
    private String fieldName;
    /**
     * 字段名说明
     */
    private String fieldNameChn;
    /**
     * 字段类型
     */
    private String type;
    /**
     * 启用标识
     */
    private String activity;
    /**
     * 时间戳
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GTM+8")
    private Date operationTime;;
    /**
     * 操作者
     */
    private String operator;

    /**
     * 是否可以用户自己配置 1:可以自己配置 0：用户不可以自己配置
     */
    private String isCustom;

    /**
     * 前端标签居中居左居右设置
     */
    private String align;

    /**
     * 前端表格宽度
     */
    private String width;

    /**
     * 是否可编辑
     */
    private String isEdit;
}

