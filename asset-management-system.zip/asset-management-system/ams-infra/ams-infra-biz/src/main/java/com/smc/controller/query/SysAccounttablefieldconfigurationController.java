package com.smc.controller.query;

import com.smc.common.model.http.HttpResult;
import com.smc.common.model.page.PageRequest;
import com.smc.service.query.SysAccounttablefieldconfigurationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * (SysAccounttablefieldconfiguration)表控制层
 *
 * @author 温建华 C02039
 * @since 2023-03-03 12:50:47
 */
@RestController
@RequestMapping("/sysAccounttablefieldconfiguration")
@CrossOrigin
public class SysAccounttablefieldconfigurationController {
    @Autowired
    private SysAccounttablefieldconfigurationService sysAccounttablefieldconfigurationService;

    /**
     * 分页查询
     *
     * @param pageRequest
     * @return
     */
    @RequestMapping(value = "/getSysAccounttablefieldconfigurationFindPageData")
    public HttpResult getSysAccounttablefieldconfigurationFindPageData(@RequestBody PageRequest pageRequest) {
        return HttpResult.ok(this.sysAccounttablefieldconfigurationService.findPage(pageRequest));
    }

    /**
     * easyExcel 指定列导出
     *
     * @param pageRequest
     * @return
     */
    @RequestMapping(value = "/exportSysAccounttablefieldconfiguration")
    public void exportSysAccounttablefieldconfiguration(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        sysAccounttablefieldconfigurationService.exportSysAccounttablefieldconfiguration(pageRequest, response);
    }

    /**
     * 新增数据
     *
     * @param map 中存放 实例对象
     * @return 新增结果
     */
    @RequestMapping(value = "/addSysAccounttablefieldconfigurationInfo")
    public HttpResult addSysAccounttablefieldconfigurationInfo(@RequestBody Map<String, Object> map) {
        return HttpResult.ok(this.sysAccounttablefieldconfigurationService.addSysAccounttablefieldconfigurationInfo(map));
    }

    /**
     * 编辑数据
     *
     * @param map 中存放 实例对象
     * @return 编辑结果
     */
    @RequestMapping(value = "/alterSysAccounttablefieldconfigurationById")
    public HttpResult alterSysAccounttablefieldconfigurationById(@RequestBody Map<String, Object> map) {
        return HttpResult.ok(this.sysAccounttablefieldconfigurationService.alterSysAccounttablefieldconfigurationById(map));
    }


    /**
     * 获取员工配置表中 的表说明信息 用于下拉菜单
     *
     * @param
     * @return 编辑结果
     */
    @RequestMapping(value = "/getTableNames")
    public HttpResult getTableNames() {
        return HttpResult.ok(this.sysAccounttablefieldconfigurationService.getTableNames());
    }


}

