package com.smc.dataobject.mdm;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 字典表
 *
 * @author C31909
 * @since 1.0.0 2024-07-09
 */
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("public_universal_code")
public class PublicUniversalCode extends AbstractEntity {
    @TableId(type = IdType.AUTO)
    @TableField(value = "id")
    private Integer id;

    @TableField(value = "classifyDesc")
    private String classifyDesc;
    
    @TableField(value = "dictValue")
    private String dictValue;

    @TableField(value = "activity")
    private Integer activity;

    @TableField(value = "remark")
    private String remark;

}