package com.smc.api.query;

import com.smc.common.model.page.PageRequest;
import com.smc.utils.ParamsUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;

/**
 * @author C31909
 */
@Service
public class QueryServiceClientImpl implements QueryServiceClient {
    @Autowired
    private ParamsUtils paramsUtils;
    /**
     * 根据字段生成查询参数
     *

     * @author C31455 Zhanqi
     * @date 2023-10-20 11:55:36
     */
    @Override
    public HashMap<String, Object> generateMapParams(PageRequest pageRequest) {
        return paramsUtils.generateMapParams(pageRequest);
    }

}
