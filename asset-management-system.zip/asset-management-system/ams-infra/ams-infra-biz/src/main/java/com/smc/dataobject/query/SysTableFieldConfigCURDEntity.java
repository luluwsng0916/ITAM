package com.smc.dataobject.query;


import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author: C02039 wjh
 * @Date: 2023/3/1  20:58
 */
@Data
@ColumnWidth(17)
public class SysTableFieldConfigCURDEntity implements Serializable {
    @ExcelProperty("ID")
    private Integer id;
    @ExcelProperty("表或视图名")
    private String tableName;
    /**
     * 表名说明
     */
    @ExcelProperty("表说明")
    private String tableNameChn;
    /**
     * 字段名
     */
    @ExcelProperty("字段名")
    private String fieldName;
    /**
     * 字段名说明
     */
    @ExcelProperty("字段说明/lable")
    private String fieldNameChn;
    /**
     * 字段类型
     */
    @ExcelProperty("字段类型")
    private String type;

    /**
     * 字段类型
     */
    @ExcelProperty("字段具体类型")
    private String detailType;
    /**
     * 启用标识
     */
    @ExcelProperty("启用标识")
    private String activity;


    /**
     * 是否可以用户自己配置 1:是默认值 0：不是默认值 （除1以外全都不是默认值）
     */
    @ExcelProperty("是否为默认值")
    private String isDefault;
    /**
     * 是否可以用户自己配置 1:需要表尾合计 0：不需要表尾合计 （除1以外全都不需要表尾合计）
     */
    @ExcelProperty("是否表尾合计")
    private String isTotal;
    /**
     * 是否可以用户自己配置 1:可以自己配置 0：用户不可以自己配置
     */
    @ExcelProperty("用户可否自配置")
    private String isCustom;
    /**
     * 该字段是否有索引 1：有索引 0：没有索引 （除1以为全部视为没有索引）
     */
    @ExcelProperty("有无索引")
    private String isIdx;

    /**
     * 前端标签居中居左居右设置
     */
    @ExcelProperty("字段居中/左/右")
    private String align;

    /**
     * 前端表格宽度
     */
    @ExcelProperty("前端表格宽度")
    private String width;

    /**
     * 前台展示排序（有限按照用户表sort排序若用户表sort为null 则按照本字段排序 如果本字段也为空 则则按照 本表id 升序）
     */
    @ExcelProperty("前台展示排序")
    private String sort;

    /**
     * 时间戳
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GTM+8")
    @ExcelProperty("操作时间")
    private Date operationTime;
    /**
     * 操作者
     */
    @ExcelProperty("操作者")
    private String operator;

    /**
     * 是否可编辑
     */
    private String isEdit;
}
