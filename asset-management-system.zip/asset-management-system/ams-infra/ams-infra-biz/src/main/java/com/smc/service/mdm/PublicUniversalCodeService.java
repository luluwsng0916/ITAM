package com.smc.service.mdm;

import com.github.pagehelper.PageInfo;
import com.smc.api.mdm.dto.PublicUniversalCodeDTO;
import com.smc.common.model.result.ResultBody;
import com.smc.common.model.page.PageRequest;
import com.smc.controller.mdm.model.bo.PublicUniversalCodeDeleteBO;
import com.smc.dataobject.mdm.PublicUniversalCode;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 字典表
 *
 * @author aaa 
 * @since 1.0.0 2024-07-09
 */
public interface PublicUniversalCodeService {

    ResultBody<PageInfo<PublicUniversalCode>> page(PageRequest pageRequest);

    ResultBody<String> editById(PublicUniversalCode model);

    ResultBody<String> add(PublicUniversalCode model);

    ResultBody<String> importData(MultipartFile multipartFile, HttpServletRequest req);

    void exportData(PageRequest pageRequest, HttpServletResponse response);

    ResultBody<String> delete(PublicUniversalCodeDeleteBO idList);

    ResultBody<List<PublicUniversalCode>> listAllType();

    List<PublicUniversalCode> getUniversalCodeByIdList(List<Integer> codeList);

    ResultBody<List<PublicUniversalCode>> listByClassify(String classifyDesc);

    List<Integer> getUniversalCodeByDictValue(String classify, String dictValue);

    List<PublicUniversalCode> listUniversalCodeByDictValue(String codeCategory, List<String> codeValueList);

    void saveBatchUniversalCode(String codeCategory, List<String> codeValueList);
}