package com.smc.service.query.easyExcelImpl;

import com.smc.dataobject.query.SysTableFieldConfigCURDEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: C02039 wjh
 * @Date: 2023/3/2  8:46
 */
@Service
public class EasyExcelImportSysTableFieldConfigServiceImpl {

    static List<SysTableFieldConfigCURDEntity> list = new ArrayList<SysTableFieldConfigCURDEntity>();

    /**
     * 分批导入的数据拼接到一起
     *
     * @param
     * @return
     */
    public static List<SysTableFieldConfigCURDEntity> getAllImportExcelData() {
        return list;
    }

    public void save(List<SysTableFieldConfigCURDEntity> cachedDataList) {
        list.addAll(cachedDataList);
    }

    /**
     * 创建一个构造方法 用于list.clean()
     *
     * @return
     */
    public List<SysTableFieldConfigCURDEntity> getList() {
        return list;
    }

}
