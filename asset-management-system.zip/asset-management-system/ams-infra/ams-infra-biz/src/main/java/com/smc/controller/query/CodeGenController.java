package com.smc.controller.query;

import com.dtflys.forest.annotation.Get;
import com.smc.common.model.result.ResultBody;
import com.smc.common.mybatis.model.KeyValueParam;
import com.smc.service.query.CodeGenService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @program: asset-management-system
 * @ClassName CodeGenController
 * @description:
 * @author: C31909
 * @create: 2024-08-07 13:58
 * @Version 1.0
 **/
@RestController
@RequestMapping(value = "/code")
@CrossOrigin
public class CodeGenController {

    @Resource
    private CodeGenService codeGenService;


    @GetMapping(value = "/listTables")
    public ResultBody<List<KeyValueParam<String, String>>> listTables() {
        return codeGenService.listTables();
    }
}
