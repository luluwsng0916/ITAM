package com.smc.controller.query;

import com.smc.common.model.http.HttpResult;
import com.smc.common.model.page.PageRequest;
import com.smc.service.query.SysAccountbuttonconfigurationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * 通用查询按钮按钮配置(SysAccountButtonConfiguration)表控制层
 *
 * @author 温建华 C02039
 * @since 2023-05-23 13:50:05
 */
@RestController
@RequestMapping("/SysAccountButtonConfiguration")
@CrossOrigin
public class SysAccountButtonConfigurationController {
    @Autowired
    private SysAccountbuttonconfigurationService sysAccountbuttonconfigurationService;

    /**
     * 按钮管理——获取所有可管理的按钮
     * 获取所有可管理的查询——并根据用户回显信息
     *
     * @param map
     * @return
     */

    /**
     * 分页查询
     *
     * @param pageRequest
     * @return
     */
    @RequestMapping(value = "/getSysAccountbuttonconfigurationFindPageData")
    public HttpResult getSysAccountButtonConfigurationData(@RequestBody PageRequest pageRequest) {
        return HttpResult.ok(this.sysAccountbuttonconfigurationService.getSysAccountButtonConfigurationData(pageRequest));
    }

    /**
     * 授权
     * @param map
     * @return
     */
    @RequestMapping(value = "/bindButtonAuth")
    public  HttpResult  bindButtonAuth(@RequestBody Map<String, Object> map ) throws Exception {
        return HttpResult.ok(sysAccountbuttonconfigurationService.bindButtonAuth(map));
    }

    /**
     * easyExcel 指定列导出
     *
     * @param pageRequest
     * @return
     */
    @RequestMapping(value = "/exportSysAccountbuttonconfiguration")
    public void exportSysAccountbuttonconfiguration(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        sysAccountbuttonconfigurationService.exportSysAccountbuttonconfiguration(pageRequest, response);
    }

}

