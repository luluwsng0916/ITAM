package com.smc.service.query;


import com.smc.common.model.page.PageRequest;
import com.smc.common.mybatis.service.CurdService;
import com.smc.dataobject.query.SysAccountButtonConfiguration;
import com.smc.dataobject.query.SysAccountRowColorRulesConfiguration;
import com.smc.dataobject.query.SysAccountTableFieldConfiguration;
import com.smc.dataobject.query.SysTableFieldConfiguration;

import java.util.List;
import java.util.Map;

/**
 * @Author: C02039 wjh
 * @Date: 2022/7/21  16:28
 */
public interface FieldDynamicConfigService extends CurdService {
    /**
     * 根据用户名、要查的表名获取 当前用户已经配置的字段
     * 用于页面查询、展示、配置页面回显打勾
     *
     * @return
     */
    List<SysAccountTableFieldConfiguration> getUsableFieldByUserIdAndTableName(PageRequest pageRequest);

    /**
     * 根据表名获取 该表有哪些字段可以配置
     * 基础表 用于配置
     *
     * @return
     */
    List<SysTableFieldConfiguration> getAllFieldByTableName(String tableName);

    /**
     * List<SysTableFieldConfiguration>
     *
     * @param submitFieldParams
     * @return
     */
    List<SysAccountTableFieldConfiguration> submitFieldConfiguration(Map<String, Object> submitFieldParams);

    /**
     * 用户自定义配置字段提交（设置显示字段显示顺序）
     *
     * @param fieldSort
     * @return
     */
    int submitFieldSort(List<SysAccountTableFieldConfiguration> fieldSort);

    /**
     *主配置数据——根据表名、用户名 获取用户在该查询的按钮权限
     *用于页面中 某个查询按钮权限的控制
     * @param pageRequest
     * @return
     */
    List<SysAccountButtonConfiguration> getButtonPermissionUserIdAndTableName(PageRequest pageRequest);

    /**
     *  主配置数据——根据表名、用户名 获取自定义数据行的颜色
     *  用于页面中 数据展示某一行的颜色控制
     * @param pageRequest
     * @return
     */
    List<SysAccountRowColorRulesConfiguration> getRowColorsByUserIdAndTableName(PageRequest pageRequest);
}
