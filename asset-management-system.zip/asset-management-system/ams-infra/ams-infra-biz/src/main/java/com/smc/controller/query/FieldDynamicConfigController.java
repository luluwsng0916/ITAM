package com.smc.controller.query;

import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.dataobject.query.SysAccountTableFieldConfiguration;
import com.smc.service.query.FieldDynamicConfigService;
import com.smc.utils.WebUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * 字段动态配置 controller
 *
 * @Author: C02039 wjh
 * @Date: 2022/7/21  16:22
 */
@RestController
@RequestMapping(value = "/publicFieldConfiguration")
@CrossOrigin
public class FieldDynamicConfigController {
    @Autowired
    FieldDynamicConfigService fieldDynamicConfigService;


    /**
     * 根据用户名、要查的表名获取 当前用户已经配置的字段
     * 用于页面查询、展示、配置页面回显打勾
     *
     * @return
     */
    @RequestMapping(value = "/getUsableFieldByUserIdAndTableName")
    public ResultBody<List<SysAccountTableFieldConfiguration>> getUsableFieldByUserIdAndTableName(@RequestBody PageRequest pageRequest) {
        return ResultBody.failed().data(fieldDynamicConfigService.getUsableFieldByUserIdAndTableName(pageRequest)).path(WebUtils.getUri());
    }

    /**
     * 根据表名获取 该表有哪些字段可以配置
     * 基础表 用于配置
     *
     * @return
     */
    @RequestMapping(value = "/getAllFieldByTableName")
    public ResultBody<List<SysAccountTableFieldConfiguration>> getAllFieldByTableName(@RequestBody String tabelName) {
        return ResultBody.failed().data(fieldDynamicConfigService.getAllFieldByTableName(tabelName)).path(WebUtils.getUri());
    }

    /**
     * 用户自定义配置字段提交 （设置字段显示、隐藏）
     *
     * @return
     */
    @RequestMapping(value = "/submitFieldConfiguration")
    public ResultBody<List<SysAccountTableFieldConfiguration>> submitFieldConfiguration(@RequestBody Map<String, Object> submitFieldParams) {
        return ResultBody.failed().data(fieldDynamicConfigService.submitFieldConfiguration(submitFieldParams)).path(WebUtils.getUri());
    }

    /**
     * 用户自定义配置字段提交（设置显示字段显示顺序）
     *
     * @return
     */
    @RequestMapping(value = "/submitFieldSort")
    public ResultBody<List<SysAccountTableFieldConfiguration>> submitFieldSort(@RequestBody List<SysAccountTableFieldConfiguration> fieldSort) {
        return ResultBody.failed().data(fieldDynamicConfigService.submitFieldSort(fieldSort)).path(WebUtils.getUri());
    }
    /**
     * 主配置数据——根据表名、用户名 获取用户在该查询的按钮权限
     * 用于页面中 某个查询按钮权限的控制
     *
     * @return
     */
    @RequestMapping(value = "/getButtonPermissionUserIdAndTableName")
    public ResultBody<List<SysAccountTableFieldConfiguration>> getButtonPermissionUserIdAndTableName(@RequestBody PageRequest pageRequest) {
        return ResultBody.failed().data(fieldDynamicConfigService.getButtonPermissionUserIdAndTableName(pageRequest)).path(WebUtils.getUri());
    }
    /**
     * 主配置数据——根据表名、用户名 获取自定义数据行的颜色
     * 用于页面中 数据展示某一行的颜色控制
     *
     * @return
     */
    @RequestMapping(value = "/getRowColorsByUserIdAndTableName")
    public ResultBody<String> getRowColorsByUserIdAndTableName(@RequestBody PageRequest pageRequest) {
        return ResultBody.failed().data(fieldDynamicConfigService.getRowColorsByUserIdAndTableName(pageRequest)).path(WebUtils.getUri());
    }


}
