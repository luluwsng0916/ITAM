package com.smc.service.query;


import com.smc.common.model.page.PageRequest;
import com.smc.common.mybatis.service.CurdService;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * (SysAccounttablefieldconfiguration)表服务接口
 *
 * @author 温建华 C02039
 * @since 2023-03-03 12:50:56
 */
public interface SysAccounttablefieldconfigurationService extends CurdService {
    /**
     * easyExcel 指定列导出
     *
     * @param pageRequest
     * @param response    抛出：IOException
     */
    void exportSysAccounttablefieldconfiguration(PageRequest pageRequest, HttpServletResponse response) throws IOException;

    /**
     * 新增数据
     *
     * @param map 中存放 实例对象
     * @return 实例对象
     */
    int addSysAccounttablefieldconfigurationInfo(Map<String, Object> map);

    /**
     * 修改数据
     *
     * @param map 中存放 实例对象
     * @return 实例对象
     * SysAccounttablefieldconfiguration update(SysAccounttablefieldconfiguration sysAccounttablefieldconfiguration);
     */
    int alterSysAccounttablefieldconfigurationById(Map<String, Object> map);

    /**
     * 获取员工配置表中 的表说明信息 用于下拉菜单
     *
     * @return
     */
    List<String> getTableNames();
}
