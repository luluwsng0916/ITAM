package com.smc.controller.mdm;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.mdm.model.bo.PublicUniversalCodeDeleteBO;
import com.smc.dataobject.mdm.PublicUniversalCode;
import com.smc.service.mdm.PublicUniversalCodeService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
* 字典表
*
* @author aaa 
* @since 1.0.0 2024-07-09
*/
@CrossOrigin
@RestController
@RequestMapping("/publicUniversalCode")
public class PublicUniversalCodeController {
    @Resource
    private PublicUniversalCodeService publicUniversalCodeService;

    @GetMapping("/listByClassify")
    public ResultBody<List<PublicUniversalCode>> listByClassify(@RequestParam("classifyDesc") String classifyDesc){
        return publicUniversalCodeService.listByClassify(classifyDesc);
    }

    @PostMapping("/list")
    public ResultBody<PageInfo<PublicUniversalCode>> page(@RequestBody  PageRequest pageRequest){
        return publicUniversalCodeService.page(pageRequest);
    }


    @PostMapping("/listAllType")
    public ResultBody<List<PublicUniversalCode>> listAllType(){
        return publicUniversalCodeService.listAllType();
    }


    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody PublicUniversalCode model){
        return publicUniversalCodeService.editById(model);
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody PublicUniversalCode model){
        return publicUniversalCodeService.add(model);
    }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody PublicUniversalCodeDeleteBO deleteBO){
        return publicUniversalCodeService.delete(deleteBO);
    }

    @PostMapping("/import")
    public ResultBody<String> importData(@RequestParam(value = "multipartFile", required = false)
        MultipartFile multipartFile, HttpServletRequest req) {
        return publicUniversalCodeService.importData(multipartFile, req);
    }

    @PostMapping("/export")
    public void exportData(@RequestBody PageRequest pageRequest, HttpServletResponse response) {
         publicUniversalCodeService.exportData(pageRequest, response);
    }

}