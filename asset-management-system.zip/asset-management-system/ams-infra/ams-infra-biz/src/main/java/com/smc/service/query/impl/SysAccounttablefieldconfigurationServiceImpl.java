package com.smc.service.query.impl;

import com.alibaba.excel.EasyExcel;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.mybatis.page.MybatisPageHelper;
import com.smc.dataobject.query.SysAccountTableFieldConfiguration;
import com.smc.mapper.query.SysAccountTableFieldConfigurationDao;
import com.smc.service.query.SysAccounttablefieldconfigurationService;
import com.smc.utils.ParamsUtils;
import com.smc.utils.PlantMarkUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * (SysAccounttablefieldconfiguration)表服务实现类
 *
 * @author 温建华 C02039
 * @since 2023-03-03 13:56:13
 */
@Service("sysAccounttablefieldconfigurationService")
public class SysAccounttablefieldconfigurationServiceImpl implements SysAccounttablefieldconfigurationService {
    @Autowired
    ParamsUtils paramsUtils;
    @Autowired
    private SysAccountTableFieldConfigurationDao sysAccounttablefieldconfigurationDao;

    @Override
    public int save(Object record) {
        return 0;
    }

    @Override
    public int delete(Object record) {
        return 0;
    }

    @Override
    public int delete(List records) {
        return 0;
    }

    @Override
    public Object findById(Long id) {
        return null;
    }

    @Override
    public PageResult findPage(PageRequest pageRequest) {
        //调用  生成 map 参数的方法
        HashMap<String, Object> map = paramsUtils.generateMapParams(pageRequest);
        return MybatisPageHelper.findPage(pageRequest, sysAccounttablefieldconfigurationDao, "getSysAccounttablefieldconfigurationFindPageData", map);
    }

    /**
     * easyExcel导出 主配置表数据 指定列导出
     *
     * @param pageRequest
     * @param response
     */
    @Override
    public void exportSysAccounttablefieldconfiguration(PageRequest pageRequest, HttpServletResponse response) throws IOException {
        //调用  生成 map 参数的方法
        HashMap<String, Object> map = paramsUtils.generateMapParams(pageRequest);
        //用easyexcel方式导出
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
        String fileName = URLEncoder.encode("文件名", "UTF-8");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
        //指定导出的字段
        List<String> distinctUsedFieldList = (List<String>) map.get("distinctUsedFieldList");
        List<SysAccountTableFieldConfiguration> excelList = sysAccounttablefieldconfigurationDao.getSysAccounttablefieldconfigurationFindPageData(map);
        EasyExcel.write(response.getOutputStream(), SysAccountTableFieldConfiguration.class).includeColumnFiledNames(distinctUsedFieldList).sheet("sheet1").doWrite(excelList);
    }

    /**
     * 新增数据
     *
     * @param map 中存放 实例对象
     * @return 实例对象
     */
    @Override
    public int addSysAccounttablefieldconfigurationInfo(Map<String, Object> map) {
        String plantName = (String) map.get("plantName");
        String plantMark = PlantMarkUtils.convertPlantNameToPlantMark(plantName);
        map.put("plantMark", plantMark);
        return this.sysAccounttablefieldconfigurationDao.addSysAccounttablefieldconfigurationInfo(map);

    }

    /**
     * 修改数据
     *
     * @param map 中存放 实例对象
     * @return 实例对象
     */
    @Override
    public int alterSysAccounttablefieldconfigurationById(Map<String, Object> map) {
        return this.sysAccounttablefieldconfigurationDao.alterSysAccounttablefieldconfigurationById(map);
    }

    /**
     * 获取员工配置表中 的表说明信息 用于下拉菜单
     *
     * @return
     */
    @Override
    public List<String> getTableNames() {
        return sysAccounttablefieldconfigurationDao.getTableNames();
    }

}
