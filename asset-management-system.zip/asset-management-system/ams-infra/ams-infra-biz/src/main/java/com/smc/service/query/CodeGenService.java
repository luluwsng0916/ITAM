package com.smc.service.query;

import com.smc.common.model.result.ResultBody;
import com.smc.common.mybatis.model.KeyValueParam;

import java.util.List;

/**
 * @author C31909
 */
public interface CodeGenService {
    ResultBody<List<KeyValueParam<String, String>>> listTables();
}
