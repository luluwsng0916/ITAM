package com.smc.api.mdm;

import com.smc.common.constants.MdmCodeRuleCreateConstant;
import com.smc.enums.mdm.TableCodeRule;
import com.smc.mapper.mdm.ISqlMapper;
import com.smc.redis.RedisUtil;
import com.smc.utils.NumberFormatterUtils;
import com.smc.utils.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * @program: asset-management-system
 * @ClassName CodeGenApiImpl
 * @description:
 * @author: C31909
 * @create: 2024-08-13 10:09
 * @Version 1.0
 **/
@Service
public class CodeGenApiImpl implements CodeGenApi {

    @Resource
    private RedisUtil redisUtil;

    @Resource
    private ISqlMapper sqlMapper;

    @Override
    public String getCodeByTableName(TableCodeRule tableCodeRule) {
        String redisKey = MdmCodeRuleCreateConstant.REDIS_CODE_KEY_PREFIX + tableCodeRule.getTableName() +
                MdmCodeRuleCreateConstant.COLON + tableCodeRule.getPrefix();
        String redisCodeRule = String.valueOf(redisUtil.get(redisKey));
        if ("null".equals(redisCodeRule) || StringUtils.isBlank(redisCodeRule)) {
            Integer startNo = getStartNoByDB(tableCodeRule);
            String nextNo = tableCodeRule.getPrefix() + NumberFormatterUtils.formatNumber(tableCodeRule.getNumLength(), startNo);
            redisUtil.set(redisKey, nextNo, MdmCodeRuleCreateConstant.REDIS_EXPIRATION_TIME);
            return nextNo;
        }
        int nextStartNo = Integer.parseInt(redisCodeRule.substring(tableCodeRule.getPrefix().length())) + 1;
        String nextNo = tableCodeRule.getPrefix() + NumberFormatterUtils.formatNumber(tableCodeRule.getNumLength(), nextStartNo);
        redisUtil.set(redisKey, nextNo, MdmCodeRuleCreateConstant.REDIS_EXPIRATION_TIME);
        return nextNo;
    }


    public String getCodeByRedis(TableCodeRule tableCodeRule) {
        String redisKey = MdmCodeRuleCreateConstant.REDIS_CODE_KEY_PREFIX + tableCodeRule.getTableName();
        String redisCodeRule = String.valueOf(redisUtil.get(redisKey));
        if ("null".equals(redisCodeRule) || StringUtils.isBlank(redisCodeRule)) {
            Integer startNo = getStartNoByDB(tableCodeRule);
            String nextNo = tableCodeRule.getPrefix() + NumberFormatterUtils.formatNumber(tableCodeRule.getNumLength(), startNo);
            redisUtil.set(redisKey, nextNo, MdmCodeRuleCreateConstant.REDIS_EXPIRATION_TIME);
            return nextNo;
        }
        int nextStartNo = Integer.parseInt(redisCodeRule.substring(tableCodeRule.getPrefix().length())) + 1;
        String nextNo = tableCodeRule.getPrefix() + NumberFormatterUtils.formatNumber(tableCodeRule.getNumLength(), nextStartNo);
        redisUtil.set(redisKey, nextNo, MdmCodeRuleCreateConstant.REDIS_EXPIRATION_TIME);
        return nextNo;
    }


    private Integer getStartNoByDB(TableCodeRule tableCodeRule) {
        int start;
        String selectSql = "SELECT MAX(RIGHT(" + tableCodeRule.getFieldName() + "," +
                tableCodeRule.getNumLength() + ") ) FROM " +
                tableCodeRule.getTableName() + " WHERE " + tableCodeRule.getFieldName() +
                " LIKE '%" + tableCodeRule.getPrefix() + "%'";
        String maxNoStr = sqlMapper.selectOne(selectSql);
        if (StringUtils.isNotBlank(maxNoStr)) {
            start = Integer.parseInt(maxNoStr) + 1;
        } else {
            // 默认从 1 开始
            start = 1;
        }
        return start;
    }

    // ========================  新增生成规则 =============================

    /**
     * 格式化获取当前时间
     *
     * @return
     */
    private String getNowTime() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        return formatter.format(calendar.getTime());

    }


    @Override
    public String getCodeByTableNameTime(TableCodeRule tableCodeRule) {
        String redisKey = MdmCodeRuleCreateConstant.REDIS_CODE_KEY_PREFIX + tableCodeRule.getTableName() +
                MdmCodeRuleCreateConstant.COLON + tableCodeRule.getPrefix() + getNowTime();
        String redisCodeRule = String.valueOf(redisUtil.get(redisKey));
        if ("null".equals(redisCodeRule) || StringUtils.isBlank(redisCodeRule)) {
            Integer startNo = getStartNoByDBTime(tableCodeRule);
            String nextNo = tableCodeRule.getPrefix() + getNowTime() + NumberFormatterUtils.formatNumber(tableCodeRule.getNumLength(), startNo);
            redisUtil.set(redisKey, nextNo, MdmCodeRuleCreateConstant.REDIS_EXPIRATION_TIME);
            return nextNo;
        }
        int nextStartNo = Integer.parseInt(redisCodeRule.substring(tableCodeRule.getPrefix().length() + getNowTime().length())) + 1;
        String nextNo = tableCodeRule.getPrefix() + getNowTime() + NumberFormatterUtils.formatNumber(tableCodeRule.getNumLength(), nextStartNo);
        redisUtil.set(redisKey, nextNo, MdmCodeRuleCreateConstant.REDIS_EXPIRATION_TIME);
        return nextNo;
    }

    private Integer getStartNoByDBTime(TableCodeRule tableCodeRule) {
        int start;

        String selectSql = "SELECT MAX(RIGHT(" + tableCodeRule.getFieldName() + "," +
                tableCodeRule.getNumLength() + ") ) FROM " +
                tableCodeRule.getTableName() + " WHERE " + tableCodeRule.getFieldName() +
                " LIKE '" + tableCodeRule.getPrefix() + getNowTime() + "%'";
        String maxNoStr = sqlMapper.selectOne(selectSql);
        if (StringUtils.isNotBlank(maxNoStr)) {
            start = Integer.parseInt(maxNoStr) + 1;
        } else {
            // 默认从 1 开始
            start = 1;
        }
        return start;
    }

}
