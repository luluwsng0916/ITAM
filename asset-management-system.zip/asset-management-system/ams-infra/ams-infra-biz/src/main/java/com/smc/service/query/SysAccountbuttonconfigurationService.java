package com.smc.service.query;

import com.smc.common.model.page.PageRequest;
import com.smc.common.mybatis.service.CurdService;
import com.smc.dataobject.query.SysAccountButtonConfiguration;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * 通用查询按钮按钮配置(SysAccountButtonConfiguration)表服务接口
 *
 * @author 温建华 C02039
 * @since 2023-05-23 13:50:12
 */
public interface SysAccountbuttonconfigurationService extends CurdService {
   /**
     * 查询不分页
     *
     * @param pageRequest
     * @return
     */
   List<SysAccountButtonConfiguration> getSysAccountButtonConfigurationData(PageRequest pageRequest);
    /**
     * easyExcel 指定列导出
     * @param pageRequest
     * @param response
     * 抛出：IOException
     */
    void exportSysAccountbuttonconfiguration(PageRequest pageRequest, HttpServletResponse response) throws IOException;
    /**
     * 授权
     * @param map
     * @return
     */
    int bindButtonAuth(Map<String, Object> map) throws Exception;
}
