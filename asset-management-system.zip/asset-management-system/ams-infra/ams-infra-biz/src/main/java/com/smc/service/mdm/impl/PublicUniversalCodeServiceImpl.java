package com.smc.service.mdm.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.smc.common.constants.ActivityConstant;
import com.smc.common.constants.CommonConstants;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.mdm.model.bo.PublicUniversalCodeDeleteBO;
import com.smc.dataobject.mdm.PublicUniversalCode;
import com.smc.mapper.mdm.PublicUniversalCodeMapper;
import com.smc.service.mdm.PublicUniversalCodeService;
import com.smc.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 字典表
 *
 * @author aaa
 * @since 1.0.0 2024-07-09
 */
@Slf4j
@Service
public class PublicUniversalCodeServiceImpl implements PublicUniversalCodeService {

    @Resource
    private PublicUniversalCodeMapper publicUniversalCodeMapper;


    /**
     * 分页查询公共通用码信息。
     *
     * @param pageRequest 分页请求对象，包含分页参数和查询参数。
     * @return 分页查询结果，包含公共通用码的分页信息。
     */
    @Override
    public ResultBody<PageInfo<PublicUniversalCode>> page(PageRequest pageRequest) {
        // 从分页请求中获取查询参数
        String classifyDesc = pageRequest.getParamValue("classifyDesc");
        // String dictKey = pageRequest.getParamValue("dictKey");
        String dictValue = pageRequest.getParamValue("dictValue");
        String remark = pageRequest.getParamValue("remark");
        String activity = pageRequest.getParamValue("activity");

        // 构建查询条件
        LambdaQueryWrapper<PublicUniversalCode> queryWrapper = new LambdaQueryWrapper<>();
        // 根据字典值查询
        if (StringUtils.isNoneBlank(classifyDesc)) {
            queryWrapper.eq(PublicUniversalCode::getClassifyDesc, classifyDesc);
        }
        // 根据字典值查询
        if (StringUtils.isNoneBlank(dictValue)) {
            queryWrapper.like(PublicUniversalCode::getDictValue, dictValue);
        }
        // 根据备注查询
        if (StringUtils.isNoneBlank(remark)) {
            queryWrapper.like(PublicUniversalCode::getRemark, remark);
        }
        // 根据活动标识查询
        if (StringUtils.isNoneBlank(activity)) {
            queryWrapper.eq(PublicUniversalCode::getActivity, activity);
        }
        // 查询未删除的记录
        queryWrapper.eq(PublicUniversalCode::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        // 按更新时间降序排序
        queryWrapper.orderByDesc(PublicUniversalCode::getUpdatedTime);

        // 初始化分页插件
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        // 根据查询条件查询公共通用码列表
        List<PublicUniversalCode> universalCodes = publicUniversalCodeMapper.selectList(queryWrapper);
        // 构建分页信息
        PageInfo<PublicUniversalCode> pageInfo = new PageInfo<>(universalCodes);
        // 返回分页查询结果
        return ResultBody.ok().data(pageInfo);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ResultBody<String> editById(PublicUniversalCode model) {
        if (ifExistedByClassifyAndDictKey(model)) {
            return ResultBody.failed().msg("通用代码" + model.getDictValue() + "在" + model.getClassifyDesc() + "已存在");
        }
        model.setUpdatedTime(new Date());
        publicUniversalCodeMapper.updateById(model);
        return ResultBody.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ResultBody<String> add(PublicUniversalCode model) {
        if (ifExistedByClassifyAndDictKey(model)) {
            return ResultBody.failed().msg("通用代码" + model.getDictValue() + "在" + model.getClassifyDesc() + "已存在");
        }
        model.setVersion(CommonConstants.DEFAULT_VERSION);
        publicUniversalCodeMapper.insert(model);
        return ResultBody.ok();
    }

    private boolean ifExistedByClassifyAndDictKey(PublicUniversalCode model) {
        LambdaQueryWrapper<PublicUniversalCode> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(PublicUniversalCode::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        queryWrapper.eq(PublicUniversalCode::getClassifyDesc, model.getClassifyDesc());
        queryWrapper.eq(PublicUniversalCode::getDictValue, model.getDictValue());
        if (model.getId() != null) {
            queryWrapper.ne(PublicUniversalCode::getId, model.getId());
        }
        return publicUniversalCodeMapper.selectCount(queryWrapper) > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ResultBody<String> delete(PublicUniversalCodeDeleteBO deleteBO) {
        // 更新公共通用码的删除标记和时间
        PublicUniversalCode publicUniversalCode = new PublicUniversalCode();
        publicUniversalCode.setId(deleteBO.getId());
        publicUniversalCode.setDeleteMark(DeleteMarkConstant.DELETED);
        publicUniversalCode.setVersion(deleteBO.getVersion());
        publicUniversalCode.setUpdatedTime(new Date());
        publicUniversalCodeMapper.updateById(publicUniversalCode);
        return ResultBody.ok();
    }

    /**
     * 查询所有类型的分类信息。
     *
     * @return 返回查询结果，包含所有类型的分类列表。如果未查询到数据，则返回失败结果。
     */
    @Override
    public ResultBody<List<PublicUniversalCode>> listAllType() {
        // 根据查询条件查询所有记录
        List<PublicUniversalCode> universalCodes = publicUniversalCodeMapper.listAllType();

        // 如果查询结果为空，返回失败信息
        if (universalCodes.isEmpty()) {
            return ResultBody.failed().msg("未查询到数据");
        }

        // 返回成功结果，并将查询到的分类信息转换为字符串列表后返回
        return ResultBody.ok().data(universalCodes);
    }

    @Override
    public List<PublicUniversalCode> getUniversalCodeByIdList(List<Integer> codeList) {
        if (CollectionUtil.isEmpty(codeList)) {
            return Collections.emptyList();
        }
        return publicUniversalCodeMapper.selectBatchIds(codeList);
    }

    @Override
    public ResultBody<List<PublicUniversalCode>> listByClassify(String classifyDesc) {
        if (StringUtils.isNoneBlank(classifyDesc)) {
            LambdaQueryWrapper<PublicUniversalCode> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(PublicUniversalCode::getClassifyDesc, classifyDesc);
            queryWrapper.eq(PublicUniversalCode::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
            queryWrapper.eq(PublicUniversalCode::getActivity, ActivityConstant.ACTIVITY);
            queryWrapper.orderByDesc(PublicUniversalCode::getUpdatedTime);
            List<PublicUniversalCode> universalCodes = publicUniversalCodeMapper.selectList(queryWrapper);
            return ResultBody.ok().data(universalCodes);
        }
        return ResultBody.failed().msg("未查询到相应数据");
    }

    @Override
    public List<Integer> getUniversalCodeByDictValue(String classifyDesc, String dictValue) {
        LambdaQueryWrapper<PublicUniversalCode> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(PublicUniversalCode::getClassifyDesc, classifyDesc);
        queryWrapper.eq(PublicUniversalCode::getDictValue, dictValue);
        queryWrapper.eq(PublicUniversalCode::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        queryWrapper.eq(PublicUniversalCode::getActivity, ActivityConstant.ACTIVITY);
        List<PublicUniversalCode> universalCodes = publicUniversalCodeMapper.selectList(queryWrapper);
        if (!universalCodes.isEmpty()) {
            return universalCodes.stream().map(PublicUniversalCode::getId).collect(Collectors.toList());
        }
        return null;
    }

    @Override
    public List<PublicUniversalCode> listUniversalCodeByDictValue(String codeCategory, List<String> codeValueList) {
        LambdaQueryWrapper<PublicUniversalCode> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(PublicUniversalCode::getClassifyDesc, codeCategory);
        queryWrapper.eq(PublicUniversalCode::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        queryWrapper.eq(PublicUniversalCode::getActivity, ActivityConstant.ACTIVITY);
        queryWrapper.in(PublicUniversalCode::getDictValue, codeValueList);
        return publicUniversalCodeMapper.selectList(queryWrapper);
    }

    @Override
    public void saveBatchUniversalCode(String codeCategory, List<String> codeValueList) {
        if (CollectionUtil.isEmpty(codeValueList)){
            return;
        }
        publicUniversalCodeMapper.saveBatchUniversalCode(codeCategory, codeValueList);
    }

    @Override
    @Transactional(rollbackFor = Exception.class, value = "")
    public ResultBody<String> importData(MultipartFile multipartFile, HttpServletRequest req) {
        return ResultBody.ok();
    }

    @Override
    public void exportData(PageRequest pageRequest, HttpServletResponse response) {

    }


}