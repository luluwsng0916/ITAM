package com.smc.dataobject.query;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import lombok.Data;

import java.io.Serializable;

/**
 * 通用查询按钮按钮配置(SysAccountButtonConfiguration)实体类
 *
 * @author 温建华
 * @since 2023-05-23 13:50:49
 */
@Data
@ColumnWidth(16)
public class SysAccountButtonConfiguration implements Serializable {
    private static final long serialVersionUID = 247308805243730850L;
    @ExcelProperty("ID")
    private Integer iD;
    /**
     * 用户名
     */
    @ExcelProperty("用户名")
    private String userId;
    /**
     * 表名
     */
    @ExcelProperty("表名")
    private String tableName;

    /**
     * 表名说明
     */
    @ExcelProperty("表名说明")
    private String tableNameChn;
    /**
     * 导出按钮权限1：有权限 0：没有权限
     */
    @ExcelProperty("导出按钮权限1：有权限 0：没有权限")
    private String export;
    /**
     * 查询按钮权限
     */
    @ExcelProperty("查询按钮权限")
    private String query;
    /**
     * 字段显示按钮权限
     */
    @ExcelProperty("字段显示按钮权限")
    private String show;
    /**
     * 字段数顺序按钮权限
     */
    @ExcelProperty("字段数顺序按钮权限")
    private String sort;
/**
 */
}

