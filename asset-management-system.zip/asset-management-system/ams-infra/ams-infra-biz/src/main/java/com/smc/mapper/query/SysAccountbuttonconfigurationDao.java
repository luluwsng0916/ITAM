package com.smc.mapper.query;

import com.smc.dataobject.query.SysAccountButtonConfiguration;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

/**
 * 通用查询按钮按钮配置(SysAccountButtonConfiguration)表数据库访问层
 *
 * @author 温建华 C02039
 * @since 2023-05-23 13:50:08
 */
 // @Mapper
public interface SysAccountbuttonconfigurationDao {
    /**
    *查询 不分页
    */
    List<SysAccountButtonConfiguration> getSysAccountButtonConfigurationData(HashMap map);
    /**
     * 按钮管理——获取所有已经配置的查询
     * @return
     */
    List<SysAccountButtonConfiguration> getAllQueryTableConfig();

    /**
     * 按钮管理——查找前台传入 且 在数据库中存在的值
     * @param list
     * @param userId
     * @return
     */
    List<SysAccountButtonConfiguration> checkIsHave(@Param("list") List<SysAccountButtonConfiguration> list,String userId);

    /**
     *按钮管理——批量更新
     * @param list
     * @return
     */
    int updateSysAccountButtonConfiguration(@Param("list") List<SysAccountButtonConfiguration> list);
    /**
     *按钮管理——批量插入
     * @param list
     * @return
     */
    int insertSysAccountButtonConfiguration(@Param("list") List<SysAccountButtonConfiguration> list);
}

