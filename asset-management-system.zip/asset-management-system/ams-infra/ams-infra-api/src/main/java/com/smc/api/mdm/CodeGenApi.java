package com.smc.api.mdm;

import com.smc.enums.mdm.TableCodeRule;

/**
 * @author C31909
 */
public interface CodeGenApi {

    String getCodeByTableName(TableCodeRule tableCodeRule);

    String getCodeByTableNameTime(TableCodeRule tableCodeRule);
}
