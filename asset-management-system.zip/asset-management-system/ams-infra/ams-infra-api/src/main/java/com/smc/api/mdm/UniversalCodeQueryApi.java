package com.smc.api.mdm;

import com.smc.api.mdm.dto.PublicUniversalCodeDTO;

import java.util.List;

/**
 * @program: asset-management-system
 * @ClassName UniversalCodeQueryApi
 * @description:
 * @author: C31909
 * @create: 2024-07-11 11:17
 * @Version 1.0
 **/
public interface UniversalCodeQueryApi {
    List<PublicUniversalCodeDTO> getUniversalCodeByIdList(List<Integer> codeList);

    List<Integer> getUniversalCodeByDictValue(String classify, String dictValue);

    List<PublicUniversalCodeDTO> listUniversalCodeByDictValue(String codeCategory, List<String> codeValueList);

    void saveUniversalCode(String codeCategory, List<String> codeValueList);
}
