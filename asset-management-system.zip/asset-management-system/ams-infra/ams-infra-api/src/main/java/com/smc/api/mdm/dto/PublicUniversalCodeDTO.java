package com.smc.api.mdm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @program: asset-management-system
 * @ClassName PublicUniversalCodeDTO
 * @description:
 * @author: C31909
 * @create: 2024-07-11 11:20
 * @Version 1.0
 **/
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class PublicUniversalCodeDTO {

    private Integer id;

    private String classifyDesc;

    private String dictValue;
}
