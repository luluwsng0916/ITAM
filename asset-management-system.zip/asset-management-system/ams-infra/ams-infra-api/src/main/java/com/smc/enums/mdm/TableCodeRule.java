package com.smc.enums.mdm;

import lombok.Getter;

/**
 * @author C31909
 */

@Getter
public enum TableCodeRule {

    HARDWARE("SM", "ams_hardware", "id", 6),
    SOFTWARE("RJ", "ams_software", "id", 6),
    VIRTUAL_MACHINE_VM("VM", "ams_virtual_machine", "id", 6),
    VIRTUAL_MACHINE_PM("PM", "ams_virtual_machine", "id", 6),
    VIRTUAL_POOL("V", "ams_vitualpoolconfig", "poolId", 6),
    MAINTENANCE("WB", "ams_maintenance", "id", 6),
    SYSTEM("S", "ams_system", "systemId", 6),
    NETWORKLINE("N", "ams_network_line", "networkLineId", 6),
    VIRTUAL_MACHINE_IDC("IDC", "ams_virtual_machine_idc", "serverId", 5),
    ;

    private final String prefix;
    private final String tableName;
    private final String fieldName;
    private final Integer numLength;


    TableCodeRule(String prefix, String tableName, String fieldName, Integer numLength) {
        this.prefix = prefix;
        this.tableName = tableName;
        this.fieldName = fieldName;
        this.numLength = numLength;
    }
}
