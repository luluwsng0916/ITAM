package com.smc.api.query;



import com.smc.common.model.page.PageRequest;

import java.util.HashMap;

/**
 * @author C31909
 */
public interface QueryServiceClient {

    /**
     * 根据字段获取query条件
     */
    HashMap<String, Object> generateMapParams(PageRequest pageRequest);
}
