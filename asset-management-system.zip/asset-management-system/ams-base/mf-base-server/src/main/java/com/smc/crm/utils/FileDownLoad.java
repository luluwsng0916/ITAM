package com.smc.crm.utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.smc.crm.exception.CrmExceptionCode;
import com.smc.exception.BaseException;

public class FileDownLoad {

	public static Logger logger = LoggerFactory.getLogger(FileDownLoad.class);

	/**
	 * 文件读写
	 * 
	 * @Author B82561
	 * @param file
	 * @param outputStream
	 */
	public static void fileReadInDownLoading(File file, OutputStream outputStream) {
		if (file.exists()) {
			byte[] buffer = new byte[1024];
			FileInputStream fis = null;// 文件输入流
			BufferedInputStream bis = null;// 带缓冲区的输入流
			OutputStream os = null;// 文件输出流
			try {
				fis = new FileInputStream(file);
				bis = new BufferedInputStream(fis);
				os = outputStream;
				int i = bis.read(buffer);
				while (i != -1) {
					os.write(buffer, 0, i);
					i = bis.read(buffer);
				}
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new BaseException(CrmExceptionCode.下载错误);
			} finally {
				try {
					if (bis != null) {
						bis.close();
					}

					if (fis != null) {
						fis.close();
					}

					if (os != null) {
						os.close();
					}
				} catch (IOException e) {
					logger.error(e.getMessage());
					throw new BaseException(CrmExceptionCode.下载错误);
				}
			}
		}
	}
}
