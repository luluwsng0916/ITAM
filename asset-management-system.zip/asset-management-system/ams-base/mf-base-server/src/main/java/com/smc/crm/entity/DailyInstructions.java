package com.smc.crm.entity;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

public class DailyInstructions {
	/**
     * 日报批示表标识
     */
    private String id;
    /**
     * 日报id
     */
    private String dailyId;
    /**
     * 批示内容
     */
    private String contents;
    /**
     * 市况需否
     */
    private String customNos;
    /**
     * 批示人ID
     */
    private String operatorId;
    /**
     * 批示人姓名
     */
    private String operatorName;
    /**
     * 职位ID
     */
    private String positionId;
    
    /**
     * 职位名称
     */
    private String positionName;
    /**
	 * 存放批示人职位的K3Code的段位数*2，如果是负责人-1，数字越小职位越高
	 */
	private Integer rank;
    /**
     *批示人职级id
     */
//    private String operRankId;
    /**
     * 批示人职级
     */
//    private String rank;
    /**
     * 批示时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date operTime;

    
//    public String getOperRankId() {
//		return operRankId;
//	}
//
//	public void setOperRankId(String operRankId) {
//		this.operRankId = operRankId;
//	}

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getDailyId() {
        return dailyId;
    }

    public void setDailyId(String dailyId) {
        this.dailyId = dailyId == null ? null : dailyId.trim();
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents == null ? null : contents.trim();
    }

    public String getCustomNos() {
        return customNos;
    }

    public void setCustomNos(String customNos) {
        this.customNos = customNos == null ? null : customNos.trim();
    }

    public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}
	

//	public String getRank() {
//		return rank;
//	}
//
//	public void setRank(String rank) {
//		this.rank = rank;
//	}

	public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName == null ? null : operatorName.trim();
    }

    public Date getOperTime() {
        return operTime;
    }

    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }
    
    

	public String getPositionId() {
		return positionId;
	}

	public void setPositionId(String positionId) {
		this.positionId = positionId;
	}

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	@Override
	public String toString() {
		return "DailyInstructions [id=" + id + ", dailyId=" + dailyId + ", contents=" + contents + ", customNos="
				+ customNos + ", operatorId=" + operatorId + ", operatorName=" + operatorName + ", operTime=" + operTime + "]";
	}

	
    
    

    
}