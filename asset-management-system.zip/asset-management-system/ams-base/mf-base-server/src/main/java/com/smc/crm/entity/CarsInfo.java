package com.smc.crm.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 * ClassName: CarsInfo <br/>  
 * Function: 车辆信息. <br/>  
 * date: 2019年5月21日 上午8:55:41 <br/>  
 *  
 * @author SMC892Q  
 * @version   
 * @since JDK 1.8
 */
public class CarsInfo implements Serializable {
	
	/**  
	 * serialVersionUID:.  
	 * @since JDK 1.8  
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 主键
	 */
	private Integer id;
	
	/**
	 * 营业所代码
	 */
	private String deptCode;
	
	/**
	 * 职员编号
	 */
	private String psnsmcid;
	
	/**
	 * 公私标识
	 */
	private String privateType;
	
	/**
	 * 车牌号
	 */
	private String carCode;
	
	/**
	 * 车型
	 */
	private String carMode;
	
	/**
	 * 行驶公里
	 */
	private Integer runli;
	
	/**
	 * 购买日期
	 */
	private Date purdate;
	
	/**
	 * 批准日期
	 */
	private Date piZhunDate;
	
	/**
	 * 排气量
	 */
	private Integer paiQi;
	
	/**
	 * 公务用车单价
	 */
	private BigDecimal mobilPrice;
	
	/**
	 * 整车价格
	 */
	private BigDecimal carPrice;
	
	/**
	 * 固定费用额度
	 */
	private Integer guding;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getPsnsmcid() {
		return psnsmcid;
	}

	public void setPsnsmcid(String psnsmcid) {
		this.psnsmcid = psnsmcid;
	}

	public String getPrivateType() {
		return privateType;
	}

	public void setPrivateType(String privateType) {
		this.privateType = privateType;
	}

	public String getCarCode() {
		return carCode;
	}

	public void setCarCode(String carCode) {
		this.carCode = carCode;
	}

	public String getCarMode() {
		return carMode;
	}

	public void setCarMode(String carMode) {
		this.carMode = carMode;
	}

	public Integer getRunli() {
		return runli;
	}

	public void setRunli(Integer runli) {
		this.runli = runli;
	}

	public Date getPurdate() {
		return purdate;
	}

	public void setPurdate(Date purdate) {
		this.purdate = purdate;
	}

	public Date getPiZhunDate() {
		return piZhunDate;
	}

	public void setPiZhunDate(Date piZhunDate) {
		this.piZhunDate = piZhunDate;
	}

	public Integer getPaiQi() {
		return paiQi;
	}

	public void setPaiQi(Integer paiQi) {
		this.paiQi = paiQi;
	}

	public BigDecimal getMobilPrice() {
		return mobilPrice;
	}

	public void setMobilPrice(BigDecimal mobilPrice) {
		this.mobilPrice = mobilPrice;
	}

	public BigDecimal getCarPrice() {
		return carPrice;
	}

	public void setCarPrice(BigDecimal carPrice) {
		this.carPrice = carPrice;
	}

	public Integer getGuding() {
		return guding;
	}

	public void setGuding(Integer guding) {
		this.guding = guding;
	}
	
	
	

}
