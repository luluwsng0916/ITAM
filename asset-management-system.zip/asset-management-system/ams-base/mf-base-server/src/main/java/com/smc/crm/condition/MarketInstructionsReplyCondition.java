package com.smc.crm.condition;

import com.smc.condition.Condition;
/**
 * 市况回复查询条件
 * @author B82559
 *
 */
public class MarketInstructionsReplyCondition implements Condition {

	private static final long serialVersionUID = 7498689306608040523L;
	/**
	 * 市况编号
	 */
	private String id;
	
	/**
	 * 登录人
	 */
	private String operatorId;
	/**
	 * 回复状态
	 */
	private String replyStatus;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getReplyStatus() {
		return replyStatus;
	}
	public void setReplyStatus(String replyStatus) {
		this.replyStatus = replyStatus;
	}
	public String getOperatorId() {
		return operatorId;
	}
	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}
	
	

}
