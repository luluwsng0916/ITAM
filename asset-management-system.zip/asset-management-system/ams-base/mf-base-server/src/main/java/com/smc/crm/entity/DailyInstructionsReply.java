package com.smc.crm.entity;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

public class DailyInstructionsReply {
	/**
	 * 日报批示回复表标识符
	 */
    private String id;
    /**
	 * 日报id
	 */
    private String dailyId;
    /**
	 * 批示id
	 */
    private String instructionsId;
    /**
	 * 回复内容
	 */
    private String contents;
    /**
	 * 回复状态
	 */
    private String replyStatus;
    /**
	 * 回复人id
	 */
    private String operatorId;
    /**
	 * 回复人姓名
	 */
    private String operator;
    /**
	 * 回复人职级ID
	 */
//    private String operRankId;
    /**
     * 回复人职级
     */
//    private String rank;
    /**
     * 职位ID
     */
    private String positionId;
    
    /**
     * 职位名称
     */
    private String positionName;
    /**
	 * 回复时间
	 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date operTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getDailyId() {
        return dailyId;
    }

    public void setDailyId(String dailyId) {
        this.dailyId = dailyId == null ? null : dailyId.trim();
    }

    public String getInstructionsId() {
        return instructionsId;
    }

    public void setInstructionsId(String instructionsId) {
        this.instructionsId = instructionsId == null ? null : instructionsId.trim();
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents == null ? null : contents.trim();
    }

    public String getReplyStatus() {
        return replyStatus;
    }

    public void setReplyStatus(String replyStatus) {
        this.replyStatus = replyStatus == null ? null : replyStatus.trim();
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId == null ? null : operatorId.trim();
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }

//    public String getRank() {
//		return rank;
//	}
//
//	public void setRank(String rank) {
//		this.rank = rank;
//	}
//
//	public String getOperRankId() {
//		return operRankId;
//	}
//
//	public void setOperRankId(String operRankId) {
//		this.operRankId = operRankId;
//	}

	public Date getOperTime() {
        return operTime;
    }

    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }

	@Override
	public String toString() {
		return "DailyInstructionsReply [id=" + id + ", dailyId=" + dailyId + ", instructionsId=" + instructionsId
				+ ", contents=" + contents + ", replyStatus=" + replyStatus + ", operatorId=" + operatorId
				+ ", operator=" + operator  + ", operTime=" + operTime + "]";
	}

	public String getPositionId() {
		return positionId;
	}

	public void setPositionId(String positionId) {
		this.positionId = positionId;
	}

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	
    
}