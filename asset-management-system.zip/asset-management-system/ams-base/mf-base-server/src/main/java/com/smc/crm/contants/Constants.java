package com.smc.crm.contants;

/**
 * @Descripton: 常量类
 * @Classname: Constants
 * @Author B82561
 * @Date 2018年11月8日
 */
public class Constants extends com.smc.base.constants.Constants {
	/**
	 * 回复状态：未回复
	 */
	public static final String REPLYSTATUS_NO = "未回复";
	/**
	 * 回复状态：已回复
	 */
	public static final String REPLYSTATUS_YES = "已回复";
	
	/**
	 * 日期格式化yyyyMMdd
	 */
	public static final String DATE_FORMATE = "yyyy";
	/**
	 * 市况附件文件名
	 */
	public static final String MARKET_FOLDER_NAME = "market";
	
	public static final String MARKET_STATUS_YES = "已批示";
	
	public static final String DEPT_SPLIT = "!";
	
	public static final String HOLON_LEVEL = "HL";
	
	public static final String NOT_HAVE_DATA = "Not have data";

	/**
	 * 权限类型，1：按部门授权，2：按员工授权，3：按客户授权，4：自定义，5，全部
	 */
	public static final String AUTHORITY_TYPE_1 = "1";
	
	public static final String AUTHORITY_TYPE_2 = "2";
	
	public static final String AUTHORITY_TYPE_3 = "3";
	
	/**
	 * 自定义
	 */
	public static final String AUTHORITY_TYPE_BY_CUSTOM = "4";
	
	/**
	 * 全部
	 */
	public static final String AUTHORITY_TYPE_ALL = "5";
	
	public static final String STORAGE_DIRECTORY = "/mnt/crm";
	
	public static final String OFFICE = "所";
	
	public static final String CONNECTOR = "-";
	
	public static final String AUTHORITY_TYPE_CONDITION_4 = "4";
	
	public static final String AUTHORITY_TYPE_CONDITION_5 = "5";
	
}
