package com.smc.crm.condition;

import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.smc.base.TreeInfo;
import com.smc.condition.Condition;

public class DailyCondition implements Condition {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1162428063206249352L;
	/**
	 * 开始时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date startDate;
	/**
	 * 结束时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date endDate;

	/**
	 * 登录人
	 */
	private String operatorId;

	/**
	 * 填报人姓名
	 */
	private String userName;
	/**
	 * 填报人编码
	 */
	private String userId;
	/**
	 * 客户编码
	 */
	private String customerCode;
	/**
	 * 范围选择传回来的参数
	 */
	private List<TreeInfo> deptList;
	/**
	 * 默认营业所，部门编码 集合
	 */
	private List<String> deptCodeList;
	
	
	/**
	 * 是否获取部门及以下部门负责人
	 */
	
	private Boolean selectScope;
	
	/**
	 * 下级部门负责人的部门代码
	 */
	private List<String> fuZeRenDeptCode;

	/**
	 * 默认根据Holon获取的用户名集合
	 */
	private List<String> userIdList;

	/**
	 * 用户Id--条件
	 */
	private List<String> userIds;
	
	public void addUserIds(List<String> userIds) {
		if (CollectionUtils.isEmpty(this.userIds)) {
			this.userIds = userIds;
		} else if(CollectionUtils.isNotEmpty(userIds)) {
			this.userIds.addAll(userIds);
		}
	}

	public List<String> getUserIds() {
		return userIds;
	}

	public void setUserIds(List<String> userIds) {
		this.userIds = userIds;
	}

	public List<String> getDeptCodes() {
		return deptCodes;
	}

	public void setDeptCodes(List<String> deptCodes) {
		this.deptCodes = deptCodes;
	}

	/**
	 * 部门代码--条件
	 */
	private List<String> deptCodes;

	/**
	 * 客户
	 */
	private List<String> customerCodes;

	/**
	 * 是否提交 提交状态位
	 */
	private Boolean submitStatus;

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public List<TreeInfo> getDeptList() {
		return deptList;
	}

	public void setDeptList(List<TreeInfo> deptList) {
		this.deptList = deptList;
	}

	public List<String> getDeptCodeList() {
		return deptCodeList;
	}

	public void setDeptCodeList(List<String> deptCodeList) {
		this.deptCodeList = deptCodeList;
	}

	public List<String> getUserIdList() {
		return userIdList;
	}

	public void setUserIdList(List<String> userIdList) {
		this.userIdList = userIdList;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<String> getCustomerCodes() {
		return customerCodes;
	}

	public void setCustomerCodes(List<String> customerCodes) {
		this.customerCodes = customerCodes;
	}

	public Boolean getSubmitStatus() {
		return submitStatus;
	}

	public void setSubmitStatus(Boolean submitStatus) {
		this.submitStatus = submitStatus;
	}

	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

	public List<String> getFuZeRenDeptCode() {
		return fuZeRenDeptCode;
	}

	public void setFuZeRenDeptCode(List<String> fuZeRenDeptCode) {
		this.fuZeRenDeptCode = fuZeRenDeptCode;
	}

	public Boolean getSelectScope() {
		return selectScope;
	}

	public void setSelectScope(Boolean selectScope) {
		this.selectScope = selectScope;
	}

}
