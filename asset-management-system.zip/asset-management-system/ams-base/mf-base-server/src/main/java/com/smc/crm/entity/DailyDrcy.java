package com.smc.crm.entity;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

/**
 * @ClassName: DailyDrcy
 * @Description:TODO(日报1--n客户拜访记录实体类)
 * @author: B82561
 * @date: 2019年5月20日 下午5:53:29
 */
public class DailyDrcy {
	/**
	 * 主键Id
	 */
	private String id;

	/**
	 * 日报Id
	 */
	private String dailyId;

	/**
	 * 客户编码
	 */
	private String customerCode;

	/**
	 * 客户名称
	 */
	private String customerName;

	/**
	 * 拜访部门
	 */
	private String customerDept;

	/**
	 * 联系人
	 */
	private String customerContacts;

	/**
	 * 拜访
	 */
	private String visit;

	/**
	 * 目的
	 */
	private String goal;

	/**
	 * 行业
	 */
	private String industry;

	/**
	 * edp
	 */
	private String edp;

	/**
	 * 开始时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date startTime;

	/**
	 * 结束时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date endTime;

	/**
	 * 面谈时间（分钟）
	 */
	private Integer minute;

	/**
	 * 里程数
	 */
	private BigDecimal mileAge;

	/**
	 * 面谈事项
	 */
	private String mtsx;

	/**
	 * 对策
	 */
	private String dc;

	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;
	/**
	 * 车牌号
	 */
	private String carNumber;

	/**
	 * 起始公里数
	 */
	private Integer startingKm;

	/**
	 * 终止公里数
	 */
	private Integer terminatingKm;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id == null ? null : id.trim();
	}

	public String getDailyId() {
		return dailyId;
	}

	public void setDailyId(String dailyId) {
		this.dailyId = dailyId == null ? null : dailyId.trim();
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode == null ? null : customerCode.trim();
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getVisit() {
		return visit;
	}

	public void setVisit(String visit) {
		this.visit = visit == null ? null : visit.trim();
	}

	public String getGoal() {
		return goal;
	}

	public void setGoal(String goal) {
		this.goal = goal == null ? null : goal.trim();
	}

	public String getCustomerDept() {
		return customerDept;
	}

	public void setCustomerDept(String customerDept) {
		this.customerDept = customerDept;
	}

	public String getCustomerContacts() {
		return customerContacts;
	}

	public void setCustomerContacts(String customerContacts) {
		this.customerContacts = customerContacts;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry == null ? null : industry.trim();
	}

	public String getEdp() {
		return edp;
	}

	public void setEdp(String edp) {
		this.edp = edp == null ? null : edp.trim();
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Integer getMinute() {
		return minute;
	}

	public void setMinute(Integer minute) {
		this.minute = minute;
	}

	public BigDecimal getMileAge() {
		return mileAge;
	}

	public void setMileAge(BigDecimal mileAge) {
		this.mileAge = mileAge;
	}

	public String getMtsx() {
		return mtsx;
	}

	public void setMtsx(String mtsx) {
		this.mtsx = mtsx == null ? null : mtsx.trim();
	}

	public String getDc() {
		return dc;
	}

	public void setDc(String dc) {
		this.dc = dc == null ? null : dc.trim();
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCarNumber() {
		return carNumber;
	}

	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber == null ? null : carNumber.trim();
	}

	public Integer getStartingKm() {
		return startingKm;
	}

	public void setStartingKm(Integer startingKm) {
		this.startingKm = startingKm;
	}

	public Integer getTerminatingKm() {
		return terminatingKm;
	}

	public void setTerminatingKm(Integer terminatingKm) {
		this.terminatingKm = terminatingKm;
	}

	@Override
	public String toString() {
		return "DailyDrcy [id=" + id + ", dailyId=" + dailyId + ", customerCode=" + customerCode + ", customerName="
				+ customerName + ", customerDept=" + customerDept + ", customerContacts=" + customerContacts
				+ ", visit=" + visit + ", goal=" + goal + ", industry=" + industry + ", edp=" + edp + ", startTime="
				+ startTime + ", endTime=" + endTime + ", minute=" + minute + ", mileAge=" + mileAge + ", mtsx=" + mtsx
				+ ", dc=" + dc + ", createTime=" + createTime + ", carNumber=" + carNumber + ", startingKm="
				+ startingKm + ", terminatingKm=" + terminatingKm + "]";
	}

}