package com.smc.crm.exception;

import com.smc.exception.BaseExceptionCode;

public class CrmExceptionCode extends BaseExceptionCode {
	
	public static final String 您没有批示权限 = "200005";

	public static final String 文件上传错误 = "200003";
	
	public static final String 下载错误="200004";
	
	public static final String 无查询权限="200002";
	
	public static final String 不能为空="200006";
	
}
