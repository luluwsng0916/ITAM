package com.smc.crm.condition;

import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.smc.base.TreeInfo;
import com.smc.condition.Condition;

/**
 * 
 * ClassName: MarketCondition <br/>  
 * Function: 市况查询条件. <br/>  
 * date: 2019年5月22日 上午11:18:56 <br/>  
 *  
 * @author SMC892Q  
 * @version   
 * @since JDK 1.8
 */
public class MarketCondition implements Condition {
	
	/**  
	 * serialVersionUID:TODO:(用一句话描述这个变量表示什么).  
	 * @since JDK 1.8  
	 */
	private static final long serialVersionUID = 2621666392164253478L;
	
	/**
	 * 范围选择传回来的参数
	 */
	private List<TreeInfo> deptList; 

	/**
	 * 担当
	 */
	private String userName;
	
	/**
	 * 登录人用户编码
	 */
	private String userId;
	
	/**
	 * 是否获取部门及以下部门负责人
	 */
	
	private Boolean selectScope;
	
	/**
	 * 下级部门负责人的部门代码
	 */
	private List<String> fuZeRenDeptCode;
	
	/**
	 * 用户Id集合默认权限
	 */
	private List<String> userIdList;
	
	/**
	 * 部门代码集合默认权限
	 */
	private List<String> deptCodeList;
	
	/**
	 * 用户Id--条件
	 */
	private List<String> userIds;
	
	/**
	 * 部门代码--条件
	 */
	private List<String> deptCodes;
	
	/**
	 * 开始时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date startDate;
	/**
	 * 结束时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date endDate;
	/**
	 * 内容区分
	 */
	private String contentType;
	/**
	 * 行业
	 */
	private String indurstry;
	/**
	 * 市况编码
	 */
	private String id;
	/**
	 * 报告题目
	 */
	private String bgtm;
	/**
	 * 是否是代理店市况
	 */
	private Integer agency;
	/**
	 * 是否审核:0未审核1已审核
	 */
	private Integer isChecked;
	
	/**
	 * 石头已提交：0未提交 1已提交
	 */
	private Integer submitStatus;
	
	/**
	 * 客户代码
	 */
	private String customerCode;
	
	/**
	 * 客户（拥有的权限）
	 */
	private List<String> customerCodes;
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public Date getStartDate() {
		return startDate;
	}
	
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	public Date getEndDate() {
		return endDate;
	}
	
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public String getContentType() {
		return contentType;
	}
	
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
	public String getIndurstry() {
		return indurstry;
	}
	
	public void setIndurstry(String indurstry) {
		this.indurstry = indurstry;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getBgtm() {
		return bgtm;
	}
	
	public void setBgtm(String bgtm) {
		this.bgtm = bgtm;
	}

	public Integer getAgency() {
		return agency;
	}

	public void setAgency(Integer agency) {
		this.agency = agency;
	}

	public Integer getIsChecked() {
		return isChecked;
	}

	public void setIsChecked(Integer isChecked) {
		this.isChecked = isChecked;
	}

	public List<String> getCustomerCodes() {
		return customerCodes;
	}

	public void setCustomerCodes(List<String> customerCodes) {
		this.customerCodes = customerCodes;
	}

	public Integer getSubmitStatus() {
		return submitStatus;
	}

	public void setSubmitStatus(Integer submitStatus) {
		this.submitStatus = submitStatus;
	}

	public List<TreeInfo> getDeptList() {
		return deptList;
	}

	public void setDeptList(List<TreeInfo> deptList) {
		this.deptList = deptList;
	}

	public List<String> getUserIdList() {
		return userIdList;
	}

	public void setUserIdList(List<String> userIdList) {
		this.userIdList = userIdList;
	}

	public List<String> getDeptCodeList() {
		return deptCodeList;
	}

	public void setDeptCodeList(List<String> deptCodeList) {
		this.deptCodeList = deptCodeList;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public List<String> getUserIds() {
		return userIds;
	}

	public void setUserIds(List<String> userIds) {
		this.userIds = userIds;
	}
	
	public void addUserIds(List<String> userIds) {
		if (CollectionUtils.isEmpty(this.userIds)) {
			this.userIds = userIds;
		} else if(CollectionUtils.isNotEmpty(userIds)) {
			this.userIds.addAll(userIds);
		}
	}

	public List<String> getDeptCodes() {
		return deptCodes;
	}

	public void setDeptCodes(List<String> deptCodes) {
		this.deptCodes = deptCodes;
	}

	public Boolean getSelectScope() {
		return selectScope;
	}

	public void setSelectScope(Boolean selectScope) {
		this.selectScope = selectScope;
	}

	public List<String> getFuZeRenDeptCode() {
		return fuZeRenDeptCode;
	}

	public void setFuZeRenDeptCode(List<String> fuZeRenDeptCode) {
		this.fuZeRenDeptCode = fuZeRenDeptCode;
	}


	
	
}
