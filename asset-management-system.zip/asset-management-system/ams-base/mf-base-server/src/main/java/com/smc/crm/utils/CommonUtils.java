package com.smc.crm.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.smc.crm.entity.FileUpload;
import com.smc.crm.exception.CrmExceptionCode;
import com.smc.exception.BaseException;

/**
 * 
 * ClassName: CommonUtils <br/>
 * Function: 本系统通用工具类. <br/>
 * Reason: TODO ADD REASON(可选). <br/>
 * date: 2019年5月22日 下午3:48:29 <br/>
 * 
 * @author SMC892Q
 * @version
 * @since JDK 1.8
 */
public class CommonUtils {

	private final static Logger logger = LoggerFactory.getLogger(CommonUtils.class);

	/**
	 * 
	 * getId:(获取主键Id). <br/>
	 * 
	 * @author SMC892Q
	 * @param now
	 *            填写日期
	 * @param lastId
	 *            表内该日期内最大值
	 * @return String 新建ID
	 */
	public static String getId(Date now, String lastId) {
		String id = "";
		if (lastId == null) {
			id = new DateTime(now).toString("yyMMdd");
			id = id + String.format("%04d", 1);
		} else {
			int max = Integer.valueOf(lastId);
			max += 1;
			id += max;
		}

		return id;

	}

	public static void deleteFile(FileUpload fileUpload) {
		if (fileUpload != null) {
			String fileFullName = fileUpload.getFilePath() + fileUpload.getRandomFileName();
			File file = new File(fileFullName);
			if (!file.exists()) {
				logger.warn("删除文件失败:" + fileUpload.getRealFileName() + "不存在！");

			} else {
				if (file.isFile())
					file.delete();
			}
		}

	}

	public static <T> List<T> mapToList(Map<String, T> map) {
		if (map == null || map.isEmpty()) {
			return null;
		}
		List<T> list = new ArrayList<T>();
		for (Map.Entry<String, T> entry : map.entrySet()) {
			T userBase = entry.getValue();
			list.add(userBase);
		}
		return list;

	}

	public static boolean isContain(List<String> allList, List<String> list) {

		if (CollectionUtils.isEmpty(allList)) {
			return false;
		}

		if (CollectionUtils.isEmpty(list)) {
			return true;
		}
		@SuppressWarnings("unchecked")
		Collection<String> intersectionList = CollectionUtils.union(allList, list);

		if (CollectionUtils.isEqualCollection(intersectionList, allList)) {
			return true;
		}
		
		return false;
	}
	
	public static boolean isContain(List<String> allList, String code) {

		if (CollectionUtils.isEmpty(allList)) {
			return false;
		}

		for (String value : allList) {
			if (StringUtils.equals(code, value)) {
				return true;
			}
		}
		
		return false;
	}
	
	public static int getRankByKsCode(String code,boolean isFuZeRen) {
		if (StringUtils.isEmpty(code)) {
			throw new BaseException(CrmExceptionCode.不能为空);
		}
		if (isFuZeRen) {
			return code.split("!").length*2 - 1;
		}
		return code.split("!").length*2;
		
	}
	
	public static void main(String[] args) {
		
		int a = getRankByKsCode("000000!100000!133000!134010!133820",true);
		System.out.println(a);
		
//		List<String> allList = new ArrayList<String>();
//		allList.add("a");
//		allList.add("b");
//		allList.add("c");
//		allList.add("d");
//		List<String> list = new ArrayList<String>();
//		list.add("a");
//		list.add("b");
//		list.add("c");
//		list.add("e");
//		boolean a= isContain(allList,list);
//		System.out.println(a);
	}


}
