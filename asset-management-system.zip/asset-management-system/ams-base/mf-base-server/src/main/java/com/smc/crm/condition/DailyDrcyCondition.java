package com.smc.crm.condition;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.smc.condition.Condition;

/**
 * @ClassName: DailyDrcyCondition
 * @Description:TODO(客户拜访 条件查询 条件类)
 * @author: B82561
 * @date: 2019年5月22日 下午6:52:29
 */
public class DailyDrcyCondition implements Condition {

	private static final long serialVersionUID = 4494326651856811713L;

	/**
	 * 营业所拜访客户担当
	 */
	private String userName;

	/**
	 * 客户编码
	 */
	private String customerCode;
	/**
	 * 用户id集合
	 */
	private List<String> userIdList;
	/**
	 * 部门代码
	 */
	private List<String> deptCodeList;
	/**
	 * 客户集合
	 */
	private List<String> customerCodes;
	/**
	 * 登录人id
	 */
	private String operatorId;
	/**
	 * 用户Id--条件
	 */
	private List<String> userIds;

	/**
	 * 部门代码--条件
	 */
	private List<String> deptCodes;
	/**
	 * 按时间区间查询的 开始时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date startDate;

	/**
	 * 按时间区间查询的 结束时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date endDate;

	public List<String> getUserIdList() {
		return userIdList;
	}

	public void setUserIdList(List<String> userIdList) {
		this.userIdList = userIdList;
	}

	public List<String> getDeptCodeList() {
		return deptCodeList;
	}

	public void setDeptCodeList(List<String> deptCodeList) {
		this.deptCodeList = deptCodeList;
	}

	public List<String> getCustomerCodes() {
		return customerCodes;
	}

	public void setCustomerCodes(List<String> customerCodes) {
		this.customerCodes = customerCodes;
	}

	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public List<String> getUserIds() {
		return userIds;
	}

	public void setUserIds(List<String> userIds) {
		this.userIds = userIds;
	}

	public List<String> getDeptCodes() {
		return deptCodes;
	}

	public void setDeptCodes(List<String> deptCodes) {
		this.deptCodes = deptCodes;
	}

	@Override
	public String toString() {
		return "DailyDrcyCondition [userName=" + userName + ", customerCode=" + customerCode + ", userIdList="
				+ userIdList + ", deptCodeList=" + deptCodeList + ", customerCodes=" + customerCodes + ", operatorId="
				+ operatorId + ", userIds=" + userIds + ", deptCodes=" + deptCodes + ", startDate=" + startDate
				+ ", endDate=" + endDate + "]";
	}

}
