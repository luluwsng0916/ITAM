package com.smc.crm.entity;
/**
 * 职级表
 * @author B82559
 *
 */
public class Rank {
	/**
	 * 职级id
	 */
    private String rankId;
    
    /**
     * 职级排序
     */
    private Integer rankSort;
    /**
     * 职级编码
     */
    private String rank;
    

    public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	public String getRankId() {
		return rankId;
	}

	public void setRankId(String rankId) {
		this.rankId = rankId;
	}

	public Integer getRankSort() {
        return rankSort;
    }

    public void setRankSort(Integer rankSort) {
        this.rankSort = rankSort;
    }

    
}