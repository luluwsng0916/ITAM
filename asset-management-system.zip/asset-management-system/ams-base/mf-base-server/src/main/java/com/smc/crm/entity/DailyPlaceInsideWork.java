package com.smc.crm.entity;

/**
 * @ClassName: PlaceInsideWork
 * @Description:TODO(所内工作实体类)
 * @author: B82561
 * @date: 2019年5月23日 下午12:41:02
 */
public class DailyPlaceInsideWork {
	/**
	 * 主键Id
	 */
	private Integer id;

	/**
	 * 所属日报Id
	 */
	private String dailyId;

	/**
	 * 工作内容
	 */
	private String jobContent;

	/**
	 * 工作分钟数
	 */
	private Integer workMinute;

	/**
	 * 详细描述
	 */
	private String workDescription;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDailyId() {
		return dailyId;
	}

	public void setDailyId(String dailyId) {
		this.dailyId = dailyId == null ? null : dailyId.trim();
	}

	public String getJobContent() {
		return jobContent;
	}

	public void setJobContent(String jobContent) {
		this.jobContent = jobContent == null ? null : jobContent.trim();
	}

	public Integer getWorkMinute() {
		return workMinute;
	}

	public void setWorkMinute(Integer workMinute) {
		this.workMinute = workMinute;
	}

	public String getWorkDescription() {
		return workDescription;
	}

	public void setWorkDescription(String description) {
		this.workDescription = description == null ? null : description.trim();
	}

	@Override
	public String toString() {
		return "DailyPlaceInsideWork [id=" + id + ", dailyId=" + dailyId + ", jobContent=" + jobContent
				+ ", workMinute=" + workMinute + ", workDescription=" + workDescription + "]";
	}

}