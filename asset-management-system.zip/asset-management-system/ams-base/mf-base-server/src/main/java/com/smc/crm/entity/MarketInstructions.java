package com.smc.crm.entity;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

public class MarketInstructions {
	/**
	 * 市况批示表标识
	 */
    private String id;
    /**
	 * 市况id
	 */
    private String marketId;
    /**
	 * 批示内容
	 */
    private String contents;
    /**
	 * 批示人id 
	 */
    private String operatorId;
    /**
     *批示人职级rank表的id
     */
//    private String operRankId;
    
    /**
     * 批示人职级
     */
//    private String rank;
    /**
	 * 批示人姓名
	 */
    private String operatorName;
    
    /**
     * 职位ID
     */
    private String positionId;
    
    /**
     * 职位名称
     */
    private String positionName;
    /**
	 * 存放批示人职位的K3Code的段位数*2，如果是负责人-1，数字越小职位越高
	 */
	private Integer rank;
    /**
	 * 批示时间
	 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date operTime;
    
    

//    public String getOperRankId() {
//		return operRankId;
//	}
//
//	public void setOperRankId(String operRankId) {
//		this.operRankId = operRankId;
//	}

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getMarketId() {
        return marketId;
    }

    public void setMarketId(String marketId) {
        this.marketId = marketId == null ? null : marketId.trim();
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents == null ? null : contents.trim();
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId == null ? null : operatorId.trim();
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName == null ? null : operatorName.trim();
    }


    public Date getOperTime() {
        return operTime;
    }

    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }

	@Override
	public String toString() {
		return "MarketInstructions [id=" + id + ", marketId=" + marketId + ", contents=" + contents + ", operatorId="
				+ operatorId + ", operatorName=" + operatorName + ", operTime=" + operTime + "]";
	}

	/*public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}*/

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	public String getPositionId() {
		return positionId;
	}

	public void setPositionId(String positionId) {
		this.positionId = positionId;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}
    

    
}