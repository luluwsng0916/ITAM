package com.smc.crm.entity;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

public class DailyAndDrcy {
	/**
	 * 日报id
	 */
	private String id;
	/**
	 * 用户id
	 */
	private String userId;
	/**
	 * 用户姓名
	 */
	private String userName;
	/**
	 * 用户职级名称
	 */
	private String positionName;
	/**
	 * 营业所，部门编码
	 */
	private String deptCode;
	/**
	 * 填报日期
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fillDate;
	/**
	 * 日报Id
	 */
	private String dailyId;

	/**
	 * 开始时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date startTime;

	/**
	 * 结束时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date endTime;
	/**
	 * 里程数
	 */
	private BigDecimal mileAge;
	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;
	/**
	 * 车牌号
	 */
	private String carNumber;

	/**
	 * 起始公里数
	 */
	private Integer startingKm;

	/**
	 * 终止公里数
	 */
	private Integer terminatingKm;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public Date getFillDate() {
		return fillDate;
	}

	public void setFillDate(Date fillDate) {
		this.fillDate = fillDate;
	}

	public String getDailyId() {
		return dailyId;
	}

	public void setDailyId(String dailyId) {
		this.dailyId = dailyId;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public BigDecimal getMileAge() {
		return mileAge;
	}

	public void setMileAge(BigDecimal mileAge) {
		this.mileAge = mileAge;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCarNumber() {
		return carNumber;
	}

	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}

	public Integer getStartingKm() {
		return startingKm;
	}

	public void setStartingKm(Integer startingKm) {
		this.startingKm = startingKm;
	}

	public Integer getTerminatingKm() {
		return terminatingKm;
	}

	public void setTerminatingKm(Integer terminatingKm) {
		this.terminatingKm = terminatingKm;
	}

	@Override
	public String toString() {
		return "DailyAndDrcy [id=" + id + ", userId=" + userId + ", userName=" + userName + ", positionName="
				+ positionName + ", deptCode=" + deptCode + ", fillDate=" + fillDate + ", dailyId=" + dailyId
				+ ", startTime=" + startTime + ", endTime=" + endTime + ", mileAge=" + mileAge + ", createTime="
				+ createTime + ", carNumber=" + carNumber + ", startingKm=" + startingKm + ", terminatingKm="
				+ terminatingKm + "]";
	}
	

}
