package com.smc.crm.condition;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.smc.condition.Condition;

public class MarketAgentShopCondition implements Condition {

	private static final long serialVersionUID = 1271279500076765692L;
	
	/**
	 * 担当
	 */
	private String userName;
	
	/**
	 * 登录人用户编码
	 */
	private String userId;
	
	/**
	 * 用户Id集合
	 */
	private List<String> userIdList;
	/**
	 * 部门编码
	 */
	private String deptCode;
	/**
	 * 代理店编码
	 */
	private String agentShopCode;
	
	/**
	 * 部门代码
	 */
	private List<String> deptCodeList;
	
	/**
	 * 开始时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date startDate;
	/**
	 * 结束时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date endDate;
	/**
	 * 内容区分
	 */
	private String contentType;
	/**
	 * 行业
	 */
	private String indurstry;
	/**
	 * 市况编码
	 */
	private String id;
	/**
	 * 报告题目
	 */
	private String bgtm;
	/**
	 * 是否是代理店市况
	 */
	private Integer agency;
	/**
	 * 是否审核:0未审核1已审核
	 */
	private Integer isChecked;
	
	/**
	 * 石头已提交：0未提交 1已提交
	 */
	private Integer submitStatus;
	
	/**
	 * 客户
	 */
	private List<String> customerCodes;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<String> getUserIdList() {
		return userIdList;
	}

	public void setUserIdList(List<String> userIdList) {
		this.userIdList = userIdList;
	}

	public List<String> getDeptCodeList() {
		return deptCodeList;
	}

	public void setDeptCodeList(List<String> deptCodeList) {
		this.deptCodeList = deptCodeList;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getIndurstry() {
		return indurstry;
	}

	public void setIndurstry(String indurstry) {
		this.indurstry = indurstry;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBgtm() {
		return bgtm;
	}

	public void setBgtm(String bgtm) {
		this.bgtm = bgtm;
	}

	public Integer getAgency() {
		return agency;
	}

	public void setAgency(Integer agency) {
		this.agency = agency;
	}

	public Integer getIsChecked() {
		return isChecked;
	}

	public void setIsChecked(Integer isChecked) {
		this.isChecked = isChecked;
	}

	public Integer getSubmitStatus() {
		return submitStatus;
	}

	public void setSubmitStatus(Integer submitStatus) {
		this.submitStatus = submitStatus;
	}

	public List<String> getCustomerCodes() {
		return customerCodes;
	}

	public void setCustomerCodes(List<String> customerCodes) {
		this.customerCodes = customerCodes;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getAgentShopCode() {
		return agentShopCode;
	}

	public void setAgentShopCode(String agentShopCode) {
		this.agentShopCode = agentShopCode;
	}
	
	

}
