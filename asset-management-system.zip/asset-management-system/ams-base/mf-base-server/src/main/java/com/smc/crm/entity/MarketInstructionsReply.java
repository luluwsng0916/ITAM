package com.smc.crm.entity;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

public class MarketInstructionsReply {
    /**
     * 市况批示回复表标识
     */
    private String id;
    /**
     * 市况id
     */
    private String marketId;
    /**
     * 批示id
     */
    private String instructonsId;
    /**
     * 回复内容
     */
    private String contents;
    /**
     * 回复状态
     */
    private String replyStatus;
    /**
     * 回复人id
     */
    private String operatorId;
    /**
     * 回复人姓名
     */
    private String operator;
    /**
     * 回复人职级id
     */
//    private String operRankId;
    
    /**
     * 职位ID
     */
    private String positionId;
    
    /**
     * 职位名称
     */
    private String positionName;
    
    /**
     * 存放批示状态职位的K3Code的段位数*2，如果是负责人-1，数字越小职位越高;默认为null
     */
    private Integer rank;
    
    /**
     * 回复人职级
     */
//    private String rank;
    /**
     * 回复时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date operTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getMarketId() {
        return marketId;
    }

    public void setMarketId(String marketId) {
        this.marketId = marketId == null ? null : marketId.trim();
    }

    public String getInstructonsId() {
        return instructonsId;
    }

    public void setInstructonsId(String instructonsId) {
        this.instructonsId = instructonsId == null ? null : instructonsId.trim();
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents == null ? null : contents.trim();
    }

    public String getReplyStatus() {
        return replyStatus;
    }

    public void setReplyStatus(String replyStatus) {
        this.replyStatus = replyStatus == null ? null : replyStatus.trim();
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId == null ? null : operatorId.trim();
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }

    

    /*public String getOperRankId() {
		return operRankId;
	}

	public void setOperRankId(String operRankId) {
		this.operRankId = operRankId;
	}*/

	public Date getOperTime() {
        return operTime;
    }

    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }

	@Override
	public String toString() {
		return "MarketInstructionsReply [id=" + id + ", marketId=" + marketId + ", instructonsId=" + instructonsId
				+ ", contents=" + contents + ", replyStatus=" + replyStatus + ", operatorId=" + operatorId
				+ ", operator=" + operator + ", operTime=" + operTime + "]";
	}

//	public String getRank() {
//		return rank;
//	}
//
//	public void setRank(String rank) {
//		this.rank = rank;
//	}

	public String getPositionId() {
		return positionId;
	}

	public void setPositionId(String positionId) {
		this.positionId = positionId;
	}

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	
    
}