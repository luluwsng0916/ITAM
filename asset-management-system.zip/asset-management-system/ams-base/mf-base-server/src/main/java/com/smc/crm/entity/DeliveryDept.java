package com.smc.crm.entity;

/**
 * 
 * ClassName: DeliveryDept <br/>  
 * Function: 配送时使用 <br/>  
 * Reason: TODO ADD REASON(可选). <br/>  
 * date: 2019年6月19日 上午10:44:53 <br/>  
 *  
 * @author SMC892Q  
 * @version   
 * @since JDK 1.8
 */
public class DeliveryDept {
	
	/**
	 * 部门Id
	 */
	private String deptId;
	
	/**
	 * 部门名称
	 */
	private String deptName;
	
	/**
	 * 职位编码
	 */
	private String positionId;
	
	/**
	 * 职位名称
	 */
	private String positionName;

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getPositionId() {
		return positionId;
	}

	public void setPositionId(String positionId) {
		this.positionId = positionId;
	}

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}
	
	

}
