package com.smc.crm.condition;

import com.smc.condition.Condition;

public class DailyInstructionsReplyCondition implements Condition {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8444078561378622713L;
	
	/**
	 * 回复状态
	 */
	private String replyStatus;
	/**
	 * 日报编号
	 */
	private String id;
	/**
	 * 回复人
	 */
	private String operator;
	
	
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getReplyStatus() {
		return replyStatus;
	}
	public void setReplyStatus(String replyStatus) {
		this.replyStatus = replyStatus;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	

}
