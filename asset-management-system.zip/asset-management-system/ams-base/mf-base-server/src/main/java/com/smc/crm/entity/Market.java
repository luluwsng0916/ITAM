package com.smc.crm.entity;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

/**
 * 
 * ClassName: Market <br/>
 * Function: 市况表. <br/>
 * date: 2019年5月24日 下午2:24:47 <br/>
 * 
 * @author SMC892Q
 * @version
 * @since JDK 1.8
 */
public class Market {
	/**
	 * 市况编码
	 */
	private String id;
	/**
	 * 用户ID
	 */
	private String userId;
	/**
	 * 用户名
	 */
	private String userName;
	/**
	 * 部门编码
	 */
	private String deptCode;
	/**
	 * 部门名称
	 */
	private String deptName;
	/**
	 * 填写日期
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fillDate;
	/**
	 * 创建日期
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createDate = new Date();

	/**
	 * 内容区分
	 */
	private String contentType;
	/**
	 * 行业
	 */
	private String indurstry;

	/**
	 * 报告题目
	 */
	private String bgtm;
	/**
	 * 客户代码
	 */
	private String customerCodes;
	/**
	 * 经纬背景
	 */
	private String jwbj;
	/**
	 * 现状把握
	 */
	private String xzbw;
	/**
	 * 对策攻略
	 */
	private String dcgl;
	/**
	 * 日程安排
	 */
	private String rcap;

	/**
	 * 存放批示状态职位的K3Code的段位数*2，如果是负责人-1，数字越小职位越高
	 */
	private Integer rank;
	/**
	 * 状态
	 */
	private String status;
	/**
	 * 代理点标识 1代理店
	 */
	private Integer agency;

	/**
	 * 是否审核0未审核1已审核
	 */
	private Integer isChecked;

	/**
	 * 职级名称
	 */
	private String operRankName;

	/**
	 * 职位Id
	 */
	private String operPositionId;

	/**
	 * 提交状态：0未提交1已提交
	 */
	private Integer submitStatus;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id == null ? null : id.trim();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId == null ? null : userId.trim();
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName == null ? null : userName.trim();
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode == null ? null : deptCode.trim();
	}

	public Date getFillDate() {
		return fillDate;
	}

	public void setFillDate(Date fillDate) {
		this.fillDate = fillDate;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType == null ? null : contentType.trim();
	}

	public String getIndurstry() {
		return indurstry;
	}

	public void setIndurstry(String indurstry) {
		this.indurstry = indurstry == null ? null : indurstry.trim();
	}

	public String getBgtm() {
		return bgtm;
	}

	public void setBgtm(String bgtm) {
		this.bgtm = bgtm == null ? null : bgtm.trim();
	}

	public String getCustomerCodes() {
		return customerCodes;
	}

	public void setCustomerCodes(String customerCodes) {
		this.customerCodes = customerCodes == null ? null : customerCodes.trim();
	}

	public String getJwbj() {
		return jwbj;
	}

	public void setJwbj(String jwbj) {
		this.jwbj = jwbj == null ? null : jwbj.trim();
	}

	public String getXzbw() {
		return xzbw;
	}

	public void setXzbw(String xzbw) {
		this.xzbw = xzbw == null ? null : xzbw.trim();
	}

	public String getDcgl() {
		return dcgl;
	}

	public void setDcgl(String dcgl) {
		this.dcgl = dcgl == null ? null : dcgl.trim();
	}

	public String getRcap() {
		return rcap;
	}

	public void setRcap(String rcap) {
		this.rcap = rcap == null ? null : rcap.trim();
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status == null ? null : status.trim();
	}

	public Integer getAgency() {
		return agency;
	}

	public void setAgency(Integer agency) {
		this.agency = agency;
	}

	public Integer getIsChecked() {
		return isChecked;
	}

	public void setIsChecked(Integer isChecked) {
		this.isChecked = isChecked;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getOperRankName() {
		return operRankName;
	}

	public void setOperRankName(String operRankName) {
		this.operRankName = operRankName;
	}

	public Integer getSubmitStatus() {
		return submitStatus;
	}

	public void setSubmitStatus(Integer submitStatus) {
		this.submitStatus = submitStatus;
	}

	public String getOperPositionId() {
		return operPositionId;
	}

	public void setOperPositionId(String operPositionId) {
		this.operPositionId = operPositionId;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

}