package com.smc.crm;

import java.util.Map;

import com.smc.base.TreeInfo;

public class CrmStatic {
	
	/**
	 * map中含有机构，holon；key为编码，value为treeInfo
	 */
	public static Map<String, TreeInfo> treeInfoMap = null;

}
