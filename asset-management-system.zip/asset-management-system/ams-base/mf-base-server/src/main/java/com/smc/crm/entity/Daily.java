package com.smc.crm.entity;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

public class Daily {
	/**
	 * 日报id
	 */
	private String id;
	/**
	 * 用户id
	 */
	private String userId;
	/**
	 * 用户姓名
	 */
	private String userName;
	/**
	 * 职级Id 2019-08-21新增
	 */
	private String positionId;
	/**
	 * 用户职级名称
	 */
	private String positionName;
	/**
	 * 营业所，部门编码
	 */
	private String deptCode;
	/**
	 * 部门编码
	 */
	private String deptName;

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	/**
	 * 填报日期
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fillDate;
	/**
	 * 总出勤时间
	 */
	private Integer totalAttendanceTime;
	/**
	 * 总外出时间
	 */
	private Integer totalTimeOut;

	/**
	 * 存放批示状态职位的K3Code的段位数*2，如果是负责人-1，数字越小职位越高
	 */
	private Integer rank;
	/**
	 * 日报状态
	 */
	private String status;
	/**
	 * 创建日期
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;
	/**
	 * 备注
	 */
	private String description;
	/**
	 * 是否审核
	 */
	private Boolean whetherAudit;

	/**
	 * 是否提交 提交状态位
	 */
	private Boolean submitStatus;
	/**
	 * 对应的拜访信息
	 */
	private List<DailyDrcy> dailyDrcyList;

	public Boolean getWhetherAudit() {
		return whetherAudit;
	}

	public void setWhetherAudit(Boolean whetherAudit) {
		this.whetherAudit = whetherAudit;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id == null ? null : id.trim();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId == null ? null : userId.trim();
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName == null ? null : userName.trim();
	}

	public String getDeptCode() {
		return deptCode;
	}

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode == null ? null : deptCode.trim();
	}

	public Date getFillDate() {
		return fillDate;
	}

	public void setFillDate(Date fillDate) {
		this.fillDate = fillDate;
	}

	public Integer getTotalAttendanceTime() {
		return totalAttendanceTime;
	}

	public void setTotalAttendanceTime(Integer totalAttendanceTime) {
		this.totalAttendanceTime = totalAttendanceTime;
	}

	public Integer getTotalTimeOut() {
		return totalTimeOut;
	}

	public void setTotalTimeOut(Integer totalTimeOut) {
		this.totalTimeOut = totalTimeOut;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status == null ? null : status.trim();
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description == null ? null : description.trim();
	}

	public Boolean getSubmitStatus() {
		return submitStatus;
	}

	public void setSubmitStatus(Boolean submitStatus) {
		this.submitStatus = submitStatus;
	}

	public List<DailyDrcy> getDailyDrcyList() {
		return dailyDrcyList;
	}

	public void setDailyDrcyList(List<DailyDrcy> dailyDrcyList) {
		this.dailyDrcyList = dailyDrcyList;
	}

	public String getPositionId() {
		return positionId;
	}

	public void setPositionId(String positionId) {
		this.positionId = positionId;
	}

	@Override
	public String toString() {
		return "Daily [id=" + id + ", userId=" + userId + ", userName=" + userName + ", positionId=" + positionId
				+ ", positionName=" + positionName + ", deptCode=" + deptCode + ", fillDate=" + fillDate
				+ ", totalAttendanceTime=" + totalAttendanceTime + ", totalTimeOut=" + totalTimeOut + ", status="
				+ status + ", createTime=" + createTime + ", description=" + description + ", whetherAudit="
				+ whetherAudit + ", submitStatus=" + submitStatus + ", dailyDrcyList=" + dailyDrcyList + "]";
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

}