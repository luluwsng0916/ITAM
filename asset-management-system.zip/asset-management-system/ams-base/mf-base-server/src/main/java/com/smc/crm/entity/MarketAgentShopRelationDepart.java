package com.smc.crm.entity;
/**
 * 代理店市况客户相关营业所表
 * @author B82559
 *
 */
public class MarketAgentShopRelationDepart {
	/**
	 * 代理店市况id
	 */
	private String id;
	/**
	 * 部门编码（6位）
	 */
	private String deptCode;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	
	

}
