package com.smc.log.util;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.smc.core.entity.SysLog;

import cn.hutool.core.util.URLUtil;
import cn.hutool.extra.servlet.ServletUtil;
import cn.hutool.json.JSONArray;

/**
 * 系统日志工具类
 */
public class SysLogUtils {

	public static SysLog getSysLog(Object obj[]) {
		HttpServletRequest request = ((ServletRequestAttributes) Objects
			.requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest();
		SysLog sysLog = new SysLog();
		sysLog.setCreateId(Objects.requireNonNull(getUsername()));
		sysLog.setCreateTime(LocalDateTime.now());
		sysLog.setRemoteAddr(ServletUtil.getClientIP(request));
		sysLog.setRequestUri(URLUtil.getPath(request.getRequestURI()));
		sysLog.setMethod(request.getMethod());
		sysLog.setUserAgent(request.getHeader("user-agent"));
		sysLog.setParams(SysLogUtils.convertJson(obj));
		sysLog.setServiceId(getClientId());
		return sysLog;
	}

	/**
	 * 获取客户端
	 *
	 * @return clientId
	 */
	private static String getClientId() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication instanceof OAuth2Authentication) {
			OAuth2Authentication auth2Authentication = (OAuth2Authentication) authentication;
			return auth2Authentication.getOAuth2Request().getClientId();
		}
		return null;
	}

	/**
	 * 获取用户名称
	 * @return username
	 */
	private static String getUsername() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null) {
			return null;
		}
		return authentication.getName();
	}
	
	/**
	 * 参数转为Json串
	 * @param obj[]
	 * @return
	 */
	public static String convertJson(Object obj[]) {
		if(obj == null)
			return null;
		JSONArray json = new JSONArray(obj);
		return json.toString();
	}
	
	// public static void main(String[] args) {
	// 	List<Role> list = new ArrayList<Role>();
	// 	list.add(new Role());
	// 	Object obj[] = {"sssss" , new Role(), list};
	// 	cn.hutool.json.JSONArray jSONArray = new cn.hutool.json.JSONArray(obj);
	// 	System.out.println(jSONArray.toString());
	// }
}
