package com.smc.log.event;

import org.springframework.context.ApplicationEvent;

import com.smc.core.entity.SysLog;

public class SysLogEvent extends ApplicationEvent {

	/**
	 * 
	 */
	private static final long serialVersionUID = -434287581254135304L;

	public SysLogEvent(SysLog source) {
		super(source);
	}
}
