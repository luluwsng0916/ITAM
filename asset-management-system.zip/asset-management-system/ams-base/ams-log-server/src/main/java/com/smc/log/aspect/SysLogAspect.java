package com.smc.log.aspect;

import org.apache.commons.codec.binary.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

import com.smc.log.annotation.SysLog;
import com.smc.log.event.SysLogEvent;
import com.smc.log.util.SysLogUtils;

import lombok.extern.slf4j.Slf4j;
import com.smc.utils.SpringContextUtil;

@Aspect
@Slf4j
public class SysLogAspect {
	
	public static final String SUCCESS = "成功";
	
	public static final String FAILURE = "失败";
	
	public static final String LOGIN = "登录";
	
	@Around("@annotation(sysLog)")
	public Object around(ProceedingJoinPoint point, SysLog sysLog) throws Throwable{
		String strClassName = point.getTarget().getClass().getName();
		String strMethodName = point.getSignature().getName();
		log.debug("[类名]:{},[方法]:{}", strClassName, strMethodName);

		Long startTime = System.currentTimeMillis();
		Object obj = null;
		com.smc.core.entity.SysLog logVo = SysLogUtils.getSysLog(point.getArgs());
		logVo.setTitle(sysLog.value());
		try {
			obj = point.proceed();
		} catch (Throwable e) {
			logVo.setStatus(FAILURE);
			Long endTime = System.currentTimeMillis();
			logVo.setTime(endTime - startTime);
			SpringContextUtil.publishEvent(new SysLogEvent(logVo));
			throw e;
		}
		if(StringUtils.equals(LOGIN, sysLog.value())) {
			logVo.setCreateId(point.getArgs()[0].toString());
		}
		logVo.setStatus(SUCCESS);
		Long endTime = System.currentTimeMillis();
		logVo.setTime(endTime - startTime);
		SpringContextUtil.publishEvent(new SysLogEvent(logVo));
		return obj;
	}
}
