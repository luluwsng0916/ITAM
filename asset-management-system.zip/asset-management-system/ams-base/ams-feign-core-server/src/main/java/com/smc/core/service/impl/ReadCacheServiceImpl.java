package com.smc.core.service.impl;

import com.smc.base.Position;
import com.smc.base.TreeInfo;
import com.smc.core.feign.service.HolonUserService;
import com.smc.core.feign.service.BaseInfoService;
import com.smc.core.service.ReadCacheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ReadCacheServiceImpl implements ReadCacheService {
	
	@Autowired
	private HolonUserService holonUserService;
	
	@Autowired
	private BaseInfoService baseInfoService;
	
	@Override
	@Cacheable(value = "organs", key = "'k3organs_and_holon'", unless = "#result == null || #result.size() == 0", cacheManager = "cacheManagerOrgan")
	public List<TreeInfo> findDepts(){
		return holonUserService.findDepts();
	}
	
	@Override
	@Cacheable(value = "holon_members", key = "'holon_all_members'", unless = "#result == null || #result.size() == 0", cacheManager = "cacheManagerOrgan")
	public Map<String, List<String>> findHolonMembers(){
		return holonUserService.findHolonMembers();
	}

	@Override
	@Cacheable(value = "k3_position", key = "'k3_all_employee_positions'", unless = "#result == null || #result.size() == 0", cacheManager = "cacheManagerOrgan")
	public List<Position> findAllEmplyeePositions() {
		return baseInfoService.findAllEmplyeePositions();
	}
	
	@Override
	@Cacheable(value = "organs", key = "'k3organs_and_holon_map'", unless = "#result == null || #result.size() == 0", cacheManager = "cacheManagerOrgan")
	public Map<String, TreeInfo> organsAndHolonMapCache(){
		return holonUserService.organsAndHolonMapCache();
	}
}
