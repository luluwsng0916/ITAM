package com.smc.core.feign.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.smc.core.entity.SysLog;
import com.smc.core.feign.FeignHeaderSupportConfig;


@FeignClient(name = "asset-management-system", path="/asset", configuration = FeignHeaderSupportConfig.class,contextId = "RemoteLogService")
public interface RemoteLogService {
	@RequestMapping(value = "/log/add", method = RequestMethod.POST,  consumes = MediaType.APPLICATION_JSON_VALUE)
	void saveLog(@RequestBody SysLog sysLog);
}
