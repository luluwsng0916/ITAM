package com.smc.core.feign.factory;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.smc.core.feign.service.RoleApiService;

import feign.hystrix.FallbackFactory;

@Component
public class RoleApiServiceFallbackFactory implements FallbackFactory<RoleApiService> {

	@Override
	public RoleApiService create(Throwable cause) {
		return new RoleApiService() {

			@Override
			public List<Map<String, String>> findRoleAndResource() {
				return null;
			}

			@Override
			public Set<String> findRoleByUserId(String userId) {
				return null;
			}
		};
	}
}
