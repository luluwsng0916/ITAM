package com.smc.core.feign.factory;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.smc.base.Depart;
import com.smc.base.OrgPosition;
import com.smc.base.Position;
import com.smc.base.RemoteUser;
//import com.smc.base.EmployeePosition;
//import com.smc.base.OrgPosition;
//import com.smc.base.OrgUnit;
//import com.smc.base.RemoteUser;
import com.smc.core.feign.service.BaseInfoService;

import feign.hystrix.FallbackFactory;

@Component
public class BaseInfoServiceFallbackFactory implements FallbackFactory<BaseInfoService> {

	@Override
	public BaseInfoService create(Throwable cause) {
		return new BaseInfoService() {
			
			@Override
			public boolean checkUser(String username) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public List<Depart> findAllDepts(){
				return null;
			}
			
			
			public List<Position> findAllEmplyeePositions(){
				return null;
			}

			public List<OrgPosition> findAllOrgPositions(){
				return null;
			}

			@Override
			public Map<String, String> findEmailAndPhoneById(String userId) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public RemoteUser findBaseInfo(String paramString) {
				// TODO Auto-generated method stub
				return null;
			}

		};
	}

}
