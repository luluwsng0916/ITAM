package com.smc.core.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.smc.core.feign.service.DataFilterApiService;
import com.smc.core.service.ReadDataFilterCacheService;

@Service
public class ReadDataFilterCacheServiceImpl implements ReadDataFilterCacheService {
	
	@Autowired
	private DataFilterApiService dataFilterApiService;

	@Override
	@Cacheable(value = "authorityCache", key = "'user_role_data_authority_' + #userId", unless = "#result == null || #result.size() == 0", cacheManager = "cacheManagerCore")
	public Map<String, List<String>> findDataByUserId(String userId) {
		return dataFilterApiService.findDataByUserId(userId);
	}
}
