package com.smc.core.feign.factory;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.smc.core.feign.service.DataFilterApiService;

import feign.hystrix.FallbackFactory;

@Component
public class DataFilterApiServiceFallbackFactory implements FallbackFactory<DataFilterApiService> {
	
	@Override
	public DataFilterApiService create(Throwable cause) {
		return new DataFilterApiService() {
			@Override
			public Map<String, List<String>> findDataByUserId(String userId) {
				return null;
			}
		};
	}
}
