package com.smc.core.feign.service;

import com.smc.core.feign.FeignHeaderSupportConfig;
import com.smc.core.feign.factory.RoleApiServiceFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import java.util.Map;
import java.util.Set;

@FeignClient(name = "asset-management-system", path="/asset", fallbackFactory = RoleApiServiceFallbackFactory.class, configuration = FeignHeaderSupportConfig.class,contextId = "RoleApiService")
public interface RoleApiService{
	
	@RequestMapping(value = "/role/findRoleAndResource",method = RequestMethod.GET)
	public List<Map<String,String>> findRoleAndResource();
	
	@RequestMapping(value = "/user/findRoleById/{userId}",method = RequestMethod.GET)
	public Set<String> findRoleByUserId(@PathVariable(value = "userId") String userId);
	
}
