package com.smc.core.feign.service;

import com.smc.base.Depart;
import com.smc.base.OrgPosition;
import com.smc.base.Position;
import com.smc.base.RemoteUser;
import com.smc.core.feign.FeignHeaderSupportConfig;
import com.smc.core.feign.factory.BaseInfoServiceFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Map;

@Service
@FeignClient(name = "cloud-oa-service", path = "/oa", fallbackFactory = BaseInfoServiceFallbackFactory.class, configuration = {FeignHeaderSupportConfig.class}, url = "${oa.service}")
public interface BaseInfoService {

    @RequestMapping(value = {"/base/findByUserIdHavePassword/{userId}"}, method = {org.springframework.web.bind.annotation.RequestMethod.GET}, consumes = {"application/json"})
    public abstract RemoteUser findBaseInfo(@PathVariable("userId") String paramString);

    @RequestMapping(value = {"/base/checkUser/{userId}"}, method = {org.springframework.web.bind.annotation.RequestMethod.GET}, consumes = {"application/json"})
    public abstract boolean checkUser(@PathVariable("userId") String paramString);

    @RequestMapping(value = {"/base/findEmailAndPhoneById/{userId}"}, method = {org.springframework.web.bind.annotation.RequestMethod.GET}, consumes = {"application/json"})
    public abstract Map<String, String> findEmailAndPhoneById(@PathVariable("userId") String paramString);

    @RequestMapping(value = {"/base/findAllDepts"}, method = {org.springframework.web.bind.annotation.RequestMethod.POST}, consumes = {"application/json"})
    public abstract List<Depart> findAllDepts();

    @RequestMapping(value = {"/base/findAllEmplyeePositions"}, method = {org.springframework.web.bind.annotation.RequestMethod.GET}, consumes = {"application/json"})
    public abstract List<Position> findAllEmplyeePositions();

    @RequestMapping(value = {"/base/findAllOrgPositions"}, method = {org.springframework.web.bind.annotation.RequestMethod.GET}, consumes = {"application/json"})
    public abstract List<OrgPosition> findAllOrgPositions();

}
