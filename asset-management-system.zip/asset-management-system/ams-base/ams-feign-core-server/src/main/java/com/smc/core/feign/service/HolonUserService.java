package com.smc.core.feign.service;

import com.smc.base.Position;
import com.smc.base.TreeInfo;
import com.smc.core.feign.FeignHeaderSupportConfig;
import com.smc.core.feign.factory.HolonUserServiceFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

@FeignClient(name = "holon",path = "holon", fallbackFactory = HolonUserServiceFallbackFactory.class, configuration = FeignHeaderSupportConfig.class)
public interface HolonUserService {
	
	/**
	 * 获取所有部门，包括holon
	 * @return
	 */
	@RequestMapping(value = "/organ/findDepts",method = RequestMethod.GET)
	public List<TreeInfo> findDepts();
	
	/**
	 * 获取所有holon成员
	 * @return
	 */
	@RequestMapping(value = "/holonUser/findHolonMembers",method = RequestMethod.GET)
	public Map<String, List<String>> findHolonMembers();
	
	
	/**
	 * findParentListByPositionId:(获取上级（K3+Holon）). <br/> 
	 * @author SMC892Q  
	 * @param userId
	 * @param positionId
	 * @return
	 */
	@RequestMapping(value = "/organ/findParentListByPositionId",method = RequestMethod.GET)
	public List<Position> findParentListByPositionId(@RequestParam("userId") String userId, @RequestParam("positionId") String positionId);
	
	/**
	 * 获取部门与holon的map缓存，key为6位部门编码或者holon编码
	 * @return map
	 */
	@RequestMapping(value = "/organ/organsAndHolonMapCache",method = RequestMethod.GET)
	public Map<String, TreeInfo> organsAndHolonMapCache();

}
