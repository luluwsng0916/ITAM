package com.smc.core.feign.factory;

import org.springframework.stereotype.Component;

import com.smc.core.feign.service.RemoteLogService;

import feign.hystrix.FallbackFactory;

@Component
public class RemoteLogServiceFallbackFactory implements FallbackFactory<RemoteLogService> {

	@Override
	public RemoteLogService create(Throwable cause) {
		return null;
	}
}
