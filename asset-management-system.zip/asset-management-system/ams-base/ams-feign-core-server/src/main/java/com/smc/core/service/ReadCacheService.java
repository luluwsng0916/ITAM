package com.smc.core.service;

import java.util.List;
import java.util.Map;

import com.smc.base.Position;
import com.smc.base.TreeInfo;

public interface ReadCacheService {
	
	/**
	 * 获取所有部门与holon
	 * @return
	 */
	public List<TreeInfo> findDepts();
	
	/**
	 * 获取holon成员组成的map，可以为holon编码，或者负责人ID
	 * @return
	 */
	public Map<String, List<String>> findHolonMembers();
	
	/**
	 * 获取所有员工Employee对应的岗位postion
	 * @return
	 */
	public List<Position> findAllEmplyeePositions();
	
	/**
	 * 获取部门与holon的map缓存，key为6位部门编码或者holon编码
	 * @return map
	 */
	public Map<String, TreeInfo> organsAndHolonMapCache();
}
