package com.smc.core.service;

import com.smc.base.RemoteUser;

public interface ReadUserInfoCacheService {
    RemoteUser findByUsername(String username);
}
