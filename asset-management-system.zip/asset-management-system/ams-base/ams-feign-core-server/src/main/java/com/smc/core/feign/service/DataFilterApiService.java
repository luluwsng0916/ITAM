package com.smc.core.feign.service;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.smc.core.feign.FeignHeaderSupportConfig;
import com.smc.core.feign.factory.DataFilterApiServiceFallbackFactory;

@FeignClient(name = "core", path = "/manage", fallbackFactory = DataFilterApiServiceFallbackFactory.class, configuration = FeignHeaderSupportConfig.class,contextId = "DataFilterApiService")
public interface DataFilterApiService {

	@RequestMapping(value = "/dataFilter/findDataByUserId", method = RequestMethod.GET)
	public Map<String, List<String>> findDataByUserId(@RequestParam("userId") String userId);

}
