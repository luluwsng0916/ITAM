package com.smc.core.feign.factory;

import org.springframework.stereotype.Component;

import com.smc.base.UserInfo;
import com.smc.core.feign.service.UserInfoApiService;

import feign.hystrix.FallbackFactory;

@Component
public class UserInfoApiServiceFallbackFactory implements FallbackFactory<UserInfoApiService> {

	@Override
	public UserInfoApiService create(Throwable cause) {
		return new UserInfoApiService() {
			@Override
			public UserInfo findUserInfo(String username) {
				return null;
			}
		};
	}
}
