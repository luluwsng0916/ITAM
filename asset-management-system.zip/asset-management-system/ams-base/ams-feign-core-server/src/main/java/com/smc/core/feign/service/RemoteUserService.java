package com.smc.core.feign.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.smc.base.UserInfo;
import com.smc.core.feign.FeignHeaderSupportConfig;
import com.smc.core.feign.factory.RemoteUserServiceFallbackFactory;

@FeignClient(name = "asset-management-system", path="/asset", fallbackFactory = RemoteUserServiceFallbackFactory.class, configuration = FeignHeaderSupportConfig.class,contextId = "RemoteUserService")
public interface RemoteUserService{
	
	@RequestMapping(value = "/user/getUserInfo/{username}",method = RequestMethod.GET)
	public UserInfo findByUsername(@PathVariable(value="username") String username);
	
}
