package com.smc.core.feign.factory;



import com.smc.core.feign.service.InterfaceCloseCheckService;

import feign.hystrix.FallbackFactory;


public class InterfaceCloseCheckServiceFallbackFactory implements FallbackFactory<InterfaceCloseCheckService> {

	@Override
	public InterfaceCloseCheckService create(Throwable cause) {
		return new InterfaceCloseCheckService(){

			@Override
			public Boolean judgeMethodIsActive(String serviceId, String className, String methodName) {
				return false;
			}
			
		};
		
	}

}
