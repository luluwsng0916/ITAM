package com.smc.core.feign.factory;

import org.springframework.stereotype.Component;

import com.smc.core.feign.service.RemoteUserService;

import feign.hystrix.FallbackFactory;

@Component
public class RemoteUserServiceFallbackFactory implements FallbackFactory<RemoteUserService> {

	@Override
	public RemoteUserService create(Throwable cause) {
		return null;
	}
}
