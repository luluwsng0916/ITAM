package com.smc.core.feign.factory;

import com.smc.base.Position;
import com.smc.base.TreeInfo;
import com.smc.core.feign.service.HolonUserService;
import feign.hystrix.FallbackFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class HolonUserServiceFallbackFactory implements FallbackFactory<HolonUserService>  {

	@Override
	public HolonUserService create(Throwable arg0) {
		return new HolonUserService() {
			@Override
			public List<TreeInfo> findDepts() {
				return null;
			}

			@Override
			public Map<String, List<String>> findHolonMembers() {
				return null;
			}


			@Override
			public List<Position> findParentListByPositionId(String userId, String positionId) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Map<String, TreeInfo> organsAndHolonMapCache() {
				// TODO Auto-generated method stub
				return null;
			}
		};
	}

}
