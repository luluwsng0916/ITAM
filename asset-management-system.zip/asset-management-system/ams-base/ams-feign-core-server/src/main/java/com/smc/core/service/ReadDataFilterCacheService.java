package com.smc.core.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestParam;

public interface ReadDataFilterCacheService {
	
	public Map<String, List<String>> findDataByUserId(@RequestParam String userId);	

}
