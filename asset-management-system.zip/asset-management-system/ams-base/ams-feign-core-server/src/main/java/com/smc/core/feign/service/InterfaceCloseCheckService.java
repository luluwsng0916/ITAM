package com.smc.core.feign.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.smc.core.feign.FeignRequestInterceptor;
import com.smc.core.feign.factory.InterfaceCloseCheckServiceFallbackFactory;


@FeignClient(name = "core", path="/manage", 
			 fallbackFactory = InterfaceCloseCheckServiceFallbackFactory.class, 
			 configuration = FeignRequestInterceptor.class ,contextId = "InterfaceCloseCheckService")
public interface InterfaceCloseCheckService {

	/**
	 * 接口方法封闭的外部调用，判断当前方法是否可用
	 * 
	 * @author C31455
	 *
	 */
	@PostMapping(value = "/interfaceCloseCheck/judgeMethodIsActive")
	public Boolean judgeMethodIsActive(@RequestParam("serviceId")String serviceId, 
			@RequestParam("className")String className, @RequestParam("methodName")String methodName);
}
