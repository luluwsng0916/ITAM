package com.smc.core.service.impl;

import com.smc.base.RemoteUser;
import com.smc.core.feign.service.BaseInfoService;
import com.smc.core.service.ReadUserInfoCacheService;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @program: asset-management-system
 * @ClassName ReadUserInfoCacheServiceImpl
 * @description:
 * @author: C31909
 * @create: 2024-07-05 14:34
 * @Version 1.0
 **/
@Service
public class ReadUserInfoCacheServiceImpl implements ReadUserInfoCacheService {
    @Resource
    private BaseInfoService baseInfoService;

    public ReadUserInfoCacheServiceImpl() {
    }

    @Cacheable(
            value = {"k3_userInfo"},
            key = "#username",
            cacheManager = "cacheManagerOrgan"
    )
    public RemoteUser findByUsername(String username) {
        return this.baseInfoService.findBaseInfo(username);
    }
}
