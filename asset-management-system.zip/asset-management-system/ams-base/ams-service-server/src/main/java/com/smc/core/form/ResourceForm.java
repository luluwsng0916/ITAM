package com.smc.core.form;

public class ResourceForm extends TreeForm{
	
	private String pattern;

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
}
