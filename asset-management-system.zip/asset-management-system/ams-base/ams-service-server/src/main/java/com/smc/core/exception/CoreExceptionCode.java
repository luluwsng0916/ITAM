package com.smc.core.exception;

import com.smc.exception.BaseExceptionCode;

public class CoreExceptionCode extends BaseExceptionCode {

	/**
	 * 名称已存在
	 */
	public static String ROLE_NAME_EXISTS = "100101100";

	public static String 文件上传错误 = "2001001100";

	public static String 下载错误 = "2001001101";
}
