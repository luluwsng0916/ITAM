package com.smc.core.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Classname: InsertBatchForExcess
 * @Descripton: 解决批量插入数据库，参数超出限制的问题 sqlserver找到最优解决方案
 * @Author B82561
 */
public class InsertBatchForExcess {
	/**
	 * 解决批量插入数据库，参数超出2100限制的问题 sqlserver找到最优解决方案 InsertBatchBySqlserver
	 * 
	 * @param list
	 * @param T    集合内的实体对象类型
	 * @return Map(size： 总条数 , row： 每次能Insert的最多条数 , num： 分num次循环插入)
	 */
	public static <T> Map<String, Integer> InsertBatchBySqlserver(List<T> list, Class<T> T) {

		int size = list.size();// 总条数
		int row = 0;
		int count = T.getDeclaredFields().length;// 获取对象属性个数

		if (count <= 2) {
			count = 3;
		}
		// 由于sqlserver数据库一次参数不能超过2100个所以需要找到最优insert方法

		// 每次能insert的最多条数
		row = size * count < 2100 ? size : (int) (2100 / count - 1);

		// 分num次循环insert
		int num = size % row == 0 ? (int) size / row : (int) (size / row + 1);

		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("row", row);
		map.put("size", size);
		map.put("num", num);

		return map;

	}
}