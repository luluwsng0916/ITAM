package com.smc.core.condition;

public class UnreadUserDetailCondition {

	private String Username;

	private String supplierName;

	private String readStatus;

	public UnreadUserDetailCondition() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getReadStatus() {
		return readStatus;
	}

	public void setReadStatus(String readStatus) {
		this.readStatus = readStatus;
	}

	@Override
	public String toString() {
		return "UnreadUserDetailCondition [Username=" + Username + ", supplierName=" + supplierName + ", readStatus="
				+ readStatus + "]";
	}

}
