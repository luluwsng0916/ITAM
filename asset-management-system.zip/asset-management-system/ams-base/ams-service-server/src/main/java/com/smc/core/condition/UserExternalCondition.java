package com.smc.core.condition;

import com.smc.condition.Condition;

/**
 * 
 * ClassName: SupplierUserCondition <br/>  
 * Function:供应商用户表查询条件. <br/>  
 * Reason: TODO ADD REASON(可选). <br/>  
 * date: 2018年11月6日 下午2:01:57 <br/>  
 *  
 * @author SMC892Q  
 * @version   
 * @since JDK 1.8
 */
public class UserExternalCondition implements Condition {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3619149552740967699L;

	/**
	 *  用户名
	 */
	private String userName;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
}
