package com.smc.core.utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.smc.core.exception.CoreExceptionCode;
import com.smc.exception.BaseException;

public class FileDownLoad {

	public static Logger logger = LoggerFactory.getLogger(FileDownLoad.class);

	/**
	 * 文件下载
	 * 
	 * @Author B82561
	 * @param request
	 * @param response
	 * @param file
	 */
	public static void fileDownLoading(HttpServletRequest request, HttpServletResponse response, File file) {
		if (file.exists()) {
			response.setContentType("application/octet-stream");// 二进制流，不知道下载文件的类型
			response.setHeader("content-type", "application/octet-stream");// 让服务器告诉浏览器它发送的数据属于什么文件类型
			response.setHeader("Content-Disposition", "attachment;fileName=" + file.getName());// 设置文件名（这个信息头会告诉浏览器这个文件的名字和类型）
			byte[] buffer = new byte[1024];
			FileInputStream fis = null;// 文件输入流
			BufferedInputStream bis = null;// 带缓冲区的输入流
			OutputStream os = null;// 文件输出流
			try {
				fis = new FileInputStream(file);
				bis = new BufferedInputStream(fis);
				os = response.getOutputStream();
				int i = bis.read(buffer);
				while (i != -1) {
					os.write(buffer, 0, i);
					i = bis.read(buffer);
				}
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new BaseException(CoreExceptionCode.下载错误);
			} finally {
				try {
					if (bis != null) {
						bis.close();
					}

					if (fis != null) {
						fis.close();
					}
				} catch (IOException e) {
					logger.error(e.getMessage());
					throw new BaseException(CoreExceptionCode.下载错误);
				}
			}
		}
	}
}
