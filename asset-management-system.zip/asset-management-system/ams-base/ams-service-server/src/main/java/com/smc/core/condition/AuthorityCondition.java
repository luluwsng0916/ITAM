package com.smc.core.condition;

import com.smc.condition.Condition;

public class AuthorityCondition implements Condition{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5920529260275835793L;
	
	/**
	 * 类型: menu表示菜单，resource表示功能，common表示通用（默认绑定）
	 */
	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
