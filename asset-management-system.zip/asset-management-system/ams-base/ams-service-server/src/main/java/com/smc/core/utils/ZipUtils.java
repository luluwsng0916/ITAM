package com.smc.core.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



/**
 * ZipUtils
 * 压缩文件用到的工具类
 * @author Ren Hongyang
 * @date 2018/08/20
 * @version v1.0
 */

public class ZipUtils {

	private static final int BUFFER_SIZE = 2 * 1024;

	private static final Logger logger = LoggerFactory.getLogger(ZipUtils.class);

	/**
	 * 单个文件压缩成ZIP到同一路径 方法0
	 * 
	 * @param srcDir
	 *            压缩文件夹路径
	 * @param out
	 *            压缩文件输出流
	 * @param isKeepDirStructure
	 *            是否保留原来的目录结构,true:保留目录结构;
	 *            false:所有文件跑到压缩包根目录下(注意：不保留目录结构可能会出现同名文件,会压缩失败)
	 * @throws ZipException
	 *             压缩失败会抛出异常
	 */
	public static void toZip(String path, String fileName, boolean isKeepDirStructure) throws Exception {

		logger.info("准备压缩中………………………………………………");

		long start = System.currentTimeMillis();

		ZipOutputStream zos = null;

		String srcDir = path + fileName;

		int index = fileName.lastIndexOf(".");

		if (index <= 0) {

			throw new Exception("压缩文件时，文件名" + fileName + "异常！");
		}
		String fileSimpleName = fileName.substring(0, index);

		FileOutputStream outStream = null;

		try {

			File filePath = new File(path);

			if (!filePath.isDirectory()) {

				throw new Exception("压缩文件时，文件路径" + path + "不存在！");
			}

			File outFile = new File(path + fileSimpleName + ".zip");

			outStream = new FileOutputStream(outFile);

			zos = new ZipOutputStream(outStream);

			File sourceFile = new File(srcDir);

			compressSingleFile(sourceFile, zos, sourceFile.getName(), isKeepDirStructure);

			long end = System.currentTimeMillis();

			logger.info("压缩完成，耗时：" + (end - start) + " ms");

		} catch (FileNotFoundException e) {

			logger.error(e.getMessage(), e);

			throw new Exception("压缩文件时，csv文件" + srcDir + "不存在！");

		} finally {

			if (zos != null) {
				try {
					zos.close();
				} catch (IOException e) {

					logger.error(e.getMessage(), e);
				}
			}
		}

	}

	/**
	 * 压缩成ZIP 方法1
	 * 
	 * @param srcDir
	 *            压缩文件夹路径
	 * @param out
	 *            压缩文件输出流
	 * @param isKeepDirStructure
	 *            是否保留原来的目录结构,true:保留目录结构;
	 *            false:所有文件跑到压缩包根目录下(注意：不保留目录结构可能会出现同名文件,会压缩失败)
	 * @throws ZipException
	 */
	public static void toZip(String srcDir, OutputStream out, boolean isKeepDirStructure) throws Exception {

		long start = System.currentTimeMillis();
		ZipOutputStream zos = null;

		try {

			zos = new ZipOutputStream(out);
			File sourceFile = new File(srcDir);
			compress(sourceFile, zos, sourceFile.getName(), isKeepDirStructure);
			long end = System.currentTimeMillis();
			logger.info("压缩完成，耗时：" + (end - start) + " ms");

		} catch (IOException e) {

			logger.error("压缩文件时，发生异常" + e.getMessage(), e);

			throw new Exception("压缩文件时，发生异常" + e.getMessage());

		} finally {

			if (zos != null) {
				try {
					zos.close();
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}
		}

	}

	/**
	 * 压缩成ZIP 方法2
	 * 
	 * @param srcFiles
	 *            需要压缩的文件列表
	 * @param out
	 *            压缩文件输出流
	 * @throws ZipException
	 */
	public static void toZip(List<File> srcFiles, OutputStream out) throws Exception {
		long start = System.currentTimeMillis();
		ZipOutputStream zos = null;
		try {

			zos = new ZipOutputStream(out);

			for (File srcFile : srcFiles) {

				FileInputStream in = null;
				try {

					byte[] buf = new byte[BUFFER_SIZE];
					zos.putNextEntry(new ZipEntry(srcFile.getName()));
					int len;
					in = new FileInputStream(srcFile);

					while ((len = in.read(buf)) != -1) {
						zos.write(buf, 0, len);
					}

				} finally {

					if (zos != null) {
						zos.closeEntry();
					}

					if (in != null) {
						in.close();
					}

				}

			}

			long end = System.currentTimeMillis();

			logger.info("压缩完成，耗时：" + (end - start) + " ms");

		} catch (Exception e) {
			logger.error(e.getMessage(), e);

			throw new Exception("zip压缩时出现异常");

		} finally {

			if (zos != null) {
				try {
					zos.close();
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}
		}
	}

	/**
	 * 单个文件压缩
	 * 
	 * @param sourceFile
	 *            源文件
	 * @param zos
	 *            zip输出流
	 * @param name
	 *            压缩后的名称
	 * @param isKeepDirStructure
	 *            是否保留原来的目录结构,true:保留目录结构;
	 *            false:所有文件跑到压缩包根目录下(注意：不保留目录结构可能会出现同名文件,会压缩失败)
	 * @throws ZipException
	 */
	public static void compressSingleFile(File sourceFile, ZipOutputStream zos, String name, boolean isKeepDirStructure)
			throws Exception {
		byte[] buf = new byte[BUFFER_SIZE];

		if (!sourceFile.isFile()) {
			throw new Exception("压缩文件时没有找到可以压缩的文件！");
		}

		FileInputStream in = null;
		// 向zip输出流中添加一个zip实体，构造器中name为zip实体的文件的名字
		try {
			zos.putNextEntry(new ZipEntry(name));
			int len;
			// copy文件到zip输出流中
			in = new FileInputStream(sourceFile);

			while ((len = in.read(buf)) != -1) {

				zos.write(buf, 0, len);

			}
			// Complete the entry

		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage(), e);

		} finally {

			if (zos != null) {

				try {
					zos.closeEntry();
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					logger.error(e.getMessage(), e);
				}
			}

			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					logger.error(e.getMessage(), e);
				}
			}
		}

	}

	/**
	 * 递归压缩方法
	 * 
	 * @param sourceFile
	 *            源文件
	 * @param zos
	 *            zip输出流
	 * @param name
	 *            压缩后的名称
	 * @param isKeepDirStructure
	 *            是否保留原来的目录结构,true:保留目录结构;
	 *            false:所有文件跑到压缩包根目录下(注意：不保留目录结构可能会出现同名文件,会压缩失败)
	 * @throws IOException
	 * @throws ZipException
	 * @throws Exception
	 */
	public static void compress(File sourceFile, ZipOutputStream zos, String name, boolean isKeepDirStructure)
			throws IOException, Exception {

		if (sourceFile.isFile()) {

			compressSingleFile(sourceFile, zos, name, isKeepDirStructure);

		} else {

			File[] listFiles = sourceFile.listFiles();
			if (listFiles == null || listFiles.length == 0) {
				// 需要保留原来的文件结构时,需要对空文件夹进行处理
				if (isKeepDirStructure) {
					// 空文件夹的处理
					zos.putNextEntry(new ZipEntry(name + "/"));
					// 没有文件，不需要文件的copy
					zos.closeEntry();
					logger.error("该路径下" + sourceFile.getName() + "没有可以压缩的文件！");
				}

			} else {

				for (File file : listFiles) {
					// 判断是否需要保留原来的文件结构
					if (isKeepDirStructure) {
						// 注意：file.getName()前面需要带上父文件夹的名字加一斜杠,
						// 不然最后压缩包中就不能保留原来的文件结构,即：所有文件都跑到压缩包根目录下了
						compress(file, zos, name + "/" + file.getName(), isKeepDirStructure);
					} else {

						compress(file, zos, file.getName(), isKeepDirStructure);
					}

				}
			}
		}
	}

}
