package com.smc.core.condition;

import com.smc.condition.Condition;

public class UserRoleCondition  implements Condition{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5647624564005104460L;
	
	/**
	 * 描述
	 */
	private String description;
	
	/**
	 * 角色ID
	 */
	private String roleId;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
}
