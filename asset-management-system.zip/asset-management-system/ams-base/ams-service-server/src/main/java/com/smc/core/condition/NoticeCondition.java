package com.smc.core.condition;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

public class NoticeCondition {

	private String id;
	/**
	 * 标题
	 */
	private String heading;
	/**
	 * 读取数量
	 */
	private Integer readedNum;
	/**
	 * 可读总人数
	 */
	private Integer totalNotice;
	/**
	 * 发布人姓名
	 */
	private String createName;
	/**
	 * 接收人
	 */
	private String readedableUser;

	/**
	 * 发布时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date newsDate;
	/**
	 * 公告状态 草稿 draft、发布 published
	 */
	private String editStatus;
	/**
	 * 公告信息
	 */
	private String noticeContent;

	/**
	 * 接收用户名
	 */
	private List<String> readers;

	/**
	 * 读取状态
	 */
	private String readStatus;

	/**
	 * 开始日期
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date startDate;

	/**
	 * 结束日期
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = Shape.STRING, timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date endDate;

	private String username;

	public NoticeCondition() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getHeading() {
		return heading;
	}

	public void setHeading(String heading) {
		this.heading = heading;
	}

	public Integer getReadedNum() {
		return readedNum;
	}

	public void setReadedNum(Integer readedNum) {
		this.readedNum = readedNum;
	}

	public Integer getTotalNotice() {
		return totalNotice;
	}

	public void setTotalNotice(Integer totalNotice) {
		this.totalNotice = totalNotice;
	}

	public String getCreateName() {
		return createName;
	}

	public void setCreateName(String createName) {
		this.createName = createName;
	}

	public String getReadedableUser() {
		return readedableUser;
	}

	public void setReadedableUser(String readedableUser) {
		this.readedableUser = readedableUser;
	}

	public Date getNewsDate() {
		return newsDate;
	}

	public void setNewsDate(Date newsDate) {
		this.newsDate = newsDate;
	}

	public String getEditStatus() {
		return editStatus;
	}

	public void setEditStatus(String editStatus) {
		this.editStatus = editStatus;
	}

	public String getNoticeContent() {
		return noticeContent;
	}

	public void setNoticeContent(String noticeContent) {
		this.noticeContent = noticeContent;
	}

	public List<String> getReaders() {
		return readers;
	}

	public void setReaders(List<String> readers) {
		this.readers = readers;
	}

	public String getReadStatus() {
		return readStatus;
	}

	public void setReadStatus(String readStatus) {
		this.readStatus = readStatus;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		return "NoticeCondition [id=" + id + ", heading=" + heading + ", readedNum=" + readedNum + ", totalNotice="
				+ totalNotice + ", createName=" + createName + ", readedableUser=" + readedableUser + ", newsDate="
				+ newsDate + ", editStatus=" + editStatus + ", noticeContent=" + noticeContent + ", readers=" + readers
				+ ", readStatus=" + readStatus + ", startDate=" + startDate + ", endDate=" + endDate + ", username="
				+ username + "]";
	}

}
