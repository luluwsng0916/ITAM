package com.smc.core.condition;

import com.smc.condition.Condition;

public class RoleCondition implements Condition{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -763396787663678913L;

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
