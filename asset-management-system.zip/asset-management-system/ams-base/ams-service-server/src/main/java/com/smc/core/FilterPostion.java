
package com.smc.core;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@Component
@RefreshScope
@ConfigurationProperties(prefix = "filter.position")
public class FilterPostion {
	
	/**
	 * 需要过滤岗位的部门
 	 */
	private List<String> departs = new ArrayList<>();

	public List<String> getDeparts() {
		return departs;
	}

	public void setDeparts(List<String> departs) {
		this.departs = departs;
	}

}
