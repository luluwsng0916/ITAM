package com.smc.core.condition;

import com.smc.condition.Condition;

public class ResourceCondition implements Condition{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -763396787663678913L;

	private String name;
	
	private String pattern;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
}
