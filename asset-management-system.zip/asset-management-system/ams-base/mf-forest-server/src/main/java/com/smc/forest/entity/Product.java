package com.smc.forest.entity;

import java.util.Date;
import java.util.List;



public class Product {
	
	  	public String getBondMark() {
		return bondMark;
	}
	public void setBondMark(String bondMark) {
		this.bondMark = bondMark;
	}
	public String getGmark() {
		return gmark;
	}
	public void setGmark(String gmark) {
		this.gmark = gmark;
	}
	public String getFacGNo() {
		return facGNo;
	}
	public void setFacGNo(String facGNo) {
		this.facGNo = facGNo;
	}
	public String getCopGNo() {
		return copGNo;
	}
	public void setCopGNo(String copGNo) {
		this.copGNo = copGNo;
	}
	public String getCopGName() {
		return copGName;
	}
	public void setCopGName(String copGName) {
		this.copGName = copGName;
	}
	public String getCopGNameEn() {
		return copGNameEn;
	}
	public void setCopGNameEn(String copGNameEn) {
		this.copGNameEn = copGNameEn;
	}
	public String getCopGModel() {
		return copGModel;
	}
	public void setCopGModel(String copGModel) {
		this.copGModel = copGModel;
	}
	public String getgModel() {
		return gModel;
	}
	public void setgModel(String gModel) {
		this.gModel = gModel;
	}
	public String getCopGModelEn() {
		return copGModelEn;
	}
	public void setCopGModelEn(String copGModelEn) {
		this.copGModelEn = copGModelEn;
	}
	public String getUnitErp() {
		return unitErp;
	}
	public void setUnitErp(String unitErp) {
		this.unitErp = unitErp;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getFactorErp() {
		return factorErp;
	}
	public void setFactorErp(String factorErp) {
		this.factorErp = factorErp;
	}
	public String getDecPrice() {
		return decPrice;
	}
	public void setDecPrice(String decPrice) {
		this.decPrice = decPrice;
	}
	public String getCurr() {
		return curr;
	}
	public void setCurr(String curr) {
		this.curr = curr;
	}
	public String getNetWt() {
		return netWt;
	}
	public void setNetWt(String netWt) {
		this.netWt = netWt;
	}
	public String getSupplierCode() {
		return supplierCode;
	}
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}
	public String getCodeTS() {
		return codeTS;
	}
	public void setCodeTS(String codeTS) {
		this.codeTS = codeTS;
	}
	public String getFactory() {
		return factory;
	}
	public void setFactory(String factory) {
		this.factory = factory;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getLastUpdateTime() {
		return lastUpdateTime;
	}
	public void setLastUpdateTime(String lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}
	public String getTempOwner() {
		return tempOwner;
	}
	public void setTempOwner(String tempOwner) {
		this.tempOwner = tempOwner;
	}
	public String getgNo() {
		return gNo;
	}
	public void setgNo(String gNo) {
		this.gNo = gNo;
	}
	public String getFactor1() {
		return factor1;
	}
	public void setFactor1(String factor1) {
		this.factor1 = factor1;
	}
	public String getFactor2() {
		return factor2;
	}
	public void setFactor2(String factor2) {
		this.factor2 = factor2;
	}
		private String bondMark;
	    private String gmark;
	    private String facGNo;
	    private String copGNo;
	    private String copGName;
	    private String copGNameEn;
	    private String copGModel;
	    private String gModel;
	    private String copGModelEn;
	    private String unitErp;
	    private String unit;
	    private String factorErp;
	    private String decPrice;
	    private String curr;
	    private String netWt;
	    private String supplierCode;
	    private String codeTS;
	    private String factory;
	    private String note;
	    private String lastUpdateTime;
	    private String tempOwner;
	    private String gNo;
	    private String factor1;
	    private String factor2;

}
