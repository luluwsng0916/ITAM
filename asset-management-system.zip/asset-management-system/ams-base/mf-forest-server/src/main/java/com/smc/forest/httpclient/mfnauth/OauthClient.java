package com.smc.forest.httpclient.mfnauth;

import com.dtflys.forest.annotation.BaseRequest;
import com.dtflys.forest.annotation.Body;
import com.dtflys.forest.annotation.Request;

@BaseRequest(baseURL = "${mfnOathUrl}")
public interface OauthClient {
	@Request(
            url = "/oauth/token",
            type = "post",
            contentType="application/x-www-form-urlencoded",
            dataType="json"
    )
	String getToken(@Body("client_id") String clientId,
					@Body("client_secret") String clientSecret,
					@Body("grant_type") String grantType);
}
