package com.smc.forest.httpclient.buinterface;

import java.util.Map;

//@Component
public class TokinUtil {
//	
//	@Autowired
//	MyClient myClient;
	
//	@Value("${bu-interface.user}")
//	private String userString;
//	
//	@Value("${bu-interface.password}")
//	private String passwroString;
//	
	
	/**
	 * 获得一个远程tokin
	 * @return
	 */
//	public String getTokin() {
//		try {
//			Map<String, Object> jsonToMap = JsonUtil.jsonToMap(myClient.dataPost(userString, passwroString));
//			String tokenString = (String)jsonToMap.get("data");
//			return tokenString; 
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//			
//		}
//		return "系统错误，请联系IT部。";
//	}
	
}
