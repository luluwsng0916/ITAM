package com.smc.forest.httpclient.zhonghaigw;

import java.util.List;

import com.dtflys.forest.annotation.BaseRequest;
import com.dtflys.forest.annotation.DataObject;
import com.dtflys.forest.annotation.DataParam;
import com.dtflys.forest.annotation.DataVariable;
import com.dtflys.forest.annotation.Request;
import com.smc.forest.entity.Product;
import com.smc.forest.entity.User;


@BaseRequest(baseURL = "${zhurl}")
public interface ZHClient {
	 @Request(
	            url = "/session",
	            type = "post",
	            contentType="application/json",
	            dataType="json"
	    )
	    String getData(@DataParam("userno") String userno,@DataParam("password") String password);
	 
	 
	 
	 
	 	@Request(
	            url = "/pms/api/session",
	            type = "post",
	            contentType="application/json"
	    )
	    String getToken(@DataObject User user);
	 	
	 	
	 	@Request(
	 			url = "/gw-edi-up/api/open/v1/erpMat/insertErpMat",
	            type = "post",
	            contentType="application/json",
	            headers= {"Authorization:${token}"}
	 			)
	 	void insertErpMat(@DataObject Product product,@DataVariable("token") String token);
	 	

}
