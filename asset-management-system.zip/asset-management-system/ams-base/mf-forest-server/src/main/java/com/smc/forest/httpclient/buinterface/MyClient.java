package com.smc.forest.httpclient.buinterface;

import com.dtflys.forest.annotation.BaseRequest;
import com.dtflys.forest.annotation.Request;

//@BaseRequest(baseURL = "${mfUrl}")
public interface MyClient {
	 @Request(
	            url = "/auth2/getToken?appId=${0}&password=${1}",
	            type = "post"
	    )
	    String dataPost(String appId, String password);
}
