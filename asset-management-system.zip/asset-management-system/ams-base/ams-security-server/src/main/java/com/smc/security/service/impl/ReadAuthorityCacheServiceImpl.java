package com.smc.security.service.impl;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.smc.core.feign.service.RoleApiService;
import com.smc.security.service.ReadAuthorityCacheService;
import com.smc.security.service.SecurityMapService;

@Service
public class ReadAuthorityCacheServiceImpl implements ReadAuthorityCacheService{

	@Autowired
	private RoleApiService roleApiService;

	@Override
	@Cacheable(value = "authorityCache", key="'role_authority_resource'", unless = "#result == null || #result.size() == 0", cacheManager = "cacheManagerCore")
	public List<Map<String, String>> findRoleAndResource() {
		//SecurityMapService.requestMap = null;
		return roleApiService.findRoleAndResource();
	}
	
	@Override
	@Cacheable(value = "authorityCache", key = "'user_all_role_' + #userId", unless = "#result == null || #result.size() == 0", cacheManager = "cacheManagerCore")
	public Set<String> findRoleByUserId(String userId){
		return roleApiService.findRoleByUserId(userId);
	}
}
