package com.smc.security.service;

import org.springframework.security.core.Authentication;

import javax.servlet.http.HttpServletRequest;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: Mr.Yangxiufeng
 * Date: 2018-05-14
 * Time: 16:01
 */
public interface RbacAuthorityService {
    boolean hasPermission(HttpServletRequest request, Authentication authentication);
}
