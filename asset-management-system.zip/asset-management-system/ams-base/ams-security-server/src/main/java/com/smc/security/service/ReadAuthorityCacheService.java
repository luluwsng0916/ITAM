package com.smc.security.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface ReadAuthorityCacheService {
	
	public List<Map<String,String>> findRoleAndResource();
	
	public Set<String> findRoleByUserId(String userId);
	
}
