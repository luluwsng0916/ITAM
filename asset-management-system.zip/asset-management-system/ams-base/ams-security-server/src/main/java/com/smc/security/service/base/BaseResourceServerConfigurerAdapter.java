package com.smc.security.service.base;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.expression.OAuth2WebSecurityExpressionHandler;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.redis.RedisTokenStore;

public abstract class BaseResourceServerConfigurerAdapter extends ResourceServerConfigurerAdapter{
	
	@Autowired
	private FilterIgnoresUrlConfig filterIgnoresUrlConfig;
	
	@Autowired
    private OAuth2WebSecurityExpressionHandler expressionHandler;
    
    @Override
    public void configure(HttpSecurity http) throws Exception {
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        .and().cors();
        
        ExpressionUrlAuthorizationConfigurer<HttpSecurity>
		.ExpressionInterceptUrlRegistry registry = http
		.authorizeRequests();
        filterIgnoresUrlConfig.getUrls()
		.forEach(url -> registry.antMatchers(url).permitAll());
        registry.anyRequest().access("@rbacAuthorityService.hasPermission(request,authentication)");
    }
    
    @Bean
    public OAuth2WebSecurityExpressionHandler oAuth2WebSecurityExpressionHandler(ApplicationContext applicationContext) {
        OAuth2WebSecurityExpressionHandler expressionHandler = new OAuth2WebSecurityExpressionHandler();
        expressionHandler.setApplicationContext(applicationContext);
        return expressionHandler;
    }

    @Override
    public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
        resources.expressionHandler(expressionHandler);
    }
    
}
