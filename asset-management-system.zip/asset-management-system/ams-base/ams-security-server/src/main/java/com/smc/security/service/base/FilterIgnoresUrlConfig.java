
package com.smc.security.service.base;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@Component
@RefreshScope
@ConfigurationProperties(prefix = "ignores")
public class FilterIgnoresUrlConfig {

	/**
	 * 不被安全拦截的URL
	 */
	private List<String> urls = new ArrayList<>();

//	FilterIgnoresUrlConfig() {
//		urls.add("/gwverification/*");
//		urls.add("/gwimport/*");
//	}

	public List<String> getUrls() {
		return urls;
	}

	public void setUrls(List<String> urls) {
		this.urls = urls;
	}
}
