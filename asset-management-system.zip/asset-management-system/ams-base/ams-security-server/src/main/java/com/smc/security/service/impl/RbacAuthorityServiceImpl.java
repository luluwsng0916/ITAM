package com.smc.security.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

//import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Service;

import com.smc.exception.RestExceptionHandle;
import com.smc.security.service.RbacAuthorityService;
import com.smc.security.service.SecurityMapService;


/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: Mr.Yangxiufeng
 * Date: 2018-05-14
 * Time: 16:01
 */
@Service("rbacAuthorityService")
public class RbacAuthorityServiceImpl implements RbacAuthorityService {
	
	public static Logger logger = LoggerFactory.getLogger(RestExceptionHandle.class);
	
//	@Autowired
//	private ReadAuthorityCacheService readAuthorityCacheService;
	
	@Autowired
	private SecurityMapService securityMapService;

    @Override
    public boolean hasPermission(HttpServletRequest request, Authentication authentication) {
        Object principal = authentication.getPrincipal();
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        boolean hasPermission = false;
        if (principal != null){
            if (CollectionUtils.isEmpty(authorities)){
                return hasPermission;
            }
            
            Set<String> set = AuthorityUtils.authorityListToSet(authorities);
            String[] strings = new String[set.size()];
            set.toArray(strings);
            /**
             * 个人拥有的角色集合
             */
        	Collection<ConfigAttribute> configAttribute = SecurityConfig.createList(strings);
        	/**
        	 * 访问的url对应的角色集合
        	 */
        	Collection<ConfigAttribute> configAttributes = getAttributes(request);
        	if(CollectionUtils.isEmpty(configAttribute) || CollectionUtils.isEmpty(configAttributes))
        		return false;
        	configAttributes.retainAll(configAttribute);
        	hasPermission = !CollectionUtils.isEmpty(configAttributes);
        }

        return hasPermission;
    }
		
    public Collection<ConfigAttribute> getAttributes(HttpServletRequest request) {
    	
    	
//    	List<Map<String,String>> list = readAuthorityCacheService.findRoleAndResource();
//    	//if(SecurityMapService.requestMap == null)
////    		securityMapService.loadResourceDefine(list);
//
//    	
//        for (Map.Entry<RequestMatcher, Collection<ConfigAttribute>> entry : SecurityMapService.requestMap.entrySet()) {
//        	if (entry.getKey().matches(request)) {
//                return new ArrayList<ConfigAttribute>(entry.getValue());
//            }
//        }
//        return null;
    	
    	Map<String, Collection<ConfigAttribute>> requestMap	 = securityMapService.loadResourceDefine();
        for (Map.Entry<String, Collection<ConfigAttribute>> entry : requestMap.entrySet()) {
        	if (new AntPathRequestMatcher(entry.getKey()).matches(request)) {
                return new ArrayList<ConfigAttribute>(entry.getValue());
            }
        }
        return null;
    }
}
