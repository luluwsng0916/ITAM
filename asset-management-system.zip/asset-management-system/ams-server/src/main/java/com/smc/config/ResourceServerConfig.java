package com.smc.config;

import com.smc.security.service.base.BaseResourceServerConfigurerAdapter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.RemoteTokenServices;
import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;

/**  
 * ClassName:OAuth2ResourceConfig <br/>  
 * Function: TODO ADD FUNCTION. <br/>  
 * Reason:   TODO ADD REASON. <br/>  
 * Date:     2018年9月11日 下午4:59:41 <br/>  
 * @author   B82443  
 * @version    
 * @since    JDK 1.8  
 * @see        
 */
@Configuration
@EnableResourceServer
public class ResourceServerConfig extends BaseResourceServerConfigurerAdapter {

	/**
	 * 用于配置OAuth2的资源服务器，以远程方式验证令牌的有效性。
	 * 这些属性从应用的配置文件中动态获取，确保了配置的灵活性和安全性。
	 */
	@Value(value = "${security.oauth2.resource.token-info-uri}")
	private String checkTokenEndpointUrl;

	/**
	 * 客户端ID，用于识别调用OAuth2授权服务器的应用程序。
	 * 此ID在授权服务器上预先注册，用于验证和授权。
	 */
	@Value(value = "${security.oauth2.client.client-id}")
	private String clientId;

	/**
	 * 客户端密钥，用于对客户端ID进行验证，确保请求的合法性。
	 * 该密钥应当被安全地存储和传输，以防止泄露。
	 */
	@Value(value = "${security.oauth2.client.client-secret}")
	private String clientSecret;

	/**
	 * 配置并返回一个远程令牌服务实例，用于验证OAuth2令牌的有效性。
	 * 这个方法配置了远程令牌服务的基本URL、客户端ID和密钥，这些都是从应用的配置文件中动态获取的。
	 *
	 * @return RemoteTokenServices 一个配置好的远程令牌服务实例，可用于资源服务器验证令牌。
	 */
	@Bean
	public ResourceServerTokenServices remoteTokenServices(){
		// 创建并配置远程令牌服务实例
		// 使用远程服务请求授权服务器校验token
		RemoteTokenServices services = new RemoteTokenServices();
		services.setCheckTokenEndpointUrl(checkTokenEndpointUrl);
		services.setClientId(clientId);
		services.setClientSecret(clientSecret);
		return services;
	}

	@Override
    public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
		resources.resourceId("asset-management-system");
		resources.tokenServices(remoteTokenServices());
		super.configure(resources);
    }
}
  
