package com.smc;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.ldap.repository.config.EnableLdapRepositories;

/**
 * @author C31909
 */
@EnableLdapRepositories
@EnableEncryptableProperties
@SpringBootApplication
// @MapperScan(basePackages = {"com.smc.mapper.mdm", "com.smc.mapper.query", "com.smc.mapper.auth", "com.smc.mapper.core", "com.smc.mapper.asset"})
@MapperScan(basePackages = {"com.smc.mapper"})
@EnableFeignClients(basePackages = "com.smc.core.feign.service")
public class AssetManagementSystemServer {
    public static void main(String[] args) {
        SpringApplication.run(AssetManagementSystemServer.class, args);
    }
}
