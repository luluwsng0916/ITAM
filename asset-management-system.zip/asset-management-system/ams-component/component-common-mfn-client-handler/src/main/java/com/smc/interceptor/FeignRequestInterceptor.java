package com.smc.interceptor;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
//import com.smc.common.utils.ReflectionUtils;
import com.smc.forest.httpclient.mfnauth.OauthClient;
import com.smc.redis.RedisUtil;
//import com.google.gson.Gson;
//import com.smc.common.model.ClientDetails;
//import com.smc.common.util.HttpRequest;
//import com.smc.common.util.ThreadLocalMapUtil;
import com.smc.util.JsonUtil;

//import java.lang.reflect.Field;
import java.util.Enumeration;
//import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 微服务之间feign调用请求头丢失的问题
 * 加入微服务之间传递的唯一标识,便于追踪
 * 加入微服务Feign调用的用户认证，替换token
 * @author B92085
 *
 */
@Slf4j
public class FeignRequestInterceptor implements RequestInterceptor {
	/**
     * 微服务之间传递的唯一标识
     */
    private static final String X_REQUEST_ID = "X-RPC-Request-Id";
    
    public static final String GRANT_TYPE = "grant_type";
    public static final String CLIANT_CREDENTIALS = "client_credentials";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String CLIENT_ID = "client_id";
    public static final String TOKEN = "authorization";
    public static final String BIG_TOKEN = "Authorization";
    public static final String FEIGN_TOKEN_KEY = "feign_token_key";
    // token过期时间间隔 单位：秒
    public static final Integer EXPIRES_IN_SPAN = 60*10;
    
    @Value("${smc.feign.oauth2.client.clientId}")
    private String clientId;

    @Value("${smc.feign.oauth2.client.clientSecret}")
    private String clientSecret;
    
    @Value("${spring.application.name}")
    private String serviceId;
    
    @Value("${security.oauth2.client.access-token-uri}")
    private String accessTokenUri;
    
    @Autowired
    private OauthClient oauthClient;
    
    @Autowired
    private RedisUtil redisUtil;
    
    private String redisKey = "";
	
	@Override
	public void apply(RequestTemplate template) {
		
		  // fegintoken key 
		  redisKey = FEIGN_TOKEN_KEY + "-" + serviceId;
		  
		  HttpServletRequest request = getHttpServletRequest();
		  Map<String, String> headers = null;
		  if(request != null){
		      headers = getHeaders(request);
		      // 微服务之间传递的唯一标识
		      if (!headers.containsKey(X_REQUEST_ID)) {
	                 String sid = String.valueOf(UUID.randomUUID());
	                 template.header(X_REQUEST_ID, sid);
	          }		      
	      	  //传递所有请求头,防止部分丢失
	      	  Iterator<Map.Entry<String, String>> iterator = headers.entrySet().iterator();
	           while (iterator.hasNext()) {
	               Map.Entry<String, String> entry = iterator.next();
	               template.header(entry.getKey(), entry.getValue());
	           }
	           
	           log.info("Before1 FeignRequestInterceptor:{}",template.toString());

	       }	  
		log.info("Before FeignRequestInterceptor:{}",template.toString());
		
		// 更换token
		template.header(GRANT_TYPE, CLIANT_CREDENTIALS);
 	    template.header(CLIENT_ID, clientId);
 	    template.header(CLIENT_SECRET, clientSecret);
 	    
//		template.header(TOKEN, "Bearer " + getToken(clientId,clientSecret));
//		据head中的Authorization大小写区分来精确更新token
		String token = getToken(clientId,clientSecret);
	    if(boolAuthorizationKey(headers,TOKEN)){
	    	  template.header(TOKEN, token);
	       }else if(boolAuthorizationKey(headers,BIG_TOKEN)){
	    	  template.header(BIG_TOKEN, token);
	       }else{
	    	  template.header(TOKEN, token);
	       }
			 	        
	    log.info("After FeignRequestInterceptor:{}", template.toString());
	}
	
	/**
	 * 1、先从redis中获取
	 * 2、redis 没有在请求服务
	 * 3、判断根据阈值判断时效时间
	 * @return
	 */
	private String getToken(String clientId,String clientSecret){
		// 从redis中获取
		if(redisUtil.hasKey(this.redisKey)){
			return (String)redisUtil.get(this.redisKey);
		}
		// redis 没有在请求服务
		else{
			String token = oauthClient.getToken(clientId, clientSecret, CLIANT_CREDENTIALS);
			Map<String, Object> jsonToMap = null;
			try{
				jsonToMap = JsonUtil.jsonToMap(token);
				String access_token = (String)jsonToMap.get("access_token");
				Integer expires_in = (Integer)jsonToMap.get("expires_in");
				if(this.isSaveToReids(expires_in)){
					redisUtil.set(this.redisKey, access_token, expires_in-EXPIRES_IN_SPAN);
				}
				return access_token;
			}catch (Exception e) {
				e.printStackTrace();
				log.info("token 获取错误！");
			}
			
		}
		return "";
	}
	
	// 判断token是否存入redis
	private boolean isSaveToReids(Integer expiresIn ){
		if(expiresIn - EXPIRES_IN_SPAN > 0)
			return true;
		return false;
	}
	
	private HttpServletRequest getHttpServletRequest() {
	     try {
	         return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
	     } catch (Exception e) {
	          return null;
	     }
	}
	
	private Map<String, String> getHeaders(HttpServletRequest request) {
        Map<String, String> map = new LinkedHashMap<>();
        Enumeration<String> enumeration = request.getHeaderNames();
        if(enumeration!=null){
            while (enumeration.hasMoreElements()) {
                String key = enumeration.nextElement();
                String value = request.getHeader(key);
                map.put(key, value);
            }
        }
        return map;
    }
	
	private boolean boolAuthorizationKey(Map<String, String> headers,String authorization){
			return headers.get(authorization) != null?true:false;
	}
		
}
    

