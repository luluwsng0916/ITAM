package com.smc.conf;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.xxl.mq.client.factory.impl.XxlMqSpringClientFactory;

@Component
public class XxlMqConf {
	 // ---------------------- param ----------------------

    @Value("${xxl.mq.admin.address:http://10.116.1.234:9080/xxl-mq-admin}")
    private String adminAddress;
    @Value("${xxl.mq.accessToken:#{null}}")
    private String accessToken;

    
    @Bean
    public XxlMqSpringClientFactory getXxlMqConsumer(){

        XxlMqSpringClientFactory xxlMqSpringClientFactory = new XxlMqSpringClientFactory();
        xxlMqSpringClientFactory.setAdminAddress(adminAddress);
        xxlMqSpringClientFactory.setAccessToken(accessToken);

        return xxlMqSpringClientFactory;
    }
}
