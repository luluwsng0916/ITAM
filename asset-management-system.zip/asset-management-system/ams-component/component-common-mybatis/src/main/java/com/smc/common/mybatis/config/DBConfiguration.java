package com.smc.common.mybatis.config;

import com.baomidou.mybatisplus.extension.plugins.OptimisticLockerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
import com.smc.common.mybatis.ModelMetaObjectHandler;
import com.smc.common.mybatis.gen.SnowflakeIdGenerator;
import com.smc.common.mybatis.health.DbHealthIndicator;
import com.smc.common.mybatis.interceptor.MybatisSqlLogInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Slf4j
@Configuration
@EnableConfigurationProperties({ OpenIdGenProperties.class })
public class DBConfiguration {
	/**
	 * 雪花主键启动
	 * 
	 * @param properties
	 * @return
	 */
	@Bean
	@ConditionalOnMissingBean(OpenIdGenProperties.class)
	public SnowflakeIdGenerator snowflakeIdWorker(OpenIdGenProperties properties) {
		SnowflakeIdGenerator snowflakeIdGenerator = new SnowflakeIdGenerator(properties.getWorkId(),
				properties.getCenterId());
		log.info("bean [{}] properties [{}] 雪花主键 启动 ", snowflakeIdGenerator, properties);
		return snowflakeIdGenerator;
	}

	/**
	 * 自动填充模型数据
	 *
	 * @return
	 */
	@Bean
	public ModelMetaObjectHandler modelMetaObjectHandler() {
		ModelMetaObjectHandler modelMetaObjectHandler = new ModelMetaObjectHandler();
		log.info("bean [{}] 自动填充模型数据 启动。", modelMetaObjectHandler);
		return modelMetaObjectHandler;
	}


	/**
	 * 乐观锁插件
	 */
	@Bean
	public OptimisticLockerInterceptor optimisticLockerInterceptor(){
		OptimisticLockerInterceptor optimisticLockerInterceptor = new OptimisticLockerInterceptor();
		log.info("bean [{}] 乐观锁插件 启动。", optimisticLockerInterceptor);
		return optimisticLockerInterceptor;
	}
	
	/**
	 * SqlLog插件
	 */
	@Bean
	public MybatisSqlLogInterceptor mybatisSqlLogInterceptor(){
		MybatisSqlLogInterceptor mybatisSqlLogInterceptor = new MybatisSqlLogInterceptor();
		log.info("bean [{}] SqlLog插件 启动。", mybatisSqlLogInterceptor);
		return mybatisSqlLogInterceptor;
	}

	/**
	 * db 健康监控
	 * 
	 * @return
	 */
	@Bean
	@ConditionalOnMissingBean(DbHealthIndicator.class)
	public DbHealthIndicator dbHealthIndicator() {
		DbHealthIndicator dbHealthIndicator = new DbHealthIndicator();
		log.info("bean [{}]  db健康监控启动 启动", dbHealthIndicator);
		return dbHealthIndicator;
	}


	/**
	 * 分页插件
	 */
	// @Bean
	// public MybatisPlusInterceptor  mybatisPlusInterceptor() {
	// 	MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
	// 	interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
	// 	// 如果配置多个插件, 切记分页最后添加
	// 	// 如果有多数据源可以不配具体类型, 否则都建议配上具体的 DbType
	// 	return interceptor;
	// }

	/**
	 * 分页插件
	 */
	@Bean
	public PaginationInterceptor paginationInterceptor() {
		PaginationInterceptor paginationInterceptor = new PaginationInterceptor();
		log.info("bean [{}] 分页插件 启动。", paginationInterceptor);
		return paginationInterceptor;
	}
	
}
