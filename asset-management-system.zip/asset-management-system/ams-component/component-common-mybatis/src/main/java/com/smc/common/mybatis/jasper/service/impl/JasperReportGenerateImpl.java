package com.smc.common.mybatis.jasper.service.impl;

import com.smc.common.mybatis.jasper.service.ReportGenerate;
import com.smc.common.mybatis.jasper.utils.BasicParams;
import com.smc.common.mybatis.jasper.utils.Export;
import com.smc.common.mybatis.jasper.utils.FileType;
import com.smc.exception.BasicNullException;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


/**
 * @author B82002 对应Jasper的报表导出方法的实现，可导出pdf\word\excel格式
 */
public class JasperReportGenerateImpl implements ReportGenerate {
	//方法1，直接传递map集合，不需再转成map集合的方式并导出到浏览器下载
	public void exportToHttpWithMap(HttpServletResponse response, BasicParams basicParams, Map paremeters, List<?> data)
			throws Exception {
		Export export = new Export();
		validate(basicParams);
		export.exportBrowser(response, paremeters, basicParams, data);
	}

	// 验证基础元素值是否为空
	public void validate(BasicParams basicParams) throws BasicNullException {
		boolean flag = false;
		String message = "";
		if (basicParams.getTemplatePath() == null || basicParams.getTemplatePath().trim() == "") {
			message = message + "模板路径为空！ ";
			flag = true;
		}
		if (basicParams.getFileType() != FileType.PDF && basicParams.getFileType() != FileType.EXCEL
				&& basicParams.getFileType() != FileType.WORD) {
			message = message + "导出文件类型为空！ ";
			flag = true;
		}
		if (basicParams.getFileName() == null || basicParams.getFileName().trim() == ""
				|| basicParams.getFileName().trim() == " ") {
			message = message + "导出文件的文件名为空！";
			flag = true;
		}
		if (flag) {
			throw new BasicNullException(message);
		}
	}

}
