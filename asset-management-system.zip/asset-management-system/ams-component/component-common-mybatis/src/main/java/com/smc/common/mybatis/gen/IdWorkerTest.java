package com.smc.common.mybatis.gen;

import java.util.HashSet;
import java.util.Set;

public class IdWorkerTest {
	
    public static void main(String[] args) {
        Set<Long> set = new HashSet<Long>();
         //要单例
        final SnowflakeIdGenerator idWorker1 = new SnowflakeIdGenerator(1, 1);
        for(int x=0;x<31;x++){
        	Thread t1 = new Thread(new Runnable() {
				@Override
				public void run() {
					   while (true) {
			                for(int x=0;x<10000;x++){
			                    long id = idWorker1.nextId();
			                    System.out.println(Thread.currentThread().getId() +":" 
			                    +Thread.currentThread().getId() +":" + id);
			                    if (!set.add(id)) {
			                        System.out.println("duplicate:" + id);
			                    }
			                }
			            }	
				}
			});
            t1.setDaemon(true);
            t1.start();
        }
        
        for(int i = 0;i< 10000;i++){
        	System.out.println("last:" + idWorker1.nextId());
        }
        
    }
}
