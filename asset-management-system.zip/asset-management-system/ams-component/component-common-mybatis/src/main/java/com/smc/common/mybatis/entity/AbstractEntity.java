package com.smc.common.mybatis.entity;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.Version;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.smc.convert.easyexcel.DateConverter;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 实体类父类
 *
 * @author B92085
 */
@Data
public class AbstractEntity extends Model implements Serializable {
    private static final long serialVersionUID = 1L;

    // task表中的value字段时，为了防止发生冲突，需要这样操作
    // update task set value = newValue, version =  versionValue + 1 where version = versionValue;
    // 系统自动赋值
    @Version
    @ExcelIgnore
    @TableField(value = "version")
    private Integer version = 1;

    @TableField(value = "createdBy")
    @ExcelProperty(value = "创建者")
    private String createdBy;
    /**
     * 创建时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "createdTime", fill = FieldFill.INSERT)
    @ExcelProperty(value = "创建时间", converter = DateConverter.class)
    @ColumnWidth(25)
    public Date createdTime;

    @ExcelProperty(value = "更新者")
    @TableField(value = "updatedBy")
    private String updatedBy;

    /**
     * 修改时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "updatedTime", fill = FieldFill.INSERT_UPDATE)
    @ExcelProperty(value = "更新时间", converter = DateConverter.class)
    @ColumnWidth(25)
    public Date updatedTime;

    // 删除标记
    // 1：ture  正常
    // 0：false 标识已删除
    @ExcelIgnore
    @TableField(value = "deleteMark")
    private Integer deleteMark = 1;

    /**
     * 权限控制参数,不映射到数据库
     */
    @TableField(exist = false)
    @ExcelIgnore
    public Map<String, Object> params;

    public Map<String, Object> getParams() {
        if (params == null) {
            params = new HashMap<>();
        }
        return params;
    }

    public void setParams(Map<String, Object> params) {
        this.params = params;
    }

}
