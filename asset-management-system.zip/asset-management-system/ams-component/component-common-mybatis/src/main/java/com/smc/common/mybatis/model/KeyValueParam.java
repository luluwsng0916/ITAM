package com.smc.common.mybatis.model;

/**
 * @program: asset-management-system
 * @ClassName SelecctParams
 * @description:
 * @author: C31909
 * @create: 2024-08-06 16:38
 * @Version 1.0
 **/

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 键值对参数
 *
 * @author C31909
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KeyValueParam<T, R> {
    private T key;
    private R value;
}
