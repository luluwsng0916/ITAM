package com.smc.common.mybatis.jasper.utils;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author B82002
 *	反射获取bean对应的属性名称和值，写入map中并返回map
 * 反射成map类
 */
public class ReFlexObjectUtil {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	public Map<String, Object>  getKeyandValue(Object object){
		
		Map<String, Object> map = new HashMap<String,Object>();		
		//得到类对象
		Class inputClass = (Class)object.getClass();		
		//得到类中所有属性集合
		Field[] fields = inputClass.getDeclaredFields();		
		//循环写入map
		for(int i = 0; i < fields.length; i++) {
			Field field = fields[i];
			field.setAccessible(true);//设置属性是可以访问的
			Object value = new Object();
			try {
				value = field.get(object);
				map.put(field.getName(), value);//将键对值写入map
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		logger.debug("单个对象的所有键值反射成Map==" + map.toString());
		return map;
	}

}
