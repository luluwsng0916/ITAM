package com.smc.common.mybatis.annotation;

import java.lang.annotation.*;

/**
 * table别名
 * @author B92085
 *
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface TableAlias {
    String value();
}
