package com.smc.common.mybatis.page;


import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.utils.DateTimeUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * MyBatis 分页查询助手
 * @author smc
 * @date Jan 12, 2019
 */
public class MybatisPageHelperByPage {

	public static final String GETPAGERESULT = "getPageResult";
	/**
	 * 将分页信息封装到统一的接口
	 * @param pageRequest 
	 * @param page
	 * @return
	 */
	public static PageResult getPageResult(PageRequest pageRequest, HashMap<String, Object> hashmap) {
		PageResult pageResult = new PageResult();
        pageResult.setPageNum(pageRequest.getPageNum());
        pageResult.setPageSize(pageRequest.getPageSize());
        pageResult.setTotalSize((Integer)hashmap.get("rCount"));
        pageResult.setTotalPages((Integer) hashmap.get("pCount"));
        pageResult.setContent((List)hashmap.get("result"));
        List<Map> lists = (List)hashmap.get("result");
        for(Map map: lists) {
        	Date inventoryDate = (Date) map.get("盘点时间");
        	Date date = (Date) map.get("立会时间");
        	Date confirmDate = (Date) map.get("确认时间");
        	if(inventoryDate !=null ) {
	        	String strInventoryDate = DateTimeUtils.getDateTime(inventoryDate);
	        	map.put("盘点时间", strInventoryDate);
            }
        	if(date !=null ) {
	        	String strDate = DateTimeUtils.getDateTime(date);
	        	map.put("立会时间", strDate);
            }
        	if(confirmDate !=null ) {
	        	String strConfirmDate = DateTimeUtils.getDateTime(confirmDate);
	        	map.put("确认时间", strConfirmDate);
            }
        }
		return pageResult;
	}

}
