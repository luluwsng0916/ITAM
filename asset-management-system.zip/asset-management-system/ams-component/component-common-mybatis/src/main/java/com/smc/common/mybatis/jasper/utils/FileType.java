package com.smc.common.mybatis.jasper.utils;

/**
 * @author B82002
 *	枚举类型，包括PDF,WORD,EXCEL
 */
public enum FileType {
		PDF,WORD,EXCEL
}
