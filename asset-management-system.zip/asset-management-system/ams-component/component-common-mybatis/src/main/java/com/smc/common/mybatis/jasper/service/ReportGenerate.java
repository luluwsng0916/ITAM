package com.smc.common.mybatis.jasper.service;

import com.smc.common.mybatis.jasper.utils.BasicParams;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


/**
 * @author B82002
 * 报表导出的接口对象
 */
public interface ReportGenerate {
	//直接传递map集合，不需再转成map集合的方式并导出到浏览器下载
	public void exportToHttpWithMap(HttpServletResponse response, BasicParams basicParams, Map paremeters, List<?> data) throws Exception;
}
