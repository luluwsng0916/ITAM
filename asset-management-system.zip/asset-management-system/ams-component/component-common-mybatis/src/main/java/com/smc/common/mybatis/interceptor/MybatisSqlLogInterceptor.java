package com.smc.common.mybatis.interceptor;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.cache.CacheKey;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.ParameterMapping;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.type.TypeHandlerRegistry;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;

@Slf4j
@Intercepts({
		@Signature(type = Executor.class, method = "query", args = { MappedStatement.class, Object.class,
				RowBounds.class, ResultHandler.class }),
		@Signature(type = Executor.class, method = "query", args = { MappedStatement.class, Object.class,
				RowBounds.class, ResultHandler.class, CacheKey.class, BoundSql.class }),
		@Signature(type = Executor.class, method = "update", args = { MappedStatement.class, Object.class }) })
public class MybatisSqlLogInterceptor implements Interceptor {

private int MIN_SIZE = 0;
	
	private final ThreadLocal<SimpleDateFormat> df_yyyy_MM_dd_HH_mm_ss = new ThreadLocal<SimpleDateFormat>() {
		@Override
		protected SimpleDateFormat initialValue() {
			return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		}
	};
    
	@Override
	public Object intercept(Invocation invocation) throws Throwable {
		MappedStatement mappedStatement = (MappedStatement) invocation.getArgs()[0];
		Object parameter = null;
		if (invocation.getArgs().length > 1) {
			parameter = invocation.getArgs()[1];
		}
		String sqlId = mappedStatement.getId();
		BoundSql boundSql = mappedStatement.getBoundSql(parameter);
		Configuration configuration = mappedStatement.getConfiguration();

		long startTime = System.currentTimeMillis();
		Object result = null;
		try {
			result = invocation.proceed();
		} finally {
			try {
				long sqlCostTime = System.currentTimeMillis() - startTime;
				String sql = getSql(configuration, boundSql);
				formatSqlLog(mappedStatement.getSqlCommandType(), sqlId, sql, sqlCostTime, result);
			} catch (Exception ignored) {
				log.error("Failed to get SQL:{}",ignored);
			}
		}
		return result;
	}

	@Override
	public Object plugin(Object target) {
		return Plugin.wrap(target, this);
	}

	@Override
	public void setProperties(Properties properties) {
		if (properties == null) {
			return;
		}
		if (properties.containsKey("minLogSize")) {
			MIN_SIZE = Integer.valueOf(properties.getProperty("minLogSize"));
		}
	}

	private String getSql(Configuration configuration, BoundSql boundSql) {
		// 输入sql字符串空判断
		String sql = boundSql.getSql();
		if (StringUtils.isBlank(sql)) {
			return "";
		}

		// 美化sql
		sql = beautifySql(sql);

		// 填充占位符, 目前基本不用mybatis存储过程调用,故此处不做考虑
		Object parameterObject = boundSql.getParameterObject();
		List<ParameterMapping> parameterMappings = boundSql.getParameterMappings();
		if (!parameterMappings.isEmpty() && parameterObject != null) {
			TypeHandlerRegistry typeHandlerRegistry = configuration.getTypeHandlerRegistry();
			if (typeHandlerRegistry.hasTypeHandler(parameterObject.getClass())) {
				sql = this.replacePlaceholder(sql, parameterObject);
			} else {
				MetaObject metaObject = configuration.newMetaObject(parameterObject);
				for (ParameterMapping parameterMapping : parameterMappings) {
					if (metaObject.hasGetter(parameterMapping.getProperty())) {
						sql = replacePlaceholder(sql, metaObject.getValue(parameterMapping.getProperty()));
					} else if (boundSql.hasAdditionalParameter(parameterMapping.getProperty())) {
						sql = replacePlaceholder(sql, boundSql.getAdditionalParameter(parameterMapping.getProperty()));
					}
				}
			}
		}
		return sql;
	}

	private String beautifySql(String sql) {
		return sql.replaceAll("[\\s\n ]+", " ");
	}

	private String replacePlaceholder(String sql, Object parameterObject) {
		String result;
		if (parameterObject instanceof String) {
			result = "'" + parameterObject.toString() + "'";
		} else if (parameterObject instanceof Date) {
			result = "'" + df_yyyy_MM_dd_HH_mm_ss.get().format((Date) parameterObject) + "'";
		} else {
			if(parameterObject==null) {
				result = "NULL";
			}else {
				result = parameterObject.toString();
			}
		}
		return sql.replaceFirst("\\?", result);
	}

	private void formatSqlLog(SqlCommandType sqlCommandType, String sqlId, String sql, long costTime, Object obj) {
		String sqllog = String.format("DAO [%s]\n[%dms] ===> %s\n", sqlId, costTime, sql);

		if (sqlCommandType == SqlCommandType.UPDATE || sqlCommandType == SqlCommandType.INSERT
				|| sqlCommandType == SqlCommandType.DELETE) {
			sqllog += "Count ===> " + obj;
		}
		if (costTime > MIN_SIZE) {
			log.debug(sqllog);
		}
	}
}
