package com.smc.config.datascope.handler;

import com.smc.common.model.page.MoreParams;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.Param;
import com.smc.common.mybatis.entity.AbstractEntity;
import com.smc.config.datascope.common.Constants;
import com.smc.config.datascope.common.annotation.DataScope;
import com.smc.config.datascope.util.DataScopeUtil;
import com.smc.redis.RedisUtil;
import com.smc.utils.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 数据过滤处理
 *
 * @author C31455
 */
@Aspect
@Component
public class DataScopeAspect {

    /**
     * 数据权限过滤关键字
     */
    public static final String DATA_SCOPE = "dataScope";

    @Autowired
    private RedisUtil redisUtil;


    @Before("@annotation(dataScope)")
    public void doBefore(JoinPoint point, DataScope dataScope) throws Throwable {
        clearDataScope(point);
        handleDataScope(point, dataScope);
    }

    protected void handleDataScope(final JoinPoint joinPoint, DataScope dataScope) {
        // 获取当前的用户
        // 获取登录员工的编码
        String userId = DataScopeUtil.getUserIdForLogin();
        // 获取redisKey
        String key = Constants.REDIS_KEY + userId;

        //获取员工登录信息集合
        HashMap<String, Object> user = (HashMap<String, Object>) redisUtil.get(key);

        // 判断是否为管理员 如果是管理员查看所有数据
        if (StringUtils.isNotNull(user) && !DataScopeUtil.isAdmin(user)){
            dataScopeFilter(joinPoint, userId, user, dataScope);
        }
    }

    /**
     * 数据范围过滤
     *
     * @param joinPoint 切点
     * @param userId    用户编号
     * @param user      用户
     * @param dataScope targetAlias 目标表别名,deptAlias 部门别名,userAlias 用户别名,procAlias 工序别名
     */
    public void dataScopeFilter(JoinPoint joinPoint, String userId, HashMap<String, Object> user, DataScope dataScope) {
        // 获取目标字段, 用于判断表中是否存在该字段
        String targetField = "";
        StringBuilder sqlString = new StringBuilder();
        String uri = this.getUri();
        //获取数据权限数据
        Map<String, Object> scopeMap = DataScopeUtil.getDataType(user, uri);
        String dataType = (String) scopeMap.get("dataType");
        String customSql = (String) scopeMap.get("customSql");

        //自定义自己编写
        if (Constants.DATA_AUTHORITY_TYPE_BY_CUSTOM.equals(dataType)) {
            // 获取自定义sql的目标筛选字段  ,目前只进行简单校验，用于截取 逻辑判断符前的字段，判断查询字段是否存在
            Pattern pattern = Pattern.compile(".*(?i)(?>(>|=|<|>=|<=|!=|\\sin|\\slike\\s))");
            Matcher matcher = pattern.matcher(customSql);
            if(matcher.find()) {
                    // 获取目标字段, 用于判断表中是否存在该字段
                    String[] strList = customSql.split("\\s+");
                    targetField = strList[0];
                    sqlString.append(String.format(" OR %s.", dataScope.targetAlias())).append(customSql);
            }
        }//按工序
        else if (Constants.DATA_AUTHORITY_TYPE_BY_PROCESSCODE.equals(dataType)) {
            targetField = "processCode";
            sqlString.append(String.format(" OR %s.%s IN ( SELECT processCode FROM %s where PersonnelCode = %s) ", dataScope.targetAlias(), dataScope.processCodeAlias(), dataScope.procAlias(), userId));
        }
        //按员工
        else if (Constants.DATA_AUTHORITY_TYPE_BY_USER.equals(dataType)) {
            targetField = dataScope.userIdAlias();
            sqlString.append(String.format(" OR %s.%s = '%s' ", dataScope.targetAlias(), dataScope.userIdAlias(), userId));
        }
        //按部门
        else if (Constants.DATA_AUTHORITY_TYPE_BY_DEPT.equals(dataType)) {
            targetField = dataScope.deptCodeAlias();
            String deptCodes = "\'" + String.join("\',\'", (ArrayList<String>) user.get("deptCodes")) + "\'";
            sqlString.append(String.format(" OR %s.%s In (%s) ", dataScope.targetAlias(), dataScope.deptCodeAlias(), deptCodes));
        }
        //按部门及向下
        else if (Constants.DATA_AUTHORITY_TYPE_BY_DEPTSUB.equals(dataType)) {
            targetField = dataScope.deptCodeAlias();
            ArrayList<String> deptCodeList = (ArrayList<String>) user.get("deptCodeChilds");
            String deptCodes = "\'" + String.join("\',\'", deptCodeList + "\'");

            sqlString.append(String.format(" OR %s.%s in (%s)", dataScope.targetAlias(), dataScope.deptCodeAlias(), deptCodes));
        }

        if (StringUtils.isNotBlank(sqlString.toString())) {
            // 是否继承了基类
            for (Object params : joinPoint.getArgs()) {
                if (StringUtils.isNotNull(params) && params instanceof PageRequest) {
                    // 不为空截取OR 往下拼接条件
                    String template = sqlString.toString();
                    PageRequest pageRequest = (PageRequest) params;
                    List<Param> paramList = pageRequest.getParams();
                    List<MoreParams> moreParamList = pageRequest.getMoreParams();
                    Map<String, String> paramMap = new HashMap<>();
                    for (Param param : paramList) {
                        paramMap.put(param.getName(), param.getValue());
                    }
                    for (MoreParams param : moreParamList) {
                        paramMap.put(param.getColumnName(), param.getColumnValue());
                    }
                    sqlString = new StringBuilder(replacePlaceholders(template, paramMap));
                }
                if (StringUtils.isNotNull(params) && params instanceof AbstractEntity) {
                    // 不为空截取OR 往下拼接条件
                    AbstractEntity baseEntity = (AbstractEntity) params;
                    // 判断查询表中是否有该查询字段，没有则不过滤
                    if (hasFieldContainingString(baseEntity, targetField)) {
                        baseEntity.getParams().put(DATA_SCOPE, " AND (" + sqlString.substring(4) + ")");
                    }
                }
            }
        }
    }

    /**
     * @methodName replacePlaceholders
     * @description 正则替换预编译SQL #{xx}
     * @Param [template, params]
     * @return java.lang.String
     * @author C31455
     * @date 2024/6/17 
     **/
    public static String replacePlaceholders(String template, Map<String, String> params) {
        String regex = "#\\{(\\w+)\\}";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(template);

        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String paramName = matcher.group(1); // 获取参数名
            String paramValue = params.get(paramName); // 从参数映射中获取值
            if (paramValue != null) {
                paramValue = "'" + paramValue + "'";
                matcher.appendReplacement(sb, Matcher.quoteReplacement(paramValue));
            }
        }
        matcher.appendTail(sb);

        return sb.toString();
    }

    /**
     * 拼接权限sql前先清空params.dataScope参数防止注入
     */
    private void clearDataScope(final JoinPoint joinPoint) {
        if (joinPoint.getArgs() != null) {
            Object params = joinPoint.getArgs()[0];
            if (StringUtils.isNotNull(params) && params instanceof AbstractEntity) {
                AbstractEntity baseEntity = (AbstractEntity) params;
                baseEntity.getParams().put(DATA_SCOPE, "");
            }
        }
    }

    private String getUri() {
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        HttpServletRequest request = sra.getRequest();
//        String uri = request.getRequestURI();
        // 获取能够与项目根路径后的路径  /serverId/path, 只获取 /path
        return request.getServletPath();
    }

    /**
     * 是否存在该字段
     *
     * @param entity
     * @param targetString
     * @return
     */
    public boolean hasFieldContainingString(Object entity, String targetString) {

        Class<?> entityClazz = entity.getClass();
        Class<?> superClazz = entityClazz.getSuperclass();
        Field[] fields = entityClazz.getDeclaredFields();
        // 查询实体类是否有该字段
        for (Field field : fields) {
            if (field.getName().equalsIgnoreCase(targetString)) {
                return true;
            }
        }
        // 没有 则查询父类中是否有
        fields = superClazz.getDeclaredFields();
        for (Field field : fields) {
            if (field.getName().equalsIgnoreCase(targetString)) {
                return true;
            }
        }
        return false;
    }
}
