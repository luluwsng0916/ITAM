package com.smc.config.datascope.util;

import com.smc.config.datascope.common.Constants;
import com.smc.utils.StringUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class DataScopeUtil {
	
	private static HashMap<String,Integer> dataTypeMaps = null;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static boolean isAdmin(HashMap<String, Object> hm) {
		Set<String> roles = (Set<String>)hm.get("roles");
		for(String role : roles) {
			if(Constants.ADMIN.equals(role) || Constants.SUPER_ADMIN.equals(role)) {
				return true;
			}
		}
		return false;
	}
	
	public static String getUserIdForLogin() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		return (String) authentication.getPrincipal();
	}
	
	public static List<String> getDeptCode(HashMap<String, Object> hm){
		return (List<String>)hm.get("deptCodes");
	}
	
	/**
	 * 通过访问的url来判断数据访问类型
	 * 
	 * @param hm
	 * @param url
	 * @return
	 */
	public static HashMap<String,Object> getDataType(HashMap<String, Object> hm, String url) {
		HashMap<String,Object> map = new HashMap<>();
		// 初始化数据过滤类型为最低
		String dataType = String.valueOf(getLowLevel());
		List<HashMap<String,Object>> scopes = (List<HashMap<String,Object>>)hm.get("scope");
		for(HashMap<String,Object> scope:scopes) {
			// if(url.contains((String)scope.get("URI"))) {
			if(url.equals(scope.get("URI"))) {
				// 判断数据权限优先级
				dataType = getDataTypeLevel(dataType,(String)scope.get("DATA_TYPE"));
				map.put("customSql",scope.get("CUSTOM_SQL"));
//				if(dataType.equals(Constants.DATA_AUTHORITY_TYPE_ALL)) {
//					return Constants.DATA_AUTHORITY_TYPE_ALL;
//				}
			}
		}
		map.put("dataType",dataType);


		return map;

	}

	public static String getDataTypeByDept(HashMap<String, Object> hm) {
		// 初始化数据过滤类型为最低
		String dataType = String.valueOf(getLowLevel());
		dataType = getDataTypeLevel(dataType,"3");
		return dataType;
	}

	public static String getDataTypeByDeptChild(HashMap<String, Object> hm) {
		// 初始化数据过滤类型为最低
		String dataType = String.valueOf(getLowLevel());
		dataType = getDataTypeLevel(dataType,"4");
		return dataType;
	}

	public static String getDataTypeByCustomSql(HashMap<String, Object> hm) {
		// 初始化数据过滤类型为最低
		String dataType = String.valueOf(getLowLevel());
		dataType = getDataTypeLevel(dataType,"0");
		return dataType;
	}

	public static String getDataTypeByProcessCode(HashMap<String, Object> hm) {
		// 初始化数据过滤类型为最低
		String dataType = String.valueOf(getLowLevel());
		dataType = getDataTypeLevel(dataType,"1");
		return dataType;
	}


	/**
	 * 判断数据权限优先级
	 * @param oldDataType
	 * @param dataType
	 * @return
	 */
	public static String getDataTypeLevel(String oldDataType,String dataType) {
		// 未设置数据权限为查询全部
		if(StringUtils.isEmpty(dataType)) {
			return Constants.DATA_AUTHORITY_TYPE_ALL;
		}
		
		// 初始化数据权限优先级map
		initDataTypeLevelMap();
		
		// 优先级比较
		Integer old = dataTypeMaps.get(oldDataType);
		Integer xin = dataTypeMaps.get(dataType);
		
		if(old>xin) {
			return dataType;
		}else {
			return oldDataType;
		}
	}
	
	public static void initDataTypeLevelMap() {
		if(dataTypeMaps == null) {
			dataTypeMaps = new HashMap<String,Integer>();
		}
		
		// 自定义权限>工序>人员>本部门>部门及向下>全部数据
		
		dataTypeMaps.put(Constants.DATA_AUTHORITY_TYPE_BY_CUSTOM, 0);   // 自定义
		dataTypeMaps.put(Constants.DATA_AUTHORITY_TYPE_BY_PROCESSCODE, 1);   // 按工序
		dataTypeMaps.put(Constants.DATA_AUTHORITY_TYPE_BY_USER, 2);   // 按人员
		dataTypeMaps.put(Constants.DATA_AUTHORITY_TYPE_BY_DEPT, 3);   // 按本部门
		dataTypeMaps.put(Constants.DATA_AUTHORITY_TYPE_BY_DEPTSUB, 4);   // 按本部门及向下
		dataTypeMaps.put("5", 999);  // 全部数据
		dataTypeMaps.put(Constants.DATA_AUTHORITY_TYPE_ALL, 999);  // 全部数据
		
	}
	
	private static Integer getLowLevel() {
		initDataTypeLevelMap();
		return dataTypeMaps.get(Constants.DATA_AUTHORITY_TYPE_ALL);
	}
}
