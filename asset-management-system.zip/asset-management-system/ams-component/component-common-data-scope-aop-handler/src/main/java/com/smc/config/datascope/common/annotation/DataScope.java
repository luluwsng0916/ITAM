package com.smc.config.datascope.common.annotation;

import java.lang.annotation.*;

/**
 * 数据权限过滤注解 传入的参数需要带有目标表对象
 * @sqlNote 在where的结尾加上${params.dataScope};
 * @1. 按员工 需指定 当前操作表名targetAlias, 代表用户ID的字段名 userIdAlias ;
 * @2. 按工序 需指定 当前操作表名targetAlias, 表中对应工序代码字段名processCodeAlias,工序与用户关系表名 procAlias ;
 * @3. 按部门 需指定 当前操作表名targetAlias 以及表中对应部门代码字段名部门表名 deptCodeAlias, 部门表名deptAlias;
 * @4. 按部门及向下 需指定 当前操作表名targetAlias， 以及表中对应部门代码字段名部门表名 deptCodeAlias , 部门表名deptAlias;
 * @author C31455
 * 
 * @DataScope(deptAlias="dept",userAlias=""user",userIdAlias="operator")
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface DataScope
{
    /**
     * 当前数据表的别名
     */
    String targetAlias() default "";
    /**
     * 部门表的别名
     */
    String deptAlias() default "MdmDept";

    /**
     * 目标表对应的部门代码字段名
     */
    String deptCodeAlias() default "deptCode";

    /**
     * 用户表的别名
     */
    String userAlias() default "MdmUser";

    /**
     * 目标表对应的用户id字段名
     */
    String userIdAlias() default "createdBy";

    /**
     * 工序表的别名
     */
    String procAlias() default "MdmUserProcessCode";

    /**
     * 目标表对应的工序字段名
     */
    String processCodeAlias() default "processCode";



}
