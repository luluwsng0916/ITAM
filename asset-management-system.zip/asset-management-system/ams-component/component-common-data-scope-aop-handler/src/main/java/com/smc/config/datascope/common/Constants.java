package com.smc.config.datascope.common;

public interface Constants {
	
	// 按自定义
	public static final String DATA_AUTHORITY_TYPE_BY_CUSTOM = "0";
	// 按工序
	public static final String DATA_AUTHORITY_TYPE_BY_PROCESSCODE = "1";
	// 按员工
	public static final String DATA_AUTHORITY_TYPE_BY_USER = "2";
	// 按本部门
	public static final String DATA_AUTHORITY_TYPE_BY_DEPT = "3";
	// 按本部门及向下
	public static final String DATA_AUTHORITY_TYPE_BY_DEPTSUB = "4";
	// 全部数据
	public static final String DATA_AUTHORITY_TYPE_ALL = "999";
	
	public static final String ADMIN = "管理员";
	public static final String SUPER_ADMIN = "超级管理员";
	public static final String REDIS_KEY = "DataScope-";

	String DATA_SCOPE = "dataScope";
}
