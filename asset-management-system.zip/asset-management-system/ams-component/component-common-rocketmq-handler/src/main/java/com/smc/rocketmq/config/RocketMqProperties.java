package com.smc.rocketmq.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * @author B92085
 */
@Data
@ConfigurationProperties("rocketmq")
public class RocketMqProperties {

    private String nameServer = "";
    private String instanceName = "";
    /**
     * 普通生成者
     */
    private String defaultProducer = "";
    private String transactionProducer = "";
    /**
     * 普通消费者
     */
    private String defaultConsumer = "";
    /**
     * 顺序消费者
     */
    private String orderConsumer = "";

    private Set<String> defaultTopic = new LinkedHashSet<>();

    private Set<String> orderTopic = new LinkedHashSet<>();

}