package com.smc.rocketmq.config;


import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.client.producer.LocalTransactionState;
import org.apache.rocketmq.client.producer.TransactionMQProducer;
import org.apache.rocketmq.common.consumer.ConsumeFromWhere;
import org.apache.rocketmq.common.message.MessageExt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Set;

/**
 * @author B92085
 */
@Slf4j
@Configuration
@EnableConfigurationProperties(RocketMqProperties.class)
public class RocketMqConfiguration {

    @Autowired
    private RocketMqProperties rmqProperties;

    @Autowired
    private ApplicationEventPublisher publisher;

    /**
     * 发送普通消息
     */
    @Bean(name = "default")
    public DefaultMQProducer defaultMQProducer() throws MQClientException {
        DefaultMQProducer producer = new DefaultMQProducer(rmqProperties.getDefaultProducer());
        producer.setNamesrvAddr(rmqProperties.getNameServer());
        producer.setInstanceName(rmqProperties.getInstanceName());
        producer.setVipChannelEnabled(false);
        producer.start();
        log.info("DefaultMQProducer is Started.");
        return producer;
    }

    /**
     * 发送事务消息
     */
    @SuppressWarnings("deprecation")
    @Bean(name = "trans")
    public TransactionMQProducer transactionMQProducer() throws MQClientException {
        TransactionMQProducer producer = new TransactionMQProducer(rmqProperties.getTransactionProducer());
        producer.setNamesrvAddr(rmqProperties.getNameServer());
        producer.setInstanceName(rmqProperties.getInstanceName());
        producer.setTransactionCheckListener((MessageExt msg) -> {
            log.info("事务回查机制！");
            return LocalTransactionState.COMMIT_MESSAGE;
        });
        // 事务回查最小并发数
        producer.setCheckThreadPoolMinSize(2);
        // 事务回查最大并发数
        producer.setCheckThreadPoolMaxSize(5);
        // 队列数
        producer.setCheckRequestHoldMax(2000);
        producer.start();
        log.info("TransactionMQProducer is Started.");
        return producer;
    }

    /**
     * 消费者
     */
    @Bean("defaultConsumer")
    public DefaultMQPushConsumer pushConsumer() throws MQClientException {
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(rmqProperties.getDefaultConsumer());
        // Specify name server addresses.
        consumer.setNamesrvAddr(rmqProperties.getNameServer());

        // Subscribe one more more topics to consume.
        Set<String> setTopic = rmqProperties.getDefaultTopic();
        for (String topic : setTopic) {
            consumer.subscribe(topic, "*");
        }

        //
        consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET);

        //
        consumer.setConsumeMessageBatchMaxSize(1);
//		consumer.registerMessageListener(new MessageListenerConcurrently(){
//
//			@Override
//			public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
//				MessageExt msg = null;
//				try {
//					msg = msgs.get(0);
//					publisher.publishEvent(new RocketMqEvent(msg, consumer));
//				} catch (Exception e) {
//					if (msg.getReconsumeTimes() <= 1) {
//					return ConsumeConcurrentlyStatus.RECONSUME_LATER;
//					} else {
//						log.info("定时重试！");
//					}
//				}
//				return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
//			}
//			
//		});
//		consumer.registerMessageListener((MessageListenerConcurrently)(List<MessageExt> msgs, ConsumeConcurrentlyContext context) -> {
//			MessageExt msg = null;
//			try {
//				msg = msgs.get(0);
//				publisher.publishEvent(new RocketMqEvent(msg, consumer));
//			} catch (Exception e) {
//				if (msg.getReconsumeTimes() <= 1) {
//				return ConsumeConcurrentlyStatus.RECONSUME_LATER;
//				} else {
//					log.info("定时重试！");
//				}
//			}
//			return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
//		});
//		new Thread(() -> {
//			try {
//				Thread.sleep(3000);
//				consumer.start();
//				log.info("普通消费开启...");
//			} catch (InterruptedException | MQClientException e) {
//				log.error("普通消费开启失败:", e);
//			}
//		}).start();
        log.info("普通消费已初始化...");
        return consumer;
    }

    /**
     * 顺序消费者
     */
    @Bean("orderConsumer")
    public DefaultMQPushConsumer pushOrderConsumer() throws MQClientException {
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(rmqProperties.getOrderConsumer());
        Set<String> setTopic = rmqProperties.getOrderTopic();
        for (String topic : setTopic) {
            consumer.subscribe(topic, "*");
        }
        consumer.setNamesrvAddr(rmqProperties.getNameServer());
        consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET);
        consumer.setConsumeMessageBatchMaxSize(1);
//		consumer.registerMessageListener((MessageListenerOrderly)(List<MessageExt> msgs, ConsumeOrderlyContext context) -> {
//			MessageExt msg = null;
//			try {
//				msg = msgs.get(0);
//				publisher.publishEvent(new RocketMqEvent(msg, consumer));
//			} catch (Exception e) {
//				if (msg.getReconsumeTimes() <= 1) {
//					return ConsumeOrderlyStatus.SUCCESS;
//				} else {
//					log.info("定时重试！");
//				}
//			}
//			return ConsumeOrderlyStatus.SUCCESS;
//		});
//		new Thread(() -> {
//			try {
//				Thread.sleep(3000);
//				consumer.start();
//				log.info("顺序消费开启...");
//			} catch (InterruptedException | MQClientException e) {
//				log.error("顺序消费开启失败:", e);
//			}
//		}).start();
        log.info("顺序消费已初始化...");
        return consumer;
    }

}
