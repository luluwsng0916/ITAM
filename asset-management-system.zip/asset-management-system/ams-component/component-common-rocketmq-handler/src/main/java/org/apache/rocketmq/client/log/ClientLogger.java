package org.apache.rocketmq.client.log;

import org.apache.rocketmq.logging.InnerLoggerFactory.InnerLogger;
import org.apache.rocketmq.logging.InternalLogger;
import org.apache.rocketmq.logging.InternalLoggerFactory;
import org.apache.rocketmq.logging.inner.Appender;
import org.apache.rocketmq.logging.inner.Layout;
import org.apache.rocketmq.logging.inner.Level;
import org.apache.rocketmq.logging.inner.Logger;
import org.apache.rocketmq.logging.inner.LoggingBuilder;

public class ClientLogger {
	public static final String CLIENT_LOG_USESLF4J = "rocketmq.client.logUseSlf4j";
    public static final String CLIENT_LOG_ROOT = "rocketmq.client.logRoot";
    public static final String CLIENT_LOG_MAXINDEX = "rocketmq.client.logFileMaxIndex";
    public static final String CLIENT_LOG_FILESIZE = "rocketmq.client.logFileMaxSize";
    public static final String CLIENT_LOG_LEVEL = "rocketmq.client.logLevel";
    public static final String CLIENT_LOG_ADDITIVE = "rocketmq.client.log.additive";
    public static final String CLIENT_LOG_FILENAME = "rocketmq.client.logFileName";
    public static final String CLIENT_LOG_ASYNC_QUEUESIZE = "rocketmq.client.logAsyncQueueSize";
    public static final String ROCKETMQ_CLIENT_APPENDER_NAME = "RocketmqClientAppender";
    private static final InternalLogger CLIENT_LOGGER;
    private static final boolean CLIENT_USE_SLF4J = Boolean.parseBoolean(System.getProperty("rocketmq.client.logUseSlf4j", "false"));
    private static Appender rocketmqClientAppender = null;


    public ClientLogger() {
    }


    private static synchronized void createClientAppender() {
        String clientLogRoot = System.getProperty("rocketmq.client.logRoot", System.getProperty("user.home") + "/logs/rocketmqlogs");
        String clientLogMaxIndex = System.getProperty("rocketmq.client.logFileMaxIndex", "10");
        String clientLogFileName = System.getProperty("rocketmq.client.logFileName", "rocketmq_client.log");
        String maxFileSize = System.getProperty("rocketmq.client.logFileMaxSize", "1073741824");
        String asyncQueueSize = System.getProperty("rocketmq.client.logAsyncQueueSize", "1024");
        String logFileName = clientLogRoot + "/" + clientLogFileName;
        int maxFileIndex = Integer.parseInt(clientLogMaxIndex);
        int queueSize = Integer.parseInt(asyncQueueSize);
        Layout layout = LoggingBuilder.newLayoutBuilder().withDefaultLayout().build();
        rocketmqClientAppender = LoggingBuilder.newAppenderBuilder().withRollingFileAppender(logFileName, maxFileSize, maxFileIndex).withAsync(false, queueSize).withName("RocketmqClientAppender").withLayout(layout).build();
        Logger.getRootLogger().addAppender(rocketmqClientAppender);
    }


    private static InternalLogger createLogger(String loggerName) {
        String clientLogLevel = System.getProperty("rocketmq.client.logLevel", "INFO");
        boolean additive = "true".equalsIgnoreCase(System.getProperty("rocketmq.client.log.additive"));
        InternalLogger logger = InternalLoggerFactory.getLogger(loggerName);
        InnerLogger innerLogger = (InnerLogger) logger;
        Logger realLogger = innerLogger.getLogger();
        if (rocketmqClientAppender == null) {
            createClientAppender();
        }


        realLogger.addAppender(rocketmqClientAppender);
        realLogger.setLevel(Level.toLevel(clientLogLevel));
        realLogger.setAdditivity(additive);
        return logger;
    }


    public static InternalLogger getLog() {
        return CLIENT_LOGGER;
    }


    static {
        InternalLoggerFactory.setCurrentLoggerType("inner");
        CLIENT_LOGGER = createLogger("RocketmqClient");
        createLogger("RocketmqCommon");
        createLogger("RocketmqRemoting");
    }
}
