package com.smc.constant;

public interface Constants {
	// LOCK
	public static final String LOCK = "LOCK";
	// Day
	public static final int DAY = 60*60*24;
	// Week
	public static final int WEEK = 60*60*24*7;
	
	// Í¨ÓÃ´úÂëÏà¹ØµÄ;
	public static final String UNIVERSALCODE = "UNIVERSALCODE_";
	
}
