package com.smc.redis;

import com.smc.redis.config.IgnoreExceptionCacheErrorHandler;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.annotation.JsonAutoDetect;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * redis配置类
 * 
 * @author B92085
 * @date 2023-02-28
 * 
 */
@Configuration
@EnableCaching
public class RedisConfig extends CachingConfigurerSupport {

	/**
	 * 缓存失效时间
	 */
	public final static Integer DEFAULT_OF_SECONDS = 60 * 60 * 24 * 7;

	/**
	 * 用户缓存失效时间
	 */
	public final static Integer K3_USERINFO_OF_SECONDS = 60 * 3;

	@Override
	public CacheErrorHandler errorHandler() {
		return new IgnoreExceptionCacheErrorHandler();
	}

	private Map<String, RedisCacheConfiguration> getRedisCacheConfigurationMap(Integer seconds) {
		Map<String, RedisCacheConfiguration> redisCacheConfigurationMap = new HashMap<>();
		redisCacheConfigurationMap.put("k3_userInfo", this.getRedisCacheConfigurationWithTtl(seconds));
		return redisCacheConfigurationMap;
	}

	private RedisCacheConfiguration getRedisCacheConfigurationWithTtl(Integer seconds) {
		RedisCacheConfiguration redisCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig()
				.entryTtl(Duration.ofSeconds(seconds));
		return redisCacheConfiguration;
	}

	@Bean
	@ConfigurationProperties(prefix = "spring.redis.lettuce.pool")
	@Scope(value = "prototype")
	public GenericObjectPoolConfig redisPool(){
		return new GenericObjectPoolConfig();
	}

	@Bean
	@ConfigurationProperties(prefix = "spring.redis.redis-token")
	public RedisStandaloneConfiguration redisConfigToken(){
		return new RedisStandaloneConfiguration();
	}

	@Bean
	@ConfigurationProperties(prefix = "spring.redis.redis-core")
	public RedisStandaloneConfiguration redisConfigCore(){
		return new RedisStandaloneConfiguration();
	}

	@Bean
	@ConfigurationProperties(prefix = "spring.redis.redis-organ")
	public RedisStandaloneConfiguration redisConfigOrgan(){
		return new RedisStandaloneConfiguration();
	}

	@Bean
	@ConfigurationProperties(prefix = "spring.redis.redis-mf")
	public RedisStandaloneConfiguration redisConfigBusiness(){
		return new RedisStandaloneConfiguration();
	}

	@Bean
	@Primary
	public LettuceConnectionFactory factoryToken(){
		GenericObjectPoolConfig config = redisPool();
		LettuceClientConfiguration clientConfiguration = LettucePoolingClientConfiguration.builder()
				.poolConfig(config).commandTimeout(Duration.ofMillis(config.getMaxWaitMillis())).build();
		return new LettuceConnectionFactory(redisConfigToken(), clientConfiguration);
	}

	@Bean
	public LettuceConnectionFactory factoryCore(){
		GenericObjectPoolConfig config = redisPool();
		LettuceClientConfiguration clientConfiguration = LettucePoolingClientConfiguration.builder()
				.poolConfig(config).commandTimeout(Duration.ofMillis(config.getMaxWaitMillis())).build();
		return new LettuceConnectionFactory(redisConfigCore(), clientConfiguration);
	}

	@Bean
	public LettuceConnectionFactory factoryOrgan(){
		GenericObjectPoolConfig config = redisPool();
		LettuceClientConfiguration clientConfiguration = LettucePoolingClientConfiguration.builder()
				.poolConfig(config).commandTimeout(Duration.ofMillis(config.getMaxWaitMillis())).build();
		return new LettuceConnectionFactory(redisConfigOrgan(), clientConfiguration);
	}

	@Bean
	public LettuceConnectionFactory factoryBusiness(){
		GenericObjectPoolConfig config = redisPool();
		LettuceClientConfiguration clientConfiguration = LettucePoolingClientConfiguration.builder()
				.poolConfig(config).commandTimeout(Duration.ofMillis(config.getMaxWaitMillis())).build();
		return new LettuceConnectionFactory(redisConfigBusiness(), clientConfiguration);
	}

	@Bean
	public RedisTemplate<String,Object> redisTemplateToken() {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new JdkSerializationRedisSerializer());
		redisTemplate.setHashValueSerializer(new JdkSerializationRedisSerializer());
		redisTemplate.setConnectionFactory(factoryToken());
		return redisTemplate;
	}

	@Bean
	public RedisTemplate<String,Object> redisTemplateCore() {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new JdkSerializationRedisSerializer());
		redisTemplate.setHashValueSerializer(new JdkSerializationRedisSerializer());
		redisTemplate.setConnectionFactory(factoryCore());
		return redisTemplate;
	}

	@Bean
	public RedisTemplate<String,Object> redisTemplateOrgan() {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new JdkSerializationRedisSerializer());
		redisTemplate.setHashValueSerializer(new JdkSerializationRedisSerializer());
		redisTemplate.setConnectionFactory(factoryOrgan());
		return redisTemplate;
	}

	@Bean
	//public RedisTemplate<String,Object> redisTemplateBusiness() {
	public RedisTemplate<String,Object> redisTemplateMf() {
//    	RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
//		redisTemplate.setKeySerializer(new StringRedisSerializer());
//		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
//		redisTemplate.setValueSerializer(new JdkSerializationRedisSerializer());
//		redisTemplate.setHashValueSerializer(new JdkSerializationRedisSerializer());
//		redisTemplate.setConnectionFactory(factoryBusiness());
//		return redisTemplate;
		RedisTemplate<String, Object> template = new RedisTemplate<String, Object>();
		template.setConnectionFactory(factoryBusiness());
		@SuppressWarnings({ "rawtypes", "unchecked" })
		Jackson2JsonRedisSerializer jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer(Object.class);
		ObjectMapper om = new ObjectMapper();
		om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
		om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
		jackson2JsonRedisSerializer.setObjectMapper(om);
		StringRedisSerializer stringRedisSerializer = new StringRedisSerializer();
		// key采用String的序列化方式
		template.setKeySerializer(stringRedisSerializer);
		// hash的key也采用String的序列化方式
		template.setHashKeySerializer(stringRedisSerializer);
		// value序列化方式采用jackson
		template.setValueSerializer(jackson2JsonRedisSerializer);
		// hash的value序列化方式采用jackson
		template.setHashValueSerializer(jackson2JsonRedisSerializer);
		template.afterPropertiesSet();
		return template;
	}

	@Bean
	@Primary
	public CacheManager cacheManagerToken() {
		return RedisCacheManager.builder(factoryToken())
				.cacheDefaults(getRedisCacheConfigurationWithTtl(DEFAULT_OF_SECONDS))
				.transactionAware()
				.build();
	}

	@Bean
	public CacheManager cacheManagerCore() {
		return RedisCacheManager.builder(factoryCore())
				.cacheDefaults(getRedisCacheConfigurationWithTtl(DEFAULT_OF_SECONDS))
				.withInitialCacheConfigurations(getRedisCacheConfigurationMap(K3_USERINFO_OF_SECONDS))
				.transactionAware()
				.build();
	}

	@Bean
	public CacheManager cacheManagerOrgan() {
		return RedisCacheManager.builder(factoryOrgan())
				.cacheDefaults(getRedisCacheConfigurationWithTtl(DEFAULT_OF_SECONDS))
				.transactionAware()
				.build();
	}

	@Bean
	public CacheManager cacheManagerBusiness() {
		return RedisCacheManager.builder(factoryBusiness())
				.cacheDefaults(getRedisCacheConfigurationWithTtl(DEFAULT_OF_SECONDS))
				.transactionAware()
				.build();
	}

	@Bean
	@Primary
	@SuppressWarnings("all")
	public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory factory) {
		RedisTemplate<String, Object> template = new RedisTemplate<String, Object>();
		template.setConnectionFactory(factory);
		Jackson2JsonRedisSerializer jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer(Object.class);
		ObjectMapper om = new ObjectMapper();
		om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
		om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
		jackson2JsonRedisSerializer.setObjectMapper(om);
		StringRedisSerializer stringRedisSerializer = new StringRedisSerializer();
		// key采用String的序列化方式
		template.setKeySerializer(stringRedisSerializer);
		// hash的key也采用String的序列化方式
		template.setHashKeySerializer(stringRedisSerializer);
		// value序列化方式采用jackson
		template.setValueSerializer(jackson2JsonRedisSerializer);
		// hash的value序列化方式采用jackson
		template.setHashValueSerializer(jackson2JsonRedisSerializer);
		template.afterPropertiesSet();
		return template;
	}
}
