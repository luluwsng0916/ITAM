package com.smc.common.constants;

/**
 * @author C31909
 * @Description: 正则表达式
 */
public interface PatternConstant {
    String IPV4 = "^((([01]?[0-9]{1,2})|(2[0-4][0-9])|(25[0-5]))\\.){3}(([01]?[0-9]{1,2})|(2[0-4][0-9])|(25[0-5]))$";

    String IPV6 = "^([0-9a-fA-F]{1,4}:){7}([0-9a-fA-F]{1,4})$";

    String EMAIL = "^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$";
    /**
     * 正整数以及正浮点数
     */
    String POSITIVE_NUMBER = "((([1-9]\\d{0,14})|0)(\\.\\d{1,2})?)$";
    /**
     * 正整数以及0
     */
    String POSITIVE_INTEGER = "^(0|[1-9]\\d*)$";
    String YES_OR_NO = "(Y|N)";

    /**
     * 日期格式 yyyy-MM-dd
     */
    String DATE_YYYY_MM_DD = "^[0-9]{4}-(0?[0-9]|1[0-2])-(0?[1-9]|[12]?[0-9]|3[01])$";

    String DATE_YYYY_MM_DD_time = "^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])[\\s](20|21|22|23|[0-1][\\d]):[0-5][\\d]:[0-5][\\d]$";

    String DATE_YYYY_MM_DD_SLASH_time = "^[0-9]{4}/(0[1-9]|1[0-2])/(0[1-9]|[1-2][0-9]|3[0-1])[\\s](20|21|22|23|[0-1][\\d]):[0-5][\\d]:[0-5][\\d]$";

    /**
     * 日期格式 yyyy/MM/dd
     */
    String DATE_YYYY_MM_DD_SLASH = "^[0-9]{4}/(0?[0-9]|1[0-2])/(0?[1-9]|[12]?[0-9]|3[01])$";
    String DATE_YYYY_MM_DD_SLASH_0 = "^[0-9]{4}/(0[0-9]|1[0-2])/(0[1-9]|[12]?[0-9]|3[01])$";

    String DATE_YYYY_MM_POINT = "^[0-9]{4}\\.(0?[0-9]|1[0-2])$";

    String NUMBER_POINT_2 = "^(0|([1-9][0-9]*))(\\.[\\d]{2})$";
}
