package com.smc.common.model.result;

import com.smc.common.constants.ErrorCode;
import lombok.Data;

@SuppressWarnings("hiding")
@Data
public class ReturnResult<T> {
	private int code;
	private String message;
	private T data;
	
	
	public ReturnResult() {}
	
	public ReturnResult(int code,String message) {
		this.code = code;
		this.message = message;
	}

	
	
	
	public static ReturnResult ok() {
		return new ReturnResult().code(ErrorCode.OK.getCode()).message(ErrorCode.OK.getMessage());
	}
	
	
	public static ReturnResult fail() {
		return new ReturnResult().code(ErrorCode.FAIL.getCode()).message(ErrorCode.FAIL.getMessage());
	}
	
	public ReturnResult code(int code) {
		this.code = code;
		return this;
	}
	
	public ReturnResult message(String message){
		this.message = message;
		return this;
	}
	
	public ReturnResult data(T data) {
		this.data = data;
		return this;
	}

	@Override
	public String toString() {
		return "ErrorResult [code=" + code + ", message=" + message + ", data=" + data + "]";
	}
	
}
