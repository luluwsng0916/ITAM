package com.smc.common.model.page;

import com.smc.common.model.Scope;

import java.util.List;

public class PageRequesScope extends PageRequest {

	/**
     * 范围集合
     */
    private List<Scope> scopeCollections;

    /**
     * 业务ID
     */
    private List<String> serviceIds;

    public List<Scope> getScopeCollections() {
        return scopeCollections;
    }

    public void setScopeCollections(List<Scope> scopeCollections) {
        this.scopeCollections = scopeCollections;
    }

    public List<String> getServiceIds() {
        return serviceIds;
    }

    public void setServiceIds(List<String> serviceIds) {
        this.serviceIds = serviceIds;
    }

	@Override
	public String toString() {
		return "ScopeBaseEntity [scopeCollections=" + scopeCollections + ", serviceIds=" + serviceIds + "]";
	}
}
