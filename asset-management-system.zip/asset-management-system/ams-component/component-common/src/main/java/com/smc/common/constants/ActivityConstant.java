package com.smc.common.constants;

/**
 * @author C31909
 */
public interface ActivityConstant {

    boolean ACTIVITY_BOOL = true;
    boolean INACTIVITY_BOOL = false;

    int ACTIVITY = 1;
    int INACTIVITY = 0;

    String ACTIVITY_STR = "Y";
    String INACTIVITY_STR = "N";

    String ACTIVITY_DESC = "有效";
    String INACTIVITY_DESC = "无效";
}
