package com.smc.common.constants;

public interface MdmCodeRuleCreateConstant {
    /**
     * redis 表编码生成规则的前缀 ，可自行拼接
     * 含义： 主数据服务：代码生成接口：
     * 举例： mdm:codeRuleCreate:
     */
    String REDIS_CODE_KEY_PREFIX = "mdm:codeRuleCreate:";
    String PLANT_MARK_ALL = "ALL";
    String GENERATE_LOCATION_DB = "DB";
    String GENERATE_LOCATION_REDIS = "REDIS";
    Boolean SEAT = true;
    Boolean NOT_SEAT = false;
    String COLON = ":";
    String DEFAULT_START_NO = "1";
    String TABLE_NAME_BOM_PROCESS_CODE = "BomProcessCode";
    String FIELD_NAME_PROCESS_CODE = "processCode";
    String TABLE_NAME_MDM_MATERIAL = "MdmMaterial";
    String FIELD_NAME_MATERIAL_NO = "materialNo";

    String TABLE_NAME_MDM_STORE = "MdmStore";
    String FIELD_NAME_STORE_ID = "storeId";

    String TABLE_NAME_MDM_WORK_CENTER = "MdmWorkCenter";
    String FIELD_NAME_WORK_CENTER_ID = "workCenterId";

    String TABLE_NAME_S_ORDER_REQUISITION_CANCEL = "SOrderRequisitionCancel";

    String TABLE_NAME_D_ORDER_MAIN = "DOrderMain";


    String TABLE_NAME_S_ORDER_MAIN = "SOrderMain";


    String FIELD_NAME_CODE = "code";

    /**
     * 含义： 主数据服务：编码生成接口：表：厂别：编码字段
     * 举例： mdm:codeRuleCreate:MdmMaterial:ALL:materialNo
     */
    String REDIS_CODE_KEY_MDM_MATERIAL = MdmCodeRuleCreateConstant.REDIS_CODE_KEY_PREFIX +
            MdmCodeRuleCreateConstant.TABLE_NAME_MDM_MATERIAL + MdmCodeRuleCreateConstant.COLON +
            MdmCodeRuleCreateConstant.PLANT_MARK_ALL + MdmCodeRuleCreateConstant.COLON +
            MdmCodeRuleCreateConstant.FIELD_NAME_MATERIAL_NO;

    Long REDIS_EXPIRATION_TIME = (long) (60 * 60 * 24 * 30);
}
