package com.smc.common.model.page;

import lombok.Data;

/**
 * 更多条件查询参数
 *
 * @Author: C02039 wjh
 * @Date: 2023/2/13  16:39
 */
@Data
public class MoreParams {
    /**
     * 字段名
     */
    private String columnName;
    /**
     * 比较符
     */
    private String compare;
    /**
     * 字段值
     */
    private String columnValue;
    /**
     * 关系符
     */
    private String relation;

    /**
     * 类型
     */
    private String type;

    /**
     * 排序规则参数
     */
    private String sort;
}
