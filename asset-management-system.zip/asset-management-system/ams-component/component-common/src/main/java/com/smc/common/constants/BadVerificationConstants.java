package com.smc.common.constants;

public interface BadVerificationConstants {
	// http连接池配置
	public static final int MAX_TOTAL = 150; // 最大连接数
	public static final int DEFALUT_MAX_PREROUTE = 15; // 每个路由默认连接数

	// 门户验证token接口
	public static final String TOKEN_VERIFICATION_URL = "http://10.116.0.207/authen/verify";

	// ZPL在线预览API接口地址
	public static final String ZPL_ONLINE_PREVIEW_API_URL_ZP = "http://api.labelary.com/v1/printers/8dpmm/labels/3x2/0/"; // 制品
	public static final String ZPL_ONLINE_PREVIEW_API_URL_XX = "http://api.labelary.com/v1/printers/8dpmm/labels/3.7x1.8/0/"; // 小箱
	public static final String ZPL_ONLINE_PREVIEW_API_URL_ZX = "http://api.labelary.com/v1/printers/8dpmm/labels/3.7x1.8/0/"; // 中箱
	public static final String ZPL_ONLINE_PREVIEW_API_URL_WX = "http://api.labelary.com/v1/printers/8dpmm/labels/3.7x1.8/0/"; // 外箱
	public static final String ZPL_ONLINE_PREVIEW_API_URL_DWX = "http://api.labelary.com/v1/printers/8dpmm/labels/4.2x1.3/0/"; // 大外箱
	public static final String ZPL_ONLINE_PREVIEW_API_URL_DBQ = "http://api.labelary.com/v1/printers/8dpmm/labels/4.5x3.4/0/"; // 大标签
	public static final String ZPL_ONLINE_PREVIEW_API_URL_ZPLPRINT = "http://api.labelary.com/v1/printers/@@/labels/7x6/0/"; // ZPL特助打印

	// 铭板型号切分次数
	public static final int LABEL_MODEL_SPLID_TIMES = 3;

	// EAN码长度
	public static final int EANCODE_LENGTH = 13;

	// 现品票号下标
	public static final int EXPORTBARCODE_STARTBIT_INDEX = 2; // 起始位
	public static final int EXPORTBARCODE_ENDBIT_INDEX = 12; // 结束位

	// 铭板打印界面型号修改密码
	public static final String ALTERMODEL_PASSWORD = "111";

	// 指示类型
	public static final String INSTRTYPE_ASSEMBLY_STRING = "1"; // 组装指示
	public static final String INSTRTYPE_EXPORT_STRING = "2"; // 出荷指示
	public static final String INSTRTYPE_PURPLETICKET_STRING = "3"; // 紫票指示
	public static final Integer INSTRTYPE_ASSEMBLY_INTEGER = 1; // 组装指示
	public static final Integer INSTRTYPE_EXPORT_INTEGER = 2; // 出荷指示
	public static final Integer INSTRTYPE_PURPLETICKET_INTEGER = 3; // 紫票指示

	// 产品类型
	public static final String PRODUCT_TYPE_ZP = "ZP"; // 制品
	public static final String PRODUCT_TYPE_BP = "BP"; // 部品

	// 部品大标签拦截客户代码
	public static final String CUSTOMERCODE_BP_INTERCEPT_00001 = "00001";
	public static final String CUSTOMERCODE_BP_INTERCEPT_9604800 = "9604800";
	public static final String CUSTOMERCODE_BP_INTERCEPT_9604802 = "9604802";
	public static final String CUSTOMERCODE_BP_INTERCEPT_8705800 = "8705800";

	// 验证ZPL开关
	public static final boolean VERIFYCATION_ZPL_SWITCH = true; // 打开
//	public static final boolean VERIFYCATION_ZPL_SWITCH = false; // 关闭

	// 生管系统版本号
	public static final String MANUFACTURE_SYSTEM_VERSION = "5.20.025";

	// 系统用户名
	public static final String USERNAME_SYSTEM = "System";

	// 文件类型后缀
	public static final String FILETYPE_SUFFIX_PDF = ".pdf";
	public static final String FILETYPE_SUFFIX_DOC = ".doc";
	public static final String FILETYPE_SUFFIX_DOCX = ".docx";
	public static final String FILETYPE_SUFFIX_XLS = ".xls";
	public static final String FILETYPE_SUFFIX_XLSX = ".xlsx";

}
