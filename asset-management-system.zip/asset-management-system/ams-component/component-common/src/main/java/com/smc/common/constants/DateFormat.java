package com.smc.common.constants;

public interface DateFormat {
    String DATE_YYYY_MM_DD = "yyyy-MM-dd";
    String DATE_YYYY_MM_DD_SLASH = "yyyy/MM/dd";
}
