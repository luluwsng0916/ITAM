package com.smc.common.constants;

import java.math.BigDecimal;

public interface Constants {

	// =============================================================================
	// =============================================================================

	// 出口明细-分页
	public static final int PAGESIZE = 100;
	public static final int P10000 = 10000;
	public static final int P100 = 100;
	public static final int P50 = 50;
	public static final int P30 = 30;

	// =============================================================================
	// =============================================================================

	// 客户代码_SMC中国课税品
	public static final String CUSTOMERCODE_SMC_CN_TAX = "9604802";
	// 客户代码_SMC中国化学品
	public static final String CUSTOMERCODE_SMC_CN_CHEMISTRY = "9604890";
	// 客户代码_SMC中国营业_制造六课
	public static final String CUSTOMERCODE_SMC_CN_YY_MANUF6 = "9501203";
	// 客户代码_SMC中国营业_上海特注工场
	public static final String CUSTOMERCODE_SMC_CN_YY_SH_SPECIALFACTORY = "9501204";
	// 客户代码_SMC上海课税仓库
	public static final String CUSTOMERCODE_SMC_SH_TAX_WAREHOUSE = "0200702";
	// 客户代码_SMC中国化学品课税
	public static final String CUSTOMERCODE_SMC_CN_TAX_CHEMISTRY = "9604891";
	// 客户代码_SMC北京保税
	public static final String CUSTOMERCODE_SMC_BJ_BONDED = "0200700";
	// 客户代码_SMC北京生技
	public static final String CUSTOMERCODE_SMC_BJ_PRODTECH = "0200701";
	// 客户代码_SMC北京化学品
	public static final String CUSTOMERCODE_SMC_BJ_CHEMISTRY = "0200790";
	// 客户代码_SMC北京生技化学品课税
	public static final String CUSTOMERCODE_SMC_BJ_PRODTECH_TAX_CHEMISTRY = "0200791";
	// 客户代码_SMC北京课税材料
	public static final String CUSTOMERCODE_SMC_BJ_TAX_MATERIAL = "0200703";
	// 客户代码_SMC北京课税材料化学品
	public static final String CUSTOMERCODE_SMC_BJ_TAX_MATERIAL_CHEMISTRY = "0200792";
	// 客户代码_SMC天津保税化学品
	public static final String CUSTOMERCODE_SMC_TJ_BONDED_CHEMISTRY = "1602090";
	// 客户代码_SMC天津课税化学品
	public static final String CUSTOMERCODE_SMC_TJ_TAX_CHEMISTRY = "1602091";
	// 客户代码_SMC天津保税原材料
	public static final String CUSTOMERCODE_SMC_TJ_BONDED_MATERIAL = "1602000";
	// 客户代码_SMC天津课税原材料
	public static final String CUSTOMERCODE_SMC_TJ_TAX_MATERIAL = "1602002";
	// 客户代码_SMC天津课税3C品
	public static final String CUSTOMERCODE_SMC_TJ_TAX_3CPRODUCTION = "1602080";
	// 客户代码_SMC天津课税设备备品
	public static final String CUSTOMERCODE_SMC_TJ_TAX_DEVICESPAREPARTS = "1602001";
	// 客户代码_SMC天津捆包材
	public static final String CUSTOMERCODE_SMC_TJ_PACKMATERIAL = "1602003";
	// 客户代码_泰国_前缀
	public static final String CUSTOMERCODE_PREFIX_THAILAND = "95005";
	// 客户代码_前缀长
	public static final Integer CUSTOMERCODE_PREFIX_LENGTH = 5;

	// =============================================================================
	// =============================================================================

	// 工序属性_制品
	public static final String PROPERTY_ZP = "ZP";
	// 工序属性_部品
	public static final String PROPERTY_BP = "BP";
	// 工序属性_保税
	public static final String PROPERTY_BONDED = "BS";
	// 工序属性_课税
	public static final String PROPERTY_TAXATION = "KS";
	// 工序属性_M工号
	public static final String PROPERTY_MJOBNUMBER = "M";
	// 工序属性_现场
	public static final String PROPERTY_SCENE = "XC";
	// 工序属性_AC单体
	public static final String PROPERTY_ACMONOMER = "AC";
	// 工序属性_内制品
	public static final String PROPERTY_INTERNALPRODUCT = "NZ";
	// 工序属性_设备
	public static final String PROPERTY_DEVICE = "SB";
	// 代购
	public static final String PROPERTY_SUBSTITUTEPURCHASE = "Untread";
	// 工序属性_临进临出
	public static final String PROPERTY_COMEINANDOUT = "LL";
	// 工序属性_营业
	public static final String PROPERTY_BUSINESS = "YY";

	// =============================================================================
	// =============================================================================

	// 重量单位_公斤
	public static final String WEIGHTUNIT_GJ = "公斤";
	// 重量单位_KG
	public static final String WEIGHTUNIT_KG = "KG";
	// 重量单位_千克
	public static final String WEIGHTUNIT_QK = "千克";

	// =============================================================================
	// =============================================================================

	// 备案限额预警余量比例
	public static final BigDecimal RECORDLIMIT_WARNING_SCALE = new BigDecimal("0.4");

	// =============================================================================
	// =============================================================================

	// 厂别_中国
	public static final String PLANTMARK_CN = "CN";
	// 厂别_北京
	public static final String PLANTMARK_BJ = "BJ";
	// 厂别_天津
	public static final String PLANTMARK_TJ = "TJ";
	// 厂别_上海
	public static final String PLANTMARK_SH = "SH";
	// 厂别_自动化
	public static final String PLANTMARK_AM = "AM";
	// 厂别_投资
	public static final String PLANTMARK_IM = "IM";
	// 厂名_中国
	public static final String PLANT_NAME_CN = "SMC(中国)有限公司";
	// 厂名_北京
	public static final String PLANT_NAME_BJ = "SMC(北京)制造有限公司";
	// 厂名_天津
	public static final String PLANT_NAME_TJ = "SMC(天津)制造有限公司";
	// 厂名_上海
	public static final String PLANT_NAME_SH = "SMC(中国)有限公司上海分公司";
	// 厂名_自动化
	public static final String PLANT_NAME_AM = "SMC自动化有限公司";
	// 厂名_投资
	public static final String PLANT_NAME_IM = "SMC投资管理有限公司";
	

	// =============================================================================
	// =============================================================================

	// 发票_退运
	public static final String INVOICE_TYPE_RETURN = "T";
	// 发票_厂间结转
	public static final String INVOICE_TYPE_PLANTSCARRYOVER = "JK";
	// 发票_厂间结转2
	public static final String INVOICE_TYPE_PLANTSCARRYOVER2 = "JL";
	// 发票_送欧洲CN
	public static final String INVOICE_TYPE_SENDEUR_CN = "CNE";
	// 发票_送欧洲BJ
	public static final String INVOICE_TYPE_SENDEUR_BJ = "BJE";
	// 发票_内销
	public static final String INVOICE_TYPE_INSIDESALES = "NX";
	// 发票_内制BJ
	public static final String INVOICE_TYPE_INSIDEMANUF_BJ = "BJNZ";
	// 发票_营业
	public static final String INVOICE_TYPE_BUSINESS = "Y";
	// 发票_采购
	public static final String INVOICE_TYPE_PURCHASE = "PIB";

	// =============================================================================
	// =============================================================================

	// 运输方式_快递
	public static final String TRANSPORT_TYPE_COURIER = "COURIER";
	// 运输方式_联邦速递
	public static final String TRANSPORT_TYPE_FEDEX = "FEDEX";
	// 运输方式_空运
	public static final String TRANSPORT_TYPE_AIR = "AIR";
	// 运输方式_快船
	public static final String TRANSPORT_TYPE_FERRY = "FERRY";
	// 运输方式_海运
	public static final String TRANSPORT_TYPE_SEA = "SEA";
	// 运输方式_陆运
	public static final String TRANSPORT_TYPE_LAND = "LAND";
	// 运输方式_美国快船
	public static final String TRANSPORT_TYPE_SEAAIR = "SEA/AIR";

	// =============================================================================
	// =============================================================================

	// 进口报关单号位数
	public static final int IMPORT_CUSTOMS_DECLARATION_DIGIT = 18;
	// 出口报关单号位数
	public static final int EXPORT_CUSTOMS_DECLARATION_DIGIT = 9;

	// =============================================================================
	// =============================================================================

	// DAT发票_解析字段对应表名
	public static final String INVOICE_DAT_TABLENAME_INVOICE = "InvoiceDetail";
	// DAT发票_解析字段对应表名_6位发票号
	public static final String INVOICE_DAT_TABLENAME_INVOICE_DIGIT6 = "InvoiceDetail_6";
	// DAT发票_处理订单项号使用
	public static final String INVOICE_DAT_ITEMNO_0000 = "0000";
	// DAT发票_解析字段_原产国
	public static final String INVOICE_COLUMNNAME_COUNTRYORIGIN = "CountryOrigin";
	// DAT发票_解析字段_中文品名
	public static final String INVOICE_COLUMNNAME_DESCRIPTIONCHN = "DescriptionChn";
	// DAT发票_解析字段_保税现品票号
	public static final String INVOICE_COLUMNNAME_GOODSLABLENO = "GoodslableNO";
	// DAT发票_解析字段_发票号
	public static final String INVOICE_COLUMNNAME_INVNO = "Invno";
	// DAT发票_解析字段_订单项号
	public static final String INVOICE_COLUMNNAME_ITEMNO = "ItemNo";
	// DAT发票_解析字段_型号
	public static final String INVOICE_COLUMNNAME_MODEL = "Model";
	// DAT发票_解析字段_无商业价值
	public static final String INVOICE_COLUMNNAME_NONCOMMERCIAL = "NonCommercial";
	// DAT发票_解析字段_无商业价值1
	public static final String INVOICE_COLUMNNAME_NONCOMMERCIAL1 = "NonCommercial_1";
	// DAT发票_解析字段_订单号
	public static final String INVOICE_COLUMNNAME_ORDERNO = "OrderNo";
	// DAT发票_解析字段_数量
	public static final String INVOICE_COLUMNNAME_QUANTITY = "Quantity";
	// DAT发票_解析字段_外包装
	public static final String INVOICE_COLUMNNAME_SORT = "Sort";
	// DAT发票_解析字段_拍号
	public static final String INVOICE_COLUMNNAME_TRAYNO = "TrayNo";
	// DAT发票_解析字段_计价单位
	public static final String INVOICE_COLUMNNAME_UNIT = "Unit";
	// DAT发票_解析字段_单价
	public static final String INVOICE_COLUMNNAME_UNITPRICE = "UnitPrice";
	// DAT发票_解析字段_单重
	public static final String INVOICE_COLUMNNAME_UNITWEIGHT = "UnitWeight";

	// =============================================================================
	// =============================================================================

	// 手册名称_临进临出
	public static final String DIRECTORY_NAME_COMEINANDOUT = "临进临出";
	// 手册名称_制造内销
	public static final String DIRECTORY_NAME_MANUFINSALSE = "制造内销";
	// 手册名称_一般贸易
	public static final String DIRECTORY_NAME_GENERALTRADE = "一般贸易";

	// =============================================================================
	// =============================================================================

	// 测试变量_操作者
	public String OPERATOR = "";

	// =============================================================================
	// =============================================================================

	// 出口核销
	public static final String BUILD_NO_MATERIALQTY = "build无单耗";
	public static final String BUCHONG_CHAIFEN = "补充拆分";
	public static final String WAIGOU_1 = "-1外购";
	public static final String JG_2 = "-2JG外购";
	public static final String DUIZHAO_3 = "-3对照";
	public static final String KESHUI_DEL_4 = "-4课税删除";
	public static final String WAIT_SURE = "-待确认";
	public static final String ZERO_STRING = "0";
	public static final Double ZERO_DOUBLE = 0d;

	// =============================================================================
	// =============================================================================

	// 发票号前缀_BJNZ
	public static final String INVOICE_NO_PREFIX_BJNZ = "BJNZ";
	// 发票号前缀_NX
	public static final String INVOICE_NO_PREFIX_NX = "NX";
	// 发票号前缀_NY
	public static final String INVOICE_NO_PREFIX_NY = "NY";
	// 发票号前缀_JZ
	public static final String INVOICE_NO_PREFIX_JZ = "JZ";

	// =============================================================================
	// =============================================================================

	// 操作代码_22
	public static final String OPERATE_CODE_22 = "22";
	// 操作代码_25
	public static final String OPERATE_CODE_25 = "25";
	// 操作代码_2A
	public static final String OPERATE_CODE_2A = "2A";

	// =============================================================================
	// =============================================================================

	// Sort类型_退运
	public static final String SORT_TYPE_RETURN = "退运";
	// Sort类型_BARCODE
	public static final String SORT_TYPE_BARCODE = "BARCODE";
	// Sort类型_DAT
	public static final String SORT_TYPE_DAT = "DAT";
	// Sort类型_P/O
	public static final String SORT_TYPE_PO = "P/O";

	// =============================================================================
	// =============================================================================

	// 标记信息_承运服务
	public static final String MARKNAME_UP_TRANSFER_SERVER = "承运服务";
	// 标记信息_FOB
	public static final String MARKNAME_UP_FOB = "FOB";
	// 标记信息_出口发票
	public static final String MARKNAME_UP_EXPORT_INVOICE = "出口发票";
	// 标记信息_出口贸易方式
	public static final String MARKNAME_UP_EXPORT_TRADEMODEL = "出口贸易方式";
	// 标记信息_进口发票
	public static final String MARKNAME_UP_IMPORT_INVOICE = "进口发票";
	// 标记信息_发货地
	public static final String MARKNAME_UP_DELIVERY_PLACE = "发货地";
	// 标记信息_进口发票起运港
	public static final String MARKNAME_UP_IMPORT_INVOICE_DEPARTUREPORT = "进口发票起运港";

	// =============================================================================
	// =============================================================================

	// payment类型_FOB
	public static final String PAYMENT_TYPE_FOB = "FOB";
	// payment类型_CIF
	public static final String PAYMENT_TYPE_CIF = "CIF";

	// =============================================================================
	// =============================================================================

	// 到货国家_NETHERLANDS
	public static final String DESTINATION_COUNTRY_NETHERLANDS = "NETHERLANDS";

	// =============================================================================
	// =============================================================================

	// 补位000
	public static final String SUPPLEMENT_000 = "000";
	// 补位001
	public static final String SUPPLEMENT_001 = "001";

	// =============================================================================
	// =============================================================================

	// 报表类型_发票封面FOB
	public static final String REPORT_TYPE_INVOICE_COVER_FOB = "发票封面FOB";
	// 报表类型_发票封面CIF
	public static final String REPORT_TYPE_INVOICE_COVER_CIF = "发票封面CIF";
	// 报表类型_装箱单封面FOB
	public static final String REPORT_TYPE_PACKLIST_COVER_FOB = "装箱单封面FOB";
	// 报表类型_装箱单封面CIF
	public static final String REPORT_TYPE_PACKLIST_COVER_CIF = "装箱单封面CIF";
	// 报表类型_装箱单明细
	public static final String REPORT_TYPE_PACKLIST_DETAIL = "装箱单明细";
	// 报表类型_装箱单唛头
	public static final String REPORT_TYPE_PACKLIST_MARK = "装箱单唛头";
	// 报表类型_装箱清单
	public static final String REPORT_TYPE_PACKLIST = "装箱清单";
	// 报表类型_货物清单
	public static final String REPORT_TYPE_GOODSLIST = "货物清单";
	// 报表类型_产地证清单
	public static final String REPORT_TYPE_PRODUCTIONPLACELIST = "产地证清单";
	// 报表类型_空运委托
	public static final String REPORT_TYPE_ENTRUSE_AIR = "空运委托";
	// 报表类型_海运委托
	public static final String REPORT_TYPE_ENTRUSE_SEA = "海运委托";

	// =============================================================================
	// =============================================================================

	// 报表原产国_CHINA
	public static final String REPORT_COUNTRYORIGIN_CHINA = "COUNTRY OF ORIGIN: P.R.CHINA";

	// =============================================================================
	// =============================================================================

	// AttachedSheet标识
	public static final String REPORT_ATTACHEDSHEET = "-  ATTACHED   SHEET  -";
	// 唛头标识Marks
	public static final String REPORT_MARKS = "MARKS";
	// 唛头SMC标识
	public static final String REPORT_SMC = "SMC";
	// 唛头C/NO标识
	public static final String REPORT_CNO = "C/NO.";
	// 唛头发票号标识
	public static final String REPORT_INVOICENO = "INVOICE NO.";

	// =============================================================================
	// =============================================================================
	
	//公共代码表
	
	//厂别
	public static final String UNIVERSALCODE_CB = "CB";
	//币种
	public static final String UNIVERSALCODE_BZ = "BZ";
	//原产国
	public static final String UNIVERSALCODE_YCG  = "YCG";
	//保课税
	public static final String UNIVERSALCODE_BKS  = "BKS";
	
	public static final String NO_CHECK  = "不检验";
	
	// LOCK
	public static final String LOCK = "LOCK";
	// Day
	public static final int DAY = 60*60*24;
	// Week
	public static final int WEEK = 60*60*24*7;
	
	
	// 通用代码相关
	public static final String UNIVERSALCODE = "UNIVERSALCODE_";
	
}
