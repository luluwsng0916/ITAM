package com.smc.common.model;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName Scope
 * @description:
 * @author: C31909
 * @create: 2024-07-05 08:08
 * @Version 1.0
 **/
@Data
public class Scope {
    private String id;
    private String type;
    private String column;
    private String tableName;
    private Object origData;
}
