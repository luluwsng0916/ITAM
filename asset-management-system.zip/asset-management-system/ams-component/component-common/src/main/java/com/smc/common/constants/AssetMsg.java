package com.smc.common.constants;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/8/30
 * @description
 */
public interface AssetMsg {

    public static final String ASSET_NOT_EXIST = "资产不存在";
}
