package com.smc.common.constants;

/**
 * @author C31909
 */
public interface DeleteMarkConstant {
    /**
     * 未删除
     */
    int NOT_DELETED = 1;
    /**
     * 已删除
     */
    int DELETED = 0;
}
