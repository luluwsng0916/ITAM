package com.smc.core.feign;

import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;

import feign.RequestInterceptor;

//@Configuration
public class FeignHeaderSupportConfig {

	@Bean
	public RequestInterceptor requestInterceptor(){
	    return new FeignRequestInterceptor();
	}
}
