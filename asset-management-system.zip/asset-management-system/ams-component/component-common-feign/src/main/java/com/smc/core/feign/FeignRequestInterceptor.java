package com.smc.core.feign;

import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.CollectionUtils;
import org.springframework.util.PathMatcher;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import feign.RequestInterceptor;
import feign.RequestTemplate;

public class FeignRequestInterceptor implements RequestInterceptor {
	
	private static final String AUTHORIZATION = "authorization";

	@Autowired
	private FeignIgnoreUrls feignIgnoreUrls;

	@Override
	public void apply(RequestTemplate requestTemplate) {
		ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		if (attributes == null) {
			return;
		}
		HttpServletRequest request = attributes.getRequest();
		String servletUrl = request.getServletPath();
		Enumeration<String> headerNames = request.getHeaderNames();
		if (headerNames != null) {
			while (headerNames.hasMoreElements()) {
				String name = headerNames.nextElement();
				String values = request.getHeader(name);
				
				if (StringUtils.equalsIgnoreCase(AUTHORIZATION, name)) {
					if (matchUrl(servletUrl)) {
						continue;
					}
					
					
				}
				if (requestTemplate.headers().containsKey(name)) {
					continue;
				}
				requestTemplate.header(name, values);
			}
		}
	}
	
	/**
	 * matchUrl:(匹配路径). <br/>  
	 * @author SMC892Q  
	 * @param servletUrl
	 * @return
	 */
	private boolean matchUrl(String servletUrl) {
		PathMatcher matcher = new AntPathMatcher();
		List<String> list = feignIgnoreUrls.getUrls();
		if (CollectionUtils.isEmpty(list)) {
			return false;
		}
		return list.stream().filter(url -> matcher.match(url, servletUrl)).findFirst().isPresent();
	}
}
