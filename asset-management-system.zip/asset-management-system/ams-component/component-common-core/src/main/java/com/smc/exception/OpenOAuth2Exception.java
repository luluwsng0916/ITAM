package com.smc.exception;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(using = OpenOAuth2ExceptionSerializer.class)
public class OpenOAuth2Exception extends org.springframework.security.oauth2.common.exceptions.OAuth2Exception {
	private static final long serialVersionUID = 4257807899611076101L;

	public OpenOAuth2Exception(String msg) {
		super(msg);
	}
}
