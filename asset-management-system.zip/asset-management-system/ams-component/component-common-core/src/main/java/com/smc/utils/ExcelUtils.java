package com.smc.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import org.apache.poi.ss.usermodel.Cell;

public class ExcelUtils {
	public static String getCellValue(Cell cell) {
	    String cellValue = "";
	    if (cell == null) {
	        return cellValue;
	    }

	    //判断数据的类型
	    switch (cell.getCellType()) {
	        case STRING:  //字符串
	        	cellValue = cell.getStringCellValue().trim();
	            break;
	        case NUMERIC: //数值
	        	double numericCellValue = cell.getNumericCellValue();
	        	DecimalFormat df = new DecimalFormat("#.############");
	        	cellValue = df.format(numericCellValue).toString(); 
	            break;
	        case FORMULA: //表达式
	        	cellValue = "celltypeerror_gongshi";
	            break;
	        case ERROR: //故障
	            cellValue = "celltypeerror";
	            break;
	        default:
	            cellValue = "celltypeerror";
	            break;
	    }
	    return cellValue;
	}
	
	public static boolean isNumeric(String str){
		
		try {
			BigDecimal bigDecimal = new BigDecimal(str);
		} catch (Exception e) {
			return false;//异常 说明包含非数字。
		}
		return true;
	}

}
