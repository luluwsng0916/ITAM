package com.smc.utils;

/**
 * @program: asset-management-system
 * @ClassName NumberFormatterUtils
 * @description:
 * @author: C31909
 * @create: 2024-07-22 10:31
 * @Version 1.0
 **/
public class NumberFormatterUtils {
    /**
     * 将整型数据转换为六位的字符串，前面不足的用0填充。
     *
     * @param number 需要转换的整数
     * @return 六位的字符串
     */
    public static String formatNumber(int index, int number) {
        return String.format("%0" + index + "d", number);
    }

    public static void main(String[] args) {
        // 测试方法
        System.out.println(formatNumber(5, 123));    // 输出: 000123
        System.out.println(formatNumber(8, 123456)); // 输出: 123456
        System.out.println(formatNumber(9, 0));      // 输出: 000000
    }
}
