package com.smc.utils;

/**
 * Object对象工具类
 * 
 * @author B91715
 *
 */
public class ObjectUtils {

	/**
	 * 判断Object是否为数字
	 * 
	 * @param obj
	 * @return
	 */
	public static boolean isNumber(Object obj) {
		if (obj instanceof Number) {
			return true;
		} else if (obj instanceof String) {
			try {
				Double.parseDouble((String) obj);
				return true;
			} catch (Exception e) {
				return false;
			}
		}
		return false;
	}

	/**
	 * 判断Object对象是否为Boolean类型
	 * 
	 * @param obj
	 * @return
	 */
	public static boolean isBoolean(Object obj) {
		if (obj instanceof Boolean) {
			return true;
		} else {
			return false;
		}
	}

}
