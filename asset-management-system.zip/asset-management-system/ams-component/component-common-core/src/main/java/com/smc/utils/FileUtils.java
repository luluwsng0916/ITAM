package com.smc.utils;


import com.jcraft.jsch.*;

import java.io.*;
import java.nio.file.Files;
import java.util.Properties;

/**
 * @program: cloud-pms-parent
 * @ClassName FileUtils
 * @description:
 * @author: C31909
 * @create: 2024-03-15 12:06
 * @Version 1.0
 **/
public class FileUtils {
	/**
	 * @param host     另一台服务器地址
	 * @param port     另一台服务器端口
	 * @param username 另一台服务器权限账户用户名
	 * @param password 另一台服务器权限账户密码
	 * @return
	 */
	public static ChannelSftp connect(String host, int port, String username, String password) throws JSchException {
		ChannelSftp sftp;
		JSch jsch = new JSch();
		jsch.getSession(username, host, port);
		Session sshSession = jsch.getSession(username, host, port);
		sshSession.setPassword(password);
		Properties sshConfig = new Properties();
		sshConfig.put("StrictHostKeyChecking", "no");
		sshSession.setConfig(sshConfig);
		sshSession.connect();
		Channel channel = sshSession.openChannel("sftp");
		channel.connect();
		sftp = (ChannelSftp) channel;
		return sftp;
	}

	/**
	 * 文件上传
	 *
	 * @param directory  上传至另一台服务器的存储路径
	 * @param uploadFile 本服务器需要上传的文件路径及文件名
	 * @param sftp       调用上方连接另一台服务器的方法connect
	 */
	public static void SendFile(String directory, String uploadFile, ChannelSftp sftp) throws Exception {
		sftp.cd(directory);
		File file = new File(uploadFile);
		sftp.put(Files.newInputStream(file.toPath()), file.getName());
	}

	/**
	 * 文件下载
	 *
	 * @param directory    另一台服务器的存储路径
	 * @param downloadFile 要下载的文件路径及文件名
	 * @param saveFile     下载下来的文件名（如下载到本地服务器需要更改文件名）
	 * @param sftp         调用上方连接另一台服务器的方法connect
	 */
	public void download(String directory, String downloadFile, String saveFile, ChannelSftp sftp) throws Exception {
		sftp.cd(directory);
		File file = new File(saveFile);
		sftp.get(downloadFile, Files.newOutputStream(file.toPath()));
	}
}
