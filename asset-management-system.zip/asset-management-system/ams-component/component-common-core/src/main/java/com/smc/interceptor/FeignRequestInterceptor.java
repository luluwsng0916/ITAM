package com.smc.interceptor;


import com.google.gson.Gson;
import com.smc.common.model.auth.ClientDetails;
import com.smc.forest.httpclient.mfnauth.OauthClient;
import com.smc.utils.HttpRequest;
import com.smc.utils.JsonUtil;
import com.smc.utils.ThreadLocalMapUtil;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * 
 * 微服务之间feign调用请求头丢失的问题
 * 加入微服务之间传递的唯一标识,便于追踪
 * 加入微服务Feign调用的用户认证，替换token
 * @author B92085
 *
 */
@Slf4j
public class FeignRequestInterceptor implements RequestInterceptor {
	/**
     * 微服务之间传递的唯一标识
     */
    private static final String X_REQUEST_ID = "X-RPC-Request-Id";
    
    public static final String GRANT_TYPE = "grant_type";
    public static final String CLIANT_CREDENTIALS = "client_credentials";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String SERVICE_NAME = "service_name";
    public static final String CLIENT_ID = "client_id";
    public static final String TOKEN = "authorization";
    public static final String BIG_TOKEN = "Authorization";
    
    
    
    @Value("${smc.feign.oauth2.client.clientId}")
    private String clientId;

    @Value("${smc.feign.oauth2.client.clientSecret}")
    private String clientSecret;
    
    @Value("${security.oauth2.client.access-token-uri}")
    private String accessTokenUri;
    
    @Autowired
    private OauthClient oauthClient;
	
	@Override
	public void apply(RequestTemplate template) {
		
		  HttpServletRequest request = getHttpServletRequest();
		  Map<String, String> headers = null;
		  if(request != null){
		      headers = getHeaders(request);
		      // 微服务之间传递的唯一标识
		      if (!headers.containsKey(X_REQUEST_ID)) {
	                 String sid = String.valueOf(UUID.randomUUID());
	                 template.header(X_REQUEST_ID, sid);
	          }		      
	      	  //传递所有请求头,防止部分丢失
	      	  Iterator<Map.Entry<String, String>> iterator = headers.entrySet().iterator();
	           while (iterator.hasNext()) {
	               Map.Entry<String, String> entry = iterator.next();
	               template.header(entry.getKey(), entry.getValue());
	           }
	           
	           log.debug("Before1 FeignRequestInterceptor:{}",template.toString());

	       }	  
		log.debug("Before FeignRequestInterceptor:{}",template.toString());
			          	
	    // 更换token
		String token = oauthClient.getToken(clientId, clientSecret, CLIANT_CREDENTIALS);
		System.out.println(token);
		Map<String, Object> jsonToMap = null;
		try {
			jsonToMap = JsonUtil.jsonToMap(token);
			String access_token = (String)jsonToMap.get("access_token");
			Integer expires_in = (Integer)jsonToMap.get("expires_in");
			System.out.println("access_token:" + access_token);
			System.out.println("expires_in:" + expires_in);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	    String grantType = getGrantType();
	 	if (grantType != null) {
	 	   if (CLIANT_CREDENTIALS.equals(grantType)) {
	 		   template.header(GRANT_TYPE, CLIANT_CREDENTIALS);
	 	       template.header(CLIENT_ID, clientId);
	 	       template.header(CLIENT_SECRET, clientSecret);
	 	       // 有bug 需要修改
	 	       //String token = createToken();
	 	       // 根据head中的Authorization大小写区分来精确更新token
	 	       if(boolAuthorizationKey(headers,TOKEN)){
	 	    	  template.header(TOKEN, token);
	 	       }else if(boolAuthorizationKey(headers,BIG_TOKEN)){
	 	    	  template.header(BIG_TOKEN, token);
	 	       }else{
	 	    	  template.header(TOKEN, token);
	 	       }
	 	       
	 	   }
	 	 }
	 	        
	    log.debug("After FeignRequestInterceptor:{}", template.toString());
	}
	
	private String getGrantType() {
        Object obj = null;
        if (RequestContextHolder.getRequestAttributes() != null) {
        	HttpServletRequest  request = getHttpServletRequest();
            obj = request.getAttribute(GRANT_TYPE);
        }
        if (obj != null) {
            return obj.toString();
        }
        obj = ThreadLocalMapUtil.get(GRANT_TYPE);
        if (obj != null) {
            return obj.toString();
        }
        return CLIANT_CREDENTIALS;
    }
	
	private String createToken() {
        Map<String, String> param = new HashMap<>();
        param.put("grant_type", CLIANT_CREDENTIALS);
        param.put("client_id", clientId);
        param.put("client_secret", clientSecret);
        String s = HttpRequest.doPost(accessTokenUri, param, null);
        ClientDetails clientDetails = new Gson().fromJson(s, ClientDetails.class);
        // 设置token
        return "bearer " + clientDetails.getAccess_token();
    }
	
	
	private HttpServletRequest getHttpServletRequest() {
	     try {
	         return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
	     } catch (Exception e) {
	          return null;
	     }
	}
	
	private Map<String, String> getHeaders(HttpServletRequest request) {
        Map<String, String> map = new LinkedHashMap<>();
        Enumeration<String> enumeration = request.getHeaderNames();
        if(enumeration!=null){
            while (enumeration.hasMoreElements()) {
                String key = enumeration.nextElement();
                String value = request.getHeader(key);
                map.put(key, value);
            }
        }
        return map;
    }
	
	private boolean boolAuthorizationKey(Map<String, String> headers,String authorization){
		return headers.get(authorization) != null?true:false;
	}
		
}
    

