package com.smc.utils;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import cn.afterturn.easypoi.excel.entity.enmus.ExcelType;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/**
 * excel 下载上传工具类
 * @author B92085
 *
 */
public class FileExcelUtil {
	public static void exportExcel(List<?> list, String title, String sheetName, Class<?> pojoClass, String fileName, boolean isCreateHeader, HttpServletResponse response)  {
        ExportParams exportParams = new ExportParams(title, sheetName);
        exportParams.setCreateHeadRows(isCreateHeader);
        defaultExport(list, pojoClass, fileName, response, exportParams);
    }
    public static void exportExcel(List<?> list, Class<?> pojoClass, String fileName,  HttpServletResponse response)  {
    	ExportParams exportParams = new ExportParams();
    	//设置excel类型
    	setFileType(fileName,exportParams);
        defaultExport(list, pojoClass, fileName, response, exportParams);
    }
    
	public static void exportExcel(List<?> list, String title, String sheetName, Class<?> pojoClass,String fileName, HttpServletResponse response)  {
        defaultExport(list, pojoClass, fileName, response, new ExportParams(title, sheetName));
    }
    public static void exportExcel(List<Map<String, Object>> list, String fileName, HttpServletResponse response)  {
        defaultExport(list, fileName, response);
    }

    private static void defaultExport(List<?> list, Class<?> pojoClass, String fileName, HttpServletResponse response, ExportParams exportParams)  {
        Workbook workbook = ExcelExportUtil.exportExcel(exportParams,pojoClass,list);
        if (workbook != null);
        downLoadExcel(fileName, response, workbook);
    }

    private static void downLoadExcel(String fileName, HttpServletResponse response, Workbook workbook)  {
        OutputStream outputStream=null;
        try {
            response.setCharacterEncoding("UTF-8");
            response.setHeader("content-Type", "application/vnd.ms-excel");
            response.setHeader("Content-Disposition",
                    "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
            outputStream = response.getOutputStream();

            workbook.write(outputStream);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }finally {
            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * 设置excel导出类型
     * @param fileName 文件名
     * @param exportParams 参数对象
     */
    private static void setFileType(String fileName, ExportParams exportParams) {
    	//截取后缀
    	String fileNameType = fileName.substring(fileName.lastIndexOf(".")+1);
    	//根据文件名判断类型
    	if(fileNameType.equalsIgnoreCase("xlsx")) {
    	    exportParams.setType(ExcelType.XSSF);
    	}
	}
    
    
    private static void defaultExport(List<Map<String, Object>> list, String fileName, HttpServletResponse response)  {
        Workbook workbook = ExcelExportUtil.exportExcel(list, ExcelType.XSSF);
        if (workbook != null);
        downLoadExcel(fileName, response, workbook);
    }

    public static <T> List<T> importExcel(String filePath,Integer titleRows,Integer headerRows, Class<T> pojoClass)  {
        if (StringUtils.isBlank(filePath)){
            return null;
        }
        ImportParams params = new ImportParams();
        params.setTitleRows(titleRows);
        params.setHeadRows(headerRows);
        List<T> list = null;
        try {
            list = ExcelImportUtil.importExcel(new File(filePath), pojoClass, params);
        }catch (NoSuchElementException e){
            throw new RuntimeException("模板不能为空");
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        }
        return list;
    }
    public static <T> List<T> importExcel(MultipartFile file, Integer titleRows, Integer headerRows, Class<T> pojoClass)  {
        if (file == null){
            return null;
        }
        ImportParams params = new ImportParams();
        params.setTitleRows(titleRows);
        params.setHeadRows(headerRows);
        List<T> list = null;
        try {
            list = ExcelImportUtil.importExcel(file.getInputStream(), pojoClass, params);
        }catch (NoSuchElementException e){
            throw new RuntimeException("excel文件不能为空");
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        return list;
    }
    
	    /**
	     * 使用方式：
	     * 
	     * @RestController
	public class EasyPOIController {
	    @RequestMapping("/exportExcel")
	    public void export(HttpServletResponse response){
	        //模拟数据库数据
	        Goods goods1 = new Goods(110, "苹果", 1, new Date(), 0, "1");
	        Goods goods2 = new Goods(111, "格子衫", 2, new Date(), 0, "0");
	        Goods goods3 = new Goods(112, "拉菲红酒", 3, new Date(), 1, "1");
	        Goods goods4 = new Goods(113, "玫瑰", 4, new Date(), 1, "0");
	
	        List<Goods> goodsList = new ArrayList<Goods>();
	        goodsList.add(goods1);
	        goodsList.add(goods2);
	        goodsList.add(goods3);
	        goodsList.add(goods4);
	
	        for (Goods goods : goodsList) {
	            System.out.println(goods);
	        }
	        //导出
	        FileUtil.exportExcel(goodsList,Goods.class,"商品.xls",response);
	    }
	
	    @RequestMapping("/importExcel")
	    public void importExcel(){
	        //本地文件 模拟文件上传解析
	        String filePath = "C:\\Users\\86178\\Desktop\\商品.xls";
	        //解析excel
	        List<Goods> goodsList = FileUtil.importExcel(filePath,0,1,Goods.class);
	        //也可以使用MultipartFile,使用 FileUtil.importExcel(MultipartFile file, Integer titleRows, Integer headerRows, Class<T> pojoClass)导入
	        System.out.println("导入数据一共【"+goodsList.size()+"】行");
	
	        //TODO 保存数据库
	        for (Goods goods:goodsList) {
	            System.out.println(goods);
	        }
	    }
	}
	     */
}
