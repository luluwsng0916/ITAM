package com.smc.utils;

/**
 * 空格工具类
 * 
 * @author B91715
 *
 */
public class SpaceUtils {

	/**
	 * 生成空格
	 * 
	 * @param count
	 * @return
	 */
	public static String genSpace(Integer count) {
		String space = "";
		if (count != null && count > 0) {
			for (int i = 0; i < count; i++) {
				space = space + " ";
			}
		}
		return space;
	}
}
