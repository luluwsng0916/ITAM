package com.smc.utils;

import com.smc.base.Position;
import com.smc.base.TreeInfo;
import com.smc.common.model.TreeNode;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class TreeUtils {
	/**
	 * 两层循环实现建树
	 * @param treeNodes 传入的树节点列表
	 * @param root
	 * @return
	 */
	public static <T extends TreeNode> List<T> bulid(List<T> treeNodes, Object root) {

		List<T> trees = new ArrayList<T>();

		for (T treeNode : treeNodes) {

			if (root.equals(treeNode.getParentId())) {
				trees.add(treeNode);
			}

			for (T it : treeNodes) {
				if (it.getParentId() == treeNode.getId()) {
					if (treeNode.getChildren() == null) {
						treeNode.setChildren(new ArrayList<TreeNode>());
					}
					treeNode.add(it);
				}
			}
		}
		return trees;
	}

	/**
	 * 使用递归方法建树
	 *
	 * @param treeNodes
	 * @return
	 */
	public static <T extends TreeNode> List<T> buildByRecursive(List<T> treeNodes, Object root) {
		List<T> trees = new ArrayList<T>();
		for (T treeNode : treeNodes) {
			if (root.equals(treeNode.getParentId())) {
				trees.add(findChildren(treeNode, treeNodes));
			}
		}
		return trees;
	}

	/**
	 * 递归查找子节点
	 *
	 * @param treeNodes
	 * @return
	 */
	public static <T extends TreeNode> T findChildren(T treeNode, List<T> treeNodes) {
		for (T it : treeNodes) {
			if (treeNode.getId() == it.getParentId()) {
				if (treeNode.getChildren() == null) {
					treeNode.setChildren(new ArrayList<TreeNode>());
				}
				treeNode.add(findChildren(it, treeNodes));
			}
		}
		return treeNode;
	}

	
	/**
	 * 通过K3Code进行过滤，例如：000000!100000!133000!133100!133092
	 * @param unitCodeList
	 * @param holonTree
	 * @return
	 */
	public static List<TreeInfo> filterTreeByK3Code(List<String> unitCodeList, List<TreeInfo> holonTree){
		if(CollectionUtils.isEmpty(unitCodeList)) {
			return holonTree;
		}
		List<TreeInfo> holonTreeByUnitCode = new ArrayList<TreeInfo>();
		
		for(TreeInfo treeInfo : holonTree) {
			for(String unitCode : unitCodeList) {
				if(StringUtils.indexOf(treeInfo.getK3Code(), unitCode) != -1) {
					holonTreeByUnitCode.add(treeInfo);
					break;
				}
			}
		}
		return holonTreeByUnitCode;
	}
	
	/**
	 * 通过6位部门编码进行过滤，例如：133092
	 * @param unitCodeList
	 * @param holonTree
	 * @return
	 */
	public static List<TreeInfo> filterTreeByUnitCode(List<String> codeList, List<TreeInfo> holonTree){
		if(CollectionUtils.isEmpty(codeList)) {
			return holonTree;
		}
		List<TreeInfo> holonTreeByUnitCode = new ArrayList<TreeInfo>();
		
		for(TreeInfo treeInfo : holonTree) {
			for(String unitCode : codeList) {
				if(StringUtils.indexOf(treeInfo.getCode(), unitCode) != -1) {
					holonTreeByUnitCode.add(treeInfo);
					break;
				}
			}
		}
		return holonTreeByUnitCode;
	}
	
	public static List<Position> filterTree(String userId, List<Position> listAllEmployeePosition){
		if(CollectionUtils.isEmpty(listAllEmployeePosition)) {
			return listAllEmployeePosition;
		}
		List<Position> list = new ArrayList<Position>();
		
		for(Position position : listAllEmployeePosition) {
			if(StringUtils.equals(userId, position.getPsnsmcId())) {
				list.add(position);
			}
		}
		return list;
	}
	
	
}
