package com.smc.exception;

import com.smc.common.model.result.ResultBody;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.provider.error.WebResponseExceptionTranslator;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;


/**
 * 自定义oauth2异常提示
 * @author B92085
 *
 */
public class OpenOAuth2WebResponseExceptionTranslator implements WebResponseExceptionTranslator {

	@Override
	public ResponseEntity translate(Exception e) throws Exception {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
				.getRequest();
		ResultBody responseData = OpenGlobalExceptionHandler.resolveException(e, request.getRequestURI());
		return ResponseEntity.status(responseData.getHttpStatus()).body(responseData);
	}

}
