package com.smc.utils;

import java.util.UUID;

public class UUID32 {
	public static String getUUID32() {
		String uuid = UUID.randomUUID().toString();// 转化为String对象
		return uuid.replace("-", "");// 因为UUID本身为32位只是生成时多了“-”，所以将它们去掉就可
	}
	
	public static void main(String args[]){
		System.out.println(UUID32.getUUID32());
	}
}
