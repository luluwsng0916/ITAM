package com.smc.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

/**
 * 行列转置工具类
 * 
 * @author B91715
 *
 */
@Slf4j
public class RowConvertColUtils {

	public static List<Map<String, Object>> rowColumnTranspose(List ts) {

		List<Map<String, Object>> resultList = new ArrayList<>();
		for (int i = 0; i < ts.size(); i++) {
			Class<? extends Object> tsClass = ts.get(i).getClass();
			Field[] fields = ts.get(i).getClass().getDeclaredFields();
			for (Field field : fields) {
				field.setAccessible(true);
				Map<String, Object> tempMap = new HashMap<String, Object>();
				tempMap.put("rowNum", i + 1);
				tempMap.put("colName", field.getName());

				Object object = new Object();
				try {
					// 将属性名字的首字母大写
					String name = field.getName().replaceFirst(field.getName().substring(0, 1),
							field.getName().substring(0, 1).toUpperCase());
					// 整合出 getId() 属性这个方法
					Method method = tsClass.getMethod("get" + name);
					object = method.invoke(ts.get(i));
				} catch (Exception e) {
					log.info("获取属性值异常");
					object = null;
					// TODO: handle exception
				}

				tempMap.put("colValue", object);
				resultList.add(tempMap);
			}
		}

		return resultList;
	}

}
