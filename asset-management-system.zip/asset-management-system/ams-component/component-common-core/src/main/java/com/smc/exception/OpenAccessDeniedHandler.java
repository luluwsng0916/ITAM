package com.smc.exception;

import com.smc.common.model.result.ResultBody;
import com.smc.utils.WebUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
/**
 * 自定义访问拒绝
 * @author B92085
 *
 */
@Slf4j
public class OpenAccessDeniedHandler implements AccessDeniedHandler {@Override
	public void handle(HttpServletRequest request, HttpServletResponse response,
			AccessDeniedException accessDeniedException) throws IOException, ServletException {
		 ResultBody resultBody = OpenGlobalExceptionHandler.resolveException(accessDeniedException,request.getRequestURI());
	     response.setStatus(resultBody.getHttpStatus());
	     WebUtils.writeJson(response, resultBody);
	}

}
