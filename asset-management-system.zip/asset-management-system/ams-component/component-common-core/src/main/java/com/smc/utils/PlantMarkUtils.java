package com.smc.utils;

import com.smc.common.constants.Constants;

/**
 * 厂别工具类，实现厂别和厂名互相转换
 * 
 * @author B91715
 *
 */
public class PlantMarkUtils {
	/**
	 * 将厂名转换为厂别
	 * 
	 * @param plantName
	 * @return
	 */
	public static String convertPlantNameToPlantMark(String plantName) {
		plantName = plantName.replaceAll("（", "(").replaceAll("）", ")");
		String plantMark = "";
		if (plantName.equals(Constants.PLANT_NAME_CN)) {
			plantMark = Constants.PLANTMARK_CN;
		} else if (plantName.equals(Constants.PLANT_NAME_BJ)) {
			plantMark = Constants.PLANTMARK_BJ;
		} else if (plantName.equals(Constants.PLANT_NAME_SH)) {
			plantMark = Constants.PLANTMARK_SH;
		} else if (plantName.equals(Constants.PLANT_NAME_TJ)) {
			plantMark = Constants.PLANTMARK_TJ;
		} else if (plantName.equals(Constants.PLANT_NAME_AM)) {
			plantMark = Constants.PLANTMARK_AM;
		} else if (plantName.equals(Constants.PLANT_NAME_IM)) {
			plantMark = Constants.PLANTMARK_IM;
		} else {
			plantMark = "";
		}
		return plantMark;
	}

	/**
	 * 将厂别转换为厂名
	 * 
	 * @param plantMark
	 * @return
	 */
	public static String convertPlantMarkToPlantName(String plantMark) {
		String plantName = "";
		if (plantMark.equals(Constants.PLANTMARK_CN)) {
			plantName = Constants.PLANT_NAME_CN;
		} else if (plantMark.equals(Constants.PLANTMARK_BJ)) {
			plantName = Constants.PLANT_NAME_BJ;
		} else if (plantMark.equals(Constants.PLANTMARK_SH)) {
			plantName = Constants.PLANT_NAME_SH;
		} else if (plantMark.equals(Constants.PLANTMARK_TJ)) {
			plantName = Constants.PLANT_NAME_TJ;
		} else if (plantMark.equals(Constants.PLANTMARK_AM)) {
			plantName = Constants.PLANT_NAME_AM;
		} else if (plantMark.equals(Constants.PLANTMARK_IM)) {
			plantName = Constants.PLANT_NAME_IM;
		} else {
			plantName = "";
		}
		return plantName;
	}

}
