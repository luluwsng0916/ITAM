package com.smc.exception;

/**
 * @author B82002
 *	基础元素为空时抛出的异常
 */
public class BasicNullException extends Exception{
	private String message;
	public BasicNullException(String message) {
		this.message = message;
	}
	public String getMessage() {
		return message;
	}
}
