package com.smc.exception;

import com.smc.common.model.result.ResultBody;
import com.smc.utils.WebUtils;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 自定义未认证处理
 * @author B92085
 *
 */
public class OpenAuthenticationEntryPoint implements AuthenticationEntryPoint {

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception)
			throws IOException, ServletException {
		ResultBody resultBody = OpenGlobalExceptionHandler.resolveException(exception, request.getRequestURI());
		response.setStatus(resultBody.getHttpStatus());
		WebUtils.writeJson(response, resultBody);
	}

}
