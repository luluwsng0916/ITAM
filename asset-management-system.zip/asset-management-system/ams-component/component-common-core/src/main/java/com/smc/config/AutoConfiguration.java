package com.smc.config;

import com.smc.exception.OpenGlobalExceptionHandler;
import com.smc.utils.SpringContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Slf4j
@Configuration
// @EnableConfigurationProperties({ OpenIdGenProperties.class })
public class AutoConfiguration {
	/**
	 * 雪花主键启动
	 * 
	 * @param properties
	 * @return
	 */
	// @Bean
	// @ConditionalOnMissingBean(OpenIdGenProperties.class)
	// public SnowflakeIdGenerator snowflakeIdWorker(OpenIdGenProperties properties) {
	// 	SnowflakeIdGenerator snowflakeIdGenerator = new SnowflakeIdGenerator(properties.getWorkId(),
	// 			properties.getCenterId());
	// 	log.info("bean [{}] properties [{}] 雪花主键 启动 ", snowflakeIdGenerator, properties);
	// 	return snowflakeIdGenerator;
	// }

	/**
	 * 自动填充模型数据
	 *
	 * @return
	 */
	// @Bean
	// public ModelMetaObjectHandler modelMetaObjectHandler() {
	// 	ModelMetaObjectHandler modelMetaObjectHandler = new ModelMetaObjectHandler();
	// 	log.info("bean [{}] 自动填充模型数据 启动。", modelMetaObjectHandler);
	// 	return modelMetaObjectHandler;
	// }

	/**
	 * 分页插件
	 */
	// @Bean
	// public PaginationInterceptor paginationInterceptor() {
	// 	PaginationInterceptor paginationInterceptor = new PaginationInterceptor();
	// 	log.info("bean [{}] 分页插件 启动。", paginationInterceptor);
	// 	return paginationInterceptor;
	// }
	/**
	 * 乐观锁插件
	 */
	// @Bean
	// public OptimisticLockerInterceptor optimisticLockerInterceptor(){
	// 	OptimisticLockerInterceptor optimisticLockerInterceptor = new OptimisticLockerInterceptor();
	// 	log.info("bean [{}] 乐观锁插件 启动。", optimisticLockerInterceptor);
	// 	return optimisticLockerInterceptor;
	// }
	
	/**
	 * SqlLog插件
	 */
	// @Bean
	// public MybatisSqlLogInterceptor mybatisSqlLogInterceptor(){
	// 	MybatisSqlLogInterceptor mybatisSqlLogInterceptor = new MybatisSqlLogInterceptor();
	// 	log.info("bean [{}] SqlLog插件 启动。", mybatisSqlLogInterceptor);
	// 	return mybatisSqlLogInterceptor;
	// }
	
	
	/**
	 * Spring上下文工具配置
	 *
	 * @return
	 */
	@Bean
	@ConditionalOnMissingBean(SpringContextHolder.class)
	public SpringContextHolder springContextHolder() {
		SpringContextHolder holder = new SpringContextHolder();
		log.info("bean [{}] Spring上下文工具配置 启动", holder);
		return holder;
	}

	/**
	 * 统一异常处理配置
	 *
	 * @return
	 */
	@Bean
	@ConditionalOnMissingBean(OpenGlobalExceptionHandler.class)
	public OpenGlobalExceptionHandler exceptionHandler() {
		OpenGlobalExceptionHandler exceptionHandler = new OpenGlobalExceptionHandler();
		log.info("bean [{}]  统一异常处理配置 启动", exceptionHandler);
		return exceptionHandler;
	}

	/**
	 * db 健康监控
	 * 
	 * @return
	 */
	// @Bean
	// @ConditionalOnMissingBean(DbHealthIndicator.class)
	// public DbHealthIndicator dbHealthIndicator() {
	// 	DbHealthIndicator dbHealthIndicator = new DbHealthIndicator();
	// 	log.info("bean [{}]  db健康监控启动 启动", dbHealthIndicator);
	// 	return dbHealthIndicator;
	// }
	
}
