package com.smc.utils;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 * 将捕获jvm中异常异常信息转化为String输出。
 * @author B92085
 *
 */
public class ErrorPrintToLog {
	public static  String printStackTraceToLog(Exception e) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		e.printStackTrace(new PrintStream(baos));
		return  baos.toString();
	}
}
