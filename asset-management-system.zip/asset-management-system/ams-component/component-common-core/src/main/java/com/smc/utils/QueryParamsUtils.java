package com.smc.utils;


import com.smc.common.model.page.MoreParams;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.Param;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author: C31455
 * @Date: 2024/2/26  11:01
 */
public class QueryParamsUtils {

    /**
     * 生成分页查询、导出、计算表尾合计的map参数
     * 查询自定义字段， 需传入参数，字段名为"fieldNameList"，字段中文名为"fieldNameChnList"，以,为字段界字符串形式进行参数传递
     * 形如 fieldNameList = "a,b,c,d,..."
     * 若需表尾合计功能需要在前端传入参数
     *
     * @param pageRequest 前台传递过来的参数
     */
    public static HashMap<String, Object> generateMapParams(PageRequest pageRequest) {
        HashMap<String, Object> map = new HashMap<>();

        /*获取多条件查询 条件拼接  开始*/
        //获取前台传过来的参数
        List<MoreParams> moreParamsList = new ArrayList<MoreParams>();
        moreParamsList = pageRequest.getMoreParams();

        //多条件查询前台传过来的参数不为空时
        if (moreParamsList.size() > 0) {
            //拼接and条件 list准备
            List<MoreParams> conditionsList = new ArrayList<MoreParams>();
            //拼接 order by list准备
            List<MoreParams> sortList = new ArrayList<MoreParams>();

            for (MoreParams moreParam : moreParamsList) {
                //列名不为空前提下方可进行如下操作
                if (moreParam.getColumnName() != null && !"".equals(moreParam.getColumnName())) {
                    //1.1、列值不为空，进行sql 条件拼接
//                    if (moreParam.getColumnValue() != null && !"".equals(moreParam.getColumnValue())) {
//                        //拼接 and 条件
//                        conditionsList.add(moreParam);
//                    }
                    //1.1、列值不为空，进行sql 条件拼接 或者 比较符中带有 “空” 字样 为空/不为空
                    if (!isEmpty(moreParam.getColumnValue())||moreParam.getCompare().contains("空")) {
                        //拼接 and 条件
                        conditionsList.add(moreParam);
                    }
                    //2、排序字段 为 ASC 或者 DESC  时 进行 排序字符串拼接
                    if ("ASC".equals(moreParam.getSort()) || "DESC".equals(moreParam.getSort())) {
                        sortList.add(moreParam);
                    }
                }
            }
            //做and 条件拼接
            if (conditionsList.size() > 0) {
                String conditionParams = "";
                int i = 0;
                //关系符 （AND  OR） (第一次关系符号 为下方写死 AND ) 第一条关系符在第二次使用
                String relation = "";
                for (MoreParams conditions : conditionsList) {
                    //比较符（ 》 = 《）
                    String compare = "";
                    compare = conditions.getCompare();
                    //列值
                    String columnValue = null;
                    if (conditions.getCompare().toUpperCase().contains("LIKE")) {
                        //如果是LIKE 或者是 NOT LIKE
//                        if (conditions.getColumnValue().contains("*")) {
                            //如果输入的带*：如果是输入 96*  * 96 =》 96% 、%96 (废弃)
//                            columnValue = convertLikeParams(conditions.getColumnValue());
                        if (conditions.getCompare().contains("start")) {
                            //列值
                            columnValue = "'" + conditions.getColumnValue()  + "%'";
                            //比较符号
                            compare = conditions.getCompare().substring(0,conditions.getCompare().indexOf("("));
                        } else if(conditions.getCompare().contains("end")){
                            //列值
                            columnValue = "'%" + conditions.getColumnValue()  + "'";
                            //比较符号
                            compare = conditions.getCompare().substring(0,conditions.getCompare().indexOf("("));
                        }else {
                            //如果输入的是正常的不带星
                            columnValue = "'%" + conditions.getColumnValue() + "%'";
                        }
                    } else {
                        //如果是数值类型拼串不用带单引号（‘model’） 否则组要带上单引号（‘model’）
                        if (conditions.getType().equals("2") || conditions.getType().equals("3")) {
                            columnValue = conditions.getColumnValue();
                        } else {
                            columnValue = "'" + conditions.getColumnValue() + "'";
                        }
                    }
                    //拼接条件sql
                    i++;
                    if (i == 1) {
                        if ("空".equals(compare)) {
                            conditionParams = "AND " + conditions.getColumnName() + " " + " IS NULL" + " ";
                            if("1".equals(conditions.getType())){
                                conditionParams = "AND ( " + conditions.getColumnName() + " " + " IS NULL OR "+ conditions.getColumnName() + " ='') ";
                            }
                        } else if ("非空".equals(compare)) {
                            conditionParams = "AND " + conditions.getColumnName() + " " + " IS NOT NULL" + " ";
                            if("1".equals(conditions.getType())){
                                conditionParams += "AND "+ conditions.getColumnName() + " !='' ";
                            }
                        } else {
                            conditionParams = "AND " + conditions.getColumnName() + " " + compare + " " + columnValue + " ";
                        }
                    } else if (i != moreParamsList.size()) {
                        if ("空".equals(compare)) {
                            conditionParams += relation + " " + conditions.getColumnName() + " " + " IS NULL" + " ";
                            if("1".equals(conditions.getType())){
                                conditionParams = "AND ( " + conditions.getColumnName() + " " + " IS NULL OR "+ conditions.getColumnName() + " ='') ";
                            }
                        } else if ("非空".equals(compare)) {
                            conditionParams += relation + " " + conditions.getColumnName() + " " + " IS NOT NULL  ";
                            if("1".equals(conditions.getType())){
                                conditionParams += "AND "+ conditions.getColumnName() + " !='' ";
                            }
                        } else {
                            conditionParams += relation + " " + conditions.getColumnName() + " " + compare + " " + columnValue + " ";
                        }
                    } else {
                        if ("空".equals(compare)) {
                            if("1".equals(conditions.getType())){
                                conditionParams += relation +" ( " + conditions.getColumnName() + " " + " IS NULL OR "+ conditions.getColumnName() + " ='') ";
                            }else{
                                conditionParams += relation + " " + conditions.getColumnName() + " " + "IS NULL ";
                            }
                        } else if ("非空".equals(compare)) {
                            conditionParams += relation + " " + conditions.getColumnName() + " " + "IS NOT NULL ";
                            if("1".equals(conditions.getType())){
                                conditionParams += "AND "+ conditions.getColumnName() + " !='' ";
                            }
                        } else {
                            conditionParams += relation + " " + conditions.getColumnName() + " " + compare + " " + columnValue;
                        }
//                        conditionParams += relation + " " + conditions.getColumnName() + " " + compare + " " + columnValue;
                    }
                    assert conditionParams != null;
//                    System.out.println(conditionParams);
                    //第一行的 关系符 放在第一行和第二行连接使用 （相当于放在了第二行的前面）
                    relation = conditions.getRelation();
                }
                map.put("conditionParams", conditionParams);
            }
            //执行 order by 条件拼接
            if (sortList.size() > 0) {
                String sortParam = "";
                int j = 0;
                for (MoreParams sortParams : sortList) {
                    j++;
                    if (j == sortList.size()) {
                        sortParam += sortParams.getColumnName() + " " + sortParams.getSort();
                    } else {
                        sortParam += sortParams.getColumnName() + " " + sortParams.getSort() + ", ";
                    }
                }
                map.put("sortParam", sortParam);
            }
        }
        /*获取多条件查询 条件拼接  结束*/

        /*常规参数提取*/
        List<Param> params = pageRequest.getParams();
        for (Param param : params) {
            map.put(param.getName(), param.getValue());
        }
        /*查询字段拼接、求和拼接*/
        //获取该员工已经配置了的所有的字段(在指定表名的前提下)

        //查询字段1、SELECT 哪些字段拼接
        //在指定表名下已经配置的实体中 取出表名字段
        String fieldNameListStr = (String) map.get("fieldNameList");
        String fieldNameChnListStr = (String) map.get("fieldNameChnList");

        if(fieldNameListStr != null && fieldNameChnListStr != null)  {
            List<String> usedFiled = Arrays.stream(fieldNameListStr.split(",")).collect(Collectors.toList());
            List<String> usedFiledChn = Arrays.stream(fieldNameChnListStr.split(",")).collect(Collectors.toList());
            //去重
            String filedParams = "";
            List<String> distinctUsedFieldList = usedFiled.stream().distinct().collect(Collectors.toList());
            List<String> distinctUsedFiledChnList = usedFiledChn.stream().distinct().collect(Collectors.toList());
            //easyexcel 动态头格式 需要类型  List<List<String>> list = new ArrayList<List<String>>();
            List<List<String>> easyExcelHeadList = new ArrayList<List<String>>();
            for (String distinctUsedFiledChn : distinctUsedFiledChnList) {
                ArrayList<String> usedFiledChnList = new ArrayList<>();
                usedFiledChnList.add(distinctUsedFiledChn);
                easyExcelHeadList.add(usedFiledChnList);
            }

            int num = 0;
            if (distinctUsedFieldList.size() > 0) {
                for (String field : distinctUsedFieldList) {
                    num++;
                    if (num == 1) {
                        filedParams = field;
                    } else if (num > 1) {
                        filedParams += "," + field;
                    }
                }
            }

            map.put("filedParams", filedParams);
            //动态展示列参数 (用于easyexcel 动态列导出 )(指定哪些列显示)
            map.put("distinctUsedFieldList", distinctUsedFieldList);
            //动态展示列参数 (用于easyexcel 动态列导出 )（动态表头） 这个不符合Easyexcel的动态头标准所以没有使用
            map.put("distinctUsedFiledChnList", distinctUsedFiledChnList);
            //easyExcel动态展示列参数 (用于easyexcel 动态列导出 )（动态表头） EasyExcel 需要的表头格式
            map.put("easyExcelHeadList", easyExcelHeadList);
        }
        //查询字段2、表尾合计查询字符串拼接 （SELECT 聚合（sum） 哪些字段拼接）
        //集合中取出 IsTotal = 1(需要计算的列) 且按照FieldName 去重后得到一个新的list
        List<String> usedFiledSum = (List<String>) map.get("sumFieldList");
        String sumFiledParams = "";
        if (usedFiledSum != null && usedFiledSum.size() > 0 ) {
            //去重
            List<String> distinctUsedFiledSumList = usedFiledSum.stream().distinct().collect(Collectors.toList());
            int sumParamsNum = 0;
            if (distinctUsedFiledSumList.size() > 0) {
                for (String sumField : distinctUsedFiledSumList) {
                    sumParamsNum++;
                    if (sumParamsNum == 1) {
                        sumFiledParams = "SUM(" + sumField + ") AS " + sumField;
                    } else if (sumParamsNum > 1) {
                        sumFiledParams += "," + "SUM(" + sumField + ") AS " + sumField;
                    }
                }
            }
        }

        if ("".equals(sumFiledParams)) {
            map.put("sumFiledParams", "noSum");
        } else {
            map.put("sumFiledParams", sumFiledParams);
        }
        return map;
    }

    /**
     * 判断是否为空
     * true 返回空
     * false 返回的不是空
     * @param ss
     * @return
     */
    public static boolean isEmpty(String ss){
        if(ss == null || ss.equals("")){
            return true;
        }else {
            return false;
        }
    }
}
