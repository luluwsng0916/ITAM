package com.smc.exception;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice(annotations = RestController.class)
public class RestExceptionHandle {
public static Logger logger = LoggerFactory.getLogger(RestExceptionHandle.class);
	
	public static final String CONTENT = "content";
	
	public static final String RESULT = "result";
	
	public static final String RESULT_SUCCESS = "success";
	
	public static final String RESULT_FAIL = "fail";
   /**
	* HandlerCatsicException:处理所有业务异常
	* @author yangyd
	* @param catsicException
	*/
	@ExceptionHandler(BaseException.class)
    public Map<String, Object> HandlerException(BaseException ex) { 
		logger.error(ex.getCode() + ":" + ex.getMessage());
		/*if(StringUtils.equals(Constants.异常输出_控制台, SpringContextUtil.getMessage(Constants.异常输出))){
			ex.printStackTrace();
		}*/
		return buildFailResult(ex.getCode(), ex.getMessage());
	}
	
	/**
	 * HandlerException:处理所有第三方jar抛出的异常
	 * @author yangyd
	 * @param Exception
	 */
	@ExceptionHandler(Exception.class) 
    public Map<String, Object> HandlerException(Exception ex) {  
		String code = "000000";
		logger.error(code + ":" + ex.getMessage());
		/*if(StringUtils.equals(Constants.异常输出_控制台, SpringContextUtil.getMessage(Constants.异常输出))){
			ex.printStackTrace();
		}*/
		return buildFailResult(code, "系统错误,稍后再试");
	}
	
	/**
	 * buildFailResult:处理异常错误
	 * @author yangyd
	 * @param errorCode
	 * @param errorMessage
	 * @return
	 */
	protected Map<String, Object> buildFailResult(String errorCode, String errorMessage) {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put(RESULT, RESULT_FAIL);
		result.put("errorCode", errorCode);
		result.put("errorMessage", errorMessage);
		return result;
	}
	
	@InitBinder  
	public void initBinder(WebDataBinder binder) {  
	    binder.setAutoGrowCollectionLimit(Integer.MAX_VALUE);  
	} 
}
