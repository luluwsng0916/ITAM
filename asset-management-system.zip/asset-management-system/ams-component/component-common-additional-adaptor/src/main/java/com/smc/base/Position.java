package com.smc.base;

import java.io.Serializable;

public class Position implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5877320366283029845L;
	
	/**
	 * 用户ID
	 */
	private String psnsmcId;
	
	/**
	 * 真实姓名
	 */
	private String psnName;

	/**
	 * 职务ID
	 */
	private String positionId;
	
	/**
	 * 职务名称
	 */
	private String positionName;
	
	/**
	 * 是否主岗
	 */
	private boolean isPrimary;
	
	/**
	 * 是否负责人
	 */
	private Integer isFuZeRen;
	
	/**
	 * 部门ID，岗级中的部门ID必须在HR系统中存在
	 */
	private String unitId;
	/**
	 * 部门名称，电算室
	 */
	private String unitName;
	/**
	 * 部门编码，如：8900
	 */
	private String deptCode;
	
	/**
	 * 部门K3层级代码：KD01.0001.0004
	 */
	private String unitCode;
	
	/**
	 * 部门全称
	 */
	private String fullName;
	
	public String getPsnsmcId() {
		return psnsmcId;
	}

	public void setPsnsmcId(String psnsmcId) {
		this.psnsmcId = psnsmcId;
	}

	public String getPsnName() {
		return psnName;
	}

	public void setPsnName(String psnName) {
		this.psnName = psnName;
	}
	
	public String getPositionId() {
		return positionId;
	}

	public void setPositionId(String positionId) {
		this.positionId = positionId;
	}

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	public boolean isPrimary() {
		return isPrimary;
	}

	public void setPrimary(boolean isPrimary) {
		this.isPrimary = isPrimary;
	}

	public Integer getIsFuZeRen() {
		return isFuZeRen;
	}

	public void setIsFuZeRen(Integer isFuZeRen) {
		this.isFuZeRen = isFuZeRen;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
}
