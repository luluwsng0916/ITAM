 package com.smc.base;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**  
 * ClassName:User <br/>  
 * Function: TODO ADD FUNCTION. <br/>  
 * Reason:   TODO ADD REASON. <br/>  
 * Date:     2018年8月23日 下午1:28:37 <br/>  
 * @author   B82443  
 * @version    
 * @since    JDK 1.8  
 * @see        
 */
public class RemoteUser implements Serializable{
	/**  
	 * @since JDK 1.8  
	 */
	private static final long serialVersionUID = 8162342822116363747L;

	/**
	 * 用户名,对应K3的psnsmcid
	 */
	private String userId;
	
	/**
	 * 用户名称
	 */
	private String username;
	
	/**
	 * 密码
	 */
	private String password;

	/**
	 * 姓名
	 */
	private String psnName;
	
	
	/**
	 * 员工编号或客户编码
	 */
	private String emId;
	
	/**
	 * 状态：1，正常；2，离职
	 */
	private String status;
	
	/**
	 * 1内部用户，2外部用户
	 */
	private String type;
	
	private List<Position> positions = new ArrayList<Position>();
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPsnName() {
		return psnName;
	}

	public void setPsnName(String psnName) {
		this.psnName = psnName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<Position> getPositions() {
		return positions;
	}

	public void setPositions(List<Position> positions) {
		this.positions = positions;
	}

	public String getEmId() {
		return emId;
	}

	public void setEmId(String emId) {
		this.emId = emId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
  
