package com.smc.base;

import java.io.Serializable;

/**
 * 部门岗位
 * @author B82443
 *
 */
public class OrgPosition implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6482675268756448349L;
	/**
	 * 岗位ID
	 */
	private String id;
	/**
	 * 岗位名称
	 */
	private String name;
	/**
	 * 部门ID
	 */
	private String unitId;
	
	/**
	 * 部门k3Code
	 */
	private String k3Code;
	/**
	 * 部门名称
	 */
	private String unitName;
	
	/**
	 * 部门全称
	 */
	private String fullName;
	
	/**
	 * 父节点ID
	 */
	private String parentId;
	/**
	 * 是否删除
	 */
	private boolean isDelete;
	/**
	 * 岗位编码
	 */
	private String code;
	/**
	 * 是否负责人，0否，1是
	 */
	private int isFuZeRen;
	/**
	 * 岗位类型
	 */
	private String positionType;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUnitId() {
		return unitId;
	}
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}
	public String getUnitName() {
		return unitName;
	}
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public boolean isDelete() {
		return isDelete;
	}
	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public int getIsFuZeRen() {
		return isFuZeRen;
	}
	public void setIsFuZeRen(int isFuZeRen) {
		this.isFuZeRen = isFuZeRen;
	}
	public String getPositionType() {
		return positionType;
	}
	public void setPositionType(String positionType) {
		this.positionType = positionType;
	}
	public String getK3Code() {
		return k3Code;
	}
	public void setK3Code(String k3Code) {
		this.k3Code = k3Code;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
}
