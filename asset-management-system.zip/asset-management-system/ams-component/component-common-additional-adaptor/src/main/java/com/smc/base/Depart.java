package com.smc.base;

import java.util.Date;

public class Depart {
	/**
	 * 部门名称
	 */
	private String deptName;
	
	private String k3code;
	/**
	 * 创建时间
	 */
	private Date createTime;
	
	/**
	 * 部门全称
	 */
	private String fullName;
	/**
	 * 部门代码（四位）
	 */
	private String deptCode;
	/**
	 * 部门级别
	 */
	private String unitLevel;
	/**
	 * 部门编码（6位）
	 */
	private String code;
	/**
	 * 父节点
	 */
	private String pid;
	
	public String getDeptName() {
		return deptName;
	}
	
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	public String getDeptCode() {
		return deptCode;
	}
	
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	
	public String getUnitLevel() {
		return unitLevel;
	}
	
	public void setUnitLevel(String unitLevel) {
		this.unitLevel = unitLevel;
	}
	
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}

	public String getK3code() {
		return k3code;
	}

	public void setK3code(String k3code) {
		this.k3code = k3code;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	@Override
	public String toString() {
		return "DeptInfo [deptName=" + deptName + ", k3code=" + k3code + ", createTime=" + createTime + ", deptCode="
				+ deptCode + ", unitLevel=" + unitLevel + ", code=" + code + ", pid=" + pid
				+ "]";
	}
	
	
	
	
}
