package com.smc.exception;

import com.smc.utils.SpringContextUtil;

public class BaseException extends RuntimeException {
	/**
	 * serialVersionUID:
	 */
	private static final long serialVersionUID = 3776449414775909590L;

	/**
	 * 错误码
	 */
	private String code;
	/**
	 * 错误信息参数
	 */
	private Object[] params;
	
	/**
	 * @param code 错误码
	 */
	public BaseException(String code){
		super(SpringContextUtil.getMessage(code));
		this.code = code;
	}
	
	/**
	 * @param code 错误码
	 * @param params 错误信息参数
	 */
	public BaseException(String code, Object... params){
		super(SpringContextUtil.getMessage(code, params));
		this.code = code;
		this.params = params;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Object[] getParams() {
		return params;
	}

	public void setParams(Object[] params) {
		this.params = params;
	}
}
