package com.smc.base;

import java.io.Serializable;

public class UserInfo implements Serializable{
	/**  
	 * @since JDK 1.8  
	 */
	private static final long serialVersionUID = 8162342822116363747L;

	/**
	 * 用户名,对应K3的psnsmcid
	 */
	private String userId;
	
	/**
	 * 用户名称
	 */
	private String username;
	
	/**
	 * 密码
	 */
	private String password;
	
	/**
	 * 员工ID
	 */
	private String emId;

	/**
	 * 姓名
	 */
	private String psnName;
	
	/**
	 * 状态：1，正常；2，离职
	 */
	private short status;
	
	/**
	 * 职务ID
	 */
	private String postionId;
	
	/**
	 * 职务名称
	 */
	private String positionName;
	
	/**
	 * 是否主岗
	 */
	private boolean isPrimary;
	
	/**
	 * 是否负责人
	 */
	private Integer isFuZeRen;
	
	/**
	 * 部门ID
	 */
	private String unitId;
	/**
	 * 部门名称，电算室
	 */
	private String unitName;
	/**
	 * 部门编码，如：8900
	 */
	private String deptCode;
	
	/**
	 * 部门K3层级代码：KD01.0001.0004
	 */
	private String unitCode;
	
	/**
	 * 部门全称
	 */
	private String fullName;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmId() {
		return emId;
	}

	public void setEmId(String emId) {
		this.emId = emId;
	}

	public String getPsnName() {
		return psnName;
	}

	public void setPsnName(String psnName) {
		this.psnName = psnName;
	}

	public short getStatus() {
		return status;
	}

	public void setStatus(short status) {
		this.status = status;
	}

	public String getPostionId() {
		return postionId;
	}

	public void setPostionId(String postionId) {
		this.postionId = postionId;
	}

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	public boolean isPrimary() {
		return isPrimary;
	}

	public void setPrimary(boolean isPrimary) {
		this.isPrimary = isPrimary;
	}

	public Integer getIsFuZeRen() {
		return isFuZeRen;
	}

	public void setIsFuZeRen(Integer isFuZeRen) {
		this.isFuZeRen = isFuZeRen;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
}