package com.smc.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationEvent;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SpringContextUtil implements ApplicationContextAware , DisposableBean {
	/**
	 * spring容器
	 */
	private static ApplicationContext applicationContext;

	/* (non-Javadoc)
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 */
	@SuppressWarnings("static-access")
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}
	
	/**
	 * 从spring容器中获取某个特定名字的bean
	 * @param beanName
	 * @return
	 */
	public static Object getBean(String beanName){
        return applicationContext.getBean(beanName);
    }
	
	/**
	 * 从spring的消息机制中获取消息
	 * @param code 消息code
	 * @return
	 */
	public static String getMessage(String code) {
		return applicationContext.getMessage(code, null, null);
	}

	/**
	 * 从spring的消息机制中获取消息
	 * @param code 消息code
	 * @param params 消息参数
	 * @return
	 */
	public static String getMessage(String code, Object[] params) {
		return applicationContext.getMessage(code, params, null);
	}

	public static void publishEvent(ApplicationEvent event) {
		if (applicationContext == null) {
			return;
		}
		applicationContext.publishEvent(event);
	}

	/**
	 * 清除SpringContextHolder中的ApplicationContext为Null.
	 */
	public static void clearHolder() {
		if (log.isDebugEnabled()) {
			log.debug("清除SpringContextHolder中的ApplicationContext:" + applicationContext);
		}

		applicationContext = null;
	}
	/**
	 * 实现DisposableBean接口, 在Context关闭时清理静态变量.
	 */
	@Override
	public void destroy() throws Exception {
		SpringContextUtil.clearHolder();
	}
}
