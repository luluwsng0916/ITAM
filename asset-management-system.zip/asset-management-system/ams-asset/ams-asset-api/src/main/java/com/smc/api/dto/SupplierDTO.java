package com.smc.api.dto;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName SuppliersDTO
 * @description:
 * @author: C31909
 * @create: 2024-07-22 11:38
 * @Version 1.0
 **/
@Data
public class SupplierDTO {
    /**
     *
     */
    private Integer id;

    /**
     * 供应商名称
     */
    private String name;

    /**
     * 联系人
     */
    private String contactPerson;

    /**
     * 联系电话
     */
    private String phone;

    /**
     * 电子邮箱
     */
    private String email;

    /**
     * 地址
     */
    private String address;

    /**
     * 供应商描述
     */
    private String remark;
}
