package com.smc.enums.asset;

/**
 * @author C31909
 */
public interface AssetConstant {
    // 编码前缀
    Integer PREFIX_LEN = 2;// 前缀编码长度
    Integer SERIAL_LEN = 6;// 顺序位长度
    String SM_PREFIX = "SM"; // 硬件前缀
    String VM_PREFIX = "VM"; // 服务器前缀
    String PM_PREFIX = "PM"; // 服务器前缀
    String VP_PREFIX = "VP"; // 虚拟池前缀
    String SW_PREFIX = "SW"; // 软件前缀
    String M_PREFIX = "M";
    String S_PREFIX = "S";
    String W_PREFIX = "W";

    // 通用代码类别
    String KPB = "卡片别";
    String YJFL = "硬件分类";
    String SCCS = "生产厂商";
    String YYLB = "应用类别";
    String FWQYT = "服务器用途";
    String CZXT = "操作系统";
    String SJK = "数据库";
    String GLZB = "管理组别";

    //  使用标识
    Boolean USE_FLAG = true;
    Boolean UNUSE_FLAG = false;
    String USE_FLAG_STR = "Y";
    String UNUSE_FLAG_STR = "N";

    String ACTIVITYFLAG_FLAG = "true";
    String UNACTIVITYFLAG_FLAG = "false";

    String ACTIVITYFLAG_STR = "Y";
    String UNACTIVITYFLAG_STR = "N";

    String ACTIVITYFLAG_NUM = "1";
    String UNACTIVITYFLAG_NUM = "0";

    //  报废标识
    Boolean SCRAPPED = true;
    Boolean NO_SCRAPPED = false;
    String SCRAPPED_STR = "Y";
    String NO_SCRAPPED_STR = "N";

    //  硬盘空间单位
    String GB = "GB";

    String TB = "TB";
}
