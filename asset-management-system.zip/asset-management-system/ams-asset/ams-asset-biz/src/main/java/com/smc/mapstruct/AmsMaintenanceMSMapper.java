package com.smc.mapstruct;

import com.smc.controller.maintenance.bo.MaintenanceAddBO;
import com.smc.controller.maintenance.bo.MaintenanceDeleteBO;
import com.smc.controller.maintenance.bo.MaintenanceEditBO;
import com.smc.dataobject.maintenance.AmsMaintenance;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
@Mapper
public interface AmsMaintenanceMSMapper {

    AmsMaintenanceMSMapper INSTANCE = Mappers.getMapper(AmsMaintenanceMSMapper.class);

    @Mapping(source = "operator", target = "createdBy")
    AmsMaintenance toMaintenanceAdd(MaintenanceAddBO maintenanceAddBO);

    @Mappings({
            @Mapping(source = "operator", target = "updatedBy"),
            @Mapping(source = "version", target = "version")
    })
    AmsMaintenance toMaintenanceEdit(MaintenanceEditBO maintenanceEditBO);

    @Mappings({
            @Mapping(source = "contractNo", target = "contractNo"),
            @Mapping(source = "updatedBy", target = "updatedBy"),
            @Mapping(source = "version", target = "version")
    })
    AmsMaintenance toMaintenanceDel(MaintenanceDeleteBO maintenanceDeleteBO);

}
