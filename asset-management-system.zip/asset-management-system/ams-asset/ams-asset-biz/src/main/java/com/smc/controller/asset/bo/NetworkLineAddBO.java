package com.smc.controller.asset.bo;

import lombok.Data;


/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/8/28
 * @description
 */
@Data
public class NetworkLineAddBO {

    /**
     * @description: 网络专线编号
     * @author: C31908
     * @date: 2025/8/11
     **/
    private String networkLineId;
    /**
     * 专线名称
     */
    private String networkLineName;
    /**
     * 专线类别
     */
    private String networkLineType;
    /**
     * 地点
     */
    private String place;
    /**
     * 带宽
     */
    private String bandwidth;
    /**
     * 月租费用
     */
    private String monthlyFee;
    /**
     * 一次性施工费用
     */
    private String oneTimeFee;
    /**
     * 协议金额（元/年）
     */
    private String agreementMoney;
    /**
     * 供应商名称
     */
    private String supplierName;
    /**
     * 起始日期
     */
    private String startDate;
    /**
     * 终止日期
     */
    private String endDate;
    /**
     * 备注
     */
    private String remark;
    /**
     * 创建人
     */
    private String operator;
}
