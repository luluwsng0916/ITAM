package com.smc.controller.asset;

import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.asset.bo.*;
import com.smc.service.asset.AmsVitualPoolConfigService;
import com.smc.utils.WebUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
@CrossOrigin
@RestController
@RequestMapping("/ams_vitualpoolconfig")
public class AmsVitualPoolConfigController {

    @Resource
    private AmsVitualPoolConfigService amsVitualPoolConfigService;

    @PostMapping("/list")
    public ResultBody<PageResult> page(@RequestBody PageRequest pageRequest) {
        PageResult res = amsVitualPoolConfigService.selectPage(pageRequest);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody VitualPoolConfigEditBO model) {
        String res = amsVitualPoolConfigService.editById(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody VitualPoolConfigAddBO model) {
        String res = amsVitualPoolConfigService.add(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody VitualPoolConfigDeleteBO model) {
        String res = amsVitualPoolConfigService.delete(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

}
