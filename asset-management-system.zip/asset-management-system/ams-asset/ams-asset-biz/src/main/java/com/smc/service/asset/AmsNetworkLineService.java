package com.smc.service.asset;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.controller.asset.bo.NetworkLineAddBO;
import com.smc.controller.asset.bo.NetworkLineDeleteBO;
import com.smc.controller.asset.bo.NetworkLineEditBO;
import com.smc.dataobject.asset.AmsNetworkLine;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 *
 * @author C31908
 * @date 2024-08-26
 * @version 1.0.0
 * @description
 */
public interface AmsNetworkLineService extends IService<AmsNetworkLine> {

    PageResult selectPage(PageRequest pageRequest);

    String editById(NetworkLineEditBO model);

    String add(NetworkLineAddBO model);

    String delete(NetworkLineDeleteBO model);

    List<String> findSuppliers();

    void export(PageRequest pageRequest, HttpServletResponse response);

    Map<String, String> importExcel(MultipartFile file, HttpServletRequest request);
}
