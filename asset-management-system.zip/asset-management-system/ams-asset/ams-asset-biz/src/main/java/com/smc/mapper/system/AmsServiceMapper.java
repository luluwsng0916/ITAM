package com.smc.mapper.system;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smc.dataobject.system.AmsService;
import com.smc.dataobject.system.AmsSystem;

import java.util.HashMap;
import java.util.List;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/6
 * @description
 */
public interface AmsServiceMapper extends BaseMapper<AmsService> {

    List<AmsService> findAll(HashMap<String, Object> map);

}
