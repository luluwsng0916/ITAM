package com.smc.service.asset.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smc.dataobject.asset.AmsDept;
import com.smc.mapper.asset.AmsDeptMapper;
import com.smc.service.asset.AmsDeptService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class AmsDeptServiceImpl extends ServiceImpl<AmsDeptMapper, AmsDept> implements AmsDeptService {

    @Resource
    private AmsDeptMapper amsDeptMapper;

    /**
     * 根据部门代码获取部门列表 格式  [code]名称
     * @param deptCode
     * @return
     */
    @Override
    public List<String> getDeptListByDeptCode(String deptCode) {
        List<String> amsDepts = new ArrayList<>();
        LambdaQueryWrapper<AmsDept> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.like(AmsDept::getDeptCode, deptCode).last("limit 20");
        List<AmsDept> list = amsDeptMapper.selectList(queryWrapper);
        for (AmsDept amsDept : list) {
            String s = "[" +amsDept.getDeptCode() + "]"  + amsDept.getDeptName();
            amsDepts.add(s);
        }
        return amsDepts;
    }
}
