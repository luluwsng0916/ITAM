package com.smc.controller.maintenance.bo;

import lombok.Data;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/20
 * @description
 */
@Data
public class MaintenanceDeleteBO {

    private String contractNo;

    private String updatedBy;

    private Integer version;

}
