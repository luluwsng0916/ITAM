package com.smc.service.maintenance;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.controller.maintenance.bo.MaintenanceAddBO;
import com.smc.controller.maintenance.bo.MaintenanceDeleteBO;
import com.smc.controller.maintenance.bo.MaintenanceEditBO;
import com.smc.dataobject.maintenance.AmsMaintenance;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/20
 * @description
 */
public interface AmsMaintenanceService extends IService<AmsMaintenance> {

    PageResult selectPage(PageRequest pageRequest);

    String editById(MaintenanceEditBO model);

    String add(MaintenanceAddBO model);

    String delete(MaintenanceDeleteBO model);

    void export(PageRequest pageRequest, HttpServletResponse response);

    Map<String, String> importExcel(MultipartFile file, HttpServletRequest request);

    List<String> findMaintenanceList(String data);

    PageResult getMaintenanceExpiration(PageRequest pageRequest);
}
