package com.smc.controller.asset;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.asset.bo.VirtualPoolBindHardwareBO;
import com.smc.controller.asset.bo.VirtualPoolDeleteBO;
import com.smc.controller.asset.bo.VirtualPoolEditBO;
import com.smc.controller.asset.dto.VirtualPoolConditionDTO;
import com.smc.controller.asset.vo.VirtualPoolVO;
import com.smc.dataobject.asset.AmsVirtualPool;
import com.smc.service.asset.AmsVirtualPoolService;
import com.smc.utils.WebUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @program: asset-management-system
 * @ClassName AmsVirtualPoolController
 * @description:
 * @author: C31909
 * @create: 2024-07-30 08:25
 * @Version 1.0
 **/
@CrossOrigin
@RestController
@RequestMapping("/pool")
public class AmsVirtualPoolController {

    @Resource
    private AmsVirtualPoolService amsVirtualPoolService;

    @PostMapping("/list")
    public ResultBody<PageInfo<VirtualPoolVO>> page(@RequestBody PageRequest pageRequest) {
        return amsVirtualPoolService.page(pageRequest);
    }


    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody VirtualPoolEditBO model) {
        return amsVirtualPoolService.editById(model);
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody AmsVirtualPool model) {
        return amsVirtualPoolService.add(model);
    }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody VirtualPoolDeleteBO model) {
        return amsVirtualPoolService.delete(model);
    }

    @PostMapping("/bind-hardware")
    public ResultBody<String> bindHardware(@RequestBody VirtualPoolBindHardwareBO bo) {
        return amsVirtualPoolService.bindHardware(bo);
    }

    @PostMapping("/export")
    public void export(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        amsVirtualPoolService.export(pageRequest, response);
    }

    @PostMapping("/importExcel")
    public ResultBody<String> importExcel(@RequestParam("multipartFile") MultipartFile file, HttpServletRequest request) {
        String res = amsVirtualPoolService.importExcel(file, request);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/findHardwareId")
    public ResultBody<List<String>> findHardwareId(@RequestBody VirtualPoolConditionDTO virtualPoolConditionDTO) {
        List<String> res = amsVirtualPoolService.findHardwareId(virtualPoolConditionDTO);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }


    @PostMapping("/findVirtualMachineId")
    public ResultBody<List<String>> findVirtualMachineId(@RequestBody VirtualPoolConditionDTO virtualPoolConditionDTO) {
        List<String> res = amsVirtualPoolService.findVirtualMachineId(virtualPoolConditionDTO);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/findManager")
    public ResultBody<List<String>> findManager(@RequestParam("data") String data) {
        List<String> res = amsVirtualPoolService.findManager(data);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/findHardwareIdByManager")
    public ResultBody<List<String>> findHardwareIdByManager(@RequestParam("manager") String manager) {
        List<String> res = amsVirtualPoolService.findHardwareIdByManager(manager);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/findVirtualMachineIdByHardwareId")
    public ResultBody<List<String>> findVirtualMachineIdByHardwareId(@RequestParam("hardwareId") String hardwareId) {
        List<String> res = amsVirtualPoolService.findVirtualMachineIdByHardwareId(hardwareId);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }
}
