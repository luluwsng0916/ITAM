package com.smc.controller.system.bo;

import lombok.Data;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/9
 * @description
 */
@Data
public class ServiceEditBO {

    /**
     * 主键ID
     */
    private String id;
    /**
     * 合同编号
     */
    private String contractNo;
    /**
     * 禀议裁决号
     */
    private String applyRulingNo;
    /**
     * 禀议书主旨及内容
     */
    private String applyContent;
    /**
     * 服务名称
     */
    private String serviceName;
    /**
     * 分类
     */
    private String serviceType;
    /**
     * 所属公司
     */
    private String company;
    /**
     * 管理担当
     */
    private String manager;
    /**
     * 含税金额
     */
    private String taxInclusiveAmount;
    /**
     * 供应商名称
     */
    private String supplierName;
    /**
     * 起始日期
     */
    private String startDate;
    /**
     * 终止日期
     */
    private String endDate;
    /**
     * 备注
     */
    private String remark;
    /**
     * 更新人
     */
    private String operator;

    private Integer version;

    private String updatedBy;

}
