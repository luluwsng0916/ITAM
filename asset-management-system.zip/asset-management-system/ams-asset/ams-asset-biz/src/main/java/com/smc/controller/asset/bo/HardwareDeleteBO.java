package com.smc.controller.asset.bo;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName HardwareDeleteBO
 * @description:
 * @author: C31909
 * @create: 2024-07-23 09:05
 * @Version 1.0
 **/
@Data
public class HardwareDeleteBO {
    private String id;
    private String updatedBy;
    private Integer version;
}
