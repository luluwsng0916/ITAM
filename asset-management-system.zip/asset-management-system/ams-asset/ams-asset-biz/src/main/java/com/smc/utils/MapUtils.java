package com.smc.utils;

import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.Param;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/8/26
 * @description
 */
public class MapUtils {

    public static Map<String,Object> generatMapByPageRequest(PageRequest pageRequest) {
        Map<String, Object> map = new HashMap<>();
        List<Param> params = pageRequest.getParams();
        for (Param param : params) {
            map.put(param.getName(), param.getValue());
        }
        return map;
    }
}
