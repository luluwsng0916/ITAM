package com.smc.service.asset;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.asset.bo.SoftwareAddBO;
import com.smc.controller.asset.bo.SoftwareDeleteBO;
import com.smc.controller.asset.bo.SoftwareEditBO;
import com.smc.dataobject.asset.AmsSoftware;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
* @author C31909
* @description 针对表【ams_software】的数据库操作Service
* @createDate 2024-08-01 09:00:18
*/
public interface AmsSoftwareService extends IService<AmsSoftware> {

    ResultBody<PageResult> page(PageRequest pageRequest);

    ResultBody<String> editById(SoftwareEditBO model);

    ResultBody<String> add(SoftwareAddBO model);

    ResultBody<String> delete(SoftwareDeleteBO model);

    String importExcel(MultipartFile multipartFile, HttpServletRequest req);

    void exportData(PageRequest pageRequest, HttpServletResponse response);
}
