package com.smc.service.asset;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.controller.asset.bo.*;
import com.smc.dataobject.asset.AmsVirtualMachineIDC;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author C31908
 * @version 1.0.0
 * @description
 */
public interface AmsVirtualMachineIDCService extends IService<AmsVirtualMachineIDC> {

    PageResult selectPage(PageRequest pageRequest);

    String editById(VirtualMachineIDCEditBO model);

    String add(VirtualMachineIDCAddBO model);

    String delete(VirtualMachineIDCDeleteBO model);

    void export(PageRequest pageRequest, HttpServletResponse response);

    String importExcel(MultipartFile file, HttpServletRequest request);
}
