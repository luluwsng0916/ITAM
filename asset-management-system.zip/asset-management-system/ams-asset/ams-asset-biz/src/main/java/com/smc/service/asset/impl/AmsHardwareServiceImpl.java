package com.smc.service.asset.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.smc.api.dto.SupplierDTO;
import com.smc.api.mdm.CodeGenApi;
import com.smc.api.mdm.UniversalCodeQueryApi;
import com.smc.api.mdm.dto.PublicUniversalCodeDTO;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.CommonConstants;
import com.smc.common.constants.DateFormat;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.constants.PatternConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.common.mybatis.model.KeyValueParam;
import com.smc.controller.asset.bo.HardwareBindSupplierBO;
import com.smc.controller.asset.bo.HardwareDeleteBO;
import com.smc.controller.asset.bo.HardwareEditBO;
import com.smc.controller.asset.bo.HardwareQueryBO;
import com.smc.controller.asset.dto.HardwareExcelDTO;
import com.smc.controller.asset.vo.HardwareVO;
import com.smc.dataobject.asset.AmsHardware;
import com.smc.dataobject.asset.AmsVirtualMachine;
import com.smc.dataobject.supplier.AmsSuppliers;
import com.smc.easyexcel.asset.listener.ImportHardwareListener;
import com.smc.enums.asset.AssetConstant;
import com.smc.enums.mdm.TableCodeRule;
import com.smc.mapper.asset.AmsHardwareMapper;
import com.smc.service.asset.AmsHardwareService;
import com.smc.service.asset.AmsVirtualMachineService;
import com.smc.service.supplier.AmsSuppliersService;
import com.smc.utils.NumberFormatterUtils;
import com.smc.utils.StringUtils;
import com.smc.utils.WebUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 硬件
 *
 * @author C31909
 * @since 1.0.0 2024-07-10
 */
@Slf4j
@Service
public class AmsHardwareServiceImpl implements AmsHardwareService {

    @Resource
    private AmsHardwareMapper amsHardwareMapper;

    @Resource
    private QueryServiceClient queryServiceClient;

    @Resource
    private UniversalCodeQueryApi universalCodeQueryApi;

    @Resource
    private AmsSuppliersService amsSuppliersService;

    @Resource
    private AmsVirtualMachineService amsVirtualMachineService;

    @Resource
    private CodeGenApi codeGenApi;

    /**
     * 分页查询硬件信息。
     * <p>
     * 根据提供的分页请求参数，查询硬件资产的分页信息。支持通过资产名称和型号进行过滤查询，
     * 并支持自定义排序条件。查询结果会转换为对应的VO对象，方便前端展示。
     *
     * @param pageRequest 分页请求对象，包含页码、每页大小、过滤条件和排序条件等信息。
     * @return 返回分页查询结果，包括总页数、总记录数和当前页的硬件信息列表。
     */
    @Override
    public ResultBody<PageInfo<HardwareVO>> page(PageRequest pageRequest) {
        // 从分页请求中获取资产名称和型号参数
        String assetName = pageRequest.getParamValue("assetName");
        String model = pageRequest.getParamValue("model");

        // 构建查询条件，根据资产名称和型号进行模糊查询，且只查询未删除的硬件
        LambdaQueryWrapper<AmsHardware> wrapper = new LambdaQueryWrapper<>();
        wrapper.like(StringUtils.isNotBlank(assetName), AmsHardware::getAssetName, assetName);
        wrapper.like(StringUtils.isNotBlank(model), AmsHardware::getModel, model);
        wrapper.eq(AmsHardware::getDeleteMark, DeleteMarkConstant.NOT_DELETED);

        // 通过queryServiceClient获取额外的查询条件和排序条件
        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        StringBuilder stringBuilder = new StringBuilder();
        if (map.get("conditionParams") != null) {
            stringBuilder.append(map.get("conditionParams"));
        }
        if (map.get("sortParam") != null) {
            stringBuilder.append(" ORDER BY ").append(map.get("sortParam"));
        } else {
            stringBuilder.append(" ORDER BY ").append("id");
        }
        wrapper.last(stringBuilder.toString());

        // 初始化分页插件，进行分页查询
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsHardware> list = amsHardwareMapper.selectList(wrapper);
        // 为什么：原因是自己封装的vo把PageInfo原有的属性破坏了
        // 解决方案：https://blog.csdn.net/qq_39765635/article/details/87694796
        PageInfo<AmsHardware> pageInfo = new PageInfo<>(list);
        // 如果查询结果为空，直接返回空的分页信息
        if (CollectionUtil.isEmpty(list)) {
            return ResultBody.ok().data(pageInfo);
        }
        // 将查询到的硬件信息转换为VO对象
        List<HardwareVO> hardwareVOList = toHardwareVO(list);
        // 构建分页信息并返回
        PageInfo<HardwareVO> pageInfoRes = new PageInfo<>(hardwareVOList);
        pageInfoRes.setPageNum(pageInfo.getPageNum());
        pageInfoRes.setPageSize(pageInfo.getPageSize());
        pageInfoRes.setTotal(pageInfo.getTotal());
        pageInfoRes.setPages(pageInfo.getPages());
        // BeanUtils.copyProperties(pageInfo,pageInfoRes);
        return ResultBody.ok().data(pageInfoRes);
    }

    private Map<Integer, PublicUniversalCodeDTO> getAllUniversalCode(List<AmsHardware> list) {
        List<Integer> codeList = new ArrayList<>();
        // 查询卡片别
        codeList.addAll(list.stream().map(AmsHardware::getCompanyCode).collect(Collectors.toList()));
        // 查询分类
        codeList.addAll(list.stream().map(AmsHardware::getCategory).collect(Collectors.toList()));
        // 查询生产厂商
        codeList.addAll(list.stream().map(AmsHardware::getBrand).collect(Collectors.toList()));
        codeList = codeList.stream().distinct().filter(Objects::nonNull).collect(Collectors.toList());
        List<PublicUniversalCodeDTO> universalCodeByIdList = universalCodeQueryApi.getUniversalCodeByIdList(codeList);
        if (CollectionUtil.isEmpty(universalCodeByIdList)) {
            return null;
        }
        return universalCodeByIdList.stream()
                .collect(Collectors.toMap(PublicUniversalCodeDTO::getId, Function.identity()));
    }


    private List<HardwareVO> toHardwareVO(List<AmsHardware> list) {
        if (CollectionUtil.isEmpty(list)) {
            return null;
        }
        Map<Integer, PublicUniversalCodeDTO> allUniversalCode = getAllUniversalCode(list);
        Map<Integer, SupplierDTO> allSuppliers = getAllSupplierIds(list);
        List<HardwareVO> hardwareVOlist = Lists.newArrayList();
        for (AmsHardware amsHardware : list) {
            hardwareVOlist.add(convertFromAmsHardware(amsHardware, allUniversalCode, allSuppliers));
        }
        return hardwareVOlist;
    }

    private Map<Integer, SupplierDTO> getAllSupplierIds(List<AmsHardware> list) {
        List<Integer> supplierId = list.stream().map(AmsHardware::getSupplierId).filter(Objects::nonNull).distinct().collect(Collectors.toList());
        List<SupplierDTO> supplierDTOList = amsSuppliersService.listByIds(supplierId);
        if (CollectionUtil.isEmpty(supplierDTOList)) {
            return null;
        }
        return supplierDTOList.stream().collect(Collectors.toMap(SupplierDTO::getId, Function.identity()));
    }

    private HardwareVO convertFromAmsHardware(AmsHardware amsHardware, Map<Integer, PublicUniversalCodeDTO> codeMap,
                                              Map<Integer, SupplierDTO> allSuppliers) {
        HardwareVO hardwareVO = new HardwareVO();
        hardwareVO.setManager(amsHardware.getManager());
        hardwareVO.setId(amsHardware.getId());
        hardwareVO.setCompanyCode(CollectionUtil.isEmpty(codeMap) ? null : getDictValueByCodeId(amsHardware.getCompanyCode(), codeMap));
        hardwareVO.setSerialNum(amsHardware.getSerialNum());
        hardwareVO.setAssetNum(amsHardware.getAssetNum());
        hardwareVO.setAssetName(amsHardware.getAssetName());
        hardwareVO.setCategory(CollectionUtil.isEmpty(codeMap) ? null : getDictValueByCodeId(amsHardware.getCategory(), codeMap));
        hardwareVO.setBrand(CollectionUtil.isEmpty(codeMap) ? null : getDictValueByCodeId(amsHardware.getBrand(), codeMap));
        hardwareVO.setModel(amsHardware.getModel());
        hardwareVO.setDeptCode(amsHardware.getDeptCode());
        hardwareVO.setPlace(amsHardware.getPlace());
        hardwareVO.setDetailPlace(amsHardware.getDetailPlace());
        hardwareVO.setUsed(amsHardware.getUsed());
        hardwareVO.setStartDate(amsHardware.getStartDate());
        hardwareVO.setSupplierId(amsHardware.getSupplierId());
        if (!CollectionUtil.isEmpty(allSuppliers)) {
            SupplierDTO supplierDTO = allSuppliers.get(amsHardware.getSupplierId());
            if (supplierDTO != null) {
                hardwareVO.setSupplierName(supplierDTO.getName());
            }
        }
        hardwareVO.setApplyId(amsHardware.getApplyId());
        hardwareVO.setScrapped(amsHardware.getScrapped() != null && amsHardware.getScrapped().equals(AssetConstant.SCRAPPED) ? AssetConstant.SCRAPPED_STR :
                AssetConstant.NO_SCRAPPED_STR);
        hardwareVO.setScrapDate(amsHardware.getScrapDate());
        hardwareVO.setHomeCurrencyValue(amsHardware.getHomeCurrencyValue());
        hardwareVO.setIp(amsHardware.getIp());
        hardwareVO.setRemark(amsHardware.getRemark());
        hardwareVO.setVersion(amsHardware.getVersion());
        hardwareVO.setCreatedBy(amsHardware.getCreatedBy());
        hardwareVO.setCreatedTime(amsHardware.getCreatedTime());
        hardwareVO.setUpdatedBy(amsHardware.getUpdatedBy());
        hardwareVO.setUpdatedTime(amsHardware.getUpdatedTime());
        return hardwareVO;
    }

    private String getDictValueByCodeId(Integer codeId, Map<Integer, PublicUniversalCodeDTO> codeMap) {
        if (codeMap.containsKey(codeId)) {
            return codeMap.get(codeId).getDictValue();
        }
        return null;
    }

    @Override
    public ResultBody<String> editById(HardwareEditBO model) {
        AmsHardware amsHardware = new AmsHardware();
        amsHardware.setId(model.getId());
        amsHardware.setManager(model.getManager());
        amsHardware.setCompanyCode(model.getCompanyCode());
        amsHardware.setAssetNum(model.getAssetNum());
        amsHardware.setSerialNum(model.getSerialNum());
        amsHardware.setAssetName(model.getAssetName());
        amsHardware.setCategory(model.getCategory());
        amsHardware.setModel(model.getModel());
        amsHardware.setHomeCurrencyValue(model.getHomeCurrencyValue());
        amsHardware.setDeptCode(model.getDeptCode());
        amsHardware.setPlace(model.getPlace());
        amsHardware.setDetailPlace(model.getDetailPlace());
        amsHardware.setUsed(model.getUsed());
        amsHardware.setStartDate(model.getStartDate());
        amsHardware.setSupplierId(model.getSupplierId());
        amsHardware.setBrand(model.getBrand());
        amsHardware.setApplyId(model.getApplyId());
        amsHardware.setScrapped(model.getScrapped());
        amsHardware.setScrapDate(model.getScrapDate());
        amsHardware.setIp(model.getIp());
        amsHardware.setRemark(model.getRemark());
        amsHardware.setVersion(model.getVersion());
        amsHardware.setUpdatedBy(model.getUpdatedBy());
        amsHardware.setUpdatedTime(new Date());
        amsHardwareMapper.updateById(amsHardware);
        return ResultBody.ok();
    }

    @Override
    public ResultBody<String> add(AmsHardware model) {
        model.setVersion(CommonConstants.DEFAULT_VERSION);
        model.setCreatedTime(new Date());
        model.setUpdatedBy(model.getCreatedBy());
        model.setUpdatedTime(new Date());
        model.setId(codeGenApi.getCodeByTableName(TableCodeRule.HARDWARE));
        if (model.getUsed() == null) {
            model.setUsed("1");
        }
        if (model.getScrapped() == null) {
            model.setScrapped(false);
        }
        amsHardwareMapper.insert(model);
        return ResultBody.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ResultBody<String> delete(HardwareDeleteBO deleteBO) {
        // 判断其是否包含了虚拟的服务器
        List<AmsVirtualMachine> amsVirtualMachines = amsVirtualMachineService.getByHardwareId(deleteBO.getId());
        if (CollectionUtil.isNotEmpty(amsVirtualMachines)) {
            return ResultBody.failed().msg("该硬件下存在虚拟服务器，请先解除绑定");
        }
        AmsHardware amsHardware = new AmsHardware();
        amsHardware.setId(deleteBO.getId());
        amsHardware.setDeleteMark(DeleteMarkConstant.DELETED);
        amsHardware.setUpdatedBy(deleteBO.getUpdatedBy());
        amsHardware.setUpdatedTime(new Date());
        amsHardware.setVersion(deleteBO.getVersion());
        amsHardwareMapper.updateById(amsHardware);
        return ResultBody.ok();
    }

    @Override
    public void saveBatch(List<AmsHardware> amsHardwares) {
        amsHardwares.forEach(amsHardware -> {
            if (StringUtils.isBlank(amsHardware.getId())) {
                amsHardware.setId(codeGenApi.getCodeByTableName(TableCodeRule.HARDWARE));
            }
        });
        List<List<AmsHardware>> partition = Lists.partition(amsHardwares, 50);
        partition.forEach(list -> amsHardwareMapper.insertBatch(list));
    }

    @Override
    public ResultBody<String> bindSupplier(HardwareBindSupplierBO bo) {
        AmsHardware amsHardware = new AmsHardware();
        amsHardware.setId(bo.getId());
        amsHardware.setSupplierId(bo.getSupplierId());
        amsHardware.setVersion(bo.getVersion());
        amsHardware.setUpdatedBy(bo.getUpdatedBy());
        amsHardware.setUpdatedTime(new Date());
        amsHardwareMapper.updateById(amsHardware);
        return ResultBody.ok();
    }

    @Override
    public List<AmsHardware> getByIdList(List<Integer> hardwareIds) {
        if (CollectionUtil.isEmpty(hardwareIds)) {
            return Collections.emptyList();
        }
        return amsHardwareMapper.selectBatchIds(hardwareIds);
    }

    @Override
    public ResultBody<HardwareVO> getById(String id) {
        LambdaQueryWrapper<AmsHardware> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AmsHardware::getId, id);
        queryWrapper.eq(AmsHardware::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        List<AmsHardware> amsHardwares = amsHardwareMapper.selectList(queryWrapper);
        if (CollectionUtil.isEmpty(amsHardwares)) {
            return ResultBody.failed().msg("该硬件不存在");
        }
        List<HardwareVO> hardwareVO = toHardwareVO(Collections.singletonList(amsHardwares.get(0)));
        return ResultBody.ok().data(hardwareVO.get(0));
    }

    @Override
    public ResultBody<List<HardwareVO>> listByCondition(HardwareQueryBO queryBO) {
        if (StringUtils.isEmpty(queryBO.getAssetName()) && StringUtils.isEmpty(queryBO.getId())) {
            LambdaQueryWrapper<AmsHardware> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(AmsHardware::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
            queryWrapper.orderByDesc(AmsHardware::getUpdatedTime);
            queryWrapper.last("limit 20");
            List<AmsHardware> amsHardwares = amsHardwareMapper.selectList(queryWrapper);
            return ResultBody.ok().data(toHardwareVO(amsHardwares));
        }

        LambdaQueryWrapper<AmsHardware> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AmsHardware::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        if (StringUtils.isNotBlank(queryBO.getId())) {
            if (queryBO.getId().startsWith(AssetConstant.SM_PREFIX)) {
                queryBO.setId(queryBO.getId().substring(AssetConstant.SM_PREFIX.length()));
                if (StringUtils.isNumeric(queryBO.getId())) {
                    queryWrapper.eq(AmsHardware::getId, Integer.parseInt(queryBO.getId()));
                } else {
                    queryWrapper.like(AmsHardware::getId, queryBO.getId());
                }
            } else {
                if (StringUtils.isNumeric(queryBO.getId())) {
                    queryWrapper.like(AmsHardware::getId, Integer.parseInt(queryBO.getId()));
                } else {
                    queryWrapper.like(AmsHardware::getId, queryBO.getId());
                }
            }
        }
        queryWrapper.like(StringUtils.isNotBlank(queryBO.getAssetName()), AmsHardware::getAssetName, queryBO.getAssetName());
        queryWrapper.orderByDesc(AmsHardware::getUpdatedTime);
        queryWrapper.last("limit 20");
        List<AmsHardware> amsHardwares = amsHardwareMapper.selectList(queryWrapper);
        return ResultBody.ok().data(toHardwareVO(amsHardwares));
    }

    @Override
    public List<AmsHardware> listHardwareIdBySearch(String searchKey) {
        LambdaQueryWrapper<AmsHardware> queryWrapper = new LambdaQueryWrapper<>();
        if (StringUtils.isBlank(searchKey) || "S".equals(searchKey) || "M".equals(searchKey)) {
            queryWrapper.eq(AmsHardware::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
            queryWrapper.orderByDesc(AmsHardware::getId);
            queryWrapper.last("limit 20");
            return amsHardwareMapper.selectList(queryWrapper);
        }
        queryWrapper.select(AmsHardware::getId);
        if (searchKey.startsWith(AssetConstant.SM_PREFIX)) {
            if (StringUtils.isNumeric(searchKey.substring(AssetConstant.SM_PREFIX.length()))) {
                queryWrapper.like(AmsHardware::getId, Integer.parseInt(searchKey.substring(AssetConstant.SM_PREFIX.length())));
            } else {
                queryWrapper.like(AmsHardware::getId, searchKey.substring(AssetConstant.SM_PREFIX.length()));
            }
        } else if (searchKey.startsWith(AssetConstant.S_PREFIX) || searchKey.startsWith(AssetConstant.M_PREFIX)) {
            if (StringUtils.isNumeric(searchKey.substring(AssetConstant.S_PREFIX.length()))) {
                queryWrapper.like(AmsHardware::getId, Integer.parseInt(searchKey.substring(AssetConstant.S_PREFIX.length())));
            } else {
                queryWrapper.like(AmsHardware::getId, searchKey.substring(AssetConstant.S_PREFIX.length()));
            }
        } else {
            if (StringUtils.isNumeric(searchKey)) {
                queryWrapper.like(AmsHardware::getId, Integer.parseInt(searchKey));
            } else {
                queryWrapper.like(AmsHardware::getId, searchKey);
            }
        }
        queryWrapper.eq(AmsHardware::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        queryWrapper.orderByDesc(AmsHardware::getId);
        queryWrapper.last("limit 20");
        return amsHardwareMapper.selectList(queryWrapper);
    }

    @Override
    public ResultBody<List<KeyValueParam<String, String>>> listAllHardwareId() {
        LambdaQueryWrapper<AmsHardware> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.select(AmsHardware::getId);
        queryWrapper.eq(AmsHardware::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        queryWrapper.orderByAsc(AmsHardware::getId);
        List<AmsHardware> amsHardwares = amsHardwareMapper.selectList(queryWrapper);
        if (CollectionUtil.isEmpty(amsHardwares)) {
            return ResultBody.failed().msg("硬件资产不存在");
        }
        List<KeyValueParam<String, String>> keyValueParams = new ArrayList<>();
        for (AmsHardware amsHardware : amsHardwares) {
            KeyValueParam<String, String> keyValue = new KeyValueParam<>();
            keyValue.setKey(amsHardware.getId());
            keyValue.setValue(amsHardware.getId());
            keyValueParams.add(keyValue);
        }
        return ResultBody.ok().data(keyValueParams);
    }

    @Override
    public List<String> findManagers() {
        return amsHardwareMapper.findManagers();
    }


    @Override
    @Transactional(rollbackFor = Exception.class, value = "")
    public ResultBody<String> importData(MultipartFile multipartFile, HttpServletRequest req) {
        List<HardwareExcelDTO> sourceExcelDataList;
        String userName = req.getParameter("userName");
        // 获取导入的excel
        sourceExcelDataList = getImportExcelData(multipartFile);
        /**
         * 导入检验
         */
        if (CollectionUtil.isEmpty(sourceExcelDataList)) {
            String msg = "导入失败，请检查是都符合规则或者导入excel符合模板要求";
            return ResultBody.failed().msg(msg);
        }
        ArrayList<AmsHardware> amsHardwares = new ArrayList<>();
        try {
            for (HardwareExcelDTO sourceExcel : sourceExcelDataList) {
//                if (StringUtils.isEmpty(sourceExcel.getManager())) {
//                    return ResultBody.ok().data("资产管理担当为空");
//                }
                // 创建一个新的AmsHardware实例
                AmsHardware amsHardware = new AmsHardware();
                if (StringUtils.isNotBlank(sourceExcel.getId()) && StringUtils.isNotBlank(sourceExcel.getId().trim())) {
                    if (sourceExcel.getId().trim().startsWith(AssetConstant.SM_PREFIX)) {
                        String numStr = sourceExcel.getId().trim().substring(AssetConstant.SM_PREFIX.length());
                        if (StringUtils.isNumeric(numStr)) {
                            String hardwareId = AssetConstant.SM_PREFIX + NumberFormatterUtils.formatNumber(6, Integer.parseInt(numStr));
                            // 判断硬件表中是否存在
                            if (amsHardwareMapper.selectById(hardwareId) != null) {
                                return ResultBody.failed().msg(sourceExcel.getId() + "资产编号已存在或已逻辑删除，请检查是否正确！");
                            }
                            amsHardware.setId(hardwareId);
                        } else {
                            return ResultBody.failed().msg(sourceExcel.getId() + "资产编号不符合规则，请检查是否正确！");
                        }
                    } else {
                        return ResultBody.failed().msg(sourceExcel.getId() + "资产编号不符合规则，请检查是否正确！");
                    }
                }
                // 检查卡片别是否被设置，以及是否为非空字符串
                if (StringUtils.isNotBlank(sourceExcel.getCompanyCode()) && StringUtils.isNotBlank(sourceExcel.getCompanyCode().trim())) {
                    // 根据卡片别名称查询对应编码
                    List<Integer> universalCodeByClassify = universalCodeQueryApi.
                            getUniversalCodeByDictValue(AssetConstant.KPB, sourceExcel.getCompanyCode().trim());
                    // 如果卡片别不存在，返回错误信息
                    if (CollectionUtil.isEmpty(universalCodeByClassify)) {
                        universalCodeQueryApi.saveUniversalCode(AssetConstant.KPB, Collections.singletonList(sourceExcel.getCompanyCode().trim()));
                        // return ResultBody.failed().msg(sourceExcel.getCompanyCode() + "卡片别不存在，请检查是否正确");
                        universalCodeByClassify = universalCodeQueryApi.
                                getUniversalCodeByDictValue(AssetConstant.KPB, sourceExcel.getCompanyCode().trim());
                    }
                    // 设置卡片别编码
                    amsHardware.setCompanyCode(universalCodeByClassify.get(0));
                }
                // 设置序列号，如果未设置或为空，则设置为空字符串
                amsHardware.setSerialNum(StringUtils.isNotBlank(sourceExcel.getSerialNum()) ? sourceExcel.getSerialNum().trim() : "");
                // 设置序列号，如果未设置或为空，则设置为空字符串
                amsHardware.setAssetNum(StringUtils.isNotBlank(sourceExcel.getAssetNum()) ? sourceExcel.getAssetNum().trim() : "");
                // 设置资产名称，如果未设置或为空，则设置为空字符串
                amsHardware.setAssetName(StringUtils.isNotBlank(sourceExcel.getAssetName()) ? sourceExcel.getAssetName().trim() : "");
                // 检查硬件分类是否被设置，以及是否为非空字符串
                if (StringUtils.isNotBlank(sourceExcel.getCategory()) && StringUtils.isNotBlank(sourceExcel.getCategory().trim())) {
                    // 根据硬件分类名称查询对应编码
                    List<Integer> universalCodeByClassify = universalCodeQueryApi.
                            getUniversalCodeByDictValue(AssetConstant.YJFL, sourceExcel.getCategory().trim());
                    if (CollectionUtil.isEmpty(universalCodeByClassify)) {
                        universalCodeQueryApi.saveUniversalCode(AssetConstant.YJFL, Collections.singletonList(sourceExcel.getCategory().trim()));
                        // 如果硬件分类不存在，返回错误信息
                        // return ResultBody.failed().msg(sourceExcel.getCategory() + "硬件分类不存在，请检查是否正确");
                        universalCodeByClassify = universalCodeQueryApi.
                                getUniversalCodeByDictValue(AssetConstant.YJFL, sourceExcel.getCategory().trim());
                    }
                    // 设置硬件分类编码
                    amsHardware.setCategory(universalCodeByClassify.get(0));
                }
                // 设置型号，如果未设置或为空，则设置为空字符串
                amsHardware.setModel(StringUtils.isNotBlank(sourceExcel.getModel()) ? sourceExcel.getModel().trim() : "");
                // 设置本币原值
                if (!(sourceExcel.getHomeCurrencyValue().contains("￥"))) {
                    return ResultBody.failed().msg("本币原值前需补充【¥】符号");
                }
                amsHardware.setHomeCurrencyValue(sourceExcel.getHomeCurrencyValue().trim().substring(1).replace(",", ""));
                // 设置部门编码，如果未设置或为空，则设置为空字符串
                amsHardware.setDeptCode(StringUtils.isNotBlank(sourceExcel.getDeptCode()) ? sourceExcel.getDeptCode().trim() : "");
                // 设置位置，如果未设置或为空，则设置为空字符串
                amsHardware.setPlace(StringUtils.isNotBlank(sourceExcel.getPlace()) ? sourceExcel.getPlace().trim() : "");
                // 设置详细位置，如果未设置或为空，则设置为空字符串
                amsHardware.setDetailPlace(StringUtils.isNotBlank(sourceExcel.getDetailPlace()) ? sourceExcel.getDetailPlace().trim() : "");
                //  设置使用状态
                amsHardware.setUsed(sourceExcel.getUsed());
                if (StringUtils.isNotBlank(sourceExcel.getStartDate()) && StringUtils.isNotBlank(sourceExcel.getStartDate().trim())) {
                    // 如果硬件设备的使用状态未设置，则默认设置为true（使用中）
                    if (amsHardware.getUsed() == null) {
                        amsHardware.setUsed("1");
                    }
                    // 判断日期格式是否包含"-"，如果是，则按照"yyyy-MM-dd"格式解析
                    if (sourceExcel.getStartDate().contains("-")) {
                        if (StringUtils.validData(sourceExcel.getStartDate(), PatternConstant.DATE_YYYY_MM_DD)) {
                            amsHardware.setStartDate(DateUtil.parse(sourceExcel.getStartDate(), DatePattern.NORM_DATE_PATTERN));
                        } else {
                            // 返回错误信息，提示日期格式不正确
                            return ResultBody.failed().msg(sourceExcel.getStartDate() + "开始使用日期格式不正确（yyyy-MM-dd或者yyyy/MM/dd），请检查是否正确");
                        }
                    } else if (sourceExcel.getStartDate().contains("/")) {
                        if (StringUtils.validData(sourceExcel.getStartDate(), PatternConstant.DATE_YYYY_MM_DD_SLASH)) {
                            // 如果日期格式包含"/"，则按照"yyyy/MM/dd"格式解析
                            amsHardware.setStartDate(DateUtil.parse(sourceExcel.getStartDate(), DateFormat.DATE_YYYY_MM_DD_SLASH));
                        } else {
                            // 返回错误信息，提示日期格式不正确
                            return ResultBody.failed().msg(sourceExcel.getStartDate() + "开始使用日期格式不正确（yyyy-MM-dd或者yyyy/MM/dd），请检查是否正确");
                        }
                    } else {
                        // 如果日期格式既不包含"-"也不包含"/"，则返回错误信息
                        return ResultBody.failed().msg(sourceExcel.getStartDate() + "开始使用日期格式不正确（yyyy-MM-dd或者yyyy/MM/dd），请检查是否正确");
                    }
                }
                // 检查供应商名称是否被设置，以及是否为非空字符串
                if (StringUtils.isNotBlank(sourceExcel.getSupplierName()) && StringUtils.isNotBlank(sourceExcel.getSupplierName().trim())) {
                    // 默认取相同供应商名称的最新的数据
                    AmsSuppliers amsSuppliers = amsSuppliersService.getSupplierInfo(sourceExcel.getSupplierName().trim());
                    if (amsSuppliers != null) {
                        // 如果供应商存在，设置供应商ID
                        amsHardware.setSupplierId(amsSuppliers.getId());
                    } else {
                        AmsSuppliers newSupplier = new AmsSuppliers();
                        newSupplier.setName(sourceExcel.getSupplierName().trim());
                        newSupplier.setCreatedBy("sys");
                        newSupplier.setUpdatedBy("sys");
                        amsSuppliersService.add(newSupplier);
                        amsHardware.setSupplierId(newSupplier.getId());
                        // 如果供应商不存在，返回错误信息
                        // return ResultBody.failed().msg("不存在供应商：" + sourceExcel.getSupplierName());
                    }
                }
                // 检查品牌是否被设置，以及是否为非空字符串
                if (StringUtils.isNotBlank(sourceExcel.getBrand()) && StringUtils.isNotBlank(sourceExcel.getBrand().trim())) {
                    // 根据生产厂商名称查询对应编码
                    List<Integer> universalCodeByClassify = universalCodeQueryApi.
                            getUniversalCodeByDictValue(AssetConstant.SCCS, sourceExcel.getBrand().trim());
                    if (CollectionUtil.isEmpty(universalCodeByClassify)) {
                        // 如果生产厂商不存在，返回错误信息
                        universalCodeQueryApi.saveUniversalCode(AssetConstant.SCCS, Collections.singletonList(sourceExcel.getBrand().trim()));
                        universalCodeByClassify = universalCodeQueryApi.
                                getUniversalCodeByDictValue(AssetConstant.SCCS, sourceExcel.getBrand().trim());
                        // return ResultBody.failed().msg(sourceExcel.getBrand() + "生产厂商不存在，请检查是否正确");
                    }
                    // 设置生产厂商编码
                    amsHardware.setBrand(universalCodeByClassify.get(0));
                }
                // 设置禀议号，如果未设置或为空，则设置为空字符串
                amsHardware.setApplyId(StringUtils.isNotBlank(sourceExcel.getApplyId()) &&
                        StringUtils.isNotBlank(sourceExcel.getApplyId().trim()) ? sourceExcel.getApplyId().trim() : "");
                // 检查是否报废字段是否被设置，以及是否为非空字符串
                if (StringUtils.isNotBlank(sourceExcel.getScrapped()) && StringUtils.isNotBlank(sourceExcel.getScrapped().trim())) {
                    // 验证是否报废的值是否正确（仅允许"Y"或"N"）
                    if (!sourceExcel.getScrapped().equals(AssetConstant.SCRAPPED_STR) && !sourceExcel.getScrapped().equals(AssetConstant.NO_SCRAPPED_STR)) {
                        return ResultBody.failed().msg(sourceExcel.getScrapped() + "是否报废格式不正确，仅为Y/N,请检查是否正确");
                    }
                    // 设置报废状态
                    amsHardware.setScrapped(sourceExcel.getScrapped().equals(AssetConstant.SCRAPPED_STR));
                }
                // 检查报废日期是否被设置，以及是否为非空字符串
                if (StringUtils.isNotBlank(sourceExcel.getScrapDate()) && StringUtils.isNotBlank(sourceExcel.getScrapDate().trim())) {
                    // 如果硬件设备的报废状态未设置，则默认设置为true（已报废）
                    if (amsHardware.getScrapped() == null) {
                        amsHardware.setScrapped(true);
                    }
                    // 如果日期格式包含"-"，按照"yyyy-MM-dd"格式进行解析
                    if (sourceExcel.getScrapDate().contains("-")) {
                        if (!StringUtils.validData(sourceExcel.getScrapDate().trim(), PatternConstant.DATE_YYYY_MM_DD)) {
                            return ResultBody.failed().msg(sourceExcel.getScrapDate() + "报废日期格式不正确（yyyy-MM-dd或者yyyy/MM/dd），请检查是否正确");
                        }
                        amsHardware.setScrapDate(DateUtil.parse(sourceExcel.getScrapDate(), DatePattern.NORM_DATE_PATTERN));
                    } else if (sourceExcel.getScrapDate().contains("/")) {
                        // 如果日期格式包含"/"，按照"yyyy/MM/dd"格式进行解析
                        if (!StringUtils.validData(sourceExcel.getScrapDate().trim(), PatternConstant.DATE_YYYY_MM_DD_SLASH)) {
                            return ResultBody.failed().msg(sourceExcel.getScrapDate() + "报废日期格式不正确（yyyy-MM-dd或者yyyy/MM/dd），请检查是否正确");
                        }
                        amsHardware.setScrapDate(DateUtil.parse(sourceExcel.getScrapDate(), DateFormat.DATE_YYYY_MM_DD_SLASH));
                    } else {
                        // 如果日期格式既不包含"-"也不包含"/"，则返回错误信息
                        return ResultBody.failed().msg(sourceExcel.getScrapDate() + "报废日期格式不正确（yyyy-MM-dd或者yyyy/MM/dd），请检查是否正确");
                    }
                }
                // 如果使用状态未设置，则默认设置为false（未使用）
                if (amsHardware.getUsed() == null) {
                    amsHardware.setUsed("0");
                }
                // 如果报废状态未设置，则默认设置为false（未报废）
                if (amsHardware.getScrapped() == null) {
                    amsHardware.setScrapped(false);
                }
                amsHardware.setIp(StringUtils.isNotBlank(sourceExcel.getIp()) ? sourceExcel.getIp().trim() : "");
                // 设置备注信息，如果未设置或为空，则设置为空字符串
                amsHardware.setRemark(StringUtils.isNotBlank(sourceExcel.getRemark()) ? sourceExcel.getRemark().trim() : "");
                // 初始化版本号、创建人、创建时间、修改人、修改时间、删除标记等字段
                amsHardware.setVersion(CommonConstants.DEFAULT_VERSION);
                amsHardware.setCreatedBy(userName);
                amsHardware.setCreatedTime(new Date());
                amsHardware.setUpdatedBy(userName);
                amsHardware.setUpdatedTime(amsHardware.getCreatedTime());
                amsHardware.setDeleteMark(DeleteMarkConstant.NOT_DELETED);
                amsHardware.setManager(sourceExcel.getManager());
                // 将硬件设备对象添加到集合中
                amsHardwares.add(amsHardware);
            }
        } catch (NumberFormatException e) {
            return ResultBody.ok().data("导入模板错误").path(WebUtils.getUri());
        }
        // 批量插入
        this.saveBatch(amsHardwares);
        return ResultBody.ok().data("success").path(WebUtils.getUri());
    }

    private List<HardwareExcelDTO> getImportExcelData(MultipartFile multipartFile) {
        try {
            if (multipartFile != null) {
                // 导入excel
                EasyExcel.read(multipartFile.getInputStream(), HardwareExcelDTO.class, new ImportHardwareListener()).sheet().doRead();
                // 获取excel导入的所有基础数据
                return EasyExcelHardwareServiceImpl.getAllImportExcelData();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void exportData(PageRequest pageRequest, HttpServletResponse response) throws IOException {
        String isFormWork = pageRequest.getParamValue("isFormWork");
        // 从分页请求中获取资产名称和型号参数
        String assetName = pageRequest.getParamValue("assetName");
        String model = pageRequest.getParamValue("model");
        if ("模板".equals(isFormWork)) {
            Set<String> excludeColumnFiledNames = new HashSet<>();
            excludeColumnFiledNames.add("id");
            excludeColumnFiledNames.add("createdBy");
            excludeColumnFiledNames.add("createdTime");
            excludeColumnFiledNames.add("updatedBy");
            excludeColumnFiledNames.add("updatedTime");
            EasyExcel.write(response.getOutputStream(), HardwareExcelDTO.class).
                    excludeColumnFiledNames(excludeColumnFiledNames).
                    sheet("硬件管理模板").doWrite(new ArrayList<HardwareExcelDTO>());
            return;
        }
        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        StringBuilder stringBuilder = new StringBuilder();
        if (map.get("conditionParams") != null) {
            stringBuilder.append(map.get("conditionParams"));
        }
        if (map.get("sortParam") != null) {
            stringBuilder.append(" ORDER BY ").append(map.get("sortParam"));
        } else {
            stringBuilder.append(" ORDER BY ").append(" id ");
        }
        // 指定导出的字段
        // List<String> distinctUsedFieldList = (List<String>) map.get("distinctUsedFieldList");
        // String selectFields;
        // if (!CollectionUtil.isEmpty(distinctUsedFieldList)) {
        //     selectFields = CollectionUtil.join(distinctUsedFieldList, ",");
        // } else {
        //     selectFields = "*";
        // }
        // List<AmsHardware> list = amsHardwareMapper.selectForExport(assetName, model, stringBuilder.toString(), selectFields);
        LambdaQueryWrapper<AmsHardware> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.like(StringUtils.isNotBlank(assetName), AmsHardware::getAssetName, assetName)
                .like(StringUtils.isNotBlank(model), AmsHardware::getModel, model)
                .eq(AmsHardware::getDeleteMark, DeleteMarkConstant.NOT_DELETED)
                .last(stringBuilder.toString());
        List<AmsHardware> list = amsHardwareMapper.selectList(queryWrapper);

        // 调用  生成 map 参数的方法
        // 用easyexcel方式导出
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");

        // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
        String fileName = URLEncoder.encode("测试", "UTF-8").replaceAll("\\+", "%20");

        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
        List<HardwareExcelDTO> hardwareExcelDTOList = toHardwareExcelDTO(list);
        EasyExcel.write(response.getOutputStream(), HardwareExcelDTO.class).
                sheet("硬件管理信息").doWrite(hardwareExcelDTOList);
    }

    private List<HardwareExcelDTO> toHardwareExcelDTO(List<AmsHardware> list) {
        if (CollectionUtil.isEmpty(list)) {
            return null;
        }
        Map<Integer, PublicUniversalCodeDTO> allUniversalCode = getAllUniversalCode(list);
        Map<Integer, SupplierDTO> allSuppliers = getAllSupplierIds(list);
        List<HardwareExcelDTO> hardwareExcelDTOList = Lists.newArrayList();
        for (AmsHardware amsHardware : list) {
            HardwareExcelDTO dto = new HardwareExcelDTO();
            dto.setId(amsHardware.getId());
            dto.setCompanyCode(CollectionUtil.isEmpty(allUniversalCode) || amsHardware.getCompanyCode() == null ? null :
                    getDictValueByCodeId(amsHardware.getCompanyCode(), allUniversalCode));
            dto.setSerialNum(amsHardware.getSerialNum());
            dto.setAssetName(amsHardware.getAssetName());
            dto.setCategory(CollectionUtil.isEmpty(allUniversalCode) || amsHardware.getCategory() == null ? null :
                    getDictValueByCodeId(amsHardware.getCategory(), allUniversalCode));
            dto.setBrand(CollectionUtil.isEmpty(allUniversalCode) || amsHardware.getBrand() == null ? null :
                    getDictValueByCodeId(amsHardware.getBrand(), allUniversalCode));
            dto.setModel(amsHardware.getModel());
            dto.setDeptCode(amsHardware.getDeptCode());
            dto.setPlace(amsHardware.getPlace());
            dto.setDetailPlace(amsHardware.getDetailPlace());
            dto.setUsed(amsHardware.getUsed().equals(AssetConstant.USE_FLAG) ? AssetConstant.USE_FLAG_STR :
                    AssetConstant.UNUSE_FLAG_STR);
            dto.setStartDate(amsHardware.getStartDate() != null ?
                    DateUtil.format(amsHardware.getStartDate(), DatePattern.NORM_DATETIME_FORMAT) : null);
            if (!CollectionUtil.isEmpty(allSuppliers)) {
                SupplierDTO supplierDTO = allSuppliers.get(amsHardware.getSupplierId());
                if (supplierDTO != null) {
                    dto.setSupplierName(supplierDTO.getName());
                }
            }
            dto.setApplyId(amsHardware.getApplyId());
            dto.setScrapped(amsHardware.getScrapped().equals(AssetConstant.SCRAPPED) ? AssetConstant.SCRAPPED_STR :
                    AssetConstant.NO_SCRAPPED_STR);
            dto.setScrapDate(amsHardware.getScrapped() != null ?
                    DateUtil.format(amsHardware.getScrapDate(), DatePattern.NORM_DATETIME_FORMAT) : null);
            dto.setHomeCurrencyValue(amsHardware.getHomeCurrencyValue().toString());
            dto.setIp(amsHardware.getIp());
            dto.setRemark(amsHardware.getRemark());
            dto.setCreatedBy(amsHardware.getCreatedBy());
            dto.setCreatedTime(amsHardware.getCreatedTime() != null ?
                    DateUtil.format(amsHardware.getCreatedTime(), DatePattern.NORM_DATETIME_FORMAT) : null);
            dto.setUpdatedBy(amsHardware.getUpdatedBy());
            dto.setUpdatedTime(amsHardware.getUpdatedTime() != null ?
                    DateUtil.format(amsHardware.getUpdatedTime(), DatePattern.NORM_DATETIME_FORMAT) : null);
            dto.setManager(amsHardware.getManager());
            dto.setAssetNum(amsHardware.getAssetNum());
            hardwareExcelDTOList.add(dto);
        }
        return hardwareExcelDTOList;
    }
}