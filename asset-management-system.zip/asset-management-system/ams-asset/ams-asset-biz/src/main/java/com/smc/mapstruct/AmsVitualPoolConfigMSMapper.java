package com.smc.mapstruct;

import com.smc.controller.asset.bo.*;
import com.smc.dataobject.asset.AmsVitualPoolConfig;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
@Mapper
public interface AmsVitualPoolConfigMSMapper {

    AmsVitualPoolConfigMSMapper INSTANCE = Mappers.getMapper(AmsVitualPoolConfigMSMapper.class);

    @Mapping(source = "operator", target = "createdBy")
    AmsVitualPoolConfig toVitualPoolConfigAdd(VitualPoolConfigAddBO vitualPoolConfigAddBO);

    @Mappings({
            @Mapping(source = "operator", target = "updatedBy"),
            @Mapping(source = "version", target = "version")
    })
    AmsVitualPoolConfig toVitualPoolConfigEdit(VitualPoolConfigEditBO vitualPoolConfigEditBO);

    @Mappings({
            @Mapping(source = "id", target = "id"),
            @Mapping(source = "updatedBy", target = "updatedBy"),
            @Mapping(source = "version", target = "version")
    })
    AmsVitualPoolConfig toVitualPoolConfigDel(VitualPoolConfigDeleteBO vitualPoolConfigDeleteBO);

}
