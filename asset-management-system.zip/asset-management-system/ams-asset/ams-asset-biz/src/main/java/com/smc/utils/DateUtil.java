package com.smc.utils;

import lombok.SneakyThrows;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

    public static Date createTimeToDate(){
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date1 = sdf.format(date);
        Date createdTime;
        try {
            createdTime = sdf.parse(date1);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return createdTime;
    }

    public static String createTimeToString(){
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String createdTime = sdf.format(date);
        return createdTime;
    }

    @SneakyThrows
    public static String formatDateToDay(String date){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date endDate = sdf.parse(date);
        String format = sdf.format(endDate);
        return format;
    }
}
