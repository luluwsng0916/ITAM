package com.smc.controller.asset.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentFontStyle;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import lombok.Data;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/10
 * @description
 */

@Data
@ColumnWidth(20)
@HeadFontStyle(fontHeightInPoints = 11)
@ContentFontStyle(fontHeightInPoints = 10)
public class VirtualPoolExcelDTO {

    private static final long serialVersionUID = 1L;

    @ExcelProperty(value = "硬件资产ID")
    private String hardwareId;

    @ExcelProperty(value = "服务器ID")
    private String virtualMachineId;

    @ExcelProperty(value = "资产管理担当")
    private String manager;

    @ExcelProperty(value = "有效性")
    private String activity;

    @ExcelProperty(value = "备注")
    private String remark;

    @ExcelProperty(value = "创建者")
    private String createdBy;

    @ExcelProperty(value = "创建时间")
    private String createdTime;

    @ExcelProperty(value = "更新者")
    private String updatedBy;

    @ExcelProperty(value = "更新时间")
    private String updatedTime;
}
