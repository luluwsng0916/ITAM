package com.smc.controller.asset.vo;

import lombok.Data;

/**
 *
 * @author C31908
 * @date 2024-08-26
 * @version 1.0.0
 * @description
 */

@Data
public class NetworkLineVO {

    /**
     * 专线编号
     */
    private String networkId;
    /**
     * 专线名称
     */
    private String networkName;
    /**
     * 专线类别
     */
    private String networkType;
    /**
     * 地点
     */
    private String place;
    /**
     * 带宽
     */
    private String bandwidth;
    /**
     * 协议金额（元/年）
     */
    private String agreementMoney;
    /**
     * 供应商名称
     */
    private String supplierName;
    /**
     * 起始日期
     */
    private String startDate;
    /**
     * 终止日期
     */
    private String endDate;
    /**
     * 备注
     */
    private String remark;
}
