package com.smc.controller.file;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.file.bo.FilePathCleanBO;
import com.smc.controller.file.bo.FilePathDeleteBO;
import com.smc.controller.file.bo.FilePathEditBO;
import com.smc.controller.file.vo.FilePathVO;
import com.smc.service.file.AmsFilePathsService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @program: asset-management-system
 * @ClassName AmsFilePathController
 * @description:
 * @author: C31909
 * @create: 2024-08-06 08:12
 * @Version 1.0
 **/
@CrossOrigin
@RestController
@RequestMapping("/file")
public class AmsFilePathController {
    @Resource
    private AmsFilePathsService amsFilePathsService;

    @PostMapping("/list")
    public ResultBody<PageInfo<FilePathVO>> page(@RequestBody PageRequest pageRequest) {
        return amsFilePathsService.page(pageRequest);
    }


    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody FilePathEditBO model) {
        return amsFilePathsService.editById(model);
    }

    // @PostMapping("/save")
    // public ResultBody<String> save(@RequestBody AmsFilePath model) {
    //     return amsFilePathService.add(model);
    // }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody FilePathDeleteBO model) {
        return amsFilePathsService.delete(model);
    }

    @PostMapping("/clean")
    public ResultBody<String> delete(@RequestBody FilePathCleanBO model) {
        return amsFilePathsService.clean(model);
    }

    // @PostMapping("/bind-hardware")
    // public ResultBody<String> bindHardware(@RequestBody FilePathBindHardwareBO bo) {
    //     return amsFilePathService.bindHardware(bo);
    // }

    // @PostMapping("/import")
    // public ResultBody<String> importData(@RequestParam(value = "multipartFile", required = false)
    //                                      MultipartFile multipartFile, HttpServletRequest req) {
    //     return amsFilePathService.importData(multipartFile, req);
    // }
    //
    // @PostMapping("/export")
    // public void exportData(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
    //     amsFilePathService.exportData(pageRequest, response);
    // }
}
