package com.smc.dataobject.maintenance;

import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @TableName ams_maintenance
 */
@TableName(value = "ams_maintenance")
@Data
public class AmsMaintenance_bak extends AbstractEntity implements Serializable {
    /**
     * 内部主键
     */
    @TableId(value = "id", type = IdType.INPUT)
    private String id;

    /**
     * 资产编码
     */
    @TableField(value = "assetId")
    private String assetId;

    /**
     * 开始日期
     */
    @TableField(value = "startDate")
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startDate;

    /**
     * 结束日期
     */
    @TableField(value = "endDate")
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endDate;

    /**
     * 服务提供商
     */
    @TableField(value = "provider")
    private String provider;

    /**
     * 服务类型
     */
    @TableField(value = "serviceType")
    private Integer serviceType;

    /**
     * 费用
     */
    @TableField(value = "cost")
    private BigDecimal cost;

    /**
     * 管理担当
     */
    @TableField(value = "manager")
    private String manager;

    /**
     * 合同编号
     */
    @TableField(value = "contractNo")
    private String contractNo;

    /**
     * 文件编码
     */
    @TableField(value = "fileId")
    private Integer fileId;

    /**
     * 有效性
     */
    @TableField(value = "activity")
    private Boolean activity;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}