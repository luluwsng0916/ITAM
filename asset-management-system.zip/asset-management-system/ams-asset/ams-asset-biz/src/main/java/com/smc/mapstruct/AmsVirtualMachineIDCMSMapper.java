package com.smc.mapstruct;

import com.smc.controller.asset.bo.*;
import com.smc.controller.asset.dto.VirtualMachineIDCExcelDTO;
import com.smc.dataobject.asset.AmsVirtualMachineIDC;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/8/26
 * @description
 */

@Mapper
public interface AmsVirtualMachineIDCMSMapper {

    AmsVirtualMachineIDCMSMapper INSTANCE = Mappers.getMapper(AmsVirtualMachineIDCMSMapper.class);

    AmsVirtualMachineIDC toAmsVirtualMachineIDCAdd(VirtualMachineIDCAddBO virtualMachineIDCAddBO);

    AmsVirtualMachineIDC toAmsVirtualMachineIDCImport(VirtualMachineIDCExcelDTO virtualMachineIDCExcelDTO);

    AmsVirtualMachineIDC toAmsVirtualMachineIDCEdit(VirtualMachineIDCEditBO virtualMachineIDCEditBO);

    AmsVirtualMachineIDC toAmsVirtualMachineIDCDel(VirtualMachineIDCDeleteBO virtualMachineIDCDeleteBO);
}
