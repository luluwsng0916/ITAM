package com.smc.controller.supplier;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.supplier.vo.SuppliersVO;
import com.smc.dataobject.supplier.AmsSuppliers;
import com.smc.service.supplier.AmsSuppliersService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @program: asset-management-system
 * @ClassName AmsSuppliersController
 * @description:
 * @author: C31909
 * @create: 2024-07-24 10:22
 * @Version 1.0
 **/
@CrossOrigin
@RestController
@RequestMapping("/supplier")
public class AmsSuppliersController {

    @Resource
    private AmsSuppliersService amsSuppliersService;

    @PostMapping("/getById")
    public ResultBody<SuppliersVO> getById(@RequestParam("id") Integer id) {
        return amsSuppliersService.getById(id);
    }


    @PostMapping("/listBySearch")
    public ResultBody<List<SuppliersVO>> listBySearch(@RequestParam("searchKey") String searchKey) {
        return amsSuppliersService.listBySearch(searchKey);
    }

    // @PostMapping("/listSupplierSelectBySearch")
    @PostMapping("/listAllSupplier")
    public ResultBody<List<SuppliersVO>> listAllSupplierVO() {
        return amsSuppliersService.listAllSupplierVO();
    }


    @PostMapping("/list")
    public ResultBody<PageInfo<SuppliersVO>> page(@RequestBody PageRequest pageRequest) {
        return amsSuppliersService.page(pageRequest);
    }

    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody AmsSuppliers model) {
        return amsSuppliersService.editById(model);
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody AmsSuppliers model) {
        return amsSuppliersService.add(model);
    }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody AmsSuppliers model) {
        return amsSuppliersService.delete(model);
    }

    @PostMapping("/import")
    public ResultBody<String> importData(@RequestParam(value = "multipartFile", required = false)
                                         MultipartFile multipartFile, HttpServletRequest req) {
        return amsSuppliersService.importData(multipartFile, req);
    }

    @PostMapping("/export")
    public void exportData(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        amsSuppliersService.exportData(pageRequest, response);
    }



}
