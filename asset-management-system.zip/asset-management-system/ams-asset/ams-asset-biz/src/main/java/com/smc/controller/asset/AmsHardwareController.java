package com.smc.controller.asset;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.common.mybatis.model.KeyValueParam;
import com.smc.controller.asset.bo.HardwareBindSupplierBO;
import com.smc.controller.asset.bo.HardwareDeleteBO;
import com.smc.controller.asset.bo.HardwareEditBO;
import com.smc.controller.asset.bo.HardwareQueryBO;
import com.smc.controller.asset.vo.HardwareVO;
import com.smc.dataobject.asset.AmsHardware;
import com.smc.service.asset.AmsHardwareService;
import com.smc.utils.StringUtils;
import com.smc.utils.WebUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 硬件
 *
 * @author C31909
 * @since 1.0.0 2024-07-10
 */
@CrossOrigin
@RestController
@RequestMapping("/hardware")
public class AmsHardwareController {
    @Resource
    private AmsHardwareService amsHardwareService;

    @PostMapping("/list")
    public ResultBody<PageInfo<HardwareVO>> page(@RequestBody PageRequest pageRequest) {
        return amsHardwareService.page(pageRequest);
    }


    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody HardwareEditBO model) {
        return amsHardwareService.editById(model);
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody AmsHardware model) {
        return amsHardwareService.add(model);
    }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody HardwareDeleteBO model) {
        return amsHardwareService.delete(model);
    }

    @PostMapping("/import")
    public ResultBody<String> importData(@RequestParam(value = "multipartFile", required = false)
                                         MultipartFile multipartFile, HttpServletRequest req) {
        return amsHardwareService.importData(multipartFile, req);
    }

    @PostMapping("/export")
    public void exportData(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        amsHardwareService.exportData(pageRequest, response);
    }

    @PostMapping("/bind-supplier")
    public ResultBody<String> bindSupplier(@RequestBody HardwareBindSupplierBO bo) {
        return amsHardwareService.bindSupplier(bo);
    }


    @PostMapping("/getById")
    public ResultBody<HardwareVO> getById(@RequestParam("id") String id) {
        if (StringUtils.isEmpty(id)) {
            return ResultBody.ok().data(null);
        }
        return amsHardwareService.getById(id);
    }


    @PostMapping("/listByCondition")
    public ResultBody<List<HardwareVO>> listByCondition(@RequestBody HardwareQueryBO queryBO) {
        return amsHardwareService.listByCondition(queryBO);
    }


    @GetMapping("/listAllHardwareId")
    public ResultBody<List<KeyValueParam<String, String>>> listAllHardwareId() {
        return amsHardwareService.listAllHardwareId();
    }

    @PostMapping("/findManagers")
    public ResultBody<List<String>> findManagers() {
        List<String> res = amsHardwareService.findManagers();
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }
}