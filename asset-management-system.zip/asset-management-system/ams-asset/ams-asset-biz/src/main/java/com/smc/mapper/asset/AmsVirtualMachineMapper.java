package com.smc.mapper.asset;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smc.dataobject.asset.AmsVirtualMachine;

import java.util.List;

/**
* 服务器虚拟池
*
* @author C31909 
* @since 1.0.0 2024-07-26
*/
public interface AmsVirtualMachineMapper extends BaseMapper<AmsVirtualMachine> {

    void insertBatch(List<AmsVirtualMachine> list);

    List<String> findSystemName(String data);
}