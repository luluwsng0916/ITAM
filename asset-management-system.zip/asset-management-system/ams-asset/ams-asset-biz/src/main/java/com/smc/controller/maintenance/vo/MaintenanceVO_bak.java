package com.smc.controller.maintenance.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.smc.convert.easyexcel.DateConverter;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @program: asset-management-system
 * @ClassName MaintenanceVO
 * @description:
 * @author: C31909
 * @create: 2024-08-01 09:15
 * @Version 1.0
 **/
@Data
public class MaintenanceVO_bak {
    /**
     * 内部主键
     */
    @ExcelProperty(value = "内部主键")
    private String id;

    /**
     * 资产编码
     */
    @ExcelProperty(value = "资产编码")
    private String assetId;

    /**
     * 开始日期
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "开始日期", converter = DateConverter.class)
    @ColumnWidth(25)
    private Date startDate;

    /**
     * 结束日期
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "结束日期", converter = DateConverter.class)
    @ColumnWidth(25)
    private Date endDate;

    /**
     * 服务提供商
     */
    @ExcelProperty(value = "服务提供商")
    private String provider;

    /**
     * 服务类型
     */
    @ExcelProperty(value = "服务类型")
    private String serviceType;

    /**
     * 费用
     */
    @ExcelProperty(value = "费用")
    private BigDecimal cost;

    /**
     * 管理担当
     */
    @ExcelProperty(value = "管理担当")
    private String manager;

    /**
     * 合同编号
     */
    @ExcelProperty(value = "合同编号")
    private String contractNo;

    /**
     * 文件编码
     */
    @ExcelIgnore
    private Integer fileId;

    @ExcelProperty(value = "文件地址")
    private String attachmentAddress;

    /**
     * 有效性
     */
    @ExcelProperty(value = "有效性")
    private String activity;

    /**
     * 备注
     */
    @ExcelProperty(value = "备注")
    private String remark;

    @ExcelIgnore
    private Integer version;


    @ExcelProperty(value = "创建者")
    private String createdBy;
    /**
     * 创建时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "创建时间", converter = DateConverter.class)
    @ColumnWidth(25)
    public Date createdTime;

    @ExcelProperty(value = "更新者")
    private String updatedBy;

    /**
     * 修改时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "更新时间", converter = DateConverter.class)
    @ColumnWidth(25)
    public Date updatedTime;
}
