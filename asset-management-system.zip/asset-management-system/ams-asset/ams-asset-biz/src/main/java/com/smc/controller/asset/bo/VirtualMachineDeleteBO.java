package com.smc.controller.asset.bo;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName VirtualMachineDeleteBO
 * @description:
 * @author: C31909
 * @create: 2024-07-26 09:17
 * @Version 1.0
 **/
@Data
public class VirtualMachineDeleteBO {
    /**
     * 内部编号
     */
    private String id;
    private String updatedBy;
    private Integer version;
}
