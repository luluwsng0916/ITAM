package com.smc.service.asset.impl;


import com.smc.controller.asset.dto.HardwareExcelDTO;
import com.smc.controller.asset.vo.HardwareVO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: C02039 wjh
 * @Date: 2023/3/2  8:46
 */
@Service
public class EasyExcelHardwareServiceImpl {

    static List<HardwareExcelDTO> list = new ArrayList<>();

    /**
     * 分批导入的数据拼接到一起
     *
     * @param
     * @return
     */
    public static List<HardwareExcelDTO> getAllImportExcelData() {
        return list;
    }

    public void save(List<HardwareExcelDTO> cachedDataList) {
        list.addAll(cachedDataList);
    }

    /**
     * 创建一个构造方法 用于list.clean()
     *
     * @return
     */
    public List<HardwareExcelDTO> getList() {
        return list;
    }

}
