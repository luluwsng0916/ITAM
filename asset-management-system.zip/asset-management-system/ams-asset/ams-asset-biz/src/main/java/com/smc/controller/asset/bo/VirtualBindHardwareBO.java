package com.smc.controller.asset.bo;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName VirtualBindHardwareBO
 * @description:
 * @author: C31909
 * @create: 2024-07-26 13:49
 * @Version 1.0
 **/
@Data
public class VirtualBindHardwareBO {
    private String id;
    private String hardwareId;
    private String updatedBy;
    private Integer version;
}
