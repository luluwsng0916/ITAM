package com.smc.controller.file.bo;

import lombok.Data;

import java.util.Date;

/**
 * @program: asset-management-system
 * @ClassName FilePathCleanBO
 * @description:
 * @author: C31909
 * @create: 2024-08-06 08:15
 * @Version 1.0
 **/
@Data
public class FilePathCleanBO {
    private Date startDate;
    private Date endDate;
}
