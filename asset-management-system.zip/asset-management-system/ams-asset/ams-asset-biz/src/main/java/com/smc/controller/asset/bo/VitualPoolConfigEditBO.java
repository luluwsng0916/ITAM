package com.smc.controller.asset.bo;

import lombok.Data;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
@Data
public class VitualPoolConfigEditBO {

    private String id;

    private String poolChargePerson;

    private String poolId;

    /**
     * 创建人
     */
    private String operator;

    private Integer version;
}
