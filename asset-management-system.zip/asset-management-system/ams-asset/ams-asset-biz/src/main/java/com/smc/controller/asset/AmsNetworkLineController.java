package com.smc.controller.asset;

import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.asset.bo.NetworkLineAddBO;
import com.smc.controller.asset.bo.NetworkLineDeleteBO;
import com.smc.controller.asset.bo.NetworkLineEditBO;
import com.smc.service.asset.AmsNetworkLineService;
import com.smc.utils.WebUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @author C31908
 * @version 1.0.0
 * @date 2024-08-26
 * @description
 */

@CrossOrigin
@RestController
@RequestMapping("/network")
public class AmsNetworkLineController {

    @Resource
    private AmsNetworkLineService amsNetworkLineService;

    @PostMapping("/list")
    public ResultBody<PageResult> page(@RequestBody PageRequest pageRequest) {
        PageResult res = amsNetworkLineService.selectPage(pageRequest);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody NetworkLineEditBO model) {
        String res = amsNetworkLineService.editById(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody NetworkLineAddBO model) {
        String res = amsNetworkLineService.add(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody NetworkLineDeleteBO model) {
        String res = amsNetworkLineService.delete(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/findSuppliers")
    public ResultBody<List<String>> findSuppliers() {
        List<String> res = amsNetworkLineService.findSuppliers();
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/export")
    public void export(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        amsNetworkLineService.export(pageRequest, response);
    }

    @PostMapping("/importExcel")
    public ResultBody<String> importExcel(@RequestParam("multipartFile") MultipartFile file, HttpServletRequest request) {
        Map<String, String> res = amsNetworkLineService.importExcel(file, request);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }


}
