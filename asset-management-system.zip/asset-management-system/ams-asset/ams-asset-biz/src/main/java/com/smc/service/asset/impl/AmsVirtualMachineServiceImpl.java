package com.smc.service.asset.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.smc.api.mdm.CodeGenApi;
import com.smc.api.mdm.UniversalCodeQueryApi;
import com.smc.api.mdm.dto.PublicUniversalCodeDTO;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.CommonConstants;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.asset.bo.VirtualBindHardwareBO;
import com.smc.controller.asset.bo.VirtualMachineDeleteBO;
import com.smc.controller.asset.bo.VirtualMachineEditBO;
import com.smc.controller.asset.bo.VirtualMachineSaveBO;
import com.smc.controller.asset.dto.VirtualMachineExcelDTO;
import com.smc.controller.asset.vo.VirtualMachineVO;
import com.smc.dataobject.asset.AmsVirtualMachine;
import com.smc.easyexcel.asset.listener.ImportVirtualMachineListener;
import com.smc.enums.asset.AssetConstant;
import com.smc.enums.mdm.TableCodeRule;
import com.smc.mapper.asset.AmsVirtualMachineMapper;
import com.smc.service.asset.AmsHardwareService;
import com.smc.service.asset.AmsVirtualMachineService;
import com.smc.utils.NumberFormatterUtils;
import com.smc.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 服务器虚拟池
 *
 * @author C31909
 * @since 1.0.0 2024-07-26
 */
@Slf4j
@Service
public class AmsVirtualMachineServiceImpl implements AmsVirtualMachineService {

    @Resource
    private AmsVirtualMachineMapper amsVirtualMachineMapper;

    @Resource
    private QueryServiceClient queryServiceClient;

    @Resource
    private UniversalCodeQueryApi universalCodeQueryApi;

    @Resource
    private AmsHardwareService amsHardwareService;

    @Resource
    private CodeGenApi codeGenApi;

    @Override
    public ResultBody<PageInfo<VirtualMachineVO>> page(PageRequest pageRequest) {
        String name = pageRequest.getParamValue("name");
        String appliedSystem = pageRequest.getParamValue("appliedSystem");
        String activity = pageRequest.getParamValue("activity");

        LambdaQueryWrapper<AmsVirtualMachine> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(AmsVirtualMachine::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        wrapper.like(StringUtils.isNoneBlank(name), AmsVirtualMachine::getName, name);
        wrapper.like(StringUtils.isNoneBlank(appliedSystem), AmsVirtualMachine::getAppliedSystem, appliedSystem);
        wrapper.eq(StringUtils.isNotBlank(activity), AmsVirtualMachine::getActivity, activity);

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        StringBuilder stringBuilder = new StringBuilder();
        if (map.get("conditionParams") != null) {
            stringBuilder.append(map.get("conditionParams"));
        }
        if (map.get("sortParam") != null) {
            stringBuilder.append(" ORDER BY ").append(map.get("sortParam"));
        } else {
            stringBuilder.append(" ORDER BY ").append("id");
        }
        wrapper.last(stringBuilder.toString());
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsVirtualMachine> list = amsVirtualMachineMapper.selectList(wrapper);
        // 为什么：原因是自己封装的vo把PageInfo原有的属性破坏了
        // 解决方案：https://blog.csdn.net/qq_39765635/article/details/87694796
        PageInfo<AmsVirtualMachine> pageInfo = PageInfo.of(list);
        if (CollectionUtil.isEmpty(list)) {
            return ResultBody.ok().data(pageInfo);
        }
        List<VirtualMachineVO> voList = toVOList(list);
        PageInfo<VirtualMachineVO> pageInfoRes = new PageInfo<>(voList);
        pageInfoRes.setPageNum(pageInfo.getPageNum());
        pageInfoRes.setPageSize(pageInfo.getPageSize());
        pageInfoRes.setTotal(pageInfo.getTotal());
        pageInfoRes.setPages(pageInfo.getPages());
        return ResultBody.ok().data(pageInfoRes);
    }

    private List<VirtualMachineVO> toVOList(List<AmsVirtualMachine> list) {
        ArrayList<VirtualMachineVO> vos = new ArrayList<>();
        Map<Integer, PublicUniversalCodeDTO> allUniversalCode = getAllUniversalCode(list);
        // Map<Integer, AmsHardware> allHardware = getAllHardware(list);
        list.forEach(amsVirtualMachine -> {
            VirtualMachineVO vo = new VirtualMachineVO();
            vo.setId(amsVirtualMachine.getId());
            vo.setHardwareId(amsVirtualMachine.getHardwareId());
            vo.setName(amsVirtualMachine.getName());
            vo.setIp(amsVirtualMachine.getIp());
            vo.setCpu(amsVirtualMachine.getCpu());
            vo.setMemory(amsVirtualMachine.getMemory());
            vo.setHardDisk(amsVirtualMachine.getHardDisk());
            vo.setAppliedSystem(amsVirtualMachine.getAppliedSystem());

            vo.setAppliedCategory(CollectionUtil.isNotEmpty(allUniversalCode) && amsVirtualMachine.getAppliedCategory() != null ?
                    allUniversalCode.get(amsVirtualMachine.getAppliedCategory()).getDictValue() : CommonConstants.NULL_STRING);
            vo.setAppliedEnv(CollectionUtil.isNotEmpty(allUniversalCode) && amsVirtualMachine.getAppliedEnv() != null ?
                    allUniversalCode.get(amsVirtualMachine.getAppliedEnv()).getDictValue() : CommonConstants.NULL_STRING);
            vo.setOperatingSystem(CollectionUtil.isNotEmpty(allUniversalCode) && amsVirtualMachine.getOperatingSystem() != null ?
                    allUniversalCode.get(amsVirtualMachine.getOperatingSystem()).getDictValue() : CommonConstants.NULL_STRING);
            vo.setSqlCategory(CollectionUtil.isNotEmpty(allUniversalCode) && amsVirtualMachine.getSqlCategory() != null ?
                    allUniversalCode.get(amsVirtualMachine.getSqlCategory()).getDictValue() : CommonConstants.NULL_STRING);
            // vo.setApplicationLicense(amsVirtualMachine.getApplicationLicense());
            vo.setDeptCode(amsVirtualMachine.getDeptCode());
            vo.setManager(amsVirtualMachine.getManager());
            vo.setManageGroup(CollectionUtil.isNotEmpty(allUniversalCode) && amsVirtualMachine.getManageGroup() != null ?
                    allUniversalCode.get(amsVirtualMachine.getManageGroup()).getDictValue() : CommonConstants.NULL_STRING);
            // vo.setHardwareIp(amsVirtualMachine.getHardwareIp());
            vo.setItManager(amsVirtualMachine.getItManager());
            vo.setRemark(amsVirtualMachine.getRemark());
            vo.setActivity(amsVirtualMachine.getActivity());
            vo.setVersion(amsVirtualMachine.getVersion());
            vo.setCreatedBy(amsVirtualMachine.getCreatedBy());
            vo.setCreatedTime(amsVirtualMachine.getCreatedTime());
            vo.setUpdatedBy(amsVirtualMachine.getUpdatedBy());
            vo.setUpdatedTime(amsVirtualMachine.getUpdatedTime());
            vos.add(vo);
        });
        return vos;
    }

    @Override
    public ResultBody<String> editById(VirtualMachineEditBO model) {
        AmsVirtualMachine amsVirtualMachine = new AmsVirtualMachine();
        amsVirtualMachine.setId(model.getId());
        amsVirtualMachine.setHardwareId(model.getHardwareId());
        amsVirtualMachine.setName(model.getName());
        amsVirtualMachine.setIp(model.getIp());
        amsVirtualMachine.setCpu(model.getCpu());
        amsVirtualMachine.setMemory(model.getMemory());
        amsVirtualMachine.setHardDisk(model.getHardDisk());
        amsVirtualMachine.setAppliedSystem(model.getAppliedSystem());
        amsVirtualMachine.setAppliedCategory(model.getAppliedCategory());
        amsVirtualMachine.setAppliedEnv(model.getAppliedEnv());
        amsVirtualMachine.setOperatingSystem(model.getOperatingSystem());
        amsVirtualMachine.setSqlCategory(model.getSqlCategory());
        amsVirtualMachine.setDeptCode(model.getDeptCode());
        amsVirtualMachine.setManager(model.getManager());
        amsVirtualMachine.setManageGroup(model.getManageGroup());
        amsVirtualMachine.setRemark(model.getRemark());
        amsVirtualMachine.setItManager(model.getItManager());
        amsVirtualMachine.setActivity(model.getActivity());
        amsVirtualMachine.setVersion(model.getVersion());
        amsVirtualMachine.setUpdatedBy(model.getUpdatedBy());
        amsVirtualMachine.setUpdatedTime(new Date());
        amsVirtualMachineMapper.updateById(amsVirtualMachine);
        return ResultBody.ok();
    }

    @Override
    public ResultBody<String> add(VirtualMachineSaveBO model) {
        AmsVirtualMachine virtualMachine = new AmsVirtualMachine();
        Integer checkNameCount = getNameCount(model.getName());
        if (checkNameCount != 0) {
            return ResultBody.failed().msg("服务器名已存在");
        }
        Integer checkIPCount = getIPCount(model.getIp());
        if (checkIPCount != 0) {
            return ResultBody.failed().msg("IP已存在");
        }
        virtualMachine.setHardwareId(model.getHardwareId());
        virtualMachine.setName(model.getName());
        virtualMachine.setIp(model.getIp());
        virtualMachine.setCpu(model.getCpu());
        virtualMachine.setMemory(model.getMemory());
        virtualMachine.setHardDisk(model.getHardDisk());
        virtualMachine.setAppliedSystem(model.getAppliedSystem());
        virtualMachine.setAppliedCategory(model.getAppliedCategory());
        virtualMachine.setAppliedEnv(model.getAppliedEnv());
        virtualMachine.setOperatingSystem(model.getOperatingSystem());
        virtualMachine.setSqlCategory(model.getSqlCategory());
        virtualMachine.setDeptCode(model.getDeptCode());
        virtualMachine.setManager(model.getManager());
        virtualMachine.setRemark(model.getRemark());
        virtualMachine.setActivity(model.getActivity());
        virtualMachine.setManageGroup(model.getManageGroup());
        virtualMachine.setItManager(model.getItManager());
        virtualMachine.setVersion(CommonConstants.DEFAULT_VERSION);
        virtualMachine.setCreatedBy(model.getCreatedBy());
        virtualMachine.setCreatedTime(new Date());
        virtualMachine.setUpdatedBy(model.getUpdatedBy());
        virtualMachine.setUpdatedTime(new Date());
        virtualMachine.setDeleteMark(DeleteMarkConstant.NOT_DELETED);
        if (model.getIsVirtual()) {
            // VM开头
            virtualMachine.setId(codeGenApi.getCodeByTableName(TableCodeRule.VIRTUAL_MACHINE_VM));
        } else {
            // PM开头
            virtualMachine.setId(codeGenApi.getCodeByTableName(TableCodeRule.VIRTUAL_MACHINE_PM));
        }
        amsVirtualMachineMapper.insert(virtualMachine);
        return ResultBody.ok();
    }

    /**
     * 获取此服务器名称数据库中的个数
     *
     * @param name
     * @return
     */
    public Integer getNameCount(String name) {
        LambdaQueryWrapper<AmsVirtualMachine> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AmsVirtualMachine::getName, name)
                .eq(AmsVirtualMachine::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        return amsVirtualMachineMapper.selectCount(queryWrapper);
    }

    /**
     * 获取此IP数据库中的个数
     *
     * @param ip
     * @return
     */
    public Integer getIPCount(String ip) {
        LambdaQueryWrapper<AmsVirtualMachine> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AmsVirtualMachine::getIp, ip)
                .eq(AmsVirtualMachine::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        return amsVirtualMachineMapper.selectCount(queryWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ResultBody<String> delete(VirtualMachineDeleteBO bo) {
        AmsVirtualMachine amsVirtualMachine = new AmsVirtualMachine();
        amsVirtualMachine.setId(bo.getId());
        amsVirtualMachine.setDeleteMark(DeleteMarkConstant.DELETED);
        amsVirtualMachine.setUpdatedBy(bo.getUpdatedBy());
        amsVirtualMachine.setUpdatedTime(new Date());
        amsVirtualMachine.setVersion(bo.getVersion());
        amsVirtualMachineMapper.updateById(amsVirtualMachine);
        return ResultBody.ok();
    }

    @Override
    public ResultBody<String> bindHardware(VirtualBindHardwareBO bo) {
        AmsVirtualMachine amsVirtualMachine = new AmsVirtualMachine();
        amsVirtualMachine.setId(bo.getId());
        amsVirtualMachine.setHardwareId(bo.getHardwareId());
        amsVirtualMachine.setVersion(bo.getVersion());
        amsVirtualMachine.setUpdatedBy(bo.getUpdatedBy());
        amsVirtualMachine.setUpdatedTime(new Date());
        amsVirtualMachineMapper.updateById(amsVirtualMachine);
        return ResultBody.ok();
    }

    @Override
    public List<AmsVirtualMachine> getByHardwareId(String hardwareId) {
        LambdaQueryWrapper<AmsVirtualMachine> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AmsVirtualMachine::getHardwareId, hardwareId);
        queryWrapper.eq(AmsVirtualMachine::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        return amsVirtualMachineMapper.selectList(queryWrapper);
    }

    @Override
    public List<String> findSystemName(String data) {
        return amsVirtualMachineMapper.findSystemName(data);
    }

    @Override
    @Transactional(rollbackFor = Exception.class, value = "")
    public ResultBody<String> importData(MultipartFile multipartFile, HttpServletRequest req) {
        String userName = req.getParameter("userName");
        // 获取导入的excel
        List<VirtualMachineExcelDTO> sourceExcelDataList = getImportExcelData(multipartFile);
        /**
         * 导入检验
         */
        if (CollectionUtil.isEmpty(sourceExcelDataList)) {
            EasyExcelVirtualMachineServiceImpl.list.clear();
            return ResultBody.failed().msg("数据为空，请检查是都符合规则或者导入excel符合模板要求");
        }
        List<PublicUniversalCodeDTO> universalCodeByApplicationCategory = new ArrayList<>();
        List<PublicUniversalCodeDTO> universalCodeByApplicationEnv = new ArrayList<>();
        List<PublicUniversalCodeDTO> universalCodeByOs = new ArrayList<>();
        List<PublicUniversalCodeDTO> universalCodeBySql = new ArrayList<>();
        List<PublicUniversalCodeDTO> universalCodeByGroup = new ArrayList<>();
        String errorMsg = dataValidationForExcel(sourceExcelDataList, universalCodeByApplicationCategory,
                universalCodeByApplicationEnv, universalCodeByOs, universalCodeBySql, universalCodeByGroup);
        if (StringUtils.isNotBlank(errorMsg)) {
            return ResultBody.failed().msg(errorMsg);
        }
        List<AmsVirtualMachine> amsVirtualMachines = excelDtoConvertDo(sourceExcelDataList, userName,
                universalCodeByApplicationCategory, universalCodeByApplicationEnv, universalCodeByOs, universalCodeBySql, universalCodeByGroup);

        Lists.partition(amsVirtualMachines, 50).forEach(list -> amsVirtualMachineMapper.insertBatch(list));
        return ResultBody.ok();
    }


    private List<AmsVirtualMachine> excelDtoConvertDo(List<VirtualMachineExcelDTO> sourceExcelDataList, String userName,
                                                      List<PublicUniversalCodeDTO> universalCodeByApplicationCategory,
                                                      List<PublicUniversalCodeDTO> universalCodeByApplicationEnv,
                                                      List<PublicUniversalCodeDTO> universalCodeByOs,
                                                      List<PublicUniversalCodeDTO> universalCodeBySql,
                                                      List<PublicUniversalCodeDTO> universalCodeByGroup) {
        List<AmsVirtualMachine> amsVirtualMachines = new ArrayList<>(sourceExcelDataList.size());
        for (VirtualMachineExcelDTO dto : sourceExcelDataList) {
            AmsVirtualMachine amsVirtualMachine = new AmsVirtualMachine();
            amsVirtualMachine.setId(dto.getId().trim());
            amsVirtualMachine.setHardwareId(StringUtils.isNotBlank(dto.getHardwareId()) &&
                    StringUtils.isNotBlank(dto.getHardwareId().trim()) ? dto.getHardwareId().trim() : null);
            amsVirtualMachine.setName(StringUtils.isNotBlank(dto.getName()) ? dto.getName().trim() : null);
            amsVirtualMachine.setIp(StringUtils.isNotBlank(dto.getIp()) ? dto.getIp().trim() : null);
            amsVirtualMachine.setCpu(StringUtils.isNotBlank(dto.getCpu()) && StringUtils.isNotBlank(dto.getCpu().trim()) ?
                    dto.getCpu().trim() : null);
            amsVirtualMachine.setMemory(StringUtils.isNotBlank(dto.getMemory()) && StringUtils.isNotBlank(dto.getMemory().trim()) ?
                    dto.getMemory().trim() : null);
            amsVirtualMachine.setHardDisk(StringUtils.isNotBlank(dto.getHardDisk()) && StringUtils.isNotBlank(dto.getHardDisk().trim()) ?
                    dto.getHardDisk().trim() : null);
            amsVirtualMachine.setAppliedSystem(StringUtils.isNotBlank(dto.getAppliedSystem()) ? dto.getAppliedSystem().trim() : null);
            amsVirtualMachine.setAppliedCategory(StringUtils.isNotBlank(dto.getAppliedCategory()) &&
                    StringUtils.isNotBlank(dto.getAppliedCategory().trim()) &&
                    CollectionUtil.isNotEmpty(universalCodeByApplicationCategory) ?
                    universalCodeByApplicationCategory.stream()
                            .collect(Collectors.toMap(PublicUniversalCodeDTO::getDictValue, Function.identity())).
                            get(dto.getAppliedCategory().trim()).getId() :
                    null);
            amsVirtualMachine.setAppliedEnv(StringUtils.isNotBlank(dto.getAppliedEnv()) &&
                    StringUtils.isNotBlank(dto.getAppliedEnv().trim()) &&
                    CollectionUtil.isNotEmpty(universalCodeByApplicationEnv) ?
                    universalCodeByApplicationEnv.stream()
                            .collect(Collectors.toMap(PublicUniversalCodeDTO::getDictValue, Function.identity())).
                            get(dto.getAppliedEnv().trim()).getId() :
                    null);
            amsVirtualMachine.setOperatingSystem(StringUtils.isNotBlank(dto.getOperatingSystem()) &&
                    StringUtils.isNotBlank(dto.getOperatingSystem().trim()) &&
                    CollectionUtil.isNotEmpty(universalCodeByOs) ?
                    universalCodeByOs.stream()
                            .collect(Collectors.toMap(PublicUniversalCodeDTO::getDictValue, Function.identity())).
                            get(dto.getOperatingSystem().trim()).getId() :
                    null);
            amsVirtualMachine.setSqlCategory(StringUtils.isNotBlank(dto.getSqlCategory()) &&
                    StringUtils.isNotBlank(dto.getSqlCategory().trim()) &&
                    CollectionUtil.isNotEmpty(universalCodeBySql) ?
                    universalCodeBySql.stream()
                            .collect(Collectors.toMap(PublicUniversalCodeDTO::getDictValue, Function.identity())).
                            get(dto.getSqlCategory().trim()).getId() :
                    null);

            amsVirtualMachine.setManageGroup(StringUtils.isNotBlank(dto.getManageGroup()) &&
                    StringUtils.isNotBlank(dto.getManageGroup().trim()) &&
                    CollectionUtil.isNotEmpty(universalCodeByGroup) ?
                    universalCodeByGroup.stream()
                            .collect(Collectors.toMap(PublicUniversalCodeDTO::getDictValue, Function.identity())).
                            get(dto.getManageGroup().trim()).getId() :
                    null);
            amsVirtualMachine.setDeptCode(StringUtils.isNotBlank(dto.getDeptCode()) ? dto.getDeptCode().trim() : null);
            amsVirtualMachine.setManager(StringUtils.isNotBlank(dto.getManager()) ? dto.getManager().trim() : null);
            amsVirtualMachine.setRemark(StringUtils.isNotBlank(dto.getRemark()) ? dto.getRemark().trim() : null);
            amsVirtualMachine.setItManager(dto.getItManager());
            amsVirtualMachine.setActivity(dto.getActivity());
            amsVirtualMachine.setVersion(CommonConstants.DEFAULT_VERSION);
            amsVirtualMachine.setCreatedBy(userName);
            amsVirtualMachine.setCreatedTime(new Date());
            amsVirtualMachine.setUpdatedBy(userName);
            amsVirtualMachine.setUpdatedTime(amsVirtualMachine.getCreatedTime());
            amsVirtualMachine.setDeleteMark(DeleteMarkConstant.NOT_DELETED);
            amsVirtualMachines.add(amsVirtualMachine);
        }
        return amsVirtualMachines;
    }

    private String dataValidationForExcel(List<VirtualMachineExcelDTO> sourceExcelDataList,
                                          List<PublicUniversalCodeDTO> universalCodeByApplicationCategory,
                                          List<PublicUniversalCodeDTO> universalCodeByApplicationEnv,
                                          List<PublicUniversalCodeDTO> universalCodeByOs,
                                          List<PublicUniversalCodeDTO> universalCodeBySql,
                                          List<PublicUniversalCodeDTO> universalCodeByGroup) {

        // List<String> hardwareIds = new ArrayList<>();
        List<String> applicationCategoryExcelList = new ArrayList<>();
        List<String> applicationEnvExcelList = new ArrayList<>();
        List<String> osExcelList = new ArrayList<>();
        List<String> sqlExcelList = new ArrayList<>();
        List<String> groupExcelList = new ArrayList<>();
        // 格式性校验
        for (VirtualMachineExcelDTO dto : sourceExcelDataList) {
            if (StringUtils.isNotBlank(dto.getId()) && StringUtils.isNotBlank(dto.getId().trim())) {
                if (dto.getId().trim().startsWith(AssetConstant.VM_PREFIX) || dto.getId().trim().startsWith(AssetConstant.PM_PREFIX)) {
                    if (dto.getId().trim().startsWith(AssetConstant.VM_PREFIX)) {
                        String numStr = dto.getId().trim().substring(AssetConstant.VM_PREFIX.length());
                        if (StringUtils.isNumeric(numStr)) {
                            String vmId = AssetConstant.VM_PREFIX + NumberFormatterUtils.formatNumber(6, Integer.parseInt(numStr));
                            // 判断硬件表中是否存在
                            if (amsVirtualMachineMapper.selectById(vmId) != null) {
                                return dto.getId() + "服务器ID已存在或已逻辑删除，请检查是否正确！";
                            }
                            dto.setId(vmId);
                        } else {
                            return dto.getId() + "服务器ID不符合规则，请检查是否正确！";
                        }
                    }
                    if (dto.getId().trim().startsWith(AssetConstant.PM_PREFIX)) {
                        String numStr = dto.getId().trim().substring(AssetConstant.PM_PREFIX.length());
                        if (StringUtils.isNumeric(numStr)) {
                            String pmId = AssetConstant.PM_PREFIX + NumberFormatterUtils.formatNumber(6, Integer.parseInt(numStr));
                            // 判断硬件表中是否存在
                            if (amsVirtualMachineMapper.selectById(pmId) != null) {
                                return dto.getId() + "服务器ID已存在或已逻辑删除，请检查是否正确！";
                            }
                            dto.setId(pmId);
                        } else {
                            return dto.getId() + "服务器ID不符合规则，请检查是否正确！";
                        }
                    }
                } else {
                    return dto.getId() + "服务器ID不符合规则，请检查是否正确！";
                }
            } else {
                return "服务器ID不存在，请检查是否正确！";
            }
            if (StringUtils.isBlank(dto.getManageGroup())) {
                return "存在空的IT部小组，IT部小组不可为空";
            }
            if (StringUtils.isBlank(dto.getItManager())) {
                return "存在空的IT部担当，IT部担当不可为空";
            }
            Integer checkNameCount = getNameCount(dto.getName());
            if (checkNameCount != 0) {
                return dto.getName() + "的服务器名已存在";
            }
            Integer checkIPCount = getIPCount(dto.getIp());
            if (checkIPCount != 0) {
                return "\"" + dto.getName() + "\"服务器的IP已存在";
            }
            if (StringUtils.isNotBlank(dto.getHardwareId()) && StringUtils.isNotBlank(dto.getHardwareId().trim())) {
                if (!dto.getHardwareId().trim().startsWith(AssetConstant.SM_PREFIX)) {
                    return "资产编号：" + dto.getHardwareId().trim() + "，格式错误";
                } else {
                    String numStr = dto.getHardwareId().trim().substring(AssetConstant.SM_PREFIX.length());
                    if (StringUtils.isNumeric(numStr)) {
                        String hardwareId = AssetConstant.SM_PREFIX + NumberFormatterUtils.formatNumber(6, Integer.parseInt(numStr));
                        // 判断硬件表中是否存在
                        if (!amsHardwareService.getById(hardwareId).isOk()) {
                            return hardwareId + "资产编号不存在，请检查是否正确！";
                        } else {
                            dto.setHardwareId(AssetConstant.SM_PREFIX + NumberFormatterUtils.formatNumber(6, Integer.parseInt(numStr)));
                        }
                    } else {
                        return dto.getHardwareId().trim() + "资产编号不符合规则，请检查是否正确！";
                    }
                }
            }
            if (StringUtils.isNotBlank(dto.getAppliedCategory()) && StringUtils.isNotBlank(dto.getAppliedCategory().trim())) {
                applicationCategoryExcelList.add(dto.getAppliedCategory().trim());
            }
            if (StringUtils.isNotBlank(dto.getAppliedEnv()) && StringUtils.isNotBlank(dto.getAppliedEnv().trim())) {
                applicationEnvExcelList.add(dto.getAppliedEnv().trim());
            }
            if (StringUtils.isNotBlank(dto.getOperatingSystem()) && StringUtils.isNotBlank(dto.getOperatingSystem().trim())) {
                osExcelList.add(dto.getOperatingSystem().trim());
            }
            if (StringUtils.isNotBlank(dto.getSqlCategory()) && StringUtils.isNotBlank(dto.getSqlCategory().trim())) {
                sqlExcelList.add(dto.getSqlCategory().trim());
            }
            if (StringUtils.isNotBlank(dto.getManageGroup()) && StringUtils.isNotBlank(dto.getManageGroup().trim())) {
                groupExcelList.add(dto.getManageGroup().trim());
            }
        }
        if (CollectionUtil.isNotEmpty(applicationCategoryExcelList)) {
            applicationCategoryExcelList = applicationCategoryExcelList.stream().distinct().collect(Collectors.toList());
            universalCodeByApplicationCategory.addAll(universalCodeQueryApi.
                    listUniversalCodeByDictValue(AssetConstant.YYLB, applicationCategoryExcelList));
            if (applicationCategoryExcelList.size() != universalCodeByApplicationCategory.size()) {
                List<String> saveList = new ArrayList<>();
                List<String> existedList = universalCodeByApplicationCategory.stream().map(PublicUniversalCodeDTO::getDictValue).collect(Collectors.toList());
                for (String value : applicationCategoryExcelList) {
                    if (!existedList.contains(value)) {
                        saveList.add(value);
                    }
                }
                universalCodeQueryApi.saveUniversalCode(AssetConstant.YYLB, saveList);
                universalCodeByApplicationCategory.clear();
                universalCodeByApplicationCategory.addAll(universalCodeQueryApi.listUniversalCodeByDictValue(AssetConstant.YYLB, applicationCategoryExcelList));
            }
        }
        if (CollectionUtil.isNotEmpty(applicationEnvExcelList)) {
            applicationEnvExcelList = applicationEnvExcelList.stream().distinct().collect(Collectors.toList());
            universalCodeByApplicationEnv.addAll(universalCodeQueryApi.listUniversalCodeByDictValue(AssetConstant.FWQYT, applicationEnvExcelList));
            if (applicationEnvExcelList.size() != universalCodeByApplicationEnv.size()) {
                List<String> saveList = new ArrayList<>();
                List<String> existedList = universalCodeByApplicationEnv.stream().map(PublicUniversalCodeDTO::getDictValue).collect(Collectors.toList());
                for (String value : applicationEnvExcelList) {
                    if (!existedList.contains(value)) {
                        saveList.add(value);
                    }
                }
                universalCodeQueryApi.saveUniversalCode(AssetConstant.FWQYT, saveList);
                universalCodeByApplicationEnv.clear();
                universalCodeByApplicationEnv.addAll(universalCodeQueryApi.listUniversalCodeByDictValue(AssetConstant.FWQYT, applicationEnvExcelList));
            }
        }
        if (CollectionUtil.isNotEmpty(osExcelList)) {
            osExcelList = osExcelList.stream().distinct().collect(Collectors.toList());
            universalCodeByOs.addAll(universalCodeQueryApi.listUniversalCodeByDictValue(AssetConstant.CZXT, osExcelList));
            if (osExcelList.size() != universalCodeByOs.size()) {
                List<String> saveList = new ArrayList<>();
                List<String> existedList = universalCodeByOs.stream().map(PublicUniversalCodeDTO::getDictValue).collect(Collectors.toList());
                for (String value : osExcelList) {
                    if (!existedList.contains(value)) {
                        saveList.add(value);
                    }
                }
                universalCodeQueryApi.saveUniversalCode(AssetConstant.CZXT, saveList);
                universalCodeByOs.clear();
                universalCodeByOs.addAll(universalCodeQueryApi.listUniversalCodeByDictValue(AssetConstant.CZXT, osExcelList));
            }
        }
        if (CollectionUtil.isNotEmpty(sqlExcelList)) {
            sqlExcelList = sqlExcelList.stream().distinct().collect(Collectors.toList());
            universalCodeBySql.addAll(universalCodeQueryApi.listUniversalCodeByDictValue(AssetConstant.SJK, sqlExcelList));
            if (sqlExcelList.size() != universalCodeBySql.size()) {
                List<String> saveList = new ArrayList<>();
                List<String> existedList = universalCodeBySql.stream().map(PublicUniversalCodeDTO::getDictValue).collect(Collectors.toList());
                for (String value : sqlExcelList) {
                    if (!existedList.contains(value)) {
                        saveList.add(value);
                    }
                }
                universalCodeQueryApi.saveUniversalCode(AssetConstant.SJK, saveList);
                universalCodeBySql.clear();
                universalCodeBySql.addAll(universalCodeQueryApi.listUniversalCodeByDictValue(AssetConstant.SJK, sqlExcelList));
            }
        }

        if (CollectionUtil.isNotEmpty(groupExcelList)) {
            groupExcelList = groupExcelList.stream().distinct().collect(Collectors.toList());
            universalCodeByGroup.addAll(universalCodeQueryApi.listUniversalCodeByDictValue(AssetConstant.GLZB, groupExcelList));
            if (groupExcelList.size() != universalCodeByGroup.size()) {
                List<String> saveList = new ArrayList<>();
                List<String> existedList = universalCodeByGroup.stream().map(PublicUniversalCodeDTO::getDictValue).collect(Collectors.toList());
                for (String value : groupExcelList) {
                    if (!existedList.contains(value)) {
                        saveList.add(value);
                    }
                }
                universalCodeQueryApi.saveUniversalCode(AssetConstant.GLZB, saveList);
                universalCodeByGroup.clear();
                universalCodeByGroup.addAll(universalCodeQueryApi.listUniversalCodeByDictValue(AssetConstant.GLZB, groupExcelList));
            }
        }
        return null;
    }

    private List<VirtualMachineExcelDTO> getImportExcelData(MultipartFile multipartFile) {
        try {
            if (multipartFile != null) {
                // 导入excel
                EasyExcel.read(multipartFile.getInputStream(), VirtualMachineExcelDTO.class,
                        new ImportVirtualMachineListener()).sheet().doRead();
                // 获取excel导入的所有基础数据
                return EasyExcelVirtualMachineServiceImpl.getAllImportExcelData();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void exportData(PageRequest pageRequest, HttpServletResponse response) throws IOException {
        String name = pageRequest.getParamValue("name");
        String appliedSystem = pageRequest.getParamValue("appliedSystem");
        String activity = pageRequest.getParamValue("activity");
        String isFormWork = pageRequest.getParamValue("isFormWork");

        if ("模板".equals(isFormWork)) {
            Set<String> excludeColumnFiledNames = new HashSet<>();
            // excludeColumnFiledNames.add("id");
            excludeColumnFiledNames.add("createdBy");
            excludeColumnFiledNames.add("createdTime");
            excludeColumnFiledNames.add("updatedBy");
            excludeColumnFiledNames.add("updatedTime");
            EasyExcel.write(response.getOutputStream(), VirtualMachineExcelDTO.class).
                    excludeColumnFiledNames(excludeColumnFiledNames).
                    sheet("服务器管理信息").doWrite(new ArrayList<VirtualMachineExcelDTO>());
            return;
        }
        LambdaQueryWrapper<AmsVirtualMachine> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(AmsVirtualMachine::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        wrapper.like(StringUtils.isNoneBlank(name), AmsVirtualMachine::getName, name);
        wrapper.like(StringUtils.isNoneBlank(appliedSystem), AmsVirtualMachine::getAppliedSystem, appliedSystem);
        wrapper.eq(StringUtils.isNotBlank(activity), AmsVirtualMachine::getActivity, Boolean.parseBoolean(activity));

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        StringBuilder stringBuilder = new StringBuilder();
        if (map.get("conditionParams") != null) {
            stringBuilder.append(map.get("conditionParams"));
        }
        if (map.get("sortParam") != null) {
            stringBuilder.append(" ORDER BY ").append(map.get("sortParam"));
        } else {
            stringBuilder.append(" ORDER BY ").append("id");
        }
        wrapper.last(stringBuilder.toString());
        List<AmsVirtualMachine> list = amsVirtualMachineMapper.selectList(wrapper);
        List<VirtualMachineExcelDTO> voList = toExcelDTOList(list);
        EasyExcel.write(response.getOutputStream(), VirtualMachineExcelDTO.class).sheet("服务器管理信息").doWrite(voList);
    }

    private List<VirtualMachineExcelDTO> toExcelDTOList(List<AmsVirtualMachine> list) {
        List<VirtualMachineExcelDTO> dtoList = new ArrayList<>();
        Map<Integer, PublicUniversalCodeDTO> allUniversalCode = getAllUniversalCode(list);
        list.forEach(amsVirtualMachine -> {
            VirtualMachineExcelDTO dto = new VirtualMachineExcelDTO();
            dto.setId(amsVirtualMachine.getId());
            dto.setHardwareId(amsVirtualMachine.getHardwareId());
            dto.setName(amsVirtualMachine.getName());
            dto.setIp(amsVirtualMachine.getIp());
            dto.setCpu(amsVirtualMachine.getCpu() != null ? String.valueOf(amsVirtualMachine.getCpu()) : CommonConstants.NULL_STRING);
            dto.setMemory(amsVirtualMachine.getMemory() != null ? String.valueOf(amsVirtualMachine.getMemory()) : CommonConstants.NULL_STRING);
            dto.setHardDisk(amsVirtualMachine.getHardDisk() != null ? String.valueOf(amsVirtualMachine.getHardDisk()) : CommonConstants.NULL_STRING);
            dto.setAppliedSystem(amsVirtualMachine.getAppliedSystem());
            dto.setAppliedCategory(CollectionUtil.isNotEmpty(allUniversalCode) && amsVirtualMachine.getAppliedCategory() != null ?
                    allUniversalCode.get(amsVirtualMachine.getAppliedCategory()).getDictValue() : CommonConstants.NULL_STRING);
            dto.setAppliedEnv(CollectionUtil.isNotEmpty(allUniversalCode) && amsVirtualMachine.getAppliedEnv() != null ?
                    allUniversalCode.get(amsVirtualMachine.getAppliedEnv()).getDictValue() : CommonConstants.NULL_STRING);
            dto.setOperatingSystem(CollectionUtil.isNotEmpty(allUniversalCode) && amsVirtualMachine.getOperatingSystem() != null ?
                    allUniversalCode.get(amsVirtualMachine.getOperatingSystem()).getDictValue() : CommonConstants.NULL_STRING);
            dto.setSqlCategory(CollectionUtil.isNotEmpty(allUniversalCode) && amsVirtualMachine.getSqlCategory() != null ?
                    allUniversalCode.get(amsVirtualMachine.getSqlCategory()).getDictValue() : CommonConstants.NULL_STRING);
            // dto.setApplicationLicense(amsVirtualMachine.getApplicationLicense());
            dto.setDeptCode(amsVirtualMachine.getDeptCode());
            dto.setManager(amsVirtualMachine.getManager());
            dto.setManageGroup(CollectionUtil.isNotEmpty(allUniversalCode) && amsVirtualMachine.getManageGroup() != null ?
                    allUniversalCode.get(amsVirtualMachine.getManageGroup()).getDictValue() : CommonConstants.NULL_STRING);
            // dto.setHardwareIp(amsVirtualMachine.getHardwareIp());
            dto.setRemark(amsVirtualMachine.getRemark());
            dto.setItManager(amsVirtualMachine.getItManager());
            dto.setActivity(amsVirtualMachine.getActivity());
            dto.setCreatedBy(amsVirtualMachine.getCreatedBy());
            dto.setCreatedTime(DateUtil.format(amsVirtualMachine.getCreatedTime(), DatePattern.NORM_DATETIME_PATTERN));
            dto.setUpdatedBy(amsVirtualMachine.getUpdatedBy());
            dto.setUpdatedTime(DateUtil.format(amsVirtualMachine.getCreatedTime(), DatePattern.NORM_DATETIME_PATTERN));
            dtoList.add(dto);
        });
        return dtoList;
    }


    private Map<Integer, PublicUniversalCodeDTO> getAllUniversalCode(List<AmsVirtualMachine> list) {
        List<Integer> codeList = new ArrayList<>();
        // 查询应用类别
        codeList.addAll(list.stream().map(AmsVirtualMachine::getAppliedCategory).collect(Collectors.toList()));
        // 查询用途
        codeList.addAll(list.stream().map(AmsVirtualMachine::getAppliedEnv).collect(Collectors.toList()));
        // 查询数据库
        codeList.addAll(list.stream().map(AmsVirtualMachine::getSqlCategory).collect(Collectors.toList()));
        // 查询操作系统
        codeList.addAll(list.stream().map(AmsVirtualMachine::getOperatingSystem).collect(Collectors.toList()));
        // 管理组别
        codeList.addAll(list.stream().map(AmsVirtualMachine::getManageGroup).collect(Collectors.toList()));
        codeList = codeList.stream().distinct().filter(Objects::nonNull).collect(Collectors.toList());
        List<PublicUniversalCodeDTO> universalCodeByIdList = universalCodeQueryApi.getUniversalCodeByIdList(codeList);
        if (CollectionUtil.isEmpty(universalCodeByIdList)) {
            return null;
        }
        return universalCodeByIdList.stream()
                .collect(Collectors.toMap(PublicUniversalCodeDTO::getId, Function.identity()));
    }

}