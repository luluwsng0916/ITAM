package com.smc.controller.asset.bo;

import lombok.Data;

/**
 * @author C31908
 * @version 1.0.0
 * @date 2024-08-26
 * @description
 */

@Data
public class NetworkLineDeleteBO {

    private String networkLineId;

    private String networkLineName;

    private String updatedBy;

    private Integer version;

}
