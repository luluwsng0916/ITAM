package com.smc.controller.asset;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.asset.bo.VirtualBindHardwareBO;
import com.smc.controller.asset.bo.VirtualMachineDeleteBO;
import com.smc.controller.asset.bo.VirtualMachineEditBO;
import com.smc.controller.asset.bo.VirtualMachineSaveBO;
import com.smc.controller.asset.vo.VirtualMachineVO;
import com.smc.dataobject.asset.AmsVirtualMachine;
import com.smc.service.asset.AmsVirtualMachineService;
import com.smc.utils.WebUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 服务器虚拟池
 *
 * @author C31909
 * @since 1.0.0 2024-07-26
 */
@CrossOrigin
@RestController
@RequestMapping("/virtual")
public class AmsVirtualMachineController {

    @Resource
    private AmsVirtualMachineService amsVirtualMachineService;

    @PostMapping("/list")
    public ResultBody<PageInfo<VirtualMachineVO>> page(@RequestBody PageRequest pageRequest) {
        return amsVirtualMachineService.page(pageRequest);
    }

    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody VirtualMachineEditBO model) {
        return amsVirtualMachineService.editById(model);
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody VirtualMachineSaveBO model) {
        return amsVirtualMachineService.add(model);
    }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody VirtualMachineDeleteBO bo) {
        return amsVirtualMachineService.delete(bo);
    }

    @PostMapping("/import")
    public ResultBody<String> importData(@RequestParam(value = "multipartFile", required = false)
                                         MultipartFile multipartFile, HttpServletRequest req) {
        return amsVirtualMachineService.importData(multipartFile, req);
    }

    @PostMapping("/export")
    public void exportData(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        amsVirtualMachineService.exportData(pageRequest, response);
    }

    @PostMapping("/bind-hardware")
    public ResultBody<String> bindHardware(@RequestBody VirtualBindHardwareBO bo) {
        return amsVirtualMachineService.bindHardware(bo);
    }

    @PostMapping("/findSystemName")
    public ResultBody<List<String>> findSystemName(@RequestParam("data") String data) {
        List<String> res = amsVirtualMachineService.findSystemName(data);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

}