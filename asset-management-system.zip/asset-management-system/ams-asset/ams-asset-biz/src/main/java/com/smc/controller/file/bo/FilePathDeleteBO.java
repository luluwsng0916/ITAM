package com.smc.controller.file.bo;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName FilePathDeleteBO
 * @description:
 * @author: C31909
 * @create: 2024-08-06 08:16
 * @Version 1.0
 **/
@Data
public class FilePathDeleteBO {
    private Integer id;
    private String updatedBy;
    private Integer version;
}
