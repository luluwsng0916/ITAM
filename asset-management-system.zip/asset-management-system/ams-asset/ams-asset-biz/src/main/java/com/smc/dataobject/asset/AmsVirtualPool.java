package com.smc.dataobject.asset;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * @author C31909
 * @TableName ams_virtual_pool
 */
@TableName(value = "ams_virtual_pool")
@Data
public class AmsVirtualPool extends AbstractEntity implements Serializable {
    /**
     *
     */
    @TableId(value = "id", type = IdType.INPUT)
    private String id;

    /**
     *
     */
    @TableField(value = "hardwareId")
    private String hardwareId;

    /**
     *
     */
    @TableField(value = "virtualMachineId")
    private String virtualMachineId;

    @TableField(value = "manager")
    private String manager;

    /**
     * 有效性
     */
    @TableField(value = "activity")
    private Boolean activity;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;


    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}