package com.smc.mapper.asset;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smc.dataobject.asset.AmsVitualPoolConfig;

import java.util.HashMap;
import java.util.List;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
public interface AmsVitualPoolConfigMapper extends BaseMapper<AmsVitualPoolConfig> {

    List<AmsVitualPoolConfig> findAll(HashMap<String, Object> map);

}
