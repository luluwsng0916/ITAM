package com.smc.service.supplier.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.smc.api.dto.SupplierDTO;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.ActivityConstant;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.supplier.vo.SuppliersVO;
import com.smc.dataobject.supplier.AmsSuppliers;
import com.smc.mapper.supplier.AmsSuppliersMapper;
import com.smc.service.supplier.AmsSuppliersService;
import com.smc.utils.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author C31909
 * @description 针对表【ams_suppliers】的数据库操作Service实现
 * @createDate 2024-07-22 09:41:49
 */
@Service
public class AmsSuppliersServiceImpl implements AmsSuppliersService {

    @Resource
    private AmsSuppliersMapper amsSuppliersMapper;

    @Resource
    private QueryServiceClient queryServiceClient;

    @Override
    public List<SupplierDTO> listByIds(List<Integer> supplierId) {
        if (supplierId != null && !supplierId.isEmpty()) {
            List<AmsSuppliers> amsSuppliers = amsSuppliersMapper.selectBatchIds(supplierId);
            if (CollectionUtil.isEmpty(amsSuppliers)) {
                return Collections.emptyList();
            }
            ArrayList<SupplierDTO> supplierDTOS = new ArrayList<>();
            amsSuppliers.forEach(amsSupplier -> {
                SupplierDTO supplierDTO = new SupplierDTO();
                BeanUtil.copyProperties(amsSupplier, supplierDTO);
                supplierDTOS.add(supplierDTO);
            });
            return supplierDTOS;
        }
        return Collections.emptyList();
    }

    @Override
    public AmsSuppliers getSupplierInfo(String supplier) {
        LambdaQueryWrapper<AmsSuppliers> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AmsSuppliers::getName, supplier);
        queryWrapper.eq(AmsSuppliers::getActivity, ActivityConstant.ACTIVITY);
        queryWrapper.eq(AmsSuppliers::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        queryWrapper.orderByDesc(AmsSuppliers::getUpdatedTime);
        queryWrapper.last("limit 1");
        return amsSuppliersMapper.selectOne(queryWrapper);
    }

    @Override
    public ResultBody<PageInfo<SuppliersVO>> page(PageRequest pageRequest) {
        // 从分页请求中获取资产名称和型号参数
        String name = pageRequest.getParamValue("name");
        String contactPerson = pageRequest.getParamValue("contactPerson");
        String activity = pageRequest.getParamValue("activity");

        // 构建查询条件，根据资产名称和型号进行模糊查询，且只查询未删除的硬件
        LambdaQueryWrapper<AmsSuppliers> wrapper = new LambdaQueryWrapper<>();
        wrapper.like(StringUtils.isNotBlank(name), AmsSuppliers::getName, name);
        wrapper.like(StringUtils.isNotBlank(contactPerson), AmsSuppliers::getContactPerson, contactPerson);
        wrapper.eq(StringUtils.isNotBlank(activity), AmsSuppliers::getActivity, Boolean.parseBoolean(activity));
        wrapper.eq(AmsSuppliers::getDeleteMark, DeleteMarkConstant.NOT_DELETED);

        // 通过queryServiceClient获取额外的查询条件和排序条件
        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        StringBuilder stringBuilder = new StringBuilder();
        if (map.get("conditionParams") != null) {
            stringBuilder.append(map.get("conditionParams"));
        }
        if (map.get("sortParam") != null) {
            stringBuilder.append(" ORDER BY ").append(map.get("sortParam"));
        } else {
            stringBuilder.append(" ORDER BY ").append("id");
        }
        wrapper.last(stringBuilder.toString());

        // 初始化分页插件，进行分页查询
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsSuppliers> list = amsSuppliersMapper.selectList(wrapper);
        // 为什么：原因是自己封装的vo把PageInfo原有的属性破坏了
        // 解决方案：https://blog.csdn.net/qq_39765635/article/details/87694796
        PageInfo<AmsSuppliers> pageInfo = new PageInfo<>(list);
        // 如果查询结果为空，直接返回空的分页信息
        if (CollectionUtil.isEmpty(list)) {
            return ResultBody.ok().data(new PageInfo<>(list));
        }
        // 构建分页信息并返回
        PageInfo<SuppliersVO> pageInfoRes = new PageInfo<>(toConvertVO(list));
        pageInfoRes.setPageNum(pageInfo.getPageNum());
        pageInfoRes.setPageSize(pageInfo.getPageSize());
        pageInfoRes.setTotal(pageInfo.getTotal());
        pageInfoRes.setPages(pageInfo.getPages());
        return ResultBody.ok().data(pageInfoRes);
    }

    private List<SuppliersVO> toConvertVO(List<AmsSuppliers> list) {
        ArrayList<SuppliersVO> suppliersVOS = new ArrayList<>();
        if (CollectionUtil.isNotEmpty(list)) {
            list.forEach(amsSuppliers -> {
                SuppliersVO suppliersVO = new SuppliersVO();
                BeanUtil.copyProperties(amsSuppliers, suppliersVO);
                suppliersVO.setActivity(amsSuppliers.getActivity() ? "Y" : "N");
                suppliersVOS.add(suppliersVO);
            });
        }
        return suppliersVOS;
    }

    @Override
    public ResultBody<String> editById(AmsSuppliers model) {
        model.setUpdatedTime(new Date());
        amsSuppliersMapper.updateById(model);
        return ResultBody.ok();
    }

    @Override
    public ResultBody<String> add(AmsSuppliers model) {
        model.setCreatedTime(new Date());
        model.setUpdatedTime(new Date());
        amsSuppliersMapper.insert(model);
        return ResultBody.ok();
    }

    @Override
    public ResultBody<String> delete(AmsSuppliers model) {
        model.setUpdatedTime(new Date());
        model.setDeleteMark(DeleteMarkConstant.DELETED);
        amsSuppliersMapper.updateById(model);
        return ResultBody.ok();
    }

    @Override
    public ResultBody<String> importData(MultipartFile multipartFile, HttpServletRequest req) {
        return null;
    }

    @Override
    public void exportData(PageRequest pageRequest, HttpServletResponse response) {

    }

    @Override
    public ResultBody<List<SuppliersVO>> listBySearch(String searchKey) {
        List<AmsSuppliers> amsSuppliers;
        searchKey = searchKey.trim();
        if (StringUtils.isEmpty(searchKey)) {
            LambdaQueryWrapper<AmsSuppliers> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(AmsSuppliers::getActivity, ActivityConstant.ACTIVITY);
            queryWrapper.eq(AmsSuppliers::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
            queryWrapper.orderByDesc(AmsSuppliers::getUpdatedTime);
            amsSuppliers = amsSuppliersMapper.selectList(queryWrapper);
            return ResultBody.ok().data(toConvertVO(amsSuppliers));
        }
        // 先走全文索引
        // 有空格： 去除空格后的所有的关键字的长度要大于3才能走全文索引
        // 没有空格： 纯中文字符至少大于两位长度才能走全文索引
        // 没有空格： 其他情况至少大于三位长度才能走全文索引，否则走模糊查询
        amsSuppliers = amsSuppliersMapper.listBySearch(searchKey);
        if (CollectionUtil.isEmpty(amsSuppliers)) {
            // 如果全文索引没有查到，则走模糊查询
            amsSuppliers = listBySearchWithLike(searchKey);
        }
        return ResultBody.ok().data(toConvertVO(amsSuppliers));
    }

    @Override
    public ResultBody<SuppliersVO> getById(Integer id) {
        AmsSuppliers amsSuppliers = amsSuppliersMapper.selectById(id);
        return ResultBody.ok().data(amsSuppliers);
    }

    @Override
    public ResultBody<List<SuppliersVO>> listAllSupplierVO() {
        LambdaQueryWrapper<AmsSuppliers> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AmsSuppliers::getActivity, ActivityConstant.ACTIVITY);
        queryWrapper.eq(AmsSuppliers::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        queryWrapper.orderByAsc(AmsSuppliers::getId);
        List<AmsSuppliers> amsSuppliers = amsSuppliersMapper.selectList(queryWrapper);
        if (CollectionUtil.isEmpty(amsSuppliers)){
            return ResultBody.ok().data(new ArrayList<>());
        }
        List<SuppliersVO> vos = new ArrayList<>();
        amsSuppliers.forEach(amsSupplier -> {
            SuppliersVO suppliersVO = new SuppliersVO();
            suppliersVO.setId(amsSupplier.getId());
            suppliersVO.setName(amsSupplier.getName());
            suppliersVO.setContactPerson(amsSupplier.getContactPerson());
            vos.add(suppliersVO);
        });
        return ResultBody.ok().data(vos);
    }


    private List<AmsSuppliers> listBySearchWithLike(String searchKey) {
        List<AmsSuppliers> amsSuppliers = new ArrayList<>();
        // 只显示前20条
        int maxCount = 20;
        if (searchKey.contains(" ")) {
            // 使用split方法按空格分割字符串，得到单词数组。
            String[] split = searchKey.split(" ");
            List<AmsSuppliers> searchList = new ArrayList<>();
            LambdaQueryWrapper<AmsSuppliers> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(AmsSuppliers::getActivity, ActivityConstant.ACTIVITY);
            wrapper.eq(AmsSuppliers::getDeleteMark, DeleteMarkConstant.NOT_DELETED);

            // 找出第一个不为空的子关键字进行查询
            int firstIndex = 0;
            for (int i = 0; i < split.length; i++) {
                if (StringUtils.isNotBlank(split[i])) {
                    firstIndex = i;
                    wrapper.like(AmsSuppliers::getName, split[i]);
                    wrapper.or().like(AmsSuppliers::getContactPerson, split[i]);
                    wrapper.or().like(AmsSuppliers::getPhone, split[i]);
                    wrapper.or().like(AmsSuppliers::getEmail, split[i]);
                    wrapper.or().like(AmsSuppliers::getAddress, split[i]);
                    searchList = amsSuppliersMapper.selectList(wrapper);
                    break;
                }
            }
            if (CollectionUtil.isEmpty(searchList)) {
                return searchList;
            }
            Map<Integer, AmsSuppliers> searchMap = searchList.stream()
                    .collect(Collectors.toMap(AmsSuppliers::getId, Function.identity()));

            //  记录多关键字出现的次数，并根据出现的次数进行排序
            Map<Integer, Integer> countMap = new HashMap<>();
            for (AmsSuppliers amsSupplier : searchList) {
                countMap.put(amsSupplier.getId(), 1);
            }
            for (int i = firstIndex + 1; i < split.length; i++) {
                for (AmsSuppliers amsSupplier : searchList) {
                    if (StringUtils.isNotBlank(split[i]) && amsSupplier.getName().contains(split[i]) ||
                            amsSupplier.getContactPerson().contains(split[i]) ||
                            amsSupplier.getPhone().contains(split[i]) ||
                            amsSupplier.getEmail().contains(split[i]) ||
                            amsSupplier.getAddress().contains(split[i])) {
                        if (countMap.containsKey(amsSupplier.getId())) {
                            countMap.put(amsSupplier.getId(), countMap.get(amsSupplier.getId()) + 1);
                        } else {
                            countMap.put(amsSupplier.getId(), 1);
                        }
                    }
                }
            }
            if (!countMap.isEmpty()) {
                List<Map.Entry<Integer, Integer>> list = new ArrayList<>(countMap.entrySet());
                list.sort((c1, c2) -> c2.getValue().compareTo(c1.getValue()));
                list = list.stream().limit(maxCount).collect(Collectors.toList());
                for (Map.Entry<Integer, Integer> entry : list) {
                    amsSuppliers.add(searchMap.get(entry.getKey()));
                }
            }
        } else {
            LambdaQueryWrapper<AmsSuppliers> wrapper = new LambdaQueryWrapper<>();
            wrapper.like(AmsSuppliers::getName, searchKey);
            wrapper.or().like(AmsSuppliers::getContactPerson, searchKey);
            wrapper.or().like(AmsSuppliers::getPhone, searchKey);
            wrapper.or().like(AmsSuppliers::getEmail, searchKey);
            wrapper.or().like(AmsSuppliers::getAddress, searchKey);
            wrapper.eq(AmsSuppliers::getActivity, ActivityConstant.ACTIVITY);
            wrapper.eq(AmsSuppliers::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
            amsSuppliers = amsSuppliersMapper.selectList(wrapper);
            if (!CollectionUtil.isEmpty(amsSuppliers)) {
                amsSuppliers = amsSuppliers.stream().limit(maxCount).collect(Collectors.toList());
            }
        }
        return amsSuppliers;
    }

    /**
     * 检查字符串中是否只包含中文字符。
     *
     * @param searchKey 待检查的字符串。
     * @return 如果字符串中所有字符都是中文字符，则返回true；否则返回false。
     */
    private Boolean isAllChineseCharacter(String searchKey) {
        // 将字符串转换为字符数组，以便逐个检查字符。
        char[] chars = searchKey.toCharArray();
        // 初始化一个标志变量，假设所有字符都是中文字符。
        boolean flag = true;
        // 遍历字符数组。
        for (char c : chars) {
            // 检查字符是否在中文字符范围内。
            // 中文字符的Unicode编码范围是0x4E00到0x9FA5。
            if (!(c >= 0x4E00 && c <= 0x9FA5)) {
                // 如果找到非中文字符，将标志变量设置为false并立即返回。
                flag = false;
                return flag;
            }
        }
        // 如果遍历完所有字符都没有找到非中文字符，则返回true。
        return flag;
    }

}




