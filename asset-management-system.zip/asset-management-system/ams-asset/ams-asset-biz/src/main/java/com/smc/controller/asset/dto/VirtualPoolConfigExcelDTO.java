package com.smc.controller.asset.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentFontStyle;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import lombok.Data;

import java.io.Serializable;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/20
 * @description
 */
@Data
@ColumnWidth(20)
@HeadFontStyle(fontHeightInPoints = 11)
@ContentFontStyle(fontHeightInPoints = 10)
public class VirtualPoolConfigExcelDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @ExcelProperty(value = "硬件资产编号")
    private String hardwareId;

    @ExcelProperty(value = "虚拟池担当")
    private String poolChargePerson;

    @ExcelProperty(value = "创建者")
    private String createdBy;

    @ExcelProperty(value = "创建时间")
    private String createdTime;

    @ExcelProperty(value = "更新者")
    private String updatedBy;

    @ExcelProperty(value = "更新时间")
    private String updatedTime;

}
