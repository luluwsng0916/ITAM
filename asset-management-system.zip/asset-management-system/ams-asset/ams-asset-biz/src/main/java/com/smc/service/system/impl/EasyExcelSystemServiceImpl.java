package com.smc.service.system.impl;

import com.smc.controller.system.dto.SystemExcelDTO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/23
 * @description
 */
@Service
public class EasyExcelSystemServiceImpl {

    static List<SystemExcelDTO> list = new ArrayList<>();

    /**
     * 分批导入的数据拼接到一起
     *
     * @param
     * @return
     */
    public static List<SystemExcelDTO> getAllImportExcelData() {
        return list;
    }

    public void save(List<SystemExcelDTO> cachedDataList) {
        list.addAll(cachedDataList);
    }

    /**
     * 创建一个构造方法 用于list.clean()
     *
     * @return
     */
    public List<SystemExcelDTO> getList() {
        return list;
    }

}
