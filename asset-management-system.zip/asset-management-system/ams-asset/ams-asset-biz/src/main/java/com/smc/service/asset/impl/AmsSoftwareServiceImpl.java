package com.smc.service.asset.impl;

import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.smc.api.mdm.CodeGenApi;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.constants.PatternConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.asset.bo.SoftwareAddBO;
import com.smc.controller.asset.bo.SoftwareDeleteBO;
import com.smc.controller.asset.bo.SoftwareEditBO;
import com.smc.controller.asset.dto.SoftwareExcelDTO;
import com.smc.dataobject.asset.AmsSoftware;
import com.smc.easyexcel.asset.listener.ImportSoftwareListener;
import com.smc.enums.mdm.TableCodeRule;
import com.smc.mapper.asset.AmsNetworkLineMapper;
import com.smc.mapper.asset.AmsSoftwareMapper;
import com.smc.mapstruct.AmsSoftwareMSMapper;
import com.smc.service.asset.AmsSoftwareService;
import com.smc.utils.DateUtil;
import com.smc.utils.StringUtils;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * @author C31909
 * @description 针对表【ams_software】的数据库操作Service实现
 * @createDate 2024-08-01 09:00:18
 */
@Service
public class AmsSoftwareServiceImpl
        extends ServiceImpl<AmsSoftwareMapper, AmsSoftware>
        implements AmsSoftwareService {

    @Resource
    private AmsSoftwareMapper amsSoftwareMapper;

    @Resource
    private QueryServiceClient queryServiceClient;

    @Resource
    private CodeGenApi codeGenApi;

    @Resource
    private EasyExceSoftwareServiceImpl easyExceSoftwareServiceImpl;

    @Resource
    private AmsSoftwareService amsSoftwareService;

    @Resource
    private AmsNetworkLineMapper amsNetworkLineMapper;

    @Override
    public ResultBody<PageResult> page(PageRequest pageRequest) {
        String name = pageRequest.getParamValue("name");
        String activity = pageRequest.getParamValue("activity");

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        map.put("name", name);
        map.put("activity", activity);
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsSoftware> list = amsSoftwareMapper.findAll(map);
        PageInfo pageInfo = new PageInfo(list);
        PageResult pageResult = new PageResult();
        pageResult.setTotalSize(pageInfo.getTotal());
        pageResult.setTotalPages(pageInfo.getPages());
        pageResult.setContent(pageInfo.getList());
        return ResultBody.ok().data(pageResult);
    }

    @Override
    public ResultBody<String> editById(SoftwareEditBO model) {
        AmsSoftware amsSoftware = AmsSoftwareMSMapper.INSTANCE.toAmsSoftwareEdit(model);
        amsSoftware.setUpdatedBy(model.getOperator());
        amsSoftware.setUpdatedTime(DateUtil.createTimeToDate());
        amsSoftwareMapper.updateById(amsSoftware);
        return ResultBody.ok().data("success");
    }

    @Override
    public ResultBody<String> add(SoftwareAddBO model) {
        AmsSoftware amsSoftware = AmsSoftwareMSMapper.INSTANCE.toAmsSoftwareAdd(model);
        String genCode = codeGenApi.getCodeByTableName(TableCodeRule.SOFTWARE);
        amsSoftware.setId(genCode);
        amsSoftware.setCreatedBy(model.getOperator());
        amsSoftware.setCreatedTime(DateUtil.createTimeToDate());
        amsSoftware.setUpdatedBy(model.getOperator());
        amsSoftware.setUpdatedTime(DateUtil.createTimeToDate());
        amsSoftwareMapper.insert(amsSoftware);
        return ResultBody.ok().data("success");
    }

    @Override
    public ResultBody<String> delete(SoftwareDeleteBO model) {
        AmsSoftware amsSoftware = AmsSoftwareMSMapper.INSTANCE.toAmsSoftDel(model);
        amsSoftware.setDeleteMark(DeleteMarkConstant.DELETED);
        amsSoftware.setUpdatedBy(model.getOperator());
        amsSoftware.setUpdatedTime(DateUtil.createTimeToDate());
        amsSoftwareMapper.updateById(amsSoftware);
        return ResultBody.ok().data("success");
    }

    @Override
    public String importExcel(MultipartFile file, HttpServletRequest request) {

        String operator = request.getParameter("userName");
        List<SoftwareExcelDTO> sourceExcelDataList;
        List<AmsSoftware> insertList = new ArrayList<>();
        List<String> suppliers = amsNetworkLineMapper.findSuppliers();
        List<String> plantNameList = new ArrayList<>(Arrays.asList("IM", "AM", "TJ", "BJ", "CN"));
        List<String> activityList = new ArrayList<>(Arrays.asList("Y", "N"));
        String regex = PatternConstant.DATE_YYYY_MM_DD_SLASH;

        try {
            sourceExcelDataList = getImportExcelData(file);
        } catch (Exception e) {
            return "导入模板错误";
        }
        if (CollectionUtils.isEmpty(sourceExcelDataList)) {
            return "导入模板为空";
        }
        for (SoftwareExcelDTO excel : sourceExcelDataList) {
            if (StringUtils.isBlank(excel.getName())) {
                return "存在空的软件名称，软件名不可为空";
            }
            if (StringUtils.isBlank(excel.getSupplierName())) {
                return "软件名为：[" + excel.getName() + "]的供应商为空，供应商不可为空";
            }
            if (StringUtils.isBlank(excel.getQty())) {
                return "软件名为：[" + excel.getName() + "]的数量为空，数量不可为空";
            }
            if (StringUtils.isBlank(excel.getTotalAmountTax())) {
                return "软件名为：[" + excel.getName() + "]的总金额（含税）为空，总金额（含税）不可为空";
            }
            if (StringUtils.isBlank(excel.getApplyNo())) {
                return "软件名为：[" + excel.getName() + "]的禀议号为空，禀议号不可为空";
            }
            if (StringUtils.isBlank(excel.getOrderNo())) {
                return "软件名为：[" + excel.getName() + "]的订单编号为空，订单编号不可为空";
            }
            if (StringUtils.isBlank(excel.getPlantName())) {
                return "软件名为：[" + excel.getName() + "]的公司别为空，公司别不可为空";
            }
            if (StringUtils.isBlank(excel.getDeadLine())) {
                return "软件名为：[" + excel.getName() + "]的到期时间为空，到期时间不可为空";
            }
            if (StringUtils.isBlank(excel.getActivity())) {
                return "软件名为：[" + excel.getName() + "]的有效性为空，有效性不可为空";
            }
            if (StringUtils.isBlank(excel.getCharger())) {
                return "软件名为：[" + excel.getName() + "]的担当为空，担当不可为空";
            }
            if (StringUtils.isNotBlank(excel.getSupplierName()) && !suppliers.contains(excel.getSupplierName())) {
                return "软件名为：[" + excel.getName() + "]的供应商错误，仅为存在的供应商列表值";
            }
            if (StringUtils.isNotBlank(excel.getPlantName()) && !plantNameList.contains(excel.getPlantName())) {
                return "软件名为：[" + excel.getName() + "]的公司别错误，仅为[IM / AM / TJ / BJ / CN]";
            }
            if (StringUtils.isNotBlank(excel.getActivity()) && !activityList.contains(excel.getActivity())) {
                return "软件名为：[" + excel.getName() + "]的有效性错误，仅为[Y / N]";
            }
            if (StringUtils.isNotBlank(excel.getQty())) {
                try {
                    Double.parseDouble(excel.getQty());
                } catch (NumberFormatException e) {
                    return "软件名为：[" + excel.getName() + "]的数量仅为数字型";
                }
            }
            if (StringUtils.isNotBlank(excel.getTotalAmountTax())) {
                try {
                    Double.parseDouble(excel.getTotalAmountTax());
                } catch (NumberFormatException e) {
                    return "软件名为：[" + excel.getName() + "]的总金额(含税)仅为数字型";
                }
            }
            if (!excel.getDeadLine().matches(regex)) {
                return "软件名为：[" + excel.getName() + "]的到期时间非法，仅为 [yyyy/MM/dd] 格式或日期错误";
            }
            AmsSoftware amsSoftware = AmsSoftwareMSMapper.INSTANCE.toAmsSoftwareImport(excel);
            String genCode = codeGenApi.getCodeByTableName(TableCodeRule.SOFTWARE);
            amsSoftware.setId(genCode);
            amsSoftware.setCreatedBy(operator);
            amsSoftware.setCreatedTime(DateUtil.createTimeToDate());
            amsSoftware.setUpdatedBy(operator);
            amsSoftware.setUpdatedTime(DateUtil.createTimeToDate());
            insertList.add(amsSoftware);
        }
        Lists.partition(insertList, 50).forEach(list -> amsSoftwareService.saveBatch(list, 50));
        return "success";
    }

    /**
     * 获取导入的excel数据
     *
     * @param multipartFile
     * @return
     */
    @SneakyThrows
    private List<SoftwareExcelDTO> getImportExcelData(MultipartFile multipartFile) {

        // 导入excel
        EasyExcel.read(multipartFile.getInputStream(), SoftwareExcelDTO.class,
                new ImportSoftwareListener()).sheet().doRead();
        // 获取excel导入的所有基础数据
        return easyExceSoftwareServiceImpl.getAllImportExcelData();

    }

    @SneakyThrows
    @Override
    public void exportData(PageRequest pageRequest, HttpServletResponse response) {

        String isFormWork = pageRequest.getParamValue("isFormWork");

        if ("模板".equals(isFormWork)) {
            Set<String> excludeColumnFiledNames = new HashSet<>();
            excludeColumnFiledNames.add("id");
            excludeColumnFiledNames.add("createdBy");
            excludeColumnFiledNames.add("createdTime");
            excludeColumnFiledNames.add("updatedBy");
            excludeColumnFiledNames.add("updatedTime");
            EasyExcel.write(response.getOutputStream(), SoftwareExcelDTO.class)
                    .excludeColumnFiledNames(excludeColumnFiledNames)
                    .sheet("sheet1")
                    .doWrite(new ArrayList<SoftwareExcelDTO>());
            return;
        }
        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        if (StringUtils.isNotBlank((String) map.get("activity"))) {
            map.put("activity", map.get("activity"));
        }
        if (StringUtils.isNotBlank((String) map.get("name"))) {
            map.put("name", map.get("name"));
        }
        //导出数据实体
        List<AmsSoftware> list = amsSoftwareMapper.findAll(map);
        EasyExcel.write(response.getOutputStream(), SoftwareExcelDTO.class)
                .sheet("sheet1")
                .doWrite(list);
    }


}




