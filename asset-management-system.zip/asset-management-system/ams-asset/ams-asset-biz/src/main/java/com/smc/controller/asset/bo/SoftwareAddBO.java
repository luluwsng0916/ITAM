package com.smc.controller.asset.bo;

import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @description:
 * @author: C31908
 * @date: 2025/4/24
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SoftwareAddBO implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 供应商
     */
    private String supplierName;
    /**
     * 软件名称
     */
    private String name;
    /**
     * 数量
     */
    private String qty;
    /**
     * 总金额（含税）
     */
    private String totalAmountTax;
    /**
     * 禀议号
     */
    private String applyNo;
    /**
     * 订单编号
     */
    private String orderNo;
    /**
     * 公司别
     */
    private String plantName;
    /**
     * 软件版本
     */
    private String softVersion;
    /**
     * 软件许可证
     */
    private String licenseKey;
    /**
     * 到期时间
     */
//    @DateTimeFormat("yyyy-MM-dd")
//    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    private String deadLine;
    /**
     * 有效性
     */
    private String activity;
    /**
     * 担当
     */
    private String charger;
    /**
     * 备注
     */
    private String remark;
    /**
     * 操作人
     */
    private String operator;
}
