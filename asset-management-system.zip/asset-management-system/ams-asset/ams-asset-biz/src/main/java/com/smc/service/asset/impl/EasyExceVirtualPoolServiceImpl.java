package com.smc.service.asset.impl;

import com.smc.controller.asset.dto.VirtualPoolExcelDTO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/5
 * @description
 */
@Service
public class EasyExceVirtualPoolServiceImpl {

    static List<VirtualPoolExcelDTO> list = new ArrayList<>();
    /**
     * 分批导入的数据拼接到一起
     *
     * @param
     * @return
     */
    public static List<VirtualPoolExcelDTO> getAllImportExcelData() {
        return list;
    }

    public void save(List<VirtualPoolExcelDTO> cachedDataList) {
        list.addAll(cachedDataList);
    }

    /**
     * 创建一个构造方法 用于list.clean()
     *
     * @return
     */
    public List<VirtualPoolExcelDTO> getList() {
        return list;
    }
}
