package com.smc.controller.maintenance.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentFontStyle;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import lombok.Data;

import java.io.Serializable;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/20
 * @description
 */
@Data
@ColumnWidth(20)
@HeadFontStyle(fontHeightInPoints = 11)
@ContentFontStyle(fontHeightInPoints = 10)
public class MaintenanceExcelDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 维保编码
     */
    @ExcelProperty(value = "维保编码")
    private String id;
    /**
     * 合同编号
     */
    @ExcelProperty(value = "合同编号")
    private String contractNo;
    /**
     * 维保对象
     */
    @ExcelProperty(value = "维保对象")
    private String maintenanceObj;
    /**
     * 管理担当
     */
    @ExcelProperty(value = "管理担当")
    private String manager;
    /**
     * 含税金额
     */
    @ExcelProperty(value = "含税金额")
    private String taxInclusiveAmount;
    /**
     * 签约公司
     */
    @ExcelProperty(value = "签约公司")
    private String company;
    /**
     * 服务商
     */
    @ExcelProperty(value = "服务商")
    private String service;
    /**
     * 起始日期
     */
    @ExcelProperty(value = "起始日期")
    private String startDate;
    /**
     * 终止日期
     */
    @ExcelProperty(value = "终止日期")
    private String endDate;
    /**
     * 巡检记录
     */
    @ExcelProperty(value = "巡检记录")
    private String records;
    /**
     * 备注
     */
    @ExcelProperty(value = "备注")
    private String remark;
    /**
     * 禀议裁决号
     */
    @ExcelProperty(value = "禀议裁决号")
    private String applyRulingNo;
    /**
     * 禀议书主旨及内容
     */
    @ExcelProperty(value = "禀议书主旨及内容")
    private String applyContent;

    @ExcelProperty(value = "创建者")
    private String createdBy;

    @ExcelProperty(value = "创建时间")
    private String createdTime;

    @ExcelProperty(value = "更新者")
    private String updatedBy;

    @ExcelProperty(value = "更新时间")
    private String updatedTime;
}
