package com.smc.service.asset.impl;

import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.smc.api.mdm.CodeGenApi;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.constants.PatternConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.controller.asset.bo.*;
import com.smc.controller.asset.dto.VirtualMachineIDCExcelDTO;
import com.smc.dataobject.asset.AmsVirtualMachineIDC;
import com.smc.easyexcel.asset.listener.ImportVirtualMachineIDCListener;
import com.smc.enums.mdm.TableCodeRule;
import com.smc.mapper.asset.AmsVirtualMachineIDCMapper;
import com.smc.mapstruct.AmsVirtualMachineIDCMSMapper;
import com.smc.service.asset.AmsVirtualMachineIDCService;
import com.smc.utils.DateUtil;
import com.smc.utils.StringUtils;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author C31908
 * @version 1.0.0
 * @description
 */

@Slf4j
@Service
public class AmsVirtualMachineIDCServiceImpl
        extends ServiceImpl<AmsVirtualMachineIDCMapper, AmsVirtualMachineIDC>
        implements AmsVirtualMachineIDCService {

    @Resource
    private AmsVirtualMachineIDCMapper amsVirtualMachineIDCMapper;
    @Resource
    private QueryServiceClient queryServiceClient;
    @Resource
    private EasyExcelVirtualMachineIDCServiceImpl easyExcelVirtualMachineIDCServiceImpl;
    @Resource
    private CodeGenApi codeGenApi;
    @Resource
    private AmsVirtualMachineIDCService amsVirtualMachineIDCService;

    /**
     * 分页查询
     *
     * @param pageRequest
     * @return
     */
    @Override
    public PageResult selectPage(PageRequest pageRequest) {

        String serverName = pageRequest.getParamValue("serverName");
        String appliedSystem = pageRequest.getParamValue("appliedSystem");
        String activity = pageRequest.getParamValue("activity");

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        map.put("serverName", serverName);
        map.put("appliedSystem", appliedSystem);
        map.put("activity", activity);
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsVirtualMachineIDC> list = amsVirtualMachineIDCMapper.findAll(map);
        for (AmsVirtualMachineIDC l : list) {
            if (StringUtils.isNotBlank(l.getActivity())) {
                l.setActivity(l.getActivity().equals("1") ? "Y" : "N");
            }
            if (StringUtils.isNotBlank(l.getRp4vm())) {
                l.setRp4vm(l.getRp4vm().equals("1") ? "是" : "否");
            }
        }
        PageInfo pageInfo = new PageInfo(list);
        PageResult pageResult = new PageResult();
        pageResult.setTotalSize(pageInfo.getTotal());
        pageResult.setTotalPages(pageInfo.getPages());
        pageResult.setContent(pageInfo.getList());
        return pageResult;
    }

    /**
     * 编辑
     *
     * @param model
     * @return
     */
    @Override
    public String editById(VirtualMachineIDCEditBO model) {
        AmsVirtualMachineIDC amsVirtualMachineIDC = AmsVirtualMachineIDCMSMapper.INSTANCE.toAmsVirtualMachineIDCEdit(model);
        String[] split = String.valueOf(model.getServerCreatedTime()).split("-");
        String format = split[0] + split[1] + split[2];
        amsVirtualMachineIDC.setAlias(model.getServerName() + model.getAppliedSystem() + format);
        amsVirtualMachineIDC.setUpdatedBy(model.getOperator());
        amsVirtualMachineIDC.setUpdatedTime(DateUtil.createTimeToDate());
        amsVirtualMachineIDCMapper.updateById(amsVirtualMachineIDC);
        return "success";
    }

    /**
     * 获取此服务器名称数据库中的个数
     *
     * @param name
     * @return
     */
    public Integer getNameCount(String name) {
        LambdaQueryWrapper<AmsVirtualMachineIDC> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AmsVirtualMachineIDC::getServerName, name)
                .eq(AmsVirtualMachineIDC::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        return amsVirtualMachineIDCMapper.selectCount(queryWrapper);
    }

    /**
     * 获取此IP数据库中的个数
     *
     * @param ip
     * @return
     */
    public Integer getIPCount(String ip) {
        LambdaQueryWrapper<AmsVirtualMachineIDC> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AmsVirtualMachineIDC::getIp, ip)
                .eq(AmsVirtualMachineIDC::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        return amsVirtualMachineIDCMapper.selectCount(queryWrapper);
    }

    /**
     * 新增
     *
     * @param model
     * @return
     */
    @Override
    public String add(VirtualMachineIDCAddBO model) {
        AmsVirtualMachineIDC amsVirtualMachineIDC = AmsVirtualMachineIDCMSMapper.INSTANCE.toAmsVirtualMachineIDCAdd(model);
        if (StringUtils.isNotBlank(model.getServerName())) {
            Integer checkNameCount = getNameCount(model.getServerName());
            if (checkNameCount != 0) {
                return "服务器名已存在";
            }
        }
        if (StringUtils.isNotBlank(model.getIp())) {
            Integer checkIPCount = getIPCount(model.getIp());
            if (checkIPCount != 0) {
                return "IP地址已存在";
            }
        }
        String genCode = codeGenApi.getCodeByTableNameTime(TableCodeRule.VIRTUAL_MACHINE_IDC);
        amsVirtualMachineIDC.setServerId(genCode);
        String[] split = model.getServerCreatedTime().split("-");
        String format = split[0] + split[1] + split[2];
        amsVirtualMachineIDC.setAlias(model.getServerName() + model.getAppliedSystem() + format);
        amsVirtualMachineIDC.setCreatedBy(model.getOperator());
        amsVirtualMachineIDC.setCreatedTime(DateUtil.createTimeToDate());
        amsVirtualMachineIDC.setUpdatedBy(model.getOperator());
        amsVirtualMachineIDC.setUpdatedTime(DateUtil.createTimeToDate());
        amsVirtualMachineIDCMapper.insert(amsVirtualMachineIDC);
        return "success";
    }

    /**
     * 删除
     *
     * @param model
     * @return
     */
    @Override
    public String delete(VirtualMachineIDCDeleteBO model) {
        AmsVirtualMachineIDC amsVirtualMachineIDC = AmsVirtualMachineIDCMSMapper.INSTANCE.toAmsVirtualMachineIDCDel(model);
        amsVirtualMachineIDC.setDeleteMark(DeleteMarkConstant.DELETED);
        amsVirtualMachineIDC.setUpdatedBy(model.getOperator());
        amsVirtualMachineIDC.setUpdatedTime(DateUtil.createTimeToDate());
        amsVirtualMachineIDCMapper.updateById(amsVirtualMachineIDC);
        return "success";
    }

    /**
     * 导出
     *
     * @param pageRequest
     * @param response
     */
    @SneakyThrows
    @Override
    public void export(PageRequest pageRequest, HttpServletResponse response) {

        String serverName = pageRequest.getParamValue("serverName");
        String appliedSystem = pageRequest.getParamValue("appliedSystem");
        String activity = pageRequest.getParamValue("activity");
        String isFormWork = pageRequest.getParamValue("isFormWork");

        if ("模板".equals(isFormWork)) {
            Set<String> excludeColumnFiledNames = new HashSet<>();
            excludeColumnFiledNames.add("serverId");
            excludeColumnFiledNames.add("alias");
            excludeColumnFiledNames.add("createdBy");
            excludeColumnFiledNames.add("createdTime");
            excludeColumnFiledNames.add("updatedBy");
            excludeColumnFiledNames.add("updatedTime");
            EasyExcel.write(response.getOutputStream(), VirtualMachineIDCExcelDTO.class)
                    .excludeColumnFiledNames(excludeColumnFiledNames)
                    .sheet("sheet1")
                    .doWrite(new ArrayList<VirtualMachineIDCExcelDTO>());
            return;
        }

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        map.put("serverName", serverName);
        map.put("appliedSystem", appliedSystem);
        map.put("activity", activity);
        Set<String> excludeColumnFiledNames = new HashSet<>();
        excludeColumnFiledNames.add("createdBy");
        excludeColumnFiledNames.add("createdTime");
        excludeColumnFiledNames.add("updatedBy");
        excludeColumnFiledNames.add("updatedTime");
        //导出数据实体
        List<AmsVirtualMachineIDC> list = amsVirtualMachineIDCMapper.findAll(map);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        for (AmsVirtualMachineIDC l : list) {
            l.setRp4vm(l.getRp4vm().equals("1") ? "是" : "否");
            l.setActivity(l.getActivity().equals("1") ? "Y" : "N");
        }
        EasyExcel.write(response.getOutputStream(), VirtualMachineIDCExcelDTO.class)
                .excludeColumnFiledNames(excludeColumnFiledNames)
                .sheet("sheet1")
                .doWrite(list);
    }

    /**
     * 导入
     *
     * @param file
     * @param request
     * @return
     */
    @Override
    public String importExcel(MultipartFile file, HttpServletRequest request) {

        String operator = request.getParameter("userName");
        List<VirtualMachineIDCExcelDTO> sourceExcelDataList;
        List<AmsVirtualMachineIDC> insertList = new ArrayList<>();

        try {
            sourceExcelDataList = getImportExcelData(file);
        } catch (Exception e) {
            return "导入模板错误";
        }
        if (CollectionUtils.isEmpty(sourceExcelDataList)) {
            return "导入模板为空";
        }
        for (VirtualMachineIDCExcelDTO excel : sourceExcelDataList) {
            if(StringUtils.isBlank(excel.getServerName())) {
                return "存在空的服务器名，服务器名不可为空";
            }
            if(StringUtils.isBlank(excel.getVcName())) {
                return "服务器名为：[" + excel.getServerName() + "]的VC显示名称为空，VC显示名称不可为空";
            }
            if(StringUtils.isBlank(excel.getAppliedSystem())) {
                return "服务器名为：[" + excel.getServerName() + "]的系统名称/应用为空，系统名称/应用不可为空";
            }
            if(StringUtils.isBlank(excel.getIp())) {
                return "服务器名为：[" + excel.getServerName() + "]的IP地址为空，IP地址不可为空";
            }
            if(StringUtils.isBlank(excel.getOperatingSystem())) {
                return "服务器名为：[" + excel.getServerName() + "]的服务器操作系统为空，服务器操作系统不可为空";
            }
            if(StringUtils.isBlank(excel.getServerType())) {
                return "服务器名为：[" + excel.getServerName() + "]的服务器类别为空，服务器类别不可为空";
            }
            if(StringUtils.isBlank(excel.getAppliedType())) {
                return "服务器名为：[" + excel.getServerName() + "]的应用类别为空，应用类别不可为空";
            }
            if(StringUtils.isBlank(excel.getAppliedEnv())) {
                return "服务器名为：[" + excel.getServerName() + "]的用途为空，用途不可为空";
            }
            if(StringUtils.isBlank(excel.getBakType())) {
                return "服务器名为：[" + excel.getServerName() + "]的备份方式为空，备份方式不可为空";
            }
            if(StringUtils.isBlank(excel.getRp4vm())) {
                return "服务器名为：[" + excel.getServerName() + "]的启用RP4VM复制为空，启用RP4VM复制不可为空";
            }
            if(StringUtils.isBlank(excel.getActivity())) {
                return "服务器名为：[" + excel.getServerName() + "]的使用中为空，使用中不可为空";
            }
            if(StringUtils.isBlank(excel.getCpu())) {
                return "服务器名为：[" + excel.getServerName() + "]的CPU为空，CPU不可为空";
            }
            if(StringUtils.isBlank(excel.getMemory())) {
                return "服务器名为：[" + excel.getServerName() + "]的内存为空，内存不可为空";
            }
            if(StringUtils.isBlank(excel.getHardDisk())) {
                return "服务器名为：[" + excel.getServerName() + "]的硬盘为空，硬盘不可为空";
            }
            if(StringUtils.isBlank(excel.getDomain())) {
                return "服务器名为：[" + excel.getServerName() + "]的域名为空，域名不可为空";
            }
            if(StringUtils.isBlank(excel.getManageGroup())) {
                return "服务器名为：[" + excel.getServerName() + "]的IT部小组为空，IT部小组不可为空";
            }
            if(StringUtils.isBlank(excel.getItManager())) {
                return "服务器名为：[" + excel.getServerName() + "]的IT部担当为空，IT部担当不可为空";
            }
            if(StringUtils.isBlank(excel.getServerCreatedTime())) {
                return "服务器名为：[" + excel.getServerName() + "]的创建时间为空，创建时间不可为空";
            }
            if (getNameCount(excel.getServerName()) != 0) {
                return "服务器名为：[" + excel.getServerName() + "]的服务器名已存在";
            }
            if (StringUtils.isNotBlank(excel.getIp()) && getIPCount(excel.getIp()) != 0) {
                return "服务器名为：[" + excel.getServerName() + "]的IP地址已存在";
            }
            List<String> hardwareIdCheckList = new ArrayList<>(Arrays.asList("P系列", "E系列"));
            if (StringUtils.isNotBlank(excel.getHardwareId()) && !hardwareIdCheckList.contains(excel.getHardwareId())) {
                return "服务器名为：[" + excel.getServerName() + "]的关联资产编码错误，仅为[P系列 / E系列]";
            }
            List<String> serverTypeCheckList = new ArrayList<>(Arrays.asList("基础系统", "业务系统"));
            if (StringUtils.isNotBlank(excel.getServerType()) && !serverTypeCheckList.contains(excel.getServerType())) {
                return "服务器名为：[" + excel.getServerName() + "]的服务器类别错误，仅为[基础系统 / 业务系统]";
            }
            List<String> appliedTpypeCheckList = new ArrayList<>(Arrays.asList("应用服务器", "数据库服务器"));
            if (StringUtils.isNotBlank(excel.getAppliedType()) && !appliedTpypeCheckList.contains(excel.getAppliedType())) {
                return "服务器名为：[" + excel.getServerName() + "]的应用类别错误，仅为[应用服务器 / 数据库服务器]";
            }
            List<String> appliedEnvCheckList = new ArrayList<>(Arrays.asList("生产", "管理", "测试", "基础"));
            if (StringUtils.isNotBlank(excel.getAppliedEnv()) && !appliedEnvCheckList.contains(excel.getAppliedEnv())) {
                return "服务器名为：[" + excel.getServerName() + "]的用途错误，仅为[生产 / 管理 / 测试/ 基础]";
            }
//            List<String> bakTypeCheckList = new ArrayList<>(Arrays.asList("PPDM VM(BR-DR)", "PPDM VM(BR-DR-CR)", "PPDM DB(BR-DR-CR)", "None"));
//            if (!bakTypeCheckList.contains(excel.getBakType())) {
//                return "服务器名为：[" + excel.getServerName() + "]的备份方式错误，仅为[PPDM VM(BR-DR) / PPDM VM(BR-DR-CR)/ PPDM DB(BR-DR-CR) / None]";
//            }
            List<String> RP4VMCheckList = new ArrayList<>(Arrays.asList("是", "否"));
            if (StringUtils.isNotBlank(excel.getRp4vm()) && !RP4VMCheckList.contains(excel.getRp4vm())) {
                return "服务器名为：[" + excel.getServerName() + "]的启用RP4VM复制错误，仅为[是 / 否]";
            }
            List<String> activityCheckList = new ArrayList<>(Arrays.asList("Y", "N"));
            if (!activityCheckList.contains(excel.getActivity())) {
                return "服务器名为：[" + excel.getServerName() + "]的使用中错误，仅为[Y / N]";
            }
            if (StringUtils.isNotBlank(excel.getCpu())) {
                try {
                    Double.parseDouble(excel.getCpu());
                } catch (NumberFormatException e) {
                    return "服务器名为：[" + excel.getServerName() + "]的CPU仅为数字型";
                }
            }
            if (StringUtils.isNotBlank(excel.getMemory())) {
                try {
                    Double.parseDouble(excel.getMemory());
                } catch (NumberFormatException e) {
                    return "服务器名为：[" + excel.getServerName() + "]的内存仅为数字型";
                }
            }
            if (StringUtils.isNotBlank(excel.getHardDisk())) {
                try {
                    Double.parseDouble(excel.getHardDisk());
                } catch (NumberFormatException e) {
                    return "服务器名为：[" + excel.getServerName() + "]的硬盘仅为数字型";
                }
            }
            String regex = PatternConstant.DATE_YYYY_MM_DD_SLASH;
            if (!excel.getServerCreatedTime().matches(regex)) {
                return "服务器名为：[" + excel.getServerName() + "]的创建时间非法，仅为 [yyyy/MM/dd] 格式";
            }
            AmsVirtualMachineIDC amsVirtualMachineIDC = AmsVirtualMachineIDCMSMapper.INSTANCE.toAmsVirtualMachineIDCImport(excel);
            String[] split = excel.getServerCreatedTime().split("/");
            String serverCreatedTime = split[0] + split[1] + split[2];
            String genCode = codeGenApi.getCodeByTableNameTime(TableCodeRule.VIRTUAL_MACHINE_IDC);
            amsVirtualMachineIDC.setServerId(genCode);
            amsVirtualMachineIDC.setAlias(excel.getServerName() + excel.getAppliedSystem() + serverCreatedTime);
            amsVirtualMachineIDC.setRp4vm(amsVirtualMachineIDC.getRp4vm().equals("是") ? "1" : "0");
            amsVirtualMachineIDC.setActivity(amsVirtualMachineIDC.getActivity().equals("Y") ? "1" : "0");
            amsVirtualMachineIDC.setCreatedBy(operator);
            amsVirtualMachineIDC.setCreatedTime(DateUtil.createTimeToDate());
            amsVirtualMachineIDC.setUpdatedBy(operator);
            amsVirtualMachineIDC.setUpdatedTime(DateUtil.createTimeToDate());
            insertList.add(amsVirtualMachineIDC);
        }
        Lists.partition(insertList, 50).forEach(list -> amsVirtualMachineIDCService.saveBatch(list, 50));
        return "success";
    }

    /**
     * 获取导入的excel数据
     *
     * @param multipartFile
     * @return
     */
    @SneakyThrows
    private List<VirtualMachineIDCExcelDTO> getImportExcelData(MultipartFile multipartFile) {
        List<VirtualMachineIDCExcelDTO> excelList = new ArrayList<>();
        if (multipartFile != null) {
            // 导入excel
            EasyExcel.read(multipartFile.getInputStream(), VirtualMachineIDCExcelDTO.class,
                    new ImportVirtualMachineIDCListener()).sheet().doRead();
            // 获取excel导入的所有基础数据
            excelList = easyExcelVirtualMachineIDCServiceImpl.getAllImportExcelData();
            return excelList;
        }
        return excelList;
    }


}
