package com.smc.controller.maintenance.bo;

import lombok.Data;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/20
 * @description
 */
@Data
public class MaintenanceAddBO {

    /**
     * 维保对象
     */
    private String maintenanceObj;
    /**
     * 管理担当
     */
    private String manager;
    /**
     * 含税金额
     */
    private String taxInclusiveAmount;
    /**
     * 签约公司
     */
    private String company;
    /**
     * 服务商
     */
    private String service;
    /**
     * 起始日期
     */
    private String startDate;
    /**
     * 终止日期
     */
    private String endDate;
    /**
     * 巡检记录
     */
    private String records;
    /**
     * 备注
     */
    private String remark;
    /**
     * 合同编号
     */
    private String contractNo;
    /**
     * 禀议裁决号
     */
    private String applyRulingNo;
    /**
     * 禀议书主旨及内容
     */
    private String applyContent;

    /**
     * 创建人
     */
    private String operator;
}
