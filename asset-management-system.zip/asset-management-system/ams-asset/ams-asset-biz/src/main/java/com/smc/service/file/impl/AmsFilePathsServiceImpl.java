package com.smc.service.file.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.ActivityConstant;
import com.smc.common.constants.CommonConstants;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.file.bo.FilePathCleanBO;
import com.smc.controller.file.bo.FilePathDeleteBO;
import com.smc.controller.file.bo.FilePathEditBO;
import com.smc.controller.file.vo.FilePathVO;
import com.smc.dataobject.file.AmsFilePath;
import com.smc.mapper.file.AmsFilePathsMapper;
import com.smc.service.file.AmsFilePathsService;
import com.smc.service.maintenance.AmsMaintenanceService_bak;
import com.smc.utils.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * @author C31909
 * @description 针对表【ams_file_paths】的数据库操作Service实现
 * @createDate 2024-08-01 09:00:18
 */
@Service
public class AmsFilePathsServiceImpl implements AmsFilePathsService {
    @Resource
    private QueryServiceClient queryServiceClient;

    @Resource
    private AmsFilePathsMapper amsFilePathsMapper;

    @Resource
    private AmsMaintenanceService_bak amsMaintenanceService;

    @Value(value = "${upload.ftp.basePath}")
    private String ftpBasePath;
    @Value(value = "${upload.ftp.contract}")
    private String ftpPath;
    @Value(value = "${upload.ftp.host}")
    private String ftpHost;
    @Value(value = "${upload.ftp.port}")
    private String ftpPort;
    @Value(value = "${upload.url.port}")
    private String urlPort;
    @Value(value = "${upload.ftp.username}")
    private String ftpUsername;
    @Value(value = "${upload.ftp.password}")
    private String ftpPassword;

    @Override
    public List<AmsFilePath> getFilePathByIdList(List<Integer> fileIdList) {
        return amsFilePathsMapper.selectBatchIds(fileIdList);
    }

    @Override
    public ResultBody<Integer> saveFilePath(List<String> filePathList, List<String> fileNameList, List<Long> fileSizeList,
                                            List<String> fileTypeList, String updatedBy) {
        AmsFilePath amsFilePath = new AmsFilePath();
        amsFilePath.setFileName(CollectionUtil.isNotEmpty(fileNameList) ? CollectionUtil.join(fileNameList, ",") : null);
        amsFilePath.setFilePath(CollectionUtil.isNotEmpty(filePathList) ? CollectionUtil.join(filePathList, ",") : null);
        amsFilePath.setFileSize(CollectionUtil.isNotEmpty(fileSizeList) ? CollectionUtil.join(fileSizeList, ",") : null);
        amsFilePath.setFileType(CollectionUtil.isNotEmpty(fileTypeList) ? CollectionUtil.join(fileTypeList, ",") : null);
        amsFilePath.setCreatedBy(updatedBy);
        amsFilePath.setCreatedTime(new Date());
        amsFilePath.setUpdatedBy(updatedBy);
        amsFilePath.setUpdatedTime(amsFilePath.getCreatedTime());
        amsFilePath.setActivity(ActivityConstant.ACTIVITY_BOOL);
        amsFilePath.setVersion(CommonConstants.DEFAULT_VERSION);
        amsFilePath.setDeleteMark(DeleteMarkConstant.NOT_DELETED);
        amsFilePathsMapper.insert(amsFilePath);
        return ResultBody.ok().data(amsFilePath.getId());
    }

    @Override
    public AmsFilePath getById(Integer fileId) {
        return amsFilePathsMapper.selectById(fileId);
    }

    @Override
    public void updateById(AmsFilePath amsFilePath) {
        amsFilePathsMapper.updateById(amsFilePath);
    }

    @Override
    public ResultBody<PageInfo<FilePathVO>> page(PageRequest pageRequest) {
        // 从分页请求中获取资产名称和型号参数
        String fileName = pageRequest.getParamValue("fileName");
        String activity = pageRequest.getParamValue("activity");

        // 构建查询条件，根据资产名称和型号进行模糊查询，且只查询未删除的硬件
        LambdaQueryWrapper<AmsFilePath> wrapper = new LambdaQueryWrapper<>();
        wrapper.like(StringUtils.isNotBlank(fileName), AmsFilePath::getFileName, fileName);
        wrapper.eq(StringUtils.isNotBlank(activity), AmsFilePath::getActivity, Boolean.parseBoolean(activity));
        wrapper.eq(AmsFilePath::getDeleteMark, DeleteMarkConstant.NOT_DELETED);

        // 通过queryServiceClient获取额外的查询条件和排序条件
        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        StringBuilder stringBuilder = new StringBuilder();
        if (map.get("conditionParams") != null) {
            stringBuilder.append(map.get("conditionParams"));
        }
        if (map.get("sortParam") != null) {
            stringBuilder.append(" ORDER BY ").append(map.get("sortParam"));
        } else {
            stringBuilder.append(" ORDER BY ").append("createdTime DESC,updatedTime DESC");
        }
        wrapper.last(stringBuilder.toString());

        // 初始化分页插件，进行分页查询
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsFilePath> list = amsFilePathsMapper.selectList(wrapper);
        // 为什么：原因是自己封装的vo把PageInfo原有的属性破坏了
        // 解决方案：https://blog.csdn.net/qq_39765635/article/details/87694796
        PageInfo<AmsFilePath> pageInfo = new PageInfo<>(list);
        // 如果查询结果为空，直接返回空的分页信息
        if (CollectionUtil.isEmpty(list)) {
            return ResultBody.ok().data(pageInfo);
        }
        // 将查询到的硬件信息转换为VO对象
        List<FilePathVO> filePathVOList = toFilePathVO(list);
        // 构建分页信息并返回
        PageInfo<FilePathVO> pageInfoRes = new PageInfo<>(filePathVOList);
        pageInfoRes.setPageNum(pageInfo.getPageNum());
        pageInfoRes.setPageSize(pageInfo.getPageSize());
        pageInfoRes.setTotal(pageInfo.getTotal());
        pageInfoRes.setPages(pageInfo.getPages());
        // BeanUtils.copyProperties(pageInfo,pageInfoRes);
        return ResultBody.ok().data(pageInfoRes);
    }

    private List<FilePathVO> toFilePathVO(List<AmsFilePath> list) {
        List<FilePathVO> vos = new ArrayList<>(list.size());
        list.forEach(amsFilePath -> {
            FilePathVO vo = new FilePathVO();
            vo.setId(amsFilePath.getId());
            vo.setFileName(amsFilePath.getFileName());
            vo.setFilePath(amsFilePath.getFilePath());
            vo.setFileSize(amsFilePath.getFileSize());
            vo.setFileType(amsFilePath.getFileType());
            vo.setActivity(amsFilePath.getActivity() ? ActivityConstant.ACTIVITY_STR :
                    ActivityConstant.INACTIVITY_STR);
            vo.setRemark(amsFilePath.getRemark());
            vo.setVersion(amsFilePath.getVersion());
            vo.setCreatedBy(amsFilePath.getCreatedBy());
            vo.setCreatedTime(amsFilePath.getCreatedTime());
            vo.setUpdatedBy(amsFilePath.getUpdatedBy());
            vo.setUpdatedTime(amsFilePath.getUpdatedTime());
            vos.add(vo);
        });
        return vos;
    }

    @Override
    public ResultBody<String> delete(FilePathDeleteBO model) {
        Boolean isExist = amsMaintenanceService.isExistFilePath(model.getId());
        if (isExist) {
            return ResultBody.failed().msg("该文件已被使用，无法删除");
        }
        AmsFilePath selectById = amsFilePathsMapper.selectById(model.getId());
        if (selectById == null) {
            return ResultBody.failed().msg("该文件不存在");
        }
        String filePathArrStr = selectById.getFilePath();
        String localPath = ftpBasePath + ftpPath;
        removeFileFromServer(localPath, filePathArrStr);
        AmsFilePath amsFilePath = new AmsFilePath();
        amsFilePath.setId(model.getId());
        amsFilePath.setUpdatedBy(model.getUpdatedBy());
        amsFilePath.setVersion(model.getVersion());
        amsFilePath.setUpdatedTime(new Date());
        amsFilePath.setDeleteMark(DeleteMarkConstant.DELETED);
        amsFilePathsMapper.updateById(amsFilePath);
        return ResultBody.ok();
    }

    @Override
    public ResultBody<String> clean(FilePathCleanBO model) {
        // 构建查询条件，根据资产名称和型号进行模糊查询，且只查询未删除的硬件
        LambdaQueryWrapper<AmsFilePath> wrapper = new LambdaQueryWrapper<>();
        wrapper.ge(model.getStartDate() != null, AmsFilePath::getUpdatedTime, model.getStartDate());
        wrapper.lt(model.getEndDate() != null, AmsFilePath::getUpdatedTime, model.getEndDate());
        wrapper.eq(AmsFilePath::getDeleteMark, DeleteMarkConstant.DELETED);
        List<AmsFilePath> list = amsFilePathsMapper.selectList(wrapper);
        if (CollectionUtil.isEmpty(list)) {
            return ResultBody.ok().msg("该时间段内没有文件需要删除");
        }
        String localPath = ftpBasePath + ftpPath;
        for (AmsFilePath amsFilePath : list) {
            String filePathArrStr = amsFilePath.getFilePath();
            removeFileFromServer(localPath, filePathArrStr);
        }
        return ResultBody.ok();
    }

    private void removeFileFromServer(String localPath, String filePathArrStr) {
        if (!StringUtils.isBlank(filePathArrStr)) {
            String[] filePathArr = filePathArrStr.split(",");
            for (String filePath : filePathArr) {
                String[] subFilePath = filePath.split("/");
                String localFilePath = localPath + subFilePath[subFilePath.length - 1];
                File localFile = new File(localFilePath);
                if (localFile.exists()) {
                    localFile.delete();
                }
            }
        }
    }

    @Override
    public ResultBody<String> editById(FilePathEditBO model) {
        AmsFilePath amsFilePath = new AmsFilePath();
        amsFilePath.setId(model.getId());
        amsFilePath.setRemark(model.getRemark());
        amsFilePath.setUpdatedBy(model.getUpdatedBy());
        amsFilePath.setVersion(model.getVersion());
        amsFilePath.setUpdatedTime(new Date());
        amsFilePathsMapper.updateById(amsFilePath);
        return ResultBody.ok();
    }
}




