package com.smc.controller.asset.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.smc.common.mybatis.entity.AbstractEntity;
import com.smc.convert.easyexcel.DateConverter;
import lombok.Data;

import java.util.Date;

/**
 * @program: asset-management-system
 * @ClassName VirtualPoolVO
 * @description:
 * @author: C31909
 * @create: 2024-07-30 08:27
 * @Version 1.0
 **/
@Data
public class VirtualPoolVO extends AbstractEntity {

    private String id;

    private String hardwareId;

    private String virtualMachineId;

    private String manager;

    private String activity;

    private String remark;
}
