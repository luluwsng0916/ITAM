package com.smc.controller.asset.dto;

import lombok.Data;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/11
 * @description
 */
@Data
public class VirtualPoolConditionDTO {

    private String searchData;

    private String manager;

    private String hardwareId;
}
