package com.smc.service.asset.impl;

import com.smc.controller.asset.dto.VirtualMachineExcelDTO;
import lombok.Data;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

/**
 * @program: asset-management-system
 * @ClassName EasyExcelVirtualMachineServiceImpl
 * @description:
 * @author: C31909
 * @create: 2024-08-02 15:29
 * @Version 1.0
 **/
@Data
@Getter
public class EasyExcelVirtualMachineServiceImpl {
    static List<VirtualMachineExcelDTO> list = new ArrayList<>();
    /**
     * 分批导入的数据拼接到一起
     *
     * @param
     * @return
     */
    public static List<VirtualMachineExcelDTO> getAllImportExcelData() {
        return list;
    }

    public void save(List<VirtualMachineExcelDTO> cachedDataList) {
        list.addAll(cachedDataList);
    }

    /**
     * 创建一个构造方法 用于list.clean()
     *
     * @return
     */
    public List<VirtualMachineExcelDTO> getList() {
        return list;
    }

}
