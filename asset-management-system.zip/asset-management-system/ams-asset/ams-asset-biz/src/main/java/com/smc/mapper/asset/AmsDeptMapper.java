package com.smc.mapper.asset;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smc.dataobject.asset.AmsDept;

public interface AmsDeptMapper extends BaseMapper<AmsDept> {
}
