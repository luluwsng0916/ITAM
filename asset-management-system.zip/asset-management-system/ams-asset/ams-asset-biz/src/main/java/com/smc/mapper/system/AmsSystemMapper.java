package com.smc.mapper.system;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smc.controller.system.dto.SystemExcelDTO;
import com.smc.dataobject.asset.AmsHardware;
import com.smc.dataobject.system.AmsSystem;

import java.util.HashMap;
import java.util.List;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/6
 * @description
 */
public interface AmsSystemMapper extends BaseMapper<AmsSystem> {

    List<AmsSystem> findAll(HashMap<String, Object> map);

    void insertBatch(List<SystemExcelDTO> list);
}
