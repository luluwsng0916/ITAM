package com.smc.mapstruct;

import com.smc.controller.asset.bo.NetworkLineAddBO;
import com.smc.controller.asset.bo.NetworkLineDeleteBO;
import com.smc.controller.asset.bo.NetworkLineEditBO;
import com.smc.dataobject.asset.AmsNetworkLine;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/8/26
 * @description
 */

@Mapper
public interface AmsNetworkLineMSMapper {

    AmsNetworkLineMSMapper INSTANCE = Mappers.getMapper(AmsNetworkLineMSMapper.class);


    @Mappings({
            @Mapping(source = "operator", target = "createdBy")
    })
    AmsNetworkLine toAmsNetworkLineAdd(NetworkLineAddBO networkLineAddBO);

    @Mappings({
            @Mapping(source = "operator", target = "updatedBy"),
            @Mapping(source = "version", target = "version")
    })
    AmsNetworkLine toAmsNetworkLineEdit(NetworkLineEditBO networkLineAddBO);

    @Mappings({
            @Mapping(source = "networkLineName", target = "networkLineName"),
            @Mapping(source = "updatedBy", target = "updatedBy"),
            @Mapping(source = "version", target = "version")
    })
    AmsNetworkLine toAmsNetworkLineDel(NetworkLineDeleteBO networkLineDeleteBO);
}
