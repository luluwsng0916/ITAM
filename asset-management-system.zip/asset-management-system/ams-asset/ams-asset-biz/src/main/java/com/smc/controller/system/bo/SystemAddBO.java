package com.smc.controller.system.bo;

import lombok.Data;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/6
 * @description
 */
@Data
public class SystemAddBO {

    /**
     * 系统中文名
     */
    private String systemName;
    /**
     * 系统英文名
     */
    private String systemEngName;
    /**
     * 系统英文简称
     */
    private String systemEngShortName;
    /**
     * 系统类别（外购/自研发）
     */
    private String systemType;
    /**
     * 主要功能
     */
    private String functional;
    /**
     * 上线时间
     */
    private String goLiveTime;
    /**
     * 下线时间
     */
    private String downtime;
    /**
     * 负责人
     */
    private String chargePerson;
    /**
     * 创建人
     */
    private String operator;

}
