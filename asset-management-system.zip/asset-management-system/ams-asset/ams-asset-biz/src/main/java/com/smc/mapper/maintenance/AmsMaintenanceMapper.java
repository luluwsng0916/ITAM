package com.smc.mapper.maintenance;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smc.controller.maintenance.dto.MaintenanceExcelDTO;
import com.smc.dataobject.maintenance.AmsMaintenance;

import java.util.HashMap;
import java.util.List;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
public interface AmsMaintenanceMapper extends BaseMapper<AmsMaintenance> {

    List<AmsMaintenance> findAll(HashMap<String, Object> map);

    void insertBatch(List<MaintenanceExcelDTO> list);

    List<String> findMaintenanceList(String data);

    List<String> findMaintenanceListCheck();

    List<AmsMaintenance> getMaintenanceExpiration();
}
