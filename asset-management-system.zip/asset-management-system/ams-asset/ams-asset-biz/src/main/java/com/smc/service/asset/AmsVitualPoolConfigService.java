package com.smc.service.asset;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.controller.asset.bo.VitualPoolConfigAddBO;
import com.smc.controller.asset.bo.VitualPoolConfigDeleteBO;
import com.smc.controller.asset.bo.VitualPoolConfigEditBO;
import com.smc.dataobject.asset.AmsVitualPoolConfig;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
public interface AmsVitualPoolConfigService extends IService<AmsVitualPoolConfig> {

    PageResult selectPage(PageRequest pageRequest);

    String editById(VitualPoolConfigEditBO model);

    String add(VitualPoolConfigAddBO model);

    String delete(VitualPoolConfigDeleteBO model);
}
