package com.smc.controller.system.bo;

import lombok.Data;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/9
 * @description
 */
@Data
public class ServiceDeleteBO {

    private String id;

    private String updatedBy;

    private Integer version;

}
