package com.smc.controller.asset.bo;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName VirtualPoolBindHardwareBO
 * @description:
 * @author: C31909
 * @create: 2024-07-30 09:21
 * @Version 1.0
 **/
@Data
public class VirtualPoolBindHardwareBO {
    private String id;
    private String hardwareId;
    private String updatedBy;
    private Integer version;
}
