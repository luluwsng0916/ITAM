package com.smc.dataobject.asset;

import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * (AmsDept)实体类
 *
 * @author makejava
 * @since 2025-03-03 16:51:37
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AmsDept extends AbstractEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    private String deptCode;

    private String parentId;

    private String deptName;

    private String k3Code;

    private String fullName;

    private String unitLevel;

    private String status;

    private Boolean salesCustomized;

    private String companyCode;

    private String companyName;

    private String unitCode;


}

