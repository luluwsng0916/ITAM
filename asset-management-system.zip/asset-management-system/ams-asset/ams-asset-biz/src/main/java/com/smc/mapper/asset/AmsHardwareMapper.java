package com.smc.mapper.asset;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smc.dataobject.asset.AmsHardware;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 硬件
 *
 * @author C31909
 * @since 1.0.0 2024-07-10
 */
public interface AmsHardwareMapper extends BaseMapper<AmsHardware> {

    List<AmsHardware> selectForExport(@Param("name") String name, @Param("model") String model, @Param("lastSql") String lastSql,
                                      @Param("selectFields") String selectFields);

    void insertBatch(@Param("list") List<AmsHardware> list);

    List<AmsHardware> listBySearch(@Param("searchKey") String searchKey);

    List<String> findManagers();
}