package com.smc.controller.system.bo;

import lombok.Data;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/6
 * @description
 */
@Data
public class SystemDeleteBO {

    private String id;

    private String updatedBy;

    private Integer version;
}
