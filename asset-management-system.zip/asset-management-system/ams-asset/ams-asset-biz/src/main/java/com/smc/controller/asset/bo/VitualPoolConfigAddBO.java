package com.smc.controller.asset.bo;

import lombok.Data;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
@Data
public class VitualPoolConfigAddBO {

    private String poolChargePerson;

    /**
     * 创建人
     */
    private String operator;

}
