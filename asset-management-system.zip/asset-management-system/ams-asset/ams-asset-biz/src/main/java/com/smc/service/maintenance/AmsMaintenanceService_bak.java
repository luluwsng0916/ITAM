package com.smc.service.maintenance;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.maintenance.bo.MaintenanceBindHardwareBO_bak;
import com.smc.controller.maintenance.bo.MaintenanceDeleteBO_bak;
import com.smc.controller.maintenance.bo.MaintenanceEditBO_bak;
import com.smc.controller.maintenance.vo.MaintenanceVO_bak;
import com.smc.dataobject.maintenance.AmsMaintenance_bak;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
* @author C31909
* @description 针对表【ams_maintenance】的数据库操作Service
* @createDate 2024-08-01 09:00:18
*/
public interface AmsMaintenanceService_bak {

    ResultBody<PageInfo<MaintenanceVO_bak>> listByPage(PageRequest pageRequest);

    ResultBody<String> updateById(MaintenanceEditBO_bak model);

    ResultBody<String> save(AmsMaintenance_bak model);

    ResultBody<String> removeById(MaintenanceDeleteBO_bak model);

    ResultBody<String> bindAsset(MaintenanceBindHardwareBO_bak bo);

    ResultBody<String> importData(MultipartFile multipartFile, HttpServletRequest req);

    void exportData(PageRequest pageRequest, HttpServletResponse response);

    ResultBody<String> upload(List<MultipartFile> files, String id, Integer version, String updatedBy, Boolean removeAndSave)  ;

    Boolean isExistFilePath(Integer id);

    List<String> listAssetIdSelectBySearch(String searchKey);
}
