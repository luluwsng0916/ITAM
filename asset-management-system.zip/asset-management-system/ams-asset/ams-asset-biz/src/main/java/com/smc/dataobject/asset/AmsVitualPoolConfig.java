package com.smc.dataobject.asset;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
@TableName(value = "ams_vitualpoolconfig")
@Data
public class AmsVitualPoolConfig extends AbstractEntity implements Serializable {

    private static final long serialVersionUID = 423431893940698268L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.INPUT)
    private Long id;
    /**
     * 虚拟池担当
     */
    @TableField(value = "poolChargePerson")
    private String poolChargePerson;
    /**
     * 虚拟池ID
     */
    @TableField(value = "poolId")
    private String poolId;

}
