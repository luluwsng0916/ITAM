package com.smc.easyexcel.asset.listener;

import cn.hutool.json.JSONUtil;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.util.ListUtils;
import com.alibaba.fastjson.JSON;
import com.smc.controller.asset.dto.NetworkLineExcelDTO;
import com.smc.controller.asset.dto.VirtualMachineIDCExcelDTO;
import com.smc.service.asset.impl.EasyExcelNetworkLineServiceImpl;
import com.smc.service.asset.impl.EasyExcelVirtualMachineIDCServiceImpl;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/5
 * @description
 */
@Slf4j
public class ImportVirtualMachineIDCListener implements ReadListener<VirtualMachineIDCExcelDTO> {

    /**
     * 每隔5条存储数据库，实际使用中可以100条，然后清理list ，方便内存回收
     */
    private static final int BATCH_COUNT = 100;
    /**
     * 缓存的数据
     */
    private List<VirtualMachineIDCExcelDTO> cachedDataList = ListUtils.newArrayListWithExpectedSize(BATCH_COUNT);
    /**
     * 假设这个是一个DAO，当然有业务逻辑这个也可以是一个service。当然如果不用存储这个对象没用。
     */
    private EasyExcelVirtualMachineIDCServiceImpl easyExcelVirtualMachineIDCServiceImpl;

    public ImportVirtualMachineIDCListener() {
        easyExcelVirtualMachineIDCServiceImpl = new EasyExcelVirtualMachineIDCServiceImpl();
        easyExcelVirtualMachineIDCServiceImpl.getList().clear();
    }

    @SneakyThrows
    @Override
    public void invokeHead(Map<Integer, ReadCellData<?>> headMap, AnalysisContext context) {
        log.info("解析到一条头数据:{}", JSONUtil.toJsonStr(headMap));
        if (context.readRowHolder().getRowIndex() == 0) {
            String[] headList = {
                    "关联资产编码",
                    "VC显示名称",
                    "服务器名",
                    "系统名称/应用",
                    "IP地址",
                    "服务器操作系统",
                    "服务器类别",
                    "应用类别",
                    "用途",
                    "备份方式",
                    "启用RP4VM复制",
                    "有效性",
                    "服务器资源",
                    "服务器资源",
                    "服务器资源",
                    "域名",
                    "业务部门",
                    "业务担当",
                    "IT部小组",
                    "IT部担当",
                    "服务器创建时间",
                    "服务器创建人",
                    "备注"
            };
            for (int i = 0; i < headList.length; i++) {
                if (!headMap.get(i).getStringValue().equals(headList[i])) {
                    throw new Exception("excel表头异常");
                }
            }
        }
    }

    /**
     * 这个每一条数据解析都会来调用
     *
     * @param data    one row value. Is is same as {@link AnalysisContext#readRowHolder()}
     * @param context
     */
    @Override
    public void invoke(VirtualMachineIDCExcelDTO data, AnalysisContext context) {
        log.info("解析到一条数据:{}", JSON.toJSONString(data));
        cachedDataList.add(data);
        // 达到BATCH_COUNT了，需要去存储一次数据库，防止数据几万条数据在内存，容易OOM
        if (cachedDataList.size() >= BATCH_COUNT) {
            saveData();
            // 存储完成清理 list
            cachedDataList = ListUtils.newArrayListWithExpectedSize(BATCH_COUNT);
        }
    }

    /**
     * 所有数据解析完成了 都会来调用
     *
     * @param context
     */
    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        // 这里也要保存数据，确保最后遗留的数据也存储到数据库
        saveData();
        log.info("所有数据解析完成！");
    }

    /**
     * 加上存储数据库
     */
    private void saveData() {
        log.info("{}条数据，开始存储数据库！", cachedDataList.size());
        easyExcelVirtualMachineIDCServiceImpl.save(cachedDataList);
    }
}
