package com.smc.controller.system.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentFontStyle;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import lombok.Data;

import java.io.Serializable;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/23
 * @description
 */
@Data
@ColumnWidth(20)
@HeadFontStyle(fontHeightInPoints = 11)
@ContentFontStyle(fontHeightInPoints = 10)
public class SystemExcelDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 系统ID
     */
    @ExcelProperty(value = "系统ID")
    private String systemId;
    /**
     * 系统中文名
     */
    @ExcelProperty(value = "系统中文名")
    private String systemName;
    /**
     * 系统英文名
     */
    @ExcelProperty(value = "系统英文名")
    private String systemEngName;
    /**
     * 系统英文简称
     */
    @ExcelProperty(value = "系统英文简称")
    private String systemEngShortName;
    /**
     * 外购/自研发
     */
    @ExcelProperty(value = "外购/自研发")
    private String systemType;
    /**
     * 主要功能
     */
    @ExcelProperty(value = "主要功能")
    private String functional;
    /**
     * 上线时间
     */
    @ExcelProperty(value = "上线时间")
    private String goLiveTime;
    /**
     * 下线时间
     */
    @ExcelProperty(value = "下线时间")
    private String downtime;
    /**
     * 负责人
     */
    @ExcelProperty(value = "负责人")
    private String chargePerson;

    @ExcelProperty(value = "创建者")
    private String createdBy;

    @ExcelProperty(value = "创建时间")
    private String createdTime;

    @ExcelProperty(value = "更新者")
    private String updatedBy;

    @ExcelProperty(value = "更新时间")
    private String updatedTime;

}
