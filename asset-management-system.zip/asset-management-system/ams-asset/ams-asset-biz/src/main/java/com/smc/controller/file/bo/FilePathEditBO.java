package com.smc.controller.file.bo;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName FilePathEditBO
 * @description:
 * @author: C31909
 * @create: 2024-08-06 09:14
 * @Version 1.0
 **/
@Data
public class FilePathEditBO {
    private Integer id;
    private String remark;
    private String updatedBy;
    private Integer version;
}
