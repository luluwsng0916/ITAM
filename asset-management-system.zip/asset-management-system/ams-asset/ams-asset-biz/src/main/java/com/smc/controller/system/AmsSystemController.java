package com.smc.controller.system;

import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.system.bo.SystemAddBO;
import com.smc.controller.system.bo.SystemDeleteBO;
import com.smc.controller.system.bo.SystemEditBO;
import com.smc.service.system.AmsSystemService;
import com.smc.utils.WebUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/6
 * @description
 */
@CrossOrigin
@RestController
@RequestMapping("/system")
public class AmsSystemController {

    @Resource
    private AmsSystemService amsSystemService;

    @PostMapping("/list")
    public ResultBody<PageResult> page(@RequestBody PageRequest pageRequest) {
        PageResult res = amsSystemService.selectPage(pageRequest);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody SystemEditBO model) {
        String res = amsSystemService.editById(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody SystemAddBO model) {
        String res = amsSystemService.add(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody SystemDeleteBO model) {
        String res = amsSystemService.delete(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/export")
    public void export(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        amsSystemService.export(pageRequest, response);
    }

    @PostMapping("/importExcel")
    public ResultBody<String> importExcel(@RequestParam("multipartFile") MultipartFile file, HttpServletRequest request) {
        Map<String, String> res = amsSystemService.importExcel(file, request);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

}
