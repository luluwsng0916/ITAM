package com.smc.service.system.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.controller.system.bo.*;
import com.smc.dataobject.system.AmsService;
import com.smc.mapper.system.AmsServiceMapper;
import com.smc.mapstruct.AmsServiceMSMapper;
import com.smc.service.system.AmsServiceService;
import com.smc.utils.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/6
 * @description
 */
@Slf4j
@Service
public class AmsServiceServiceImpl extends ServiceImpl<AmsServiceMapper, AmsService> implements AmsServiceService {

    @Resource
    private AmsServiceMapper amsServiceMapper;
    @Resource
    private QueryServiceClient queryServiceClient;

    @Override
    public PageResult selectPage(PageRequest pageRequest) {

        String contractNo = pageRequest.getParamValue("contractNo");
        String serviceName = pageRequest.getParamValue("serviceName");

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        map.put("contractNo", contractNo);
        map.put("serviceName", serviceName);
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsService> list = amsServiceMapper.findAll(map);
        list.forEach(o -> {
            o.setStartDate(DateUtil.formatDateToDay(o.getStartDate()));
            o.setEndDate(DateUtil.formatDateToDay(o.getEndDate()));
        });
        PageInfo pageInfo = new PageInfo(list);
        PageResult pageResult = new PageResult();
        pageResult.setTotalSize(pageInfo.getTotal());
        pageResult.setTotalPages(pageInfo.getPages());
        pageResult.setContent(pageInfo.getList());
        return pageResult;
    }

    @Override
    public String editById(ServiceEditBO model) {
        AmsService amsService = AmsServiceMSMapper.INSTANCE.toAmsServiceEdit(model);
        amsService.setUpdatedBy(model.getOperator());
        amsService.setUpdatedTime(DateUtil.createTimeToDate());
        amsServiceMapper.updateById(amsService);
        return "success";
    }

    @Override
    public String add(ServiceAddBO model) {
        AmsService amsService = AmsServiceMSMapper.INSTANCE.toAmsServiceAdd(model);
        amsService.setCreatedBy(model.getOperator());
        amsService.setUpdatedBy(model.getOperator());
        amsServiceMapper.insert(amsService);
        return "success";
    }

    @Override
    public String delete(ServiceDeleteBO model) {
        AmsService amsService = AmsServiceMSMapper.INSTANCE.toAmsServiceDel(model);
        amsService.setDeleteMark(DeleteMarkConstant.DELETED);
        amsService.setUpdatedBy(model.getUpdatedBy());
        amsService.setUpdatedTime(DateUtil.createTimeToDate());
        amsServiceMapper.updateById(amsService);
        return "success";
    }

}
