package com.smc.mapstruct;

import com.smc.controller.asset.bo.SoftwareAddBO;
import com.smc.controller.asset.bo.SoftwareDeleteBO;
import com.smc.controller.asset.bo.SoftwareEditBO;
import com.smc.controller.asset.dto.SoftwareExcelDTO;
import com.smc.dataobject.asset.AmsSoftware;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/8/26
 * @description
 */

@Mapper
public interface AmsSoftwareMSMapper {

    AmsSoftwareMSMapper INSTANCE = Mappers.getMapper(AmsSoftwareMSMapper.class);

    AmsSoftware toAmsSoftwareAdd(SoftwareAddBO softwareAddBO);

    AmsSoftware toAmsSoftwareEdit(SoftwareEditBO model);

    AmsSoftware toAmsSoftDel(SoftwareDeleteBO model);

    AmsSoftware toAmsSoftwareImport(SoftwareExcelDTO excel);
}
