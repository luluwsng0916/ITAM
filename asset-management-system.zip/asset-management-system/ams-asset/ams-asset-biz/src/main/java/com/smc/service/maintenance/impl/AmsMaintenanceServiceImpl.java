package com.smc.service.maintenance.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.smc.api.mdm.CodeGenApi;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.constants.PatternConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.controller.maintenance.bo.MaintenanceAddBO;
import com.smc.controller.maintenance.bo.MaintenanceDeleteBO;
import com.smc.controller.maintenance.bo.MaintenanceEditBO;
import com.smc.controller.maintenance.dto.MaintenanceExcelDTO;
import com.smc.dataobject.maintenance.AmsMaintenance;
import com.smc.easyexcel.maintenance.listener.ImportMaintenanceListener;
import com.smc.enums.mdm.TableCodeRule;
import com.smc.mapper.maintenance.AmsMaintenanceMapper;
import com.smc.mapstruct.AmsMaintenanceMSMapper;
import com.smc.service.maintenance.AmsMaintenanceService;
import com.smc.utils.DateUtil;
import com.smc.utils.StringUtils;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/20
 * @description
 */
@Slf4j
@Service
public class AmsMaintenanceServiceImpl extends ServiceImpl<AmsMaintenanceMapper, AmsMaintenance> implements AmsMaintenanceService {

    @Resource
    private AmsMaintenanceMapper amsMaintenanceMapper;
    @Resource
    private QueryServiceClient queryServiceClient;
    @Resource
    private EasyExcelMaintenanceServiceImpl easyExcelMaintenanceServiceImpl;
    @Resource
    private CodeGenApi codeGenApi;
    @Resource
    private AmsMaintenanceService amsMaintenanceService;

    @Override
    public PageResult selectPage(PageRequest pageRequest) {

        String maintenanceObj = pageRequest.getParamValue("maintenanceObj");

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        map.put("maintenanceObj", maintenanceObj);
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsMaintenance> list = amsMaintenanceMapper.findAll(map);
        list.forEach(o -> {
            o.setStartDate(DateUtil.formatDateToDay(o.getStartDate()));
            o.setEndDate(DateUtil.formatDateToDay(o.getEndDate()));
        });
        PageInfo pageInfo = new PageInfo(list);
        PageResult pageResult = new PageResult();
        pageResult.setTotalSize(pageInfo.getTotal());
        pageResult.setTotalPages(pageInfo.getPages());
        pageResult.setContent(pageInfo.getList());
        return pageResult;
    }

    @Override
    public String editById(MaintenanceEditBO model) {
        AmsMaintenance amsMaintenance = AmsMaintenanceMSMapper.INSTANCE.toMaintenanceEdit(model);
        amsMaintenance.setUpdatedBy(model.getOperator());
        amsMaintenance.setUpdatedTime(DateUtil.createTimeToDate());
        amsMaintenanceMapper.updateById(amsMaintenance);
        return "success";
    }

    @Override
    public String add(MaintenanceAddBO model) {
        AmsMaintenance amsMaintenance = AmsMaintenanceMSMapper.INSTANCE.toMaintenanceAdd(model);
        amsMaintenance.setCreatedBy(model.getOperator());
        amsMaintenance.setUpdatedBy(model.getOperator());
        LambdaQueryWrapper<AmsMaintenance> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AmsMaintenance::getContractNo, amsMaintenance.getContractNo());
        if (amsMaintenanceService.count(queryWrapper) != 0) {
            return "数据重复";
        }
        amsMaintenance.setId(codeGenApi.getCodeByTableName(TableCodeRule.MAINTENANCE));
        amsMaintenanceMapper.insert(amsMaintenance);
        return "success";
    }

    @Override
    public String delete(MaintenanceDeleteBO model) {
        AmsMaintenance amsMaintenance = AmsMaintenanceMSMapper.INSTANCE.toMaintenanceDel(model);
        amsMaintenance.setDeleteMark(DeleteMarkConstant.DELETED);
        amsMaintenance.setUpdatedBy(model.getUpdatedBy());
        amsMaintenance.setUpdatedTime(DateUtil.createTimeToDate());
        amsMaintenanceMapper.updateById(amsMaintenance);
        return "success";
    }

    @SneakyThrows
    @Override
    public void export(PageRequest pageRequest, HttpServletResponse response) {

        String maintenanceObj = pageRequest.getParamValue("maintenanceObj");
        String isFormWork = pageRequest.getParamValue("isFormWork");

        if ("模板".equals(isFormWork)) {
            Set<String> excludeColumnFiledNames = new HashSet<>();
            excludeColumnFiledNames.add("id");
            excludeColumnFiledNames.add("createdBy");
            excludeColumnFiledNames.add("createdTime");
            excludeColumnFiledNames.add("updatedBy");
            excludeColumnFiledNames.add("updatedTime");
            EasyExcel.write(response.getOutputStream(), MaintenanceExcelDTO.class)
                    .excludeColumnFiledNames(excludeColumnFiledNames)
                    .sheet("sheet1")
                    .doWrite(new ArrayList<MaintenanceExcelDTO>());
            return;
        }
        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        map.put("maintenanceObj", maintenanceObj);
        //导出数据实体
        List<AmsMaintenance> list = amsMaintenanceMapper.findAll(map);
        EasyExcel.write(response.getOutputStream(), MaintenanceExcelDTO.class)
                .sheet("sheet1")
                .doWrite(list);
    }

    @Override
    public Map<String, String> importExcel(MultipartFile file, HttpServletRequest request) {

        HashMap<String, String> map = new HashMap<>();
        String operator = request.getParameter("userName");

        List<MaintenanceExcelDTO> sourceExcelDataList;
        sourceExcelDataList = getImportExcelData(file);
        if (CollectionUtil.isEmpty(sourceExcelDataList)) {
            map.put("0", "导入模板错误");
            return map;
        }

        List<String> maintenanceListCheck = findMaintenanceListCheck();
        try {
            String regex = PatternConstant.DATE_YYYY_MM_DD;
            String regex1 = PatternConstant.DATE_YYYY_MM_DD_SLASH;
            for (int i = 0, len = sourceExcelDataList.size(); i < len; i++) {
                MaintenanceExcelDTO dto = sourceExcelDataList.get(i);
                dto.setId(codeGenApi.getCodeByTableName(TableCodeRule.MAINTENANCE));
                dto.setCreatedBy(operator);
                dto.setCreatedTime(DateUtil.createTimeToString());
                dto.setUpdatedBy(operator);
                dto.setUpdatedTime(DateUtil.createTimeToString());
                if (StringUtils.isEmpty(dto.getContractNo())) {
                    map.put("2", "\'" + dto.getMaintenanceObj() + "\' 的合同编号不可为空");
                    return map;
                }
                if (StringUtils.isEmpty(dto.getMaintenanceObj())) {
                    map.put("2", "\'" + dto.getMaintenanceObj() + "\' 维保对象不可为空");
                    return map;
                }
                if (StringUtils.isEmpty(dto.getStartDate())) {
                    map.put("3", "\'" + dto.getMaintenanceObj() + "\' 的起始日期不可为空");
                    return map;
                }
                if (StringUtils.isEmpty(dto.getEndDate())) {
                    map.put("4", "\'" + dto.getMaintenanceObj() + "\' 的终止日期不可为空");
                    return map;
                }
//                if (!maintenanceListCheck.contains(dto.getMaintenanceObj())) {
//                    map.put("5", "\'" + dto.getMaintenanceObj() + "\' 维保对象非法");
//                    return map;
//                }
                if (!dto.getStartDate().matches(regex1) && !dto.getStartDate().matches(regex)) {
                    map.put("6", "\'" + dto.getMaintenanceObj() + "\' 的起始日期非法，请使用 \'yyyy-MM-dd或yyyy/MM/dd\' 格式");
                    return map;
                }
                if (!dto.getEndDate().matches(regex1) && !dto.getEndDate().matches(regex)) {
                    map.put("7", "\'" + dto.getMaintenanceObj() + "\' 的终止日期非法，请使用 \'yyyy-MM-dd或yyyy/MM/dd\' 格式");
                    return map;
                }
//                if (!dto.getApplyContent().equals("有") && !dto.getApplyContent().equals("无")) {
//                    map.put("8", "\'" + dto.getMaintenanceObj() + "\' 的禀议书主旨及内容非法，数值仅为 \'有/无\'");
//                    return map;
//                }
                LambdaQueryWrapper<AmsMaintenance> queryWrapper = new LambdaQueryWrapper<>();
                queryWrapper.eq(AmsMaintenance::getContractNo, dto.getContractNo());
                if (amsMaintenanceService.count(queryWrapper) != 0) {
                    map.put("8", "\'" + dto.getMaintenanceObj() + "\' 的合同编号重复");
                    return map;
                }
                try {
                    Double.parseDouble(dto.getTaxInclusiveAmount());
                } catch (Exception e) {
                    map.put("9", "\'" + dto.getMaintenanceObj() + "\' 的含税金额非法，请使用小数或整数类型");
                    return map;
                }
            }
        } catch (Exception e) {
            map.put("0", "导入模板错误");
            return map;
        }

        Lists.partition(sourceExcelDataList, 50).forEach(list -> amsMaintenanceMapper.insertBatch(list));
        map.put("1", "success");
        return map;
    }


    /**
     * 获取导入的excel数据
     *
     * @param multipartFile
     * @return
     */
    @SneakyThrows
    private List<MaintenanceExcelDTO> getImportExcelData(MultipartFile multipartFile) {
        if (multipartFile != null) {
            // 导入excel
            EasyExcel.read(multipartFile.getInputStream(), MaintenanceExcelDTO.class,
                    new ImportMaintenanceListener()).sheet().doRead();
            // 获取excel导入的所有基础数据
            return easyExcelMaintenanceServiceImpl.getAllImportExcelData();
        }
        return null;
    }

    @Override
    public List<String> findMaintenanceList(String data) {
        return amsMaintenanceMapper.findMaintenanceList(data);
    }

    private List<String> findMaintenanceListCheck() {
        return amsMaintenanceMapper.findMaintenanceListCheck();
    }

    @Override
    public PageResult getMaintenanceExpiration(PageRequest pageRequest) {
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsMaintenance> list = amsMaintenanceMapper.getMaintenanceExpiration();
        PageInfo pageInfo = new PageInfo(list);
        PageResult pageResult = new PageResult();
        pageResult.setTotalSize(pageInfo.getTotal());
        pageResult.setTotalPages(pageInfo.getPages());
        pageResult.setContent(pageInfo.getList());
        return pageResult;
    }

}
