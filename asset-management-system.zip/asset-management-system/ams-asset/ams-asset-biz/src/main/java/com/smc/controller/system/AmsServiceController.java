package com.smc.controller.system;

import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.system.bo.*;
import com.smc.service.system.AmsServiceService;
import com.smc.utils.WebUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/6
 * @description
 */
@CrossOrigin
@RestController
@RequestMapping("/service")
public class AmsServiceController {

    @Resource
    private AmsServiceService amsServiceService;

    @PostMapping("/list")
    public ResultBody<PageResult> page(@RequestBody PageRequest pageRequest) {
        PageResult res = amsServiceService.selectPage(pageRequest);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody ServiceEditBO model) {
        String res = amsServiceService.editById(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody ServiceAddBO model) {
        String res = amsServiceService.add(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody ServiceDeleteBO model) {
        String res = amsServiceService.delete(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

}
