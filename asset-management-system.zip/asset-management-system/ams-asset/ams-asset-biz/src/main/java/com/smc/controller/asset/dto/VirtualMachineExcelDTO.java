package com.smc.controller.asset.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName VirtualMachineExcelBO
 * @description:
 * @author: C31909
 * @create: 2024-08-02 16:16
 * @Version 1.0
 **/
@Data
public class VirtualMachineExcelDTO {

    @ExcelProperty(value = "服务器ID")
    @ColumnWidth(16)
    private String id;

    @ExcelProperty(value = "资产ID")
    @ColumnWidth(16)
    private String hardwareId;

    @ExcelProperty(value = "服务器名称")
    @ColumnWidth(16)
    private String name;

    @ExcelProperty(value = "IP")
    @ColumnWidth(20)
    private String ip;

    @ExcelProperty(value = "CPU（核）")
    @ColumnWidth(16)
    private String cpu;

    @ExcelProperty(value = "内存（G）")
    @ColumnWidth(16)
    private String memory;

    @ExcelProperty(value = "硬盘（G）")
    @ColumnWidth(16)
    private String hardDisk;

    @ExcelProperty(value = "应用系统")
    @ColumnWidth(12)
    private String appliedSystem;

    @ExcelProperty(value = "应用类别")
    @ColumnWidth(12)
    private String appliedCategory;

    @ExcelProperty(value = "用途")
    @ColumnWidth(12)
    private String appliedEnv;

    @ExcelProperty(value = "操作系统")
    @ColumnWidth(15)
    private String operatingSystem;

    @ExcelProperty(value = "数据库")
    @ColumnWidth(12)
    private String sqlCategory;

    // @ExcelProperty(value = "应用软件（版权）")
    // @ColumnWidth(20)
    // private String applicationLicense;

    @ExcelProperty(value = "是否使用中")
    @ColumnWidth(16)
    private String activity;

    @ExcelProperty(value = "业务部门")
    @ColumnWidth(12)
    private String deptCode;

    @ExcelProperty(value = "业务担当")
    @ColumnWidth(12)
    private String manager;

    @ExcelProperty(value = "IT部小组")
    @ColumnWidth(16)
    private String manageGroup;

    @ExcelProperty(value = "IT部担当")
    @ColumnWidth(16)
    private String itManager;

    @ExcelProperty(value = "备注")
    @ColumnWidth(20)
    private String remark;

    @ExcelProperty(value = "创建者")
    @ColumnWidth(12)
    private String createdBy;

    @ExcelProperty(value = "创建时间")
    @ColumnWidth(25)
    public String createdTime;

    @ExcelProperty(value = "更新者")
    @ColumnWidth(12)
    private String updatedBy;

    @ExcelProperty(value = "更新时间")
    @ColumnWidth(25)
    public String updatedTime;
}
