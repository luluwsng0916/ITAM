package com.smc.controller.file.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.smc.convert.easyexcel.DateConverter;
import lombok.Data;

import java.util.Date;

/**
 * @program: asset-management-system
 * @ClassName FilePathVO
 * @description:
 * @author: C31909
 * @create: 2024-08-06 08:16
 * @Version 1.0
 **/
@Data
public class FilePathVO {
    /**
     * 内部主键
     */
    private Integer id;

    /**
     * 文件名称
     */
    private String fileName;

    /**
     * 文件路径
     */
    private String filePath;

    /**
     * 文件占用空间
     */
    private String fileSize;

    /**
     * 文件类型
     */
    private String fileType;

    /**
     * 有效性
     */
    private String activity;

    /**
     * 备注
     */
    private String remark;

    @ExcelIgnore
    private Integer version;


    @ExcelProperty(value = "创建者")
    private String createdBy;
    /**
     * 创建时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "创建时间", converter = DateConverter.class)
    @ColumnWidth(25)
    public Date createdTime;

    @ExcelProperty(value = "更新者")
    private String updatedBy;

    /**
     * 修改时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "更新时间", converter = DateConverter.class)
    @ColumnWidth(25)
    public Date updatedTime;
}
