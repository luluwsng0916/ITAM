package com.smc.mapper.asset;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smc.controller.asset.dto.NetworkLineExcelDTO;
import com.smc.dataobject.asset.AmsNetworkLine;

import java.util.List;
import java.util.Map;

/**
 *
 * @author C31908
 * @date 2024-08-26
 * @version 1.0.0
 * @description
 */
public interface AmsNetworkLineMapper extends BaseMapper<AmsNetworkLine> {

    List<AmsNetworkLine> findAll(Map<String, Object> map);

    List<String> findSuppliers();

    void insertBatch(List<NetworkLineExcelDTO> list);

    List<String> findUniversalCodeBycDesc(String desc);
}
