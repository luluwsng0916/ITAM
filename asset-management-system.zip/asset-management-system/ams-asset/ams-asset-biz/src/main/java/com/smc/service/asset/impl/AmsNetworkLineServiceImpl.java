package com.smc.service.asset.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.smc.api.mdm.CodeGenApi;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.constants.PatternConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.controller.asset.bo.NetworkLineAddBO;
import com.smc.controller.asset.bo.NetworkLineDeleteBO;
import com.smc.controller.asset.bo.NetworkLineEditBO;
import com.smc.controller.asset.dto.NetworkLineExcelDTO;
import com.smc.dataobject.asset.AmsNetworkLine;
import com.smc.easyexcel.asset.listener.ImportNetworkLineListener;
import com.smc.enums.asset.AssetConstant;
import com.smc.enums.mdm.TableCodeRule;
import com.smc.mapper.asset.AmsNetworkLineMapper;
import com.smc.mapstruct.AmsNetworkLineMSMapper;
import com.smc.service.asset.AmsNetworkLineService;
import com.smc.utils.DateUtil;
import com.smc.utils.StringUtils;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * @author C31908
 * @version 1.0.0
 * @date 2024-08-26
 * @description
 */

@Slf4j
@Service
public class AmsNetworkLineServiceImpl
        extends ServiceImpl<AmsNetworkLineMapper, AmsNetworkLine>
        implements AmsNetworkLineService {

    @Resource
    private AmsNetworkLineMapper amsNetworkLineMapper;
    @Resource
    private QueryServiceClient queryServiceClient;
    @Resource
    private AmsNetworkLineService amsNetworkLineService;
    @Resource
    private EasyExcelNetworkLineServiceImpl easyExcelNetworkLineServiceImpl;
    @Resource
    private CodeGenApi codeGenApi;

    /**
     * 分页查询
     *
     * @param pageRequest
     * @return
     */
    @Override
    public PageResult selectPage(PageRequest pageRequest) {

        String networkLineName = pageRequest.getParamValue("networkLineName");

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        map.put("networkLineName", networkLineName);
        map.put("sortParam", "sort");
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsNetworkLine> list = amsNetworkLineMapper.findAll(map);
        list.forEach(o -> {
            if (!StringUtils.isEmpty(o.getStartDate())) {
                o.setStartDate(DateUtil.formatDateToDay(o.getStartDate()));
            }
            if (!StringUtils.isEmpty(o.getEndDate())) {
                o.setEndDate(DateUtil.formatDateToDay(o.getEndDate()));
            }
        });
        PageInfo pageInfo = new PageInfo(list);
        PageResult pageResult = new PageResult();
        pageResult.setTotalSize(pageInfo.getTotal());
        pageResult.setTotalPages(pageInfo.getPages());
        pageResult.setContent(pageInfo.getList());
        return pageResult;
    }

    /**
     * 编辑
     *
     * @param model
     * @return
     */
    @Override
    public String editById(NetworkLineEditBO model) {
        AmsNetworkLine amsNetworkLine = AmsNetworkLineMSMapper.INSTANCE.toAmsNetworkLineEdit(model);
        amsNetworkLine.setUpdatedBy(model.getOperator());
        amsNetworkLine.setUpdatedTime(DateUtil.createTimeToDate());
        amsNetworkLineMapper.updateById(amsNetworkLine);
        return "success";
    }

    /**
     * 新增
     *
     * @param model
     * @return
     */
    @Override
    public String add(NetworkLineAddBO model) {
        AmsNetworkLine amsNetworkLine = AmsNetworkLineMSMapper.INSTANCE.toAmsNetworkLineAdd(model);
//        amsNetworkLine.setNetworkLineId(codeGenApi.getCodeByTableName(TableCodeRule.NETWORKLINE));
//        String checkRes = checkAddModel(model);
//        if (checkRes.length() != 0) {
//            return checkRes;
//        }
        Integer idCount = amsNetworkLineMapper.selectCount(new LambdaQueryWrapper<AmsNetworkLine>()
                .eq(AmsNetworkLine::getNetworkLineName, model.getNetworkLineName()));
        if(idCount!= 0) {
            return "网络专线名称已存在，请重新添加";
        }
        amsNetworkLine.setCreatedBy(model.getOperator());
        amsNetworkLine.setUpdatedBy(model.getOperator());
        amsNetworkLineMapper.insert(amsNetworkLine);
        return "success";
    }

    /**
     * @description: 校验新增数据
     * @author: C31908
     * @date: 2025/8/11
     **/
    private String checkAddModel(NetworkLineAddBO model) {
        String checkRes = "";
        // 网络专线编号唯一
        Integer idCount = amsNetworkLineMapper.selectCount(new LambdaQueryWrapper<AmsNetworkLine>()
                .eq(AmsNetworkLine::getNetworkLineId, model.getNetworkLineId()));
        if (idCount != 0) {
            checkRes = "此网络编号已存在";
        }
        return checkRes;
    }

    /**
     * 删除
     *
     * @param model
     * @return
     */
    @Override
    public String delete(NetworkLineDeleteBO model) {
        AmsNetworkLine amsNetworkLine = AmsNetworkLineMSMapper.INSTANCE.toAmsNetworkLineDel(model);
        amsNetworkLine.setDeleteMark(DeleteMarkConstant.DELETED);
        amsNetworkLine.setUpdatedBy(model.getUpdatedBy());
        amsNetworkLine.setUpdatedTime(DateUtil.createTimeToDate());
        amsNetworkLineMapper.updateById(amsNetworkLine);
        return "success";
    }

    /**
     * 获取供应商列表
     *
     * @return
     */
    @Override
    public List<String> findSuppliers() {
        return amsNetworkLineMapper.findSuppliers();
    }

    /**
     * 导出
     *
     * @param pageRequest
     * @param response
     */
    @SneakyThrows
    @Override
    public void export(PageRequest pageRequest, HttpServletResponse response) {

        String isFormWork = pageRequest.getParamValue("isFormWork");

        if ("模板".equals(isFormWork)) {
            Set<String> excludeColumnFiledNames = new HashSet<>();
            excludeColumnFiledNames.add("createdBy");
            excludeColumnFiledNames.add("createdTime");
            excludeColumnFiledNames.add("updatedBy");
            excludeColumnFiledNames.add("updatedTime");
            EasyExcel.write(response.getOutputStream(), NetworkLineExcelDTO.class)
                    .excludeColumnFiledNames(excludeColumnFiledNames)
                    .sheet("sheet1")
                    .doWrite(new ArrayList<NetworkLineExcelDTO>());
            return;
        }

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        //导出数据实体
        List<AmsNetworkLine> list = amsNetworkLineMapper.findAll(map);
        EasyExcel.write(response.getOutputStream(), NetworkLineExcelDTO.class)
                .sheet("sheet1")
                .doWrite(list);
    }

    /**
     * 导入
     *
     * @param file
     * @param request
     * @return
     */
    @Override
    public Map<String, String> importExcel(MultipartFile file, HttpServletRequest request) {

        HashMap<String, String> map = new HashMap<>();
        String operator = request.getParameter("userName");

        List<NetworkLineExcelDTO> sourceExcelDataList = null;
        try {
            sourceExcelDataList = getImportExcelData(file);
        } catch (Exception e) {
            map.put("10", "导入模板错误");
            return map;
        }
        if (CollectionUtil.isEmpty(sourceExcelDataList)) {
            easyExcelNetworkLineServiceImpl.list.clear();
            map.put("0", "导入模板为空");
            return map;
        }
        List<String> desc = findUniversalCodeBycDesc("专线类别");
        String regex = PatternConstant.DATE_YYYY_MM_DD;
        String regex1 = PatternConstant.DATE_YYYY_MM_DD_SLASH;
        try {
            for (int i = 0, len = sourceExcelDataList.size(); i < len; i++) {
                NetworkLineExcelDTO o = sourceExcelDataList.get(i);
                if (StringUtils.isEmpty(o.getSort())) {
                    map.put("8", "存在空的序号，序号不可为空");
                    return map;
                }
//                Integer idCount = amsNetworkLineMapper.selectCount(new LambdaQueryWrapper<AmsNetworkLine>()
//                        .eq(AmsNetworkLine::getNetworkLineId, o.getNetworkLineId()));
//                if (idCount != 0) {
//                    map.put("8", "\'" + o.getNetworkLineId() + "\'网络专线编号已存在");
//                    return map;
//                }
                Integer idCount = amsNetworkLineMapper.selectCount(new LambdaQueryWrapper<AmsNetworkLine>()
                        .eq(AmsNetworkLine::getNetworkLineName, o.getNetworkLineName()));
                if(idCount!= 0) {
                    map.put("7", "网络专线名称已存在，请检查后重试");
                    return map;
                }
                if (StringUtils.isEmpty(o.getNetworkLineName())) {
                    map.put("2", "存在空的网络专线名称，网络专线名称不可为空");
                    return map;
                }
                if (!desc.contains(o.getNetworkLineType())) {
                    map.put("3", "\'" + o.getNetworkLineName() + "\' 的专线类别非法");
                    return map;
                }
                //校验协议金额
                try {
                    Double.parseDouble(o.getAgreementMoney());
                } catch (Exception e) {
                    map.put("4", "\'" + o.getNetworkLineName() + "\' 的协议金额非法");
                    return map;
                }
                //起始日期、终止日期校验
                if (!StringUtils.isEmpty(o.getStartDate())) {
                    if (!o.getStartDate().matches(regex1) && !o.getStartDate().matches(regex)) {
                        map.put("5", "\'" + o.getNetworkLineName() + "\' 的起始日期非法，请使用 \'yyyy-MM-dd或yyyy/MM/dd\' 格式");
                        return map;
                    }
                }
                if (!StringUtils.isEmpty(o.getEndDate())) {
                    if (!o.getEndDate().matches(regex1) && !o.getEndDate().matches(regex)) {
                        map.put("6", "\'" + o.getNetworkLineName() + "\' 的终止日期非法，请使用 \'yyyy-MM-dd或yyyy/MM/dd\' 格式");
                        return map;
                    }
                }
//                o.setNetworkLineId(codeGenApi.getCodeByTableName(TableCodeRule.NETWORKLINE));
                if(StringUtils.isBlank(o.getSort())) {
                    o.setSort("9999");
                }
                o.setCreatedBy(operator);
                o.setCreatedTime(DateUtil.createTimeToString());
                o.setUpdatedBy(operator);
                o.setUpdatedTime(DateUtil.createTimeToString());
            }
        } catch (Exception e) {
            map.put("0", "导入模板错误");
            return map;
        }
        Lists.partition(sourceExcelDataList, 50).forEach(list -> amsNetworkLineMapper.insertBatch(list));
        map.put("1", "success");
        return map;
    }

    /**
     * 获取通用类别系列数据
     *
     * @param desc
     * @return
     */
    public List<String> findUniversalCodeBycDesc(String desc) {
        return amsNetworkLineMapper.findUniversalCodeBycDesc(desc);
    }

    /**
     * 获取导入的excel数据
     *
     * @param multipartFile
     * @return
     */
    @SneakyThrows
    private List<NetworkLineExcelDTO> getImportExcelData(MultipartFile multipartFile) {
        if (multipartFile != null) {
            // 导入excel
            EasyExcel.read(multipartFile.getInputStream(), NetworkLineExcelDTO.class,
                    new ImportNetworkLineListener()).sheet().doRead();
            // 获取excel导入的所有基础数据
            return easyExcelNetworkLineServiceImpl.getAllImportExcelData();
        }
        return null;
    }


}
