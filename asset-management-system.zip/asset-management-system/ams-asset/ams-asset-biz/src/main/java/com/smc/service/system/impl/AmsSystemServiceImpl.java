package com.smc.service.system.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.smc.api.mdm.CodeGenApi;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.constants.PatternConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.controller.system.bo.SystemAddBO;
import com.smc.controller.system.bo.SystemDeleteBO;
import com.smc.controller.system.bo.SystemEditBO;
import com.smc.controller.system.dto.SystemExcelDTO;
import com.smc.dataobject.system.AmsSystem;
import com.smc.easyexcel.system.listener.ImportSystemListener;
import com.smc.enums.mdm.TableCodeRule;
import com.smc.mapper.system.AmsSystemMapper;
import com.smc.mapstruct.AmsSystemMSMapper;
import com.smc.service.system.AmsSystemService;
import com.smc.utils.DateUtil;
import com.smc.utils.StringUtils;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/6
 * @description
 */
@Slf4j
@Service
public class AmsSystemServiceImpl extends ServiceImpl<AmsSystemMapper, AmsSystem> implements AmsSystemService {

    @Resource
    private AmsSystemMapper amsSystemMapper;
    @Resource
    private QueryServiceClient queryServiceClient;
    @Resource
    private AmsSystemService amsSystemService;
    @Resource
    private CodeGenApi codeGenApi;
    @Resource
    private EasyExcelSystemServiceImpl easyExcelSystemService;

    @Override
    public PageResult selectPage(PageRequest pageRequest) {

        String systemId = pageRequest.getParamValue("systemId");
        String systemName = pageRequest.getParamValue("systemName");

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        map.put("systemId", systemId);
        map.put("systemName", systemName);
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsSystem> list = amsSystemMapper.findAll(map);
        list.forEach(l -> {
            if (!StringUtils.isEmpty(l.getGoLiveTime()) && !l.getGoLiveTime().equals("-")) {
                String[] split = l.getGoLiveTime().split("-");
                l.setGoLiveTime(split[0] + "." + split[1]);
            }
            if (!StringUtils.isEmpty(l.getDowntime()) && !l.getDowntime().equals("-")) {
                String[] split = l.getDowntime().split("-");
                l.setDowntime(split[0] + "." + split[1]);
            }
        });
        PageInfo pageInfo = new PageInfo(list);
        PageResult pageResult = new PageResult();
        pageResult.setTotalSize(pageInfo.getTotal());
        pageResult.setTotalPages(pageInfo.getPages());
        pageResult.setContent(pageInfo.getList());
        return pageResult;
    }

    @Override
    public String editById(SystemEditBO model) {
        if (StringUtils.isNotBlank(model.getGoLiveTime())) {
            if (model.getGoLiveTime().contains(".")) {
                model.setGoLiveTime(model.getGoLiveTime().replace(".", "-"));
            }
        }
        if (StringUtils.isNotBlank(model.getDowntime())) {
            if (model.getDowntime().contains(".")) {
                model.setDowntime(model.getDowntime().replace(".", "-"));
            }
        }
        AmsSystem amsSystem = AmsSystemMSMapper.INSTANCE.toAmsSystemEdit(model);
        amsSystem.setUpdatedBy(model.getOperator());
        amsSystem.setUpdatedTime(DateUtil.createTimeToDate());
        amsSystemMapper.updateById(amsSystem);
        return "success";
    }

    @Override
    public String add(SystemAddBO model) {
        QueryWrapper<AmsSystem> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AmsSystem::getSystemName, model.getSystemName())
                .eq(AmsSystem::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        int count = amsSystemService.count(queryWrapper);
        if (count != 0) {
            return "数据重复";
        }
        AmsSystem amsSystem = AmsSystemMSMapper.INSTANCE.toAmsSystemAdd(model);
        amsSystem.setSystemId(codeGenApi.getCodeByTableName(TableCodeRule.SYSTEM));
        amsSystem.setCreatedBy(model.getOperator());
        amsSystem.setUpdatedBy(model.getOperator());
        amsSystemMapper.insert(amsSystem);
        return "success";
    }

    @Override
    public String delete(SystemDeleteBO model) {
        AmsSystem amsSystem = AmsSystemMSMapper.INSTANCE.toAmsSystemDel(model);
        amsSystem.setDeleteMark(DeleteMarkConstant.DELETED);
        amsSystem.setUpdatedBy(model.getUpdatedBy());
        amsSystem.setUpdatedTime(DateUtil.createTimeToDate());
        amsSystemMapper.updateById(amsSystem);
        return "success";
    }

    @SneakyThrows
    @Override
    public void export(PageRequest pageRequest, HttpServletResponse response) {

        String systemId = pageRequest.getParamValue("systemId");
        String systemName = pageRequest.getParamValue("systemName");
        String isFormWork = pageRequest.getParamValue("isFormWork");

        if ("模板".equals(isFormWork)) {
            Set<String> excludeColumnFiledNames = new HashSet<>();
            excludeColumnFiledNames.add("systemId");
            excludeColumnFiledNames.add("createdBy");
            excludeColumnFiledNames.add("createdTime");
            excludeColumnFiledNames.add("updatedBy");
            excludeColumnFiledNames.add("updatedTime");
            EasyExcel.write(response.getOutputStream(), SystemExcelDTO.class)
                    .excludeColumnFiledNames(excludeColumnFiledNames)
                    .sheet("sheet1")
                    .doWrite(new ArrayList<SystemExcelDTO>());
            return;
        }
        Set<String> excludeColumnFiledNames = new HashSet<>();
        excludeColumnFiledNames.add("id");
        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        map.put("systemId", systemId);
        map.put("systemName", systemName);
        //导出数据实体
        List<AmsSystem> list = amsSystemMapper.findAll(map);
        EasyExcel.write(response.getOutputStream(), SystemExcelDTO.class)
                .excludeColumnFiledNames(excludeColumnFiledNames)
                .sheet("sheet1")
                .doWrite(list);
    }

    @Override
    public Map<String, String> importExcel(MultipartFile file, HttpServletRequest request) {

        HashMap<String, String> map = new HashMap<>();
        String operator = request.getParameter("userName");

        List<SystemExcelDTO> sourceExcelDataList;
        sourceExcelDataList = getImportExcelData(file);
        if (CollectionUtil.isEmpty(sourceExcelDataList)) {
            map.put("0", "导入模板错误");
            return map;
        }
        try {
            String regex = PatternConstant.DATE_YYYY_MM_DD;
            for (int i = 0, len = sourceExcelDataList.size(); i < len; i++) {
                SystemExcelDTO dto = sourceExcelDataList.get(i);
                dto.setSystemId(codeGenApi.getCodeByTableName(TableCodeRule.SYSTEM));
                dto.setCreatedBy(operator);
                dto.setCreatedTime(DateUtil.createTimeToString());
                dto.setUpdatedBy(operator);
                dto.setUpdatedTime(DateUtil.createTimeToString());
                if (StringUtils.isEmpty(dto.getSystemName())) {
                    map.put("2", "系统中文名不可为空");
                    return map;
                }
//                if (!dto.getSystemType().equals("外购") && !dto.getSystemType().equals("自研发")) {
//                    map.put("3", "\'" + dto.getSystemName() + "\' 的外购/自研发非法，数值仅为 \'外购/自研发\'");
//                    return map;
//                }
                if (!StringUtils.isEmpty(dto.getGoLiveTime())) {
                    if (!dto.getGoLiveTime().matches(regex) && !dto.getGoLiveTime().equals("-")) {
                        map.put("4", "\'" + dto.getSystemName() + "\' 的上线时间非法，请使用 \'yyyy-MM-dd' 格式 或 \'-\' ");
                        return map;
                    }
                }
                if (!StringUtils.isEmpty(dto.getDowntime())) {
                    if (!dto.getDowntime().matches(regex) && !dto.getDowntime().equals("-")) {
                        map.put("5", "\'" + dto.getSystemName() + "\' 的下线时间非法，请使用 \'yyyy-MM-dd' 格式 或 \'-\'");
                        return map;
                    }
                }
            }
        } catch (Exception e) {
            map.put("0", "导入模板错误");
            return map;
        }

        Lists.partition(sourceExcelDataList, 50).forEach(list -> amsSystemMapper.insertBatch(list));
        map.put("1", "success");
        return map;
    }


    /**
     * 获取导入的excel数据
     *
     * @param multipartFile
     * @return
     */
    @SneakyThrows
    private List<SystemExcelDTO> getImportExcelData(MultipartFile multipartFile) {
        if (multipartFile != null) {
            // 导入excel
            EasyExcel.read(multipartFile.getInputStream(), SystemExcelDTO.class,
                    new ImportSystemListener()).sheet().doRead();
            // 获取excel导入的所有基础数据
            return easyExcelSystemService.getAllImportExcelData();
        }
        return null;
    }

}
