package com.smc.dataobject.file;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * 
 * @author C31909
 * @TableName ams_file_paths
 */
@TableName(value ="ams_file_path")
@Data
public class AmsFilePath extends AbstractEntity implements Serializable {
    /**
     * 内部主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 文件名称
     */
    @TableField(value = "fileName")
    private String fileName;

    /**
     * 文件路径
     */
    @TableField(value = "filePath")
    private String filePath;

    /**
     * 文件占用空间
     */
    @TableField(value = "fileSize")
    private String fileSize;

    /**
     * 文件类型
     */
    @TableField(value = "fileType")
    private String fileType;

    /**
     * 有效性
     */
    @TableField(value = "activity")
    private Boolean activity;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}