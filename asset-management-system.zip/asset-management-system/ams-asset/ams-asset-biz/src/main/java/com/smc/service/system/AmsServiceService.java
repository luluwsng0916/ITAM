package com.smc.service.system;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.controller.system.bo.*;
import com.smc.dataobject.system.AmsService;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/6
 * @description
 */
public interface AmsServiceService extends IService<AmsService> {

    PageResult selectPage(PageRequest pageRequest);

    String editById(ServiceEditBO model);

    String add(ServiceAddBO model);

    String delete(ServiceDeleteBO model);

}
