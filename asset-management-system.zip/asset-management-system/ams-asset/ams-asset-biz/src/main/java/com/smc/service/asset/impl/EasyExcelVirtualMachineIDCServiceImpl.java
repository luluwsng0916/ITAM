package com.smc.service.asset.impl;

import com.smc.controller.asset.dto.VirtualMachineIDCExcelDTO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/5
 * @description
 */
@Service
public class EasyExcelVirtualMachineIDCServiceImpl {

    static List<VirtualMachineIDCExcelDTO> list = new ArrayList<>();
    /**
     * 分批导入的数据拼接到一起
     *
     * @param
     * @return
     */
    public static List<VirtualMachineIDCExcelDTO> getAllImportExcelData() {
        return list;
    }

    public void save(List<VirtualMachineIDCExcelDTO> cachedDataList) {
        list.addAll(cachedDataList);
    }

    /**
     * 创建一个构造方法 用于list.clean()
     *
     * @return
     */
    public List<VirtualMachineIDCExcelDTO> getList() {
        return list;
    }
}
