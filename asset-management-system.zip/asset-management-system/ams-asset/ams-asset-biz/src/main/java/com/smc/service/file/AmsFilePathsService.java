package com.smc.service.file;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.file.bo.FilePathCleanBO;
import com.smc.controller.file.bo.FilePathDeleteBO;
import com.smc.controller.file.bo.FilePathEditBO;
import com.smc.controller.file.vo.FilePathVO;
import com.smc.dataobject.file.AmsFilePath;

import java.util.List;

/**
 * @author C31909
 * @description 针对表【ams_file_paths】的数据库操作Service
 * @createDate 2024-08-01 09:00:18
 */
public interface AmsFilePathsService {

    List<AmsFilePath> getFilePathByIdList(List<Integer> fileIdList);

    ResultBody<Integer> saveFilePath(List<String> filePathList, List<String> fileNameList, List<Long> fileSizeList,
                                    List<String> fileTypeList, String updatedBy);

    AmsFilePath getById(Integer fileId);

    void updateById(AmsFilePath amsFilePath);

    ResultBody<PageInfo<FilePathVO>> page(PageRequest pageRequest);

    ResultBody<String> delete(FilePathDeleteBO model);

    ResultBody<String> clean(FilePathCleanBO model);

    ResultBody<String> editById(FilePathEditBO model);
}
