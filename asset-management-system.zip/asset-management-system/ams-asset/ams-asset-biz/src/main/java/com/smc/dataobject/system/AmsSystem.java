package com.smc.dataobject.system;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/6
 * @description
 */
@TableName(value = "ams_system")
@Data
public class AmsSystem extends AbstractEntity implements Serializable {

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.INPUT)
    private String id;
    /**
     * 系统ID
     */
    @TableField(value = "systemId")
    private String systemId;
    /**
     * 系统中文名
     */
    @TableField(value = "systemName")
    private String systemName;
    /**
     * 系统英文名
     */
    @TableField(value = "systemEngName")
    private String systemEngName;
    /**
     * 系统英文简称
     */
    @TableField(value = "systemEngShortName")
    private String systemEngShortName;
    /**
     * 系统类别（外购/自研发）
     */
    @TableField(value = "systemType")
    private String systemType;
    /**
     * 主要功能
     */
    @TableField(value = "functional")
    private String functional;
    /**
     * 上线时间
     */
    @TableField(value = "goLiveTime")
    private String goLiveTime;
    /**
     * 下线时间
     */
    @TableField(value = "downtime")
    private String downtime;
    /**
     * 负责人
     */
    @TableField(value = "chargePerson")
    private String chargePerson;

}
