package com.smc.controller.asset.bo;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName VirtualPoolEditBO
 * @description:
 * @author: C31909
 * @create: 2024-07-30 09:07
 * @Version 1.0
 **/
@Data
public class VirtualPoolEditBO {
    private String id;
    private String hardwareId;
    private String virtualMachineId;
    private String manager;
    private Boolean activity;
    private String remark;
    private Integer version;
    private String updatedBy;
}
