package com.smc.service.asset.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.smc.api.mdm.CodeGenApi;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.controller.asset.bo.*;
import com.smc.dataobject.asset.AmsVitualPoolConfig;
import com.smc.enums.mdm.TableCodeRule;
import com.smc.mapper.asset.AmsVitualPoolConfigMapper;
import com.smc.mapstruct.AmsVitualPoolConfigMSMapper;
import com.smc.service.asset.AmsVitualPoolConfigService;
import com.smc.utils.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
@Slf4j
@Service
public class AmsVitualPoolConfigServiceImpl extends ServiceImpl<AmsVitualPoolConfigMapper, AmsVitualPoolConfig> implements AmsVitualPoolConfigService {

    @Resource
    private AmsVitualPoolConfigMapper amsVitualPoolConfigMapper;
    @Resource
    private QueryServiceClient queryServiceClient;
    @Resource
    private AmsVitualPoolConfigService amsVitualPoolConfigService;
    @Resource
    private CodeGenApi codeGenApi;

    @Override
    public PageResult selectPage(PageRequest pageRequest) {

        String poolChargePerson = pageRequest.getParamValue("poolChargePerson");

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        map.put("poolChargePerson", poolChargePerson);
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsVitualPoolConfig> list = amsVitualPoolConfigMapper.findAll(map);
        PageInfo pageInfo = new PageInfo(list);
        PageResult pageResult = new PageResult();
        pageResult.setTotalSize(pageInfo.getTotal());
        pageResult.setTotalPages(pageInfo.getPages());
        pageResult.setContent(pageInfo.getList());
        return pageResult;
    }

    @Override
    public String editById(VitualPoolConfigEditBO model) {
        QueryWrapper<AmsVitualPoolConfig> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AmsVitualPoolConfig::getPoolChargePerson, model.getPoolChargePerson())
                .eq(AmsVitualPoolConfig::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        int count = amsVitualPoolConfigService.count(queryWrapper);
        if (count != 0) {
            return "数据重复";
        }
        AmsVitualPoolConfig amsVitualPoolConfig = AmsVitualPoolConfigMSMapper.INSTANCE.toVitualPoolConfigEdit(model);
        amsVitualPoolConfig.setUpdatedBy(model.getOperator());
        amsVitualPoolConfig.setUpdatedTime(DateUtil.createTimeToDate());
        amsVitualPoolConfigMapper.updateById(amsVitualPoolConfig);
        return "success";
    }

    @Override
    public String add(VitualPoolConfigAddBO model) {
        QueryWrapper<AmsVitualPoolConfig> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AmsVitualPoolConfig::getPoolChargePerson, model.getPoolChargePerson())
                .eq(AmsVitualPoolConfig::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        int count = amsVitualPoolConfigService.count(queryWrapper);
        if (count != 0) {
            return "数据重复";
        }
        AmsVitualPoolConfig amsVitualPoolConfig = AmsVitualPoolConfigMSMapper.INSTANCE.toVitualPoolConfigAdd(model);
        amsVitualPoolConfig.setPoolId(codeGenApi.getCodeByTableName(TableCodeRule.VIRTUAL_POOL));
        amsVitualPoolConfig.setCreatedBy(model.getOperator());
        amsVitualPoolConfig.setUpdatedBy(model.getOperator());
        amsVitualPoolConfigMapper.insert(amsVitualPoolConfig);
        return "success";
    }

    @Override
    public String delete(VitualPoolConfigDeleteBO model) {
        AmsVitualPoolConfig amsVitualPoolConfig = AmsVitualPoolConfigMSMapper.INSTANCE.toVitualPoolConfigDel(model);
        amsVitualPoolConfig.setDeleteMark(DeleteMarkConstant.DELETED);
        amsVitualPoolConfig.setUpdatedBy(model.getUpdatedBy());
        amsVitualPoolConfig.setUpdatedTime(DateUtil.createTimeToDate());
        amsVitualPoolConfigMapper.updateById(amsVitualPoolConfig);
        return "success";
    }

}
