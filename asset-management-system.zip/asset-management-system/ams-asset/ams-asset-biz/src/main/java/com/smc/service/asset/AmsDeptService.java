package com.smc.service.asset;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smc.dataobject.asset.AmsDept;

import java.util.List;

public interface AmsDeptService extends IService<AmsDept> {

    /**
     * 根据部门代码获取部门列表 格式  [code]名称
     * @param deptCode
     * @return
     */
    List<String> getDeptListByDeptCode(String deptCode);
}
