package com.smc.service.system;

import com.baomidou.mybatisplus.extension.service.IService;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.controller.system.bo.SystemAddBO;
import com.smc.controller.system.bo.SystemDeleteBO;
import com.smc.controller.system.bo.SystemEditBO;
import com.smc.dataobject.asset.AmsVitualPoolConfig;
import com.smc.dataobject.system.AmsSystem;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/6
 * @description
 */
public interface AmsSystemService extends IService<AmsSystem> {

    PageResult selectPage(PageRequest pageRequest);

    String editById(SystemEditBO model);

    String add(SystemAddBO model);

    String delete(SystemDeleteBO model);

    void export(PageRequest pageRequest, HttpServletResponse response);

    Map<String, String> importExcel(MultipartFile file, HttpServletRequest request);

}
