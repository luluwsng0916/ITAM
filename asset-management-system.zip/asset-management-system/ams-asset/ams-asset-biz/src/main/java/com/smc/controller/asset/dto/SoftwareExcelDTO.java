package com.smc.controller.asset.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentFontStyle;
import com.alibaba.excel.annotation.write.style.ContentStyle;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.enums.poi.HorizontalAlignmentEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/14
 * @description
 */
@Data
@ColumnWidth(20)
@HeadFontStyle(fontHeightInPoints = 11)
@ContentFontStyle(fontHeightInPoints = 10)
public class SoftwareExcelDTO {

    /**
     * 软件编码
     */
    @ExcelProperty(value = "软件编码")
    private String id;
    /**
     * 供应商
     */
    @ExcelProperty(value = "供应商")
    private String supplierName;
    /**
     * 软件名称
     */
    @ExcelProperty(value = "软件名称")
    private String name;
    /**
     * 数量
     */
    @ExcelProperty(value = "数量")
    private String qty;
    /**
     * 总金额（含税）
     */
    @ExcelProperty(value = "总金额(含税)")
    private String totalAmountTax;
    /**
     * 禀议号
     */
    @ExcelProperty(value = "禀议号")
    private String applyNo;
    /**
     * 订单编号
     */
    @ExcelProperty(value = "订单编号")
    private String orderNo;
    /**
     * 公司别
     */
    @ExcelProperty(value = "公司别")
    private String plantName;
    /**
     * 软件版本
     */
    @ExcelProperty(value = "软件版本")
    private String softVersion;
    /**
     * 软件许可证
     */
    @ExcelProperty(value = "软件许可证")
    private String licenseKey;
    /**
     * 到期时间
     */
    @ExcelProperty(value = "到期时间")
//    @DateTimeFormat("yyyy-MM-dd")
//    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    @ContentStyle(horizontalAlignment = HorizontalAlignmentEnum.LEFT, dataFormat = 49)
    private String deadLine;
    /**
     * 有效性
     */
    @ExcelProperty(value = "有效性")
    private String activity;
    /**
     * 担当
     */
    @ExcelProperty(value = "担当")
    private String charger;
    /**
     * 备注
     */
    @ExcelProperty(value = "备注")
    private String remark;

    @ExcelProperty(value = "创建者")
    private String createdBy;

    @ExcelProperty(value = "创建时间")
    private String createdTime;

    @ExcelProperty(value = "更新者")
    private String updatedBy;

    @ExcelProperty(value = "更新时间")
    private String updatedTime;
}
