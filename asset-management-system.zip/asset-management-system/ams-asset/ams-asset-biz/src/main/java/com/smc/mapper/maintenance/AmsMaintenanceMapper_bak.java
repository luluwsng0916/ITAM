package com.smc.mapper.maintenance;

import com.smc.dataobject.maintenance.AmsMaintenance_bak;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
* @author C31909
* @description 针对表【ams_maintenance】的数据库操作Mapper
* @createDate 2024-08-01 09:00:18
* @Entity com.smc.dataobject.maintenance.AmsMaintenance
*/
public interface AmsMaintenanceMapper_bak extends BaseMapper<AmsMaintenance_bak> {

    List<String> findHardwordIdList(String searchKey);

    List<String> findSoftIdList(String searchKey);
}




