package com.smc.service.asset;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.asset.bo.VirtualBindHardwareBO;
import com.smc.controller.asset.bo.VirtualMachineDeleteBO;
import com.smc.controller.asset.bo.VirtualMachineEditBO;
import com.smc.controller.asset.bo.VirtualMachineSaveBO;
import com.smc.controller.asset.vo.VirtualMachineVO;
import com.smc.dataobject.asset.AmsVirtualMachine;
import org.springframework.web.multipart.MultipartFile;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 服务器虚拟池
 *
 * @author C31909 
 * @since 1.0.0 2024-07-26
 */
public interface AmsVirtualMachineService {

    ResultBody<PageInfo<VirtualMachineVO>> page(PageRequest pageRequest);

    ResultBody<String> editById(VirtualMachineEditBO model);

    ResultBody<String> add(VirtualMachineSaveBO model);

    ResultBody<String> importData(MultipartFile multipartFile, HttpServletRequest req);

    void exportData(PageRequest pageRequest, HttpServletResponse response) throws IOException;

    ResultBody<String> delete(VirtualMachineDeleteBO bo);

    ResultBody<String> bindHardware(VirtualBindHardwareBO bo);

    List<AmsVirtualMachine> getByHardwareId(String hardwareId);

    List<String> findSystemName(String data);
}