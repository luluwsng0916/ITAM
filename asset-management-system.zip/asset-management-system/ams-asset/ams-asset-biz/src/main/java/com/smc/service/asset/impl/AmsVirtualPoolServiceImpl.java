package com.smc.service.asset.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.smc.api.mdm.CodeGenApi;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.ActivityConstant;
import com.smc.common.constants.CommonConstants;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.asset.bo.VirtualPoolBindHardwareBO;
import com.smc.controller.asset.bo.VirtualPoolDeleteBO;
import com.smc.controller.asset.bo.VirtualPoolEditBO;
import com.smc.controller.asset.dto.VirtualPoolConditionDTO;
import com.smc.controller.asset.dto.VirtualPoolExcelDTO;
import com.smc.controller.asset.vo.VirtualPoolVO;
import com.smc.dataobject.asset.AmsVirtualPool;
import com.smc.easyexcel.asset.listener.ImportVirtualPoolListener;
import com.smc.enums.asset.AssetConstant;
import com.smc.mapper.asset.AmsVirtualPoolMapper;
import com.smc.service.asset.AmsVirtualPoolService;
import com.smc.utils.DateUtil;
import com.smc.utils.StringUtils;
import com.smc.utils.WebUtils;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * @author C31908
 * @description
 */
@Service
public class AmsVirtualPoolServiceImpl implements AmsVirtualPoolService {

    @Resource
    private AmsVirtualPoolMapper amsVirtualPoolMapper;

    @Resource
    private QueryServiceClient queryServiceClient;

    @Resource
    private CodeGenApi codeGenApi;

    @Resource
    private EasyExceVirtualPoolServiceImpl easyExceVirtualPoolServiceImpl;

    @Override
    public ResultBody<PageInfo<VirtualPoolVO>> page(PageRequest pageRequest) {
        // 从分页请求中获取资产名称和型号参数
        String hardwareId = pageRequest.getParamValue("hardwareId");
        String virtualMachineId = pageRequest.getParamValue("virtualMachineId");
        String activity = pageRequest.getParamValue("activity");

        // 构建查询条件，根据资产名称和型号进行模糊查询，且只查询未删除的硬件
        LambdaQueryWrapper<AmsVirtualPool> wrapper = new LambdaQueryWrapper<>();
        if (StringUtils.isNotBlank(hardwareId)) {
            wrapper.like(AmsVirtualPool::getHardwareId, hardwareId);
        }
        if (StringUtils.isNotBlank(virtualMachineId)) {
            wrapper.like(AmsVirtualPool::getVirtualMachineId, virtualMachineId);
        }
        wrapper.eq(StringUtils.isNotBlank(activity), AmsVirtualPool::getActivity, Boolean.parseBoolean(activity));
        wrapper.eq(AmsVirtualPool::getDeleteMark, DeleteMarkConstant.NOT_DELETED);

        // 通过queryServiceClient获取额外的查询条件和排序条件
        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        StringBuilder stringBuilder = new StringBuilder();
        if (map.get("conditionParams") != null) {
            stringBuilder.append(map.get("conditionParams"));
        }
        if (map.get("sortParam") != null) {
            stringBuilder.append(" ORDER BY ").append(map.get("sortParam"));
        } else {
            stringBuilder.append(" ORDER BY ").append(" id ");
        }
        wrapper.last(stringBuilder.toString());
        // 初始化分页插件，进行分页查询
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsVirtualPool> list = amsVirtualPoolMapper.selectList(wrapper);
        // 为什么：原因是自己封装的vo把PageInfo原有的属性破坏了
        // 解决方案：https://blog.csdn.net/qq_39765635/article/details/87694796
        PageInfo<AmsVirtualPool> pageInfo = PageInfo.of(list);
        // 如果查询结果为空，直接返回空的分页信息
        if (CollectionUtil.isEmpty(list)) {
            return ResultBody.ok().data(pageInfo);
        }
        // 构建分页信息并返回
        PageInfo<VirtualPoolVO> pageInfoRes = new PageInfo<>(toConvertVO(list));
        pageInfoRes.setPageNum(pageInfo.getPageNum());
        pageInfoRes.setPageSize(pageInfo.getPageSize());
        pageInfoRes.setTotal(pageInfo.getTotal());
        pageInfoRes.setPages(pageInfo.getPages());
        return ResultBody.ok().data(pageInfoRes);
    }

    private List<VirtualPoolVO> toConvertVO(List<AmsVirtualPool> list) {
        List<VirtualPoolVO> virtualPoolVOS = new ArrayList<>(list.size());
        for (AmsVirtualPool amsVirtualPool : list) {
            VirtualPoolVO virtualPoolVO = new VirtualPoolVO();
            virtualPoolVO.setId(amsVirtualPool.getId());
            virtualPoolVO.setHardwareId(amsVirtualPool.getHardwareId());
            virtualPoolVO.setVirtualMachineId(amsVirtualPool.getVirtualMachineId());
            virtualPoolVO.setManager(amsVirtualPool.getManager());
            virtualPoolVO.setRemark(amsVirtualPool.getRemark());
            virtualPoolVO.setActivity(amsVirtualPool.getActivity() ? ActivityConstant.ACTIVITY_STR : ActivityConstant.INACTIVITY_STR);
            virtualPoolVO.setVersion(amsVirtualPool.getVersion());
            virtualPoolVO.setCreatedBy(amsVirtualPool.getCreatedBy());
            virtualPoolVO.setCreatedTime(amsVirtualPool.getCreatedTime());
            virtualPoolVO.setUpdatedBy(amsVirtualPool.getUpdatedBy());
            virtualPoolVO.setUpdatedTime(amsVirtualPool.getUpdatedTime());
            virtualPoolVOS.add(virtualPoolVO);
        }
        return virtualPoolVOS;
    }

    @Override
    public ResultBody<String> editById(VirtualPoolEditBO model) {
        AmsVirtualPool amsVirtualPool = new AmsVirtualPool();
        amsVirtualPool.setId(model.getId());
        amsVirtualPool.setHardwareId(model.getHardwareId());
        amsVirtualPool.setVirtualMachineId(model.getVirtualMachineId());
        amsVirtualPool.setManager(model.getManager());
        amsVirtualPool.setActivity(model.getActivity());
        amsVirtualPool.setRemark(model.getRemark());
        amsVirtualPool.setVersion(model.getVersion());
        amsVirtualPool.setUpdatedBy(model.getUpdatedBy());
        amsVirtualPool.setUpdatedTime(new Date());
        amsVirtualPoolMapper.updateById(amsVirtualPool);
        return ResultBody.ok();
    }

    public String validateManger(String hardwareId, String virtualMachineId, String manager) {
        int count = amsVirtualPoolMapper.validateManger(hardwareId, virtualMachineId, manager);
        if (count == 0) {
            return "资产管理担当非法";
        }
        return "success";
    }

    @Override
    public ResultBody<String> add(AmsVirtualPool model) {
        if (validateManger(model.getHardwareId(), model.getVirtualMachineId(), model.getManager()).equals("资产管理担当非法")) {
            String res = "资产管理担当非法";
            return ResultBody.ok().data(res).path(WebUtils.getUri());
        }
        int count = amsVirtualPoolMapper.checkRepeat(model.getHardwareId(), model.getVirtualMachineId(), model.getManager());
        if (count != 0) {
            String res = "资产管理担当配置重复";
            return ResultBody.ok().data(res).path(WebUtils.getUri());
        }
        model.setVersion(CommonConstants.DEFAULT_VERSION);
        model.setCreatedTime(new Date());
        model.setUpdatedTime(new Date());
        model.setDeleteMark(DeleteMarkConstant.NOT_DELETED);
        amsVirtualPoolMapper.insert(model);
        return ResultBody.ok().data("success").path(WebUtils.getUri());
    }

    @Override
    public ResultBody<String> delete(VirtualPoolDeleteBO model) {
        AmsVirtualPool amsVirtualPool = new AmsVirtualPool();
        amsVirtualPool.setId(model.getId());
        amsVirtualPool.setVersion(model.getVersion());
        amsVirtualPool.setUpdatedBy(model.getUpdatedBy());
        amsVirtualPool.setUpdatedTime(new Date());
        amsVirtualPool.setDeleteMark(DeleteMarkConstant.DELETED);
        amsVirtualPoolMapper.updateById(amsVirtualPool);
        return ResultBody.ok();
    }

    @Override
    public ResultBody<String> bindHardware(VirtualPoolBindHardwareBO bo) {
        AmsVirtualPool amsVirtualPool = new AmsVirtualPool();
        amsVirtualPool.setId(bo.getId());
        amsVirtualPool.setHardwareId(bo.getHardwareId());
        amsVirtualPool.setVersion(bo.getVersion());
        amsVirtualPool.setUpdatedBy(bo.getUpdatedBy());
        amsVirtualPool.setUpdatedTime(new Date());
        amsVirtualPoolMapper.updateById(amsVirtualPool);
        return ResultBody.ok();
    }

    /**
     * 导出
     *
     * @param pageRequest
     * @param response
     */
    @SneakyThrows
    @Override
    public void export(PageRequest pageRequest, HttpServletResponse response) {

        String isFormWork = pageRequest.getParamValue("isFormWork");

        if ("模板".equals(isFormWork)) {
            Set<String> excludeColumnFiledNames = new HashSet<>();
            excludeColumnFiledNames.add("createdBy");
            excludeColumnFiledNames.add("createdTime");
            excludeColumnFiledNames.add("updatedBy");
            excludeColumnFiledNames.add("updatedTime");
            EasyExcel.write(response.getOutputStream(), VirtualPoolExcelDTO.class)
                    .excludeColumnFiledNames(excludeColumnFiledNames)
                    .sheet("sheet1")
                    .doWrite(new ArrayList<VirtualPoolExcelDTO>());
            return;
        }

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        if (StringUtils.isNotBlank((String) map.get("activity"))) {
            if (map.get("activity").equals(AssetConstant.ACTIVITYFLAG_FLAG)) {
                map.put("activity", "1");
            }
            if (map.get("activity").equals(AssetConstant.UNACTIVITYFLAG_FLAG)) {
                map.put("activity", "0");
            }
        }
        ArrayList<VirtualPoolExcelDTO> virtualPoolExcelDTOList = new ArrayList<>();
        //导出数据实体
        List<AmsVirtualPool> list = amsVirtualPoolMapper.findAll(map);
        list.forEach(o -> {
            VirtualPoolExcelDTO dto = new VirtualPoolExcelDTO();
            dto.setHardwareId(o.getHardwareId());
            dto.setVirtualMachineId(o.getVirtualMachineId());
            dto.setManager(o.getManager());
            dto.setActivity(o.getActivity() ? AssetConstant.ACTIVITYFLAG_STR : AssetConstant.UNACTIVITYFLAG_STR);
            dto.setRemark(o.getRemark());
            dto.setCreatedBy(o.getCreatedBy());
            dto.setCreatedTime(cn.hutool.core.date.DateUtil.format(o.getCreatedTime(), DatePattern.NORM_DATETIME_FORMAT));
            dto.setUpdatedBy(o.getUpdatedBy());
            dto.setUpdatedTime(cn.hutool.core.date.DateUtil.format(o.getUpdatedTime(), DatePattern.NORM_DATETIME_FORMAT));
            virtualPoolExcelDTOList.add(dto);
        });
        EasyExcel.write(response.getOutputStream(), VirtualPoolExcelDTO.class)
                .sheet("sheet1")
                .doWrite(virtualPoolExcelDTOList);
    }

    /**
     * 导入
     *
     * @param file
     * @param request
     * @return
     */
    @Override
    public String importExcel(MultipartFile file, HttpServletRequest request) {

        String operator = request.getParameter("userName");

        List<VirtualPoolExcelDTO> sourceExcelDataList;
        sourceExcelDataList = getImportExcelData(file);
        if (CollectionUtil.isEmpty(sourceExcelDataList)) {
            return "导入模板错误";
        }

        try {
            for (int i = 0, len = sourceExcelDataList.size(); i < len; i++) {
                VirtualPoolExcelDTO dto = sourceExcelDataList.get(i);
                if (!dto.getActivity().equals(AssetConstant.ACTIVITYFLAG_STR) && !dto.getActivity().equals(AssetConstant.UNACTIVITYFLAG_STR)) {
                    return "有效性非法";
                }
                int count = amsVirtualPoolMapper.checkRepeat(dto.getHardwareId(), dto.getVirtualMachineId(), dto.getManager());
                if (count != 0) {
                    sourceExcelDataList.remove(i);
                    len--;
                    i--;
                    continue;
                }
                if (validateManger(dto.getHardwareId(), dto.getVirtualMachineId(), dto.getManager()).equals("资产管理担当非法")) {
                    return "资产管理担当非法";
                }
                dto.setActivity(dto.getActivity().equals(AssetConstant.ACTIVITYFLAG_STR) ? AssetConstant.ACTIVITYFLAG_NUM : AssetConstant.UNACTIVITYFLAG_NUM);
                dto.setCreatedBy(operator);
                dto.setCreatedTime(DateUtil.createTimeToString());
                dto.setUpdatedBy(operator);
                dto.setUpdatedTime(DateUtil.createTimeToString());
            }
        } catch (Exception e) {
            return "导入模板错误";
        }

        Lists.partition(sourceExcelDataList, 50).forEach(list -> amsVirtualPoolMapper.insertBatch(list));
        return "success";
    }


    /**
     * 获取导入的excel数据
     *
     * @param multipartFile
     * @return
     */
    @SneakyThrows
    private List<VirtualPoolExcelDTO> getImportExcelData(MultipartFile multipartFile) {

        // 导入excel
        EasyExcel.read(multipartFile.getInputStream(), VirtualPoolExcelDTO.class,
                new ImportVirtualPoolListener()).sheet().doRead();

        // 获取excel导入的所有基础数据
        return easyExceVirtualPoolServiceImpl.getAllImportExcelData();

    }

    @Override
    public List<String> findHardwareId(VirtualPoolConditionDTO virtualPoolConditionDTO) {
        return amsVirtualPoolMapper.findHardwareId(virtualPoolConditionDTO);
    }

    @Override
    public List<String> findVirtualMachineId(VirtualPoolConditionDTO virtualPoolConditionDTO) {
        return amsVirtualPoolMapper.findVirtualMachineId(virtualPoolConditionDTO);
    }

    @Override
    public List<String> findManager(String data) {
        return amsVirtualPoolMapper.findManager(data);
    }

    @Override
    public List<String> findHardwareIdByManager(String manager) {
        return amsVirtualPoolMapper.findHardwareIdByManager(manager);
    }

    @Override
    public List<String> findVirtualMachineIdByHardwareId(String hardwareId) {
        return amsVirtualPoolMapper.findVirtualMachineIdByHardwareId(hardwareId);
    }
}




