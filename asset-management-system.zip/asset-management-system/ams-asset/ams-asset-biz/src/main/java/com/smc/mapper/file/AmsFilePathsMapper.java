package com.smc.mapper.file;

import com.smc.dataobject.file.AmsFilePath;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author C31909
* @description 针对表【ams_file_paths】的数据库操作Mapper
* @createDate 2024-08-01 09:00:18
* @Entity generator.domain.AmsFilePaths
*/
public interface AmsFilePathsMapper extends BaseMapper<AmsFilePath> {

}




