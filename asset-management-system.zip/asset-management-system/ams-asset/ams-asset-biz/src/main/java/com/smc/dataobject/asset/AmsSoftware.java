package com.smc.dataobject.asset;

import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * (AmsSoftware)实体类
 *
 * @author makejava
 * @since 2025-04-24 13:06:40
 */
@TableName("ams_software")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AmsSoftware extends AbstractEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 内部主键
     */
    @TableId(value = "id", type = IdType.INPUT)
    private String id;
    /**
     * 供应商
     */
    private String supplierName;
    /**
     * 软件名称
     */
    private String name;
    /**
     * 数量
     */
    private String qty;
    /**
     * 总金额（含税）
     */
    private String totalAmountTax;
    /**
     * 禀议号
     */
    private String applyNo;
    /**
     * 订单编号
     */
    private String orderNo;
    /**
     * 公司别
     */
    private String plantName;
    /**
     * 软件版本
     */
    private String softVersion;
    /**
     * 软件许可证
     */
    private String licenseKey;
    /**
     * 到期时间
     */
//    @DateTimeFormat("yyyy-MM-dd")
//    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    private String deadLine;
    /**
     * 有效性
     */
    private String activity;
    /**
     * 担当
     */
    private String charger;
    /**
     * 备注
     */
    private String remark;


}

