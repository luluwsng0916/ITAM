package com.smc.controller.asset.bo;

import lombok.Data;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
@Data
public class VitualPoolConfigDeleteBO {

    private String id;

    private String updatedBy;

    private Integer version;

}
