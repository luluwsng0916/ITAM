package com.smc.dataobject.asset;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;

/**
 * 服务器虚拟池
 *
 * @author C31909
 * @since 1.0.0 2024-07-26
 */
@Data
@TableName("ams_virtual_machine")
public class AmsVirtualMachine extends AbstractEntity {
    /**
     * 内部编号
     */
    @TableId(value = "id", type = IdType.INPUT)
    @TableField(value = "id")
    private String id;

    /**
     * 硬件资产主键
     */
    @TableField(value = "hardwareId")
    private String hardwareId;

    /**
     * 虚拟机名称
     */
    @TableField(value = "name")
    private String name;

    /**
     * IP
     */
    @TableField(value = "ip")
    private String ip;

    /**
     * CPU核心数
     */
    @TableField(value = "cpu")
    private String cpu;

    /**
     * 内存空间MB
     */
    @TableField(value = "memory")
    private String memory;

    /**
     * 硬盘空间GB
     */
    @TableField(value = "hardDisk")
    private String hardDisk;

    /**
     * 应用系统
     */
    @TableField(value = "appliedSystem")
    private String appliedSystem;

    /**
     * 应用类别，通用代码
     */
    @TableField(value = "appliedCategory")
    private Integer appliedCategory;

    /**
     * 用途，通用代码
     */
    @TableField(value = "appliedEnv")
    private Integer appliedEnv;

    /**
     * 操作系统，通用代码
     */
    @TableField(value = "operatingSystem")
    private Integer operatingSystem;

    /**
     * 数据库，通用代码
     */
    @TableField(value = "sqlCategory")
    private Integer sqlCategory;

    /**
     * 使用部门
     */
    @TableField(value = "deptCode")
    private String deptCode;

    /**
     * 管理担当
     */
    @TableField(value = "manager")
    private String manager;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

    /**
     * 是否使用
     */
    @TableField(value = "activity")
    private String activity;

    /**
     * 管理组别
     */
    @TableField(value = "manageGroup")
    private Integer manageGroup;

    /**
     * IT部担当
     */
    private String itManager;

}