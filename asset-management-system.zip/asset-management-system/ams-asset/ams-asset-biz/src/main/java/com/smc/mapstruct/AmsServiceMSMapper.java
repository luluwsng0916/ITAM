package com.smc.mapstruct;

import com.smc.controller.system.bo.ServiceAddBO;
import com.smc.controller.system.bo.ServiceDeleteBO;
import com.smc.controller.system.bo.ServiceEditBO;
import com.smc.dataobject.system.AmsService;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
@Mapper
public interface AmsServiceMSMapper {

    AmsServiceMSMapper INSTANCE = Mappers.getMapper(AmsServiceMSMapper.class);

    @Mapping(source = "operator", target = "createdBy")
    AmsService toAmsServiceAdd(ServiceAddBO serviceAddBO);

    @Mappings({
            @Mapping(source = "operator", target = "updatedBy"),
            @Mapping(source = "version", target = "version")
    })
    AmsService toAmsServiceEdit(ServiceEditBO serviceEditBO);

    @Mappings({
            @Mapping(source = "id", target = "id"),
            @Mapping(source = "updatedBy", target = "updatedBy"),
            @Mapping(source = "version", target = "version")
    })
    AmsService toAmsServiceDel(ServiceDeleteBO serviceDeleteBO);

}
