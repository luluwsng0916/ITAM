package com.smc.controller.asset.bo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @program: asset-management-system
 * @ClassName HardwareEditBO
 * @description:
 * @author: C31909
 * @create: 2024-07-23 09:26
 * @Version 1.0
 **/
@Data
public class HardwareEditBO {
    /**
     * 内部编号
     */
    private String id;

    /**
     * 卡片别,通用代码
     */
    private Integer companyCode;

    /**
     * 资产编号
     */
    private String assetNum;

    /**
     * 序列号
     */
    private String serialNum;

    /**
     * 资产名称
     */
    private String assetName;

    /**
     * 分类,通用代码
     */
    private Integer category;

    /**
     * 型号
     */
    private String model;

    /**
     * 本币原值
     */
    private String homeCurrencyValue;

    /**
     * 部门代码
     */
    private String deptCode;

    /**
     * 存放地点
     */
    private String place;

    /**
     * 具体位置
     */
    private String detailPlace;

    /**
     * 是否使用
     */
    private String used;

    /**
     * 开始使用日期
     */
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    private Date startDate;
    /**
     * 供应商，供应商ID
     */
    private Integer supplierId;

    /**
     * 供应商，供应商ID
     */
    private Integer brand;
    /**
     * 禀议号
     */
    private String applyId;

    /**
     * 是否报废
     */
    private Boolean scrapped;

    /**
     * 报废日期
     */
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    private Date scrapDate;

    /**
     * 备注
     */
    private String remark;

    private String ip;

    private Integer version;

    private String updatedBy;

    /**
     * 资产管理担当
     */
    private String manager;
}
