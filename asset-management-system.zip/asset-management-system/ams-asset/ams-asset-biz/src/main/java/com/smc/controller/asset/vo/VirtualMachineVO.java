package com.smc.controller.asset.vo;

import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @program: asset-management-system
 * @ClassName VirtualMachineVO
 * @description:
 * @author: C31909
 * @create: 2024-07-26 08:18
 * @Version 1.0
 **/
@Data
public class VirtualMachineVO {
    /**
     * 内部编号
     */
    private String id;

    /**
     * 硬件资产主键
     */
    private String hardwareId;
    /**
     * 虚拟机名称
     */
    private String name;

    /**
     * IP
     */
    private String ip;

    /**
     * CPU核心数
     */
    private String cpu;

    /**
     * 内存空间MB
     */
    private String memory;

    /**
     * 硬盘空间GB
     */
    private String hardDisk;

    /**
     * 应用系统
     */
    private String appliedSystem;

    /**
     * 应用类别，通用代码
     */
    private String appliedCategory;

    /**
     * 用途，通用代码
     */
    private String appliedEnv;

    /**
     * 操作系统，通用代码
     */
    private String operatingSystem;

    /**
     * 数据库，通用代码
     */
    private String sqlCategory;

    /**
     * 应用软件的版权
     */
    // private String applicationLicense;

    /**
     * 使用部门
     */
    private String deptCode;

    /**
     * 管理担当
     */
    private String manager;

    /**
     * 备注
     */
    private String remark;

    /**
     * 有效性
     */
    private String activity;

    /**
     * 管理组别，通用代码
     */
    private String manageGroup;

    /**
     * 物理机IP
     */
    // private String hardwareIp;
    /**
     * IT部担当
     */
    private String itManager;

    private Integer version;

    private String createdBy;
    /**
     * 创建时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    public Date createdTime;

    private String updatedBy;

    /**
     * 修改时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    public Date updatedTime;
}
