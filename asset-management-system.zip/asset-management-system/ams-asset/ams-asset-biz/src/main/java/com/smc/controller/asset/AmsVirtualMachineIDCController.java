package com.smc.controller.asset;

import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.asset.bo.*;
import com.smc.dataobject.asset.AmsDept;
import com.smc.service.asset.AmsDeptService;
import com.smc.service.asset.AmsVirtualMachineIDCService;
import com.smc.utils.WebUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 服务器管理IDC
 * @author C31909
 * @since 1.0.0 2025-02-27
 */
@CrossOrigin
@RestController
@RequestMapping("/virtual_IDC")
public class AmsVirtualMachineIDCController {

    @Resource
    private AmsVirtualMachineIDCService amsVirtualMachineIDCService;
    @Resource
    private AmsDeptService amsDeptService;

    @PostMapping("/list")
    public ResultBody<PageResult> page(@RequestBody PageRequest pageRequest) {
        PageResult res = amsVirtualMachineIDCService.selectPage(pageRequest);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody VirtualMachineIDCEditBO model) {
        String res = amsVirtualMachineIDCService.editById(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody VirtualMachineIDCAddBO model) {
        String res = amsVirtualMachineIDCService.add(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody VirtualMachineIDCDeleteBO model) {
        String res = amsVirtualMachineIDCService.delete(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/export")
    public void export(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        amsVirtualMachineIDCService.export(pageRequest, response);
    }

    @PostMapping("/import")
    public ResultBody<String> importExcel(@RequestParam("multipartFile") MultipartFile file, HttpServletRequest request) {
        String res = amsVirtualMachineIDCService.importExcel(file, request);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @GetMapping("/getDeptListByDeptCode")
    public ResultBody<List<String>> getDeptListByDeptCode(@RequestParam("deptCode") String deptCode) {
        List<String> res = amsDeptService.getDeptListByDeptCode(deptCode);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

}