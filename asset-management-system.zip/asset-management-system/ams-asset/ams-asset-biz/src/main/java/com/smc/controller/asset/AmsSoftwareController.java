package com.smc.controller.asset;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.asset.bo.SoftwareAddBO;
import com.smc.controller.asset.bo.SoftwareDeleteBO;
import com.smc.controller.asset.bo.SoftwareEditBO;
import com.smc.controller.asset.bo.SoftwareQueryBO;
import com.smc.controller.asset.vo.SoftwareVO;
import com.smc.service.asset.AmsSoftwareService;
import com.smc.utils.StringUtils;
import com.smc.utils.WebUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * 软件
 *
 * @author C31909
 * @since 1.0.0 2024-08-2
 */
@CrossOrigin
@RestController
@RequestMapping("/software")
public class AmsSoftwareController {
    @Resource
    private AmsSoftwareService amsSoftwareService;

    @PostMapping("/list")
    public ResultBody<PageResult> page(@RequestBody PageRequest pageRequest) {
        return amsSoftwareService.page(pageRequest);
    }


    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody SoftwareEditBO model) {
        return amsSoftwareService.editById(model);
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody SoftwareAddBO model) {
        return amsSoftwareService.add(model);
    }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody SoftwareDeleteBO model) {
        return amsSoftwareService.delete(model);
    }

    @PostMapping("/import")
    public ResultBody<String> importData(@RequestParam("multipartFile") MultipartFile file, HttpServletRequest request) {
        String res = amsSoftwareService.importExcel(file, request);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/export")
    public void exportData(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        amsSoftwareService.exportData(pageRequest, response);
    }


    @PostMapping("/getById")
    public ResultBody<SoftwareVO> getById(@RequestParam("id") String id) {
        return null;
    }


    @PostMapping("/listByCondition")
    public ResultBody<List<SoftwareVO>> listByCondition(@RequestBody SoftwareQueryBO queryBO) {
        return null;
    }
}