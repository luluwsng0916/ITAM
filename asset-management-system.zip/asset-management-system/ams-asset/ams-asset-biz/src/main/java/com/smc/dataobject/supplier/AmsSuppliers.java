package com.smc.dataobject.supplier;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * @author C31909
 * @TableName ams_suppliers
 */
@TableName(value = "ams_suppliers")
@Data
public class AmsSuppliers extends AbstractEntity implements Serializable {
    /**
     *
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 供应商名称
     */
    @TableField(value = "name")
    private String name;

    /**
     * 联系人
     */
    @TableField(value = "contactPerson")
    private String contactPerson;

    /**
     * 联系电话
     */
    @TableField(value = "phone")
    private String phone;

    /**
     * 电子邮箱
     */
    @TableField(value = "email")
    private String email;

    /**
     * 地址
     */
    @TableField(value = "address")
    private String address;

    /**
     * 供应商描述
     */
    @TableField(value = "remark")
    private String remark;

    @TableField(value = "activity")
    private Boolean activity;

}