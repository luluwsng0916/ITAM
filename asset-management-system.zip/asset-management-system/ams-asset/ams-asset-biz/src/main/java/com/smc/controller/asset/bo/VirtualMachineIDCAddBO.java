package com.smc.controller.asset.bo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * (AmsVirtualMachineIDC)
 * @author makejava
 * @since 2025-02-27 14:27:23
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VirtualMachineIDCAddBO implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 服务器ID
     */
    private String serverId;
    /**
     * 关联资产编码
     */
    private String hardwareId;
    /**
     * 服务器名
     */
    private String serverName;
    /**
     * 系统名称/应用
     */
    private String appliedSystem;
    /**
     * IP地址
     */
    private String ip;
    /**
     * 服务器操作系统，通用代码
     */
    private String operatingSystem;
    /**
     * 服务器类别
     */
    private String serverType;
    /**
     * 用途，通用代码
     */
    private String appliedEnv;
    /**
     * 备份方式
     */
    private String bakType;
    /**
     * 启用RP4VM复制
     */
    private String rp4vm;
    /**
     * 有效性
     */
    private String activity;
    /**
     * CPU
     */
    private String cpu;
    /**
     * 内存(G)
     */
    private String memory;
    /**
     * 硬盘(G)
     */
    private String hardDisk;
    /**
     * 域名
     */
    private String domain;
    /**
     * 业务部门
     */
    private String deptCode;
    /**
     * 业务担当
     */
    private String manager;
    /**
     * IT部小组,通用代码
     */
    private String manageGroup;
    /**
     * IT部担当
     */
    private String itManager;
    /**
     * 服务器别名
     */
    private String alias;
    /**
     * 备注
     */
    private String remark;
    /**
     * 服务器创建时间
     */
    private String serverCreatedTime;
    /**
     * 服务器创建人
     */
    private String serverCreatedBy;
    /**
     * 创建人
     */
    private String operator;
    /**
     * VC显示名称
     */
    private String vcName;
    /**
     * 应用类别
     */
    private String appliedType;
    /**
     * 2025/03/12 新增OA申请编号
     */
    private String oaId;


}

