package com.smc.service.asset;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.common.mybatis.model.KeyValueParam;
import com.smc.controller.asset.bo.HardwareBindSupplierBO;
import com.smc.controller.asset.bo.HardwareDeleteBO;
import com.smc.controller.asset.bo.HardwareEditBO;
import com.smc.controller.asset.bo.HardwareQueryBO;
import com.smc.controller.asset.vo.HardwareVO;
import com.smc.dataobject.asset.AmsHardware;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 硬件
 *
 * @author C31909
 * @since 1.0.0 2024-07-10
 */
public interface AmsHardwareService {

    ResultBody<PageInfo<HardwareVO>> page(PageRequest pageRequest);

    ResultBody<String> editById(HardwareEditBO model);

    ResultBody<String> add(AmsHardware model);

    ResultBody<String> importData(MultipartFile multipartFile, HttpServletRequest req);

    void exportData(PageRequest pageRequest, HttpServletResponse response) throws IOException;

    ResultBody<String> delete(HardwareDeleteBO model);

    void saveBatch(List<AmsHardware> amsHardwares);

    ResultBody<String> bindSupplier(HardwareBindSupplierBO bo);

    List<AmsHardware> getByIdList(List<Integer> hardwareIds);

    ResultBody<HardwareVO> getById(String id);

    ResultBody<List<HardwareVO>> listByCondition(HardwareQueryBO queryBO);

    List<AmsHardware> listHardwareIdBySearch(String searchKey);

    ResultBody<List<KeyValueParam<String, String>>> listAllHardwareId();

    List<String> findManagers();
}