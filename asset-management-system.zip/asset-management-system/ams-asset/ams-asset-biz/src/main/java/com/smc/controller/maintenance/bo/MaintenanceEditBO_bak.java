package com.smc.controller.maintenance.bo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @program: asset-management-system
 * @ClassName VirtualPoolEditBO
 * @description:
 * @author: C31909
 * @create: 2024-07-30 09:07
 * @Version 1.0
 **/
@Data
public class MaintenanceEditBO_bak {
    private String id;

    /**
     * 资产编码
     */
    private String assetId;

    /**
     * 开始日期
     */
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startDate;

    /**
     * 结束日期
     */
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endDate;

    /**
     * 服务提供商
     */
    private String provider;

    /**
     * 服务类型
     */
    private Integer serviceType;

    /**
     * 费用
     */
    private BigDecimal cost;

    /**
     * 管理担当
     */
    private String manager;

    /**
     * 合同编号
     */
    private String contractNo;

    /**
     * 有效性
     */
    private Boolean activity;

    /**
     * 备注
     */
    private String remark;
    private Integer version;
    private String updatedBy;
}
