package com.smc.utils;

import com.alibaba.fastjson.JSON;
import com.smc.controller.asset.dto.VirtualPoolExcelDTO;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/13
 * @description
 */
public class ListUtils {
    public static List<VirtualPoolExcelDTO> removeListItem(List<VirtualPoolExcelDTO> list, VirtualPoolExcelDTO item) {
        final CopyOnWriteArrayList<VirtualPoolExcelDTO> cowList = new CopyOnWriteArrayList<>(list);
        for (VirtualPoolExcelDTO c : cowList) {
            if(c.equals(item)) {
                cowList.remove(c);
            }
        }
        return cowList;
    }
}
