package com.smc.controller.asset.vo;

import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @program: asset-management-system
 * @ClassName HardwareVO
 * @description:
 * @author: C31909
 * @create: 2024-07-11 11:08
 * @Version 1.0
 **/
@Data
public class HardwareVO {

    private String id;

    /**
     * 卡片别,通用代码
     */
    private String companyCode;

    /**
     * 序列号
     */
    private String serialNum;

    /**
     * 资产名称
     */
    private String assetNum;
    /**
     * 资产名称
     */
    private String assetName;

    /**
     * 分类,通用代码
     */
    private String category;

    /**
     * 型号
     */
    private String model;

    /**
     * 本币原值
     */
    private String homeCurrencyValue;

    /**
     * 使用部门
     */
    private String deptCode;

    /**
     * 存放地点
     */
    private String place;

    /**
     * 具体位置
     */
    private String detailPlace;

    /**
     * 是否使用
     */
    private String used;

    /**
     * 开始使用日期
     */
    @DateTimeFormat("yyyy-MM-dd")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    private Date startDate;

    /**
     * 采购供应商
     */
    private Integer supplierId;

    /**
     * 采购供应商
     */
    private String supplierName;

    /**
     * 生产厂商
     */
    private String brand;

    /**
     * 禀议号
     */
    private String applyId;

    /**
     * 是否报废
     */
    private String scrapped;

    /**
     * 报废日期
     */
    @DateTimeFormat("yyyy-MM-dd")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    private Date scrapDate;

    /**
     * 备注
     */
    private String remark;

    private Integer version;


    private String createdBy;
    /**
     * 创建时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    public Date createdTime;

    private String updatedBy;

    /**
     * 修改时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    public Date updatedTime;

    /**
     * 物理机IP
     */
    private String ip;

    private String manager;
}
