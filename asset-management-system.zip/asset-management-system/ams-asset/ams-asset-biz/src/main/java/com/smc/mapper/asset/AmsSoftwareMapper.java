package com.smc.mapper.asset;

import com.smc.controller.asset.dto.SoftwareExcelDTO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smc.dataobject.asset.AmsSoftware;

import java.util.HashMap;
import java.util.List;

/**
* @author C31909
* @description 针对表【ams_software】的数据库操作Mapper
* @createDate 2024-08-01 09:00:18
* @Entity com.smc.dataobject.asset.AmsSoftware
*/
public interface AmsSoftwareMapper extends BaseMapper<AmsSoftware> {

    List<AmsSoftware> findAll(HashMap<String, Object> map);

    void insertBatch(List<SoftwareExcelDTO> list);

    Integer checkAmsSoftware(String name);
}




