package com.smc.service.asset;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.asset.bo.VirtualPoolBindHardwareBO;
import com.smc.controller.asset.bo.VirtualPoolDeleteBO;
import com.smc.controller.asset.bo.VirtualPoolEditBO;
import com.smc.controller.asset.dto.VirtualPoolConditionDTO;
import com.smc.controller.asset.vo.VirtualPoolVO;
import com.smc.dataobject.asset.AmsVirtualPool;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
* @author C31909
* @description 针对表【ams_virtual_pool】的数据库操作Service
* @createDate 2024-07-30 08:22:10
*/
public interface AmsVirtualPoolService  {

    ResultBody<PageInfo<VirtualPoolVO>> page(PageRequest pageRequest);

    ResultBody<String> editById(VirtualPoolEditBO model);

    ResultBody<String> add(AmsVirtualPool model);

    ResultBody<String> delete(VirtualPoolDeleteBO model);

    ResultBody<String> bindHardware(VirtualPoolBindHardwareBO bo);

    List<String> findHardwareId(VirtualPoolConditionDTO virtualPoolConditionDTO);

    List<String> findVirtualMachineId(VirtualPoolConditionDTO virtualPoolConditionDTO);

    List<String> findManager(String data);

    void export(PageRequest pageRequest, HttpServletResponse response);

    String importExcel(MultipartFile file, HttpServletRequest request);

    List<String> findHardwareIdByManager(String manager);

    List<String> findVirtualMachineIdByHardwareId(String hardwareId);
}
