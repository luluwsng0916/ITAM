package com.smc.mapper.asset;

import com.smc.controller.asset.dto.VirtualPoolConditionDTO;
import com.smc.controller.asset.dto.VirtualPoolExcelDTO;
import com.smc.dataobject.asset.AmsVirtualPool;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

/**
 * @author C31909
 * @description 针对表【ams_virtual_pool】的数据库操作Mapper
 * @createDate 2024-07-30 08:22:10
 * @Entity com.smc.dataobject.asset.AmsVirtualPool
 */
public interface AmsVirtualPoolMapper extends BaseMapper<AmsVirtualPool> {

//    List<String> findHardwareId(String data);
    List<String> findHardwareId(VirtualPoolConditionDTO virtualPoolConditionDTO);

//        List<String> findVirtualMachineId(String data);
    List<String> findVirtualMachineId(VirtualPoolConditionDTO virtualPoolConditionDTO);


    List<String> findManager(String data);

    List<AmsVirtualPool> findAll(HashMap<String, Object> map);

    void insertBatch(List<VirtualPoolExcelDTO> list);

    List<String> findHardwareIdByManager(String manager);

    List<String> findVirtualMachineIdByHardwareId(String hardwareId);

    int validateManger(@Param("hardwareId") String hardwareId, @Param("virtualMachineId")String virtualMachineId, @Param("manager")String manager);

    int checkRepeat(@Param("hardwareId") String hardwareId,@Param("virtualMachineId") String virtualMachineId,@Param("manager") String manager);
}




