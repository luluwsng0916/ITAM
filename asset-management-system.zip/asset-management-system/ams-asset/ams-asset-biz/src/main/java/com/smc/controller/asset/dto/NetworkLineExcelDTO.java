package com.smc.controller.asset.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.format.NumberFormat;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentFontStyle;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import lombok.Data;

import java.io.Serializable;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/2
 * @description
 */
@Data
@ColumnWidth(20)
@HeadFontStyle(fontHeightInPoints = 11)
@ContentFontStyle(fontHeightInPoints = 10)
public class NetworkLineExcelDTO implements Serializable  {

    private static final long serialVersionUID = 1L;

    /**
     * 序号（excel手动排序序号）
     */
    @ExcelProperty(value = "序号")
    private String sort;
    /**
     * 专线编号
     */
    @ExcelProperty(value = "专线编号")
    private String networkLineId;
    /**
     * 专线名称
     */
    @ExcelProperty(value = "专线名称")
    private String networkLineName;
    /**
     * 专线类别
     */
    @ExcelProperty(value = "专线类别")
    private String networkLineType;
    /**
     * 地点
     */
    @ExcelProperty(value = "地点")
    private String place;
    /**
     * 带宽
     */
    @ExcelProperty(value = "带宽")
    private String bandwidth;
    /**
     * 月租费用
     */
    @ExcelProperty(value = "月租费用")
    private String monthlyFee;
    /**
     * 一次性施工费用
     */
    @ExcelProperty(value = "一次性施工费用")
    private String oneTimeFee;
    /**
     * 协议金额（元/年）
     */
    @ExcelProperty(value = "协议金额")
    @NumberFormat("0.00")
    private String agreementMoney;
    /**
     * 供应商名称
     */
    @ExcelProperty(value = "供应商名称")
    private String supplierName;
    /**
     * 起始日期
     */
    @ExcelProperty(value = "起始日期")
    @DateTimeFormat("yyyy-MM-dd")
    private String startDate;
    /**
     * 终止日期
     */
    @ExcelProperty(value = "终止日期")
    @DateTimeFormat("yyyy-MM-dd")
    private String endDate;
    /**
     * 备注
     */
    @ExcelProperty(value = "备注")
    private String remark;

    @ExcelProperty(value = "创建者")
    private String createdBy;

    @ExcelProperty(value = "创建时间")
    private String createdTime;

    @ExcelProperty(value = "更新者")
    private String updatedBy;

    @ExcelProperty(value = "更新时间")
    private String updatedTime;
}
