package com.smc.service.maintenance.impl;


import com.smc.controller.maintenance.dto.MaintenanceExcelDTO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EasyExcelMaintenanceServiceImpl {

    static List<MaintenanceExcelDTO> list = new ArrayList<>();

    /**
     * 分批导入的数据拼接到一起
     *
     * @param
     * @return
     */
    public static List<MaintenanceExcelDTO> getAllImportExcelData() {
        return list;
    }

    public void save(List<MaintenanceExcelDTO> cachedDataList) {
        list.addAll(cachedDataList);
    }

    /**
     * 创建一个构造方法 用于list.clean()
     *
     * @return
     */
    public List<MaintenanceExcelDTO> getList() {
        return list;
    }

}
