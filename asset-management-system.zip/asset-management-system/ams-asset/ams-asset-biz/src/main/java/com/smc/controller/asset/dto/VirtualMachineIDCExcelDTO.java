package com.smc.controller.asset.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentFontStyle;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * (AmsVirtualMachineIDC)
 *
 * @author makejava
 * @since 2025-02-27 14:27:23
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ColumnWidth(20)
@HeadFontStyle(fontHeightInPoints = 11)
@ContentFontStyle(fontHeightInPoints = 10)
public class VirtualMachineIDCExcelDTO extends AbstractEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 服务器ID
     */
    @ExcelProperty(value = "服务器ID")
    private String serverId;
    /**
     * 关联资产编码
     */
    @ExcelProperty(value = "关联资产编码")
    private String hardwareId;
    /**
     * VC显示名称
     */
    @ExcelProperty(value = "VC显示名称")
    private String vcName;
    /**
     * 服务器名
     */
    @ExcelProperty(value = "服务器名")
    private String serverName;
    /**
     * 系统名称/应用
     */
    @ExcelProperty(value = "系统名称/应用")
    private String appliedSystem;
    /**
     * IP地址
     */
    @ExcelProperty(value = "IP地址")
    private String ip;
    /**
     * 服务器操作系统，通用代码
     */
    @ExcelProperty(value = "服务器操作系统")
    private String operatingSystem;
    /**
     * 服务器类别
     */
    @ExcelProperty(value = "服务器类别")
    private String serverType;
    /**
     * 应用类别
     */
    @ExcelProperty(value = "应用类别")
    private String appliedType;
    /**
     * 用途，通用代码
     */
    @ExcelProperty(value = "用途")
    private String appliedEnv;
    /**
     * 备份方式
     */
    @ExcelProperty(value = "备份方式")
    private String bakType;
    /**
     * 启用RP4VM复制
     */
    @ExcelProperty(value = "启用RP4VM复制")
    private String rp4vm;
    /**
     * 有效性
     */
    @ExcelProperty(value = "有效性")
    private String activity;
    /**
     * CPU
     */
    @ExcelProperty({"服务器资源", "CPU"})
    private String cpu;
    /**
     * 内存(G)
     */
    @ExcelProperty({"服务器资源", "内存(G)"})
    private String memory;
    /**
     * 硬盘(G)
     */
    @ExcelProperty({"服务器资源", "硬盘(G)"})
    private String hardDisk;
    /**
     * 域名
     */
    @ExcelProperty(value = "域名")
    private String domain;
    /**
     * 业务部门
     */
    @ExcelProperty(value = "业务部门")
    private String deptCode;
    /**
     * 业务担当
     */
    @ExcelProperty(value = "业务担当")
    private String manager;
    /**
     * IT部小组,通用代码
     */
    @ExcelProperty(value = "IT部小组")
    private String manageGroup;
    /**
     * IT部担当
     */
    @ExcelProperty(value = "IT部担当")
    private String itManager;
    /**
     * 服务器别名
     */
    @ExcelProperty(value = "服务器别名")
    private String alias;
    /**
     * 服务器创建时间
     */
    @ExcelProperty(value = "服务器创建时间")
    private String serverCreatedTime;
    /**
     * 服务器创建人
     */
    @ExcelProperty(value = "服务器创建人")
    private String serverCreatedBy;
    /**
     * 备注
     */
    @ExcelProperty(value = "备注")
    private String remark;
    /**
     * 2025/03/12 新增OA申请编号
     */
    @ExcelProperty(value = "OA申请编号")
    private String oaId;

}

