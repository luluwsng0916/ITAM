package com.smc.controller.asset.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName HardwareVO
 * @description:
 * @author: C31909
 * @create: 2024-08-08 12:20
 * @Version 1.0
 **/
@Data
public class HardwareExcelDTO {

    @ExcelProperty("硬件资产编码")
    @ColumnWidth(16)
    private String id;

    /**
     * 卡片别,通用代码
     */
    @ExcelProperty(value = "卡片别")
    @ColumnWidth(10)
    private String companyCode;

    /**
     * 序列号
     */
    @ExcelProperty(value = "序列号")
    @ColumnWidth(12)
    private String serialNum;

    /**
     * 资产名称
     */
    @ExcelProperty(value = "资产名称")
    @ColumnWidth(16)
    private String assetName;

    /**
     * 分类,通用代码
     */
    @ExcelProperty(value = "分类")
    @ColumnWidth(16)
    private String category;

    /**
     * 型号
     */
    @ExcelProperty(value = "型号")
    @ColumnWidth(20)
    private String model;

    /**
     * 本币原值
     */
    @ExcelProperty(value = "本币原值")
    @ColumnWidth(16)
    private String homeCurrencyValue;

    /**
     * 使用部门
     */
    @ExcelProperty(value = "管理部门")
    @ColumnWidth(16)
    private String deptCode;

    @ExcelProperty(value = "资产管理担当")
    @ColumnWidth(16)
    private String manager;

    /**
     * 存放地点
     */
    @ExcelProperty(value = "存放地点")
    @ColumnWidth(16)
    private String place;

    /**
     * 具体位置
     */
    @ExcelProperty(value = "具体位置")
    @ColumnWidth(25)
    private String detailPlace;

    /**
     * 是否使用
     */
    @ExcelProperty(value = "是否使用")
    @ColumnWidth(22)
    private String used;

    /**
     * 开始使用日期
     */
    @ExcelProperty(value = "开始使用日期")
    @ColumnWidth(25)
    private String startDate;

    /**
     * 采购供应商
     */
    @ExcelProperty(value = "供应商")
    @ColumnWidth(25)
    private String supplierName;

    /**
     * 禀议号
     */
    @ExcelProperty(value = "禀议号")
    @ColumnWidth(20)
    private String applyId;

    @ExcelProperty(value = "物理机IP")
    @ColumnWidth(16)
    private String ip;

    /**
     * 生产厂商
     */
    @ExcelProperty(value = "生产厂商")
    @ColumnWidth(16)
    private String brand;

    /**
     * 资产编号
     */
    @ExcelProperty(value = "资产编号")
    @ColumnWidth(16)
    private String assetNum;

    /**
     * 是否报废
     */
    @ExcelProperty(value = "是否报废")
    @ColumnWidth(16)
    private String scrapped;

    /**
     * 报废日期
     */
    @ExcelProperty(value = "报废日期")
    @ColumnWidth(25)
    private String scrapDate;

    /**
     * 备注
     */
    @ExcelProperty(value = "备注")
    @ColumnWidth(25)
    private String remark;

    @ExcelProperty(value = "创建者")
    @ColumnWidth(12)
    private String createdBy;
    /**
     * 创建时间
     */
    @ExcelProperty(value = "创建时间")
    @ColumnWidth(25)
    public String createdTime;

    @ExcelProperty(value = "更新者")
    @ColumnWidth(12)
    private String updatedBy;

    /**
     * 修改时间
     */
    @ExcelProperty(value = "更新时间")
    @ColumnWidth(25)
    public String updatedTime;


}
