package com.smc.mapper.supplier;

import com.smc.dataobject.supplier.AmsSuppliers;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
* @author C31909
* @description 针对表【ams_suppliers】的数据库操作Mapper
* @createDate 2024-07-22 09:41:49
* @Entity com.smc.dataobject.base.AmsSuppliers
*/
public interface AmsSuppliersMapper extends BaseMapper<AmsSuppliers> {

    List<AmsSuppliers> listBySearch(@Param("searchKey") String searchKey);
}




