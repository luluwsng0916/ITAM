package com.smc.mapstruct;

import com.smc.controller.system.bo.SystemAddBO;
import com.smc.controller.system.bo.SystemDeleteBO;
import com.smc.controller.system.bo.SystemEditBO;
import com.smc.dataobject.system.AmsSystem;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/6
 * @description
 */
@Mapper
public interface AmsSystemMSMapper {

    AmsSystemMSMapper INSTANCE = Mappers.getMapper(AmsSystemMSMapper.class);

    @Mapping(source = "operator", target = "createdBy")
    AmsSystem toAmsSystemAdd(SystemAddBO systemAddBO);

    @Mappings({
            @Mapping(source = "id", target = "id"),
            @Mapping(source = "operator", target = "updatedBy"),
            @Mapping(source = "version", target = "version")
    })
    AmsSystem toAmsSystemEdit(SystemEditBO systemEditBO);

    @Mappings({
            @Mapping(source = "id", target = "id"),
            @Mapping(source = "updatedBy", target = "updatedBy"),
            @Mapping(source = "version", target = "version")
    })
    AmsSystem toAmsSystemDel(SystemDeleteBO systemDeleteBO);

}
