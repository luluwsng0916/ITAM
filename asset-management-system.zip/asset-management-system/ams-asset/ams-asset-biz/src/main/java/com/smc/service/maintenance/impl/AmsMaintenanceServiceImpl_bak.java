package com.smc.service.maintenance.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.smc.api.mdm.CodeGenApi;
import com.smc.api.mdm.UniversalCodeQueryApi;
import com.smc.api.mdm.dto.PublicUniversalCodeDTO;
import com.smc.api.query.QueryServiceClient;
import com.smc.common.constants.ActivityConstant;
import com.smc.common.constants.CommonConstants;
import com.smc.common.constants.DeleteMarkConstant;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.common.mybatis.model.KeyValueParam;
import com.smc.controller.maintenance.bo.MaintenanceBindHardwareBO_bak;
import com.smc.controller.maintenance.bo.MaintenanceDeleteBO_bak;
import com.smc.controller.maintenance.bo.MaintenanceEditBO_bak;
import com.smc.controller.maintenance.vo.MaintenanceVO_bak;
import com.smc.dataobject.asset.AmsHardware;
import com.smc.dataobject.asset.AmsSoftware;
import com.smc.dataobject.file.AmsFilePath;
import com.smc.dataobject.maintenance.AmsMaintenance_bak;
import com.smc.enums.asset.AssetConstant;
import com.smc.enums.mdm.TableCodeRule;
import com.smc.mapper.maintenance.AmsMaintenanceMapper_bak;
import com.smc.service.asset.AmsHardwareService;
import com.smc.service.asset.AmsSoftwareService;
import com.smc.service.file.AmsFilePathsService;
import com.smc.service.maintenance.AmsMaintenanceService_bak;
import com.smc.utils.FileUtils;
import com.smc.utils.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author C31909
 * @description 针对表【ams_maintenance】的数据库操作Service实现
 * @createDate 2024-08-01 09:00:18
 */
@Service
public class AmsMaintenanceServiceImpl_bak implements AmsMaintenanceService_bak {

    @Resource
    private AmsMaintenanceMapper_bak amsMaintenanceMapper_bak;
    @Resource
    private QueryServiceClient queryServiceClient;

    @Resource
    private UniversalCodeQueryApi universalCodeQueryApi;

    @Resource
    private AmsHardwareService amsHardwareService;

    @Resource
    private AmsSoftwareService amsSoftwareService;

    @Resource
    private AmsFilePathsService amsFilePathsService;

    @Value(value = "${upload.ftp.basePath}")
    private String ftpBasePath;
    @Value(value = "${upload.ftp.contract}")
    private String ftpPath;
    @Value(value = "${upload.ftp.host}")
    private String ftpHost;
    @Value(value = "${upload.ftp.port}")
    private String ftpPort;
    @Value(value = "${upload.url.port}")
    private String urlPort;
    @Value(value = "${upload.ftp.username}")
    private String ftpUsername;
    @Value(value = "${upload.ftp.password}")
    private String ftpPassword;

    @Resource
    private CodeGenApi codeGenApi;

    @Override
    public ResultBody<PageInfo<MaintenanceVO_bak>> listByPage(PageRequest pageRequest) {
        String assetId = pageRequest.getParamValue("assetId");
        String serviceType = pageRequest.getParamValue("serviceType");
        String activity = pageRequest.getParamValue("activity");

        LambdaQueryWrapper<AmsMaintenance_bak> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(AmsMaintenance_bak::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        wrapper.like(StringUtils.isNoneBlank(assetId), AmsMaintenance_bak::getAssetId, assetId);
        wrapper.like(StringUtils.isNoneBlank(serviceType), AmsMaintenance_bak::getServiceType, serviceType);
        wrapper.eq(StringUtils.isNotBlank(activity), AmsMaintenance_bak::getActivity, Boolean.parseBoolean(activity));

        HashMap<String, Object> map = queryServiceClient.generateMapParams(pageRequest);
        StringBuilder stringBuilder = new StringBuilder();
        if (map.get("conditionParams") != null) {
            stringBuilder.append(map.get("conditionParams"));
        }
        if (map.get("sortParam") != null) {
            stringBuilder.append(" ORDER BY ").append(map.get("sortParam"));
        } else {
            stringBuilder.append(" ORDER BY ").append("createdTime DESC,updatedTime DESC");
        }
        wrapper.last(stringBuilder.toString());
        PageHelper.startPage(pageRequest.getPageNum(), pageRequest.getPageSize());
        List<AmsMaintenance_bak> list = amsMaintenanceMapper_bak.selectList(wrapper);
        // 为什么：原因是自己封装的vo把PageInfo原有的属性破坏了
        // 解决方案：https://blog.csdn.net/qq_39765635/article/details/87694796
        PageInfo<AmsMaintenance_bak> pageInfo = new PageInfo<>(list);
        List<MaintenanceVO_bak> voList = toVOList(list);
        if (CollectionUtil.isEmpty(list)) {
            return ResultBody.ok().data(new PageInfo<>(voList));
        }
        PageInfo<MaintenanceVO_bak> pageInfoRes = new PageInfo<>(voList);
        pageInfoRes.setPageNum(pageInfo.getPageNum());
        pageInfoRes.setPageSize(pageInfo.getPageSize());
        pageInfoRes.setTotal(pageInfo.getTotal());
        pageInfoRes.setPages(pageInfo.getPages());
        return ResultBody.ok().data(pageInfoRes);
    }

    private static boolean isStartWithCodePrefix(String assetId) {
        return assetId.startsWith(AssetConstant.SM_PREFIX) ||
                assetId.startsWith(AssetConstant.VP_PREFIX) ||
                assetId.startsWith(AssetConstant.VM_PREFIX) ||
                assetId.startsWith(AssetConstant.SW_PREFIX);
    }

    private List<MaintenanceVO_bak> toVOList(List<AmsMaintenance_bak> list) {
        List<MaintenanceVO_bak> maintenanceVOS = new ArrayList<>(list.size());
        Map<Integer, PublicUniversalCodeDTO> allUniversalCode = getAllUniversalCode(list);
        Map<Integer, AmsFilePath> allFiles = getAllFile(list);
        list.forEach(amsMaintenance -> {
            MaintenanceVO_bak vo = new MaintenanceVO_bak();
            vo.setId(amsMaintenance.getId());
            vo.setAssetId(amsMaintenance.getAssetId());
            vo.setStartDate(amsMaintenance.getStartDate());
            vo.setEndDate(amsMaintenance.getEndDate());
            vo.setProvider(amsMaintenance.getProvider());
            vo.setServiceType(CollectionUtil.isNotEmpty(allUniversalCode) && amsMaintenance.getServiceType() != null ?
                    allUniversalCode.get(amsMaintenance.getServiceType()).getDictValue() : CommonConstants.NULL_STRING);
            vo.setCost(amsMaintenance.getCost());
            vo.setManager(amsMaintenance.getManager());
            vo.setContractNo(amsMaintenance.getContractNo());
            vo.setFileId(amsMaintenance.getFileId());
            vo.setAttachmentAddress(CollectionUtil.isNotEmpty(allFiles) && amsMaintenance.getFileId() != null ?
                    allFiles.get(amsMaintenance.getFileId()).getFilePath() : null);
            vo.setActivity(amsMaintenance.getActivity() ?
                    ActivityConstant.ACTIVITY_STR : ActivityConstant.INACTIVITY_STR);
            vo.setRemark(amsMaintenance.getRemark());
            vo.setVersion(amsMaintenance.getVersion());
            vo.setCreatedBy(amsMaintenance.getCreatedBy());
            vo.setCreatedTime(amsMaintenance.getCreatedTime());
            vo.setUpdatedBy(amsMaintenance.getUpdatedBy());
            vo.setUpdatedTime(amsMaintenance.getUpdatedTime());
            maintenanceVOS.add(vo);
        });
        return maintenanceVOS;
    }

    private Map<Integer, AmsFilePath> getAllFile(List<AmsMaintenance_bak> list) {
        List<Integer> fileIdList = new ArrayList<>();
        // 查询文件地址
        fileIdList.addAll(list.stream().map(AmsMaintenance_bak::getFileId).collect(Collectors.toList()));
        fileIdList = fileIdList.stream().distinct().filter(Objects::nonNull).collect(Collectors.toList());
        if (CollectionUtil.isEmpty(fileIdList)) {
            return null;
        }
        List<AmsFilePath> filePathList = amsFilePathsService.getFilePathByIdList(fileIdList);
        if (CollectionUtil.isEmpty(filePathList)) {
            return null;
        }
        return filePathList.stream().collect(Collectors.toMap(AmsFilePath::getId, Function.identity()));
    }

    private Map<Integer, PublicUniversalCodeDTO> getAllUniversalCode(List<AmsMaintenance_bak> list) {
        List<Integer> codeList = new ArrayList<>();
        // 查询服务类型
        codeList.addAll(list.stream().map(AmsMaintenance_bak::getServiceType).collect(Collectors.toList()));
        codeList = codeList.stream().distinct().filter(Objects::nonNull).collect(Collectors.toList());
        if (CollectionUtil.isEmpty(codeList)) {
            return null;
        }
        List<PublicUniversalCodeDTO> universalCodeByIdList = universalCodeQueryApi.getUniversalCodeByIdList(codeList);
        if (CollectionUtil.isEmpty(universalCodeByIdList)) {
            return null;
        }
        return universalCodeByIdList.stream()
                .collect(Collectors.toMap(PublicUniversalCodeDTO::getId, Function.identity()));
    }

    @Override
    public ResultBody<String> updateById(MaintenanceEditBO_bak model) {
//        String errorMsg = assetIdExists(model.getAssetId());
//        if (StringUtils.isNotBlank(errorMsg)) {
//            return ResultBody.failed().msg(errorMsg);
//        }
        AmsMaintenance_bak amsMaintenance = new AmsMaintenance_bak();
        amsMaintenance.setId(model.getId());
        amsMaintenance.setAssetId(model.getAssetId());
        amsMaintenance.setStartDate(model.getStartDate());
        amsMaintenance.setEndDate(model.getEndDate());
        amsMaintenance.setProvider(model.getProvider());
        amsMaintenance.setServiceType(model.getServiceType());
        amsMaintenance.setCost(model.getCost());
        amsMaintenance.setManager(model.getManager());
        amsMaintenance.setContractNo(model.getContractNo());
        amsMaintenance.setActivity(model.getActivity());
        amsMaintenance.setRemark(model.getRemark());
        amsMaintenance.setVersion(model.getVersion());
        amsMaintenance.setUpdatedBy(model.getUpdatedBy());
        amsMaintenance.setUpdatedTime(new Date());
        amsMaintenanceMapper_bak.updateById(amsMaintenance);
        return ResultBody.ok();
    }

    @Override
    public ResultBody<String> save(AmsMaintenance_bak amsMaintenance) {
        amsMaintenance.setId(codeGenApi.getCodeByTableName(TableCodeRule.MAINTENANCE));
        amsMaintenance.setCreatedTime(new Date());
        amsMaintenance.setUpdatedTime(new Date());
        amsMaintenance.setVersion(CommonConstants.DEFAULT_VERSION);
        amsMaintenance.setDeleteMark(DeleteMarkConstant.NOT_DELETED);
        amsMaintenanceMapper_bak.insert(amsMaintenance);
        return ResultBody.ok();
    }

//    private String assetIdExists(String assetId) {
//        String errorMsg = null;
//        if (StringUtils.isNotBlank(assetId)) {
//            if (isStartWithCodePrefix(assetId)) {
//                String serialStr = assetId.substring(AssetConstant.PREFIX_LEN);
//                if (serialStr.length() != AssetConstant.SERIAL_LEN) {
//                    errorMsg = "资产顺序位长度错误";
//                    return errorMsg;
//                }
//                switch (assetId.substring(0, AssetConstant.PREFIX_LEN)) {
//                    case AssetConstant.SM_PREFIX:
//                        ResultBody<HardwareVO> hardwareVOResultBody = amsHardwareService.getById(assetId);
//                        if (!hardwareVOResultBody.isOk()) {
//                            errorMsg = "资产不存在";
//                        } else {
//                            errorMsg = hardwareVOResultBody.getData() == null ? "资产不存在" : "";
//                        }
//                        break;
//                    case AssetConstant.SW_PREFIX:
//                        ResultBody<SoftwareVO> softwareVOResultBody = amsSoftwareService.getById(assetId);
//                        if (!softwareVOResultBody.isOk()) {
//                            errorMsg = "资产不存在";
//                        } else {
//                            errorMsg = softwareVOResultBody.getData() == null ? "资产不存在" : "";
//                        }
//                        break;
//                    default:
//                        errorMsg = "资产不存在";
//                }
//            } else {
//                errorMsg = "资产不存在";
//            }
//        }
//        return errorMsg;
//    }



    @Override
    public ResultBody<String> removeById(MaintenanceDeleteBO_bak bo) {
        AmsMaintenance_bak amsMaintenance = new AmsMaintenance_bak();
        amsMaintenance.setId(bo.getId());
        amsMaintenance.setDeleteMark(DeleteMarkConstant.DELETED);
        amsMaintenance.setUpdatedBy(bo.getUpdatedBy());
        amsMaintenance.setUpdatedTime(new Date());
        amsMaintenance.setVersion(bo.getVersion());
        amsMaintenanceMapper_bak.updateById(amsMaintenance);
        return ResultBody.ok();
    }

    @Override
    public ResultBody<String> bindAsset(MaintenanceBindHardwareBO_bak bo) {
        AmsMaintenance_bak amsMaintenance = new AmsMaintenance_bak();
        amsMaintenance.setId(bo.getId());
        amsMaintenance.setAssetId(bo.getAssetId());
        amsMaintenance.setUpdatedBy(bo.getUpdatedBy());
        amsMaintenance.setUpdatedTime(new Date());
        amsMaintenance.setVersion(bo.getVersion());
        amsMaintenanceMapper_bak.updateById(amsMaintenance);
        return ResultBody.ok();
    }

    @Override
    public ResultBody<String> importData(MultipartFile multipartFile, HttpServletRequest req) {
        return null;
    }

    @Override
    public void exportData(PageRequest pageRequest, HttpServletResponse response) {

    }

    @Override
    public ResultBody<String> upload(List<MultipartFile> files, String id, Integer version, String updatedBy, Boolean removeAndSave) {
        if (CollectionUtil.isEmpty(files)) {
            return ResultBody.failed().msg("文件不能为空！");
        }
        String localPath = ftpBasePath + ftpPath;
        if (System.getProperty("os.name").toLowerCase().contains("windows")) {
            localPath = "upload/contract/";
        }
        // 判断文件保存目录是否存在，不存在则创建相关目录
        File tempFile = new File(localPath);
        if (!tempFile.exists()) {
            tempFile.mkdirs();
        }
        // 链接预览服务器
        ChannelSftp connect;
        try {
            connect = FileUtils.connect(ftpHost, Integer.parseInt(ftpPort), ftpUsername, ftpPassword);
        } catch (JSchException e) {
            return ResultBody.failed().msg(e.getMessage());
        }
        List<String> filePathList = new ArrayList<>();
        List<String> fileNameList = new ArrayList<>();
        List<Long> fileSizeList = new ArrayList<>();
        List<String> fileTypeList = new ArrayList<>();
        for (MultipartFile file : files) {
            OutputStream os = null;
            InputStream inputStream = null;
            LocalDateTime now = LocalDateTime.now();
            String curTime = now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            String originalFilename = file.getOriginalFilename();
            if (StringUtils.isNotBlank(originalFilename)) {
                fileNameList.add(originalFilename.substring(0, originalFilename.lastIndexOf(".")));
                fileSizeList.add(file.getSize());
                fileTypeList.add(originalFilename.substring(originalFilename.lastIndexOf(".") + 1));
            }
            String fileName = curTime + "_" + originalFilename;
            String localFilePath = localPath + fileName;
            try {
                inputStream = file.getInputStream();
                os = Files.newOutputStream(Paths.get(localFilePath));
                // 开始读取
                byte[] bs = new byte[1024];
                // 读取数据
                int length;
                while ((length = inputStream.read(bs)) != -1) {
                    os.write(bs, 0, length);
                }
            } catch (IOException e) {
                return ResultBody.failed().msg("文件上传异常！" + e.getMessage());
            }
            // 关闭所有链接
            try {
                os.close();
                inputStream.close();
            } catch (IOException e) {
                return ResultBody.failed().msg(e.getMessage());
            }
            // File localFile = new File(localFilePath);
            // if (localFile.exists()) {
            //     localFile.delete();
            // }
            filePathList.add("http://" + ftpHost + ":" + urlPort + "/" + ftpPath + fileName);
        }
        // 关闭ssh
        connect.disconnect();

        AmsMaintenance_bak selectById = amsMaintenanceMapper_bak.selectById(Integer.parseInt(id.substring(AssetConstant.M_PREFIX.length())));
        if (removeAndSave) {
            if (selectById.getFileId() != null) {
                AmsFilePath amsFilePath = amsFilePathsService.getById(selectById.getFileId());
                amsFilePath.setUpdatedBy(updatedBy);
                amsFilePath.setUpdatedTime(new Date());
                amsFilePath.setActivity(ActivityConstant.INACTIVITY_BOOL);
                amsFilePathsService.updateById(amsFilePath);
            }
            if (saveFileInfo(id, version, updatedBy, filePathList, fileNameList, fileSizeList, fileTypeList)) {
                return ResultBody.failed().msg("文件上传失败！");
            }
        } else {
            if (selectById.getFileId() == null) {
                if (saveFileInfo(id, version, updatedBy, filePathList, fileNameList, fileSizeList, fileTypeList)) {
                    return ResultBody.failed().msg("文件上传失败！");
                }
            } else {
                AmsFilePath amsFilePath = amsFilePathsService.getById(selectById.getFileId());
                amsFilePath.setFileName(CollectionUtil.isNotEmpty(fileNameList) ?
                        amsFilePath.getFileName() + "," + CollectionUtil.join(fileNameList, ",") : amsFilePath.getFileName());
                amsFilePath.setFilePath(CollectionUtil.isNotEmpty(filePathList) ?
                        amsFilePath.getFilePath() + "," + CollectionUtil.join(filePathList, ",") : amsFilePath.getFilePath());
                amsFilePath.setFileSize(CollectionUtil.isNotEmpty(fileSizeList) ?
                        amsFilePath.getFileSize() + "," + CollectionUtil.join(fileSizeList, ",") : amsFilePath.getFileSize());
                amsFilePath.setFileType(CollectionUtil.isNotEmpty(fileTypeList) ?
                        amsFilePath.getFileType() + "," + CollectionUtil.join(fileTypeList, ",") : amsFilePath.getFileType());
                amsFilePath.setUpdatedBy(updatedBy);
                amsFilePath.setUpdatedTime(new Date());
                amsFilePathsService.updateById(amsFilePath);
            }
        }
        return ResultBody.ok();
    }

    @Override
    public Boolean isExistFilePath(Integer id) {
        LambdaQueryWrapper<AmsMaintenance_bak> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AmsMaintenance_bak::getFileId, id);
        queryWrapper.eq(AmsMaintenance_bak::getActivity, ActivityConstant.ACTIVITY_BOOL);
        queryWrapper.eq(AmsMaintenance_bak::getDeleteMark, DeleteMarkConstant.NOT_DELETED);
        List<AmsMaintenance_bak> amsMaintenances = amsMaintenanceMapper_bak.selectList(queryWrapper);
        return CollectionUtil.isNotEmpty(amsMaintenances);
    }

    @Override
    public List<String> listAssetIdSelectBySearch(String searchKey) {
        List<String> hardwordIdList = amsMaintenanceMapper_bak.findHardwordIdList(searchKey);
        List<String> softIdList = amsMaintenanceMapper_bak.findSoftIdList(searchKey);
        ArrayList<String> list = new ArrayList<>();
        list.addAll(hardwordIdList);
        list.addAll(softIdList);
        return list;
    }

//    @Override
//    public ResultBody<List<KeyValueParam<String, String>>> listAssetIdSelectBySearch(String searchKey) {
//        List<KeyValueParam<String, String>> list = new ArrayList<>();
//        if (searchKey.startsWith(AssetConstant.SM_PREFIX) || searchKey.startsWith(AssetConstant.M_PREFIX)) {
//            listHardwareIdSelectBySearch(searchKey, list);
//        } else if (searchKey.startsWith(AssetConstant.SW_PREFIX) || searchKey.startsWith(AssetConstant.W_PREFIX)) {
//            listSoftwareIdSelectBySearch(searchKey, list);
//        } else {
//            listHardwareIdSelectBySearch(searchKey, list);
//            listSoftwareIdSelectBySearch(searchKey, list);
//        }
//        return ResultBody.ok().data(list);
//    }

    private void listSoftwareIdSelectBySearch(String searchKey, List<KeyValueParam<String, String>> list) {
//        List<AmsSoftware> amsSoftwareList = amsSoftwareService.listSoftwareIdBySearch(searchKey);
//        if (CollectionUtil.isNotEmpty(amsSoftwareList)) {
//            amsSoftwareList.forEach(item -> {
//                KeyValueParam<String, String> keyValueParam = new KeyValueParam<>();
//                keyValueParam.setKey(item.getId());
//                keyValueParam.setValue(item.getId());
//                list.add(keyValueParam);
//            });
//        }
    }

    private void listHardwareIdSelectBySearch(String searchKey, List<KeyValueParam<String, String>> list) {
        List<AmsHardware> amsHardwareList = amsHardwareService.listHardwareIdBySearch(searchKey);
        if (CollectionUtil.isNotEmpty(amsHardwareList)) {
            amsHardwareList.forEach(item -> {
                KeyValueParam<String, String> keyValueParam = new KeyValueParam<>();
                keyValueParam.setKey(item.getId());
                keyValueParam.setValue(item.getId());
                list.add(keyValueParam);
            });
        }
    }

    private boolean saveFileInfo(String id, Integer version, String updatedBy, List<String> filePathList,
                                 List<String> fileNameList, List<Long> fileSizeList, List<String> fileTypeList) {
        ResultBody<Integer> fileSaveResultBody = amsFilePathsService.saveFilePath(filePathList, fileNameList,
                fileSizeList, fileTypeList, updatedBy);
        if (!fileSaveResultBody.isOk()) {
            return true;
        }
        AmsMaintenance_bak amsMaintenance = new AmsMaintenance_bak();
        amsMaintenance.setId(id);
        amsMaintenance.setVersion(version);
        amsMaintenance.setFileId(fileSaveResultBody.getData());
        amsMaintenance.setUpdatedBy(updatedBy);
        amsMaintenance.setUpdatedTime(new Date());
        amsMaintenanceMapper_bak.updateById(amsMaintenance);
        return false;
    }
}




