package com.smc.service.supplier;

import com.github.pagehelper.PageInfo;
import com.smc.api.dto.SupplierDTO;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.supplier.vo.SuppliersVO;
import com.smc.dataobject.supplier.AmsSuppliers;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
* @author C31909
* @description 针对表【ams_suppliers】的数据库操作Service
* @createDate 2024-07-22 09:46:05
*/
public interface AmsSuppliersService {

    List<SupplierDTO> listByIds(List<Integer> supplierId);

    AmsSuppliers getSupplierInfo(String supplier);

    ResultBody<PageInfo<SuppliersVO>> page(PageRequest pageRequest);

    ResultBody<String> editById(AmsSuppliers model);

    ResultBody<String> add(AmsSuppliers model);

    ResultBody<String> delete(AmsSuppliers model);

    ResultBody<String> importData(MultipartFile multipartFile, HttpServletRequest req);

    void exportData(PageRequest pageRequest, HttpServletResponse response);

    ResultBody<List<SuppliersVO>> listBySearch(String searchKey);

    ResultBody<SuppliersVO> getById(Integer id);

    ResultBody<List<SuppliersVO>> listAllSupplierVO();
}
