package com.smc.controller.maintenance;

import com.smc.common.model.page.PageRequest;
import com.smc.common.model.page.PageResult;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.maintenance.bo.MaintenanceAddBO;
import com.smc.controller.maintenance.bo.MaintenanceDeleteBO;
import com.smc.controller.maintenance.bo.MaintenanceEditBO;
import com.smc.dataobject.maintenance.AmsMaintenance;
import com.smc.service.maintenance.AmsMaintenanceService;
import com.smc.utils.WebUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/20
 * @description
 */
@CrossOrigin
@RestController
@RequestMapping("/maintenance")
public class AmsMaintenanceController {

    @Resource
    private AmsMaintenanceService amsMaintenanceService;

    @PostMapping("/list")
    public ResultBody<PageResult> page(@RequestBody PageRequest pageRequest) {
        PageResult res = amsMaintenanceService.selectPage(pageRequest);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody MaintenanceEditBO model) {
        String res = amsMaintenanceService.editById(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody MaintenanceAddBO model) {
        String res = amsMaintenanceService.add(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/delete")
    public ResultBody<String> delete(@RequestBody MaintenanceDeleteBO model) {
        String res = amsMaintenanceService.delete(model);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/export")
    public void export(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        amsMaintenanceService.export(pageRequest, response);
    }

    @PostMapping("/importExcel")
    public ResultBody<String> importExcel(@RequestParam("multipartFile") MultipartFile file, HttpServletRequest request) {
        Map<String, String> res = amsMaintenanceService.importExcel(file, request);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/findMaintenanceList")
    public ResultBody<List<String>> findMaintenanceList(@RequestParam("data") String data) {
        List<String> res = amsMaintenanceService.findMaintenanceList(data);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }

    @PostMapping("/getMaintenanceExpiration")
    public ResultBody<PageResult> getMaintenanceExpiration(@RequestBody PageRequest pageRequest) {
        PageResult res = amsMaintenanceService.getMaintenanceExpiration(pageRequest);
        return ResultBody.ok().data(res).path(WebUtils.getUri());
    }


}
