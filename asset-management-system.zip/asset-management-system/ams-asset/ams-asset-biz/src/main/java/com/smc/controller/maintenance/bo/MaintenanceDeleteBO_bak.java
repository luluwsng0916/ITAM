package com.smc.controller.maintenance.bo;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName VirtualPoolDeleteBO
 * @description:
 * @author: C31909
 * @create: 2024-07-30 09:13
 * @Version 1.0
 **/
@Data
public class MaintenanceDeleteBO_bak {
    private String id;
    private String updatedBy;
    private Integer version;
}
