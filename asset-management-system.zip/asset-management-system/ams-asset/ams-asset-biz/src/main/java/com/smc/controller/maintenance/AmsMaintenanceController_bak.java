package com.smc.controller.maintenance;

import com.github.pagehelper.PageInfo;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.controller.maintenance.bo.MaintenanceBindHardwareBO_bak;
import com.smc.controller.maintenance.bo.MaintenanceDeleteBO_bak;
import com.smc.controller.maintenance.bo.MaintenanceEditBO_bak;
import com.smc.controller.maintenance.vo.MaintenanceVO_bak;
import com.smc.dataobject.maintenance.AmsMaintenance_bak;
import com.smc.service.maintenance.AmsMaintenanceService_bak;
import com.smc.utils.WebUtils;
import org.springframework.util.unit.DataSize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @program: asset-management-system
 * @ClassName AmsMaintenanceController
 * @description:
 * @author: C31909
 * @create: 2024-08-01 09:12
 * @Version 1.0
 **/
@CrossOrigin
@RestController
@RequestMapping("/maintenance_bak")
public class AmsMaintenanceController_bak {

    @Resource
    private AmsMaintenanceService_bak amsMaintenanceService;


    @PostMapping("/list")
    public ResultBody<PageInfo<MaintenanceVO_bak>> page(@RequestBody PageRequest pageRequest) {
        return amsMaintenanceService.listByPage(pageRequest);
    }


    @PostMapping("/edit")
    public ResultBody<String> update(@RequestBody MaintenanceEditBO_bak model) {
        return amsMaintenanceService.updateById(model);
    }

    @PostMapping("/save")
    public ResultBody<String> save(@RequestBody AmsMaintenance_bak model) {
        return amsMaintenanceService.save(model);
    }

    @PostMapping("/delete")
    public ResultBody<String> removeById(@RequestBody MaintenanceDeleteBO_bak model) {
        return amsMaintenanceService.removeById(model);
    }

    @PostMapping("/bind-asset")
    public ResultBody<String> bindHardware(@RequestBody MaintenanceBindHardwareBO_bak bo) {
        return amsMaintenanceService.bindAsset(bo);
    }

    @PostMapping("/import")
    public ResultBody<String> importData(@RequestParam(value = "multipartFile", required = false)
                                         MultipartFile multipartFile, HttpServletRequest req) {
        return amsMaintenanceService.importData(multipartFile, req);
    }

    @PostMapping("/export")
    public void exportData(@RequestBody PageRequest pageRequest, HttpServletResponse response) throws IOException {
        amsMaintenanceService.exportData(pageRequest, response);
    }

    /**
     * 文件上传接口
     *
     * @param files 文件列表，包含所有要上传的文件
     * @param id 维保编码
     * @param version 维保的版本号，用于控制版本更新
     * @param updatedBy 更新文件的用户标识
     * @param removeAndSave 是否在上传后删除源文件并保存到数据库中
     * @return 返回上传结果，包括成功与否和相关消息
     */
    @PostMapping("/upload")
    public ResultBody<String> upload(@RequestParam("files") List<MultipartFile> files,
                                     @RequestParam("id") String id,
                                     @RequestParam("version") Integer version,
                                     @RequestParam("updatedBy") String updatedBy,
                                     @RequestParam("removeAndSave")  Boolean removeAndSave
                                     )   {
        // 定义上传文件的总大小限制为100MB
        long maxSize = 100 * 1024 * 1024;
        // 初始化上传文件的总大小为0
        long totalSize = 0;
        // 遍历文件列表，检查每个文件的大小并计算总大小
        for (MultipartFile file : files) {
            // 如果文件总大小超过限制，则返回错误信息
            if (totalSize > maxSize){
                return ResultBody.failed().msg("文件总大小不能超过100M");
            }
            // 定义单个文件大小限制为20MB，并检查当前文件大小是否超过限制
            DataSize dataSize = DataSize.ofMegabytes(20);
            if (file.getSize() > dataSize.toBytes()){
                // 如果单个文件大小超过限制，则返回错误信息
                return ResultBody.failed().msg("单个文件大小不能超过20M");
            }
            // 累加当前文件大小到总大小
            totalSize += file.getSize();
        }
        // 调用服务层方法进行文件上传操作
        return amsMaintenanceService.upload(files, id, version, updatedBy,removeAndSave);
    }

    @PostMapping("/listAssetIdSelectBySearch")
    public ResultBody<List<String>> listAssetIdSelectBySearch(@RequestParam("searchKey") String searchKey){
        return ResultBody.ok().data(amsMaintenanceService.listAssetIdSelectBySearch(searchKey)).path(WebUtils.getUri());
    }

}
