package com.smc.controller.asset.bo;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName HardwareBindSupplierBO
 * @description:
 * @author: C31909
 * @create: 2024-07-25 14:33
 * @Version 1.0
 **/
@Data
public class HardwareBindSupplierBO {
    private String id;
    private Integer supplierId;
    private String updatedBy;
    private Integer version;
}
