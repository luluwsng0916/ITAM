package com.smc.dataobject.system;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * @author C31908
 * @version 1.0.0
 * @data 2024/9/9
 * @description
 */
@TableName(value = "ams_service")
@Data
public class AmsService extends AbstractEntity implements Serializable {

    private static final long serialVersionUID = 662951445927712772L;
    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private String id;
    /**
     * 合同编号
     */
    private String contractNo;
    /**
     * 禀议裁决号
     */
    private String applyRulingNo;
    /**
     * 禀议书主旨及内容
     */
    private String applyContent;
    /**
     * 服务名称
     */
    private String serviceName;
    /**
     * 分类
     */
    private String serviceType;
    /**
     * 所属公司
     */
    private String company;
    /**
     * 管理担当
     */
    private String manager;
    /**
     * 含税金额
     */
    private String taxInclusiveAmount;
    /**
     * 供应商名称
     */
    private String supplierName;
    /**
     * 起始日期
     */
    private String startDate;
    /**
     * 终止日期
     */
    private String endDate;
    /**
     * 备注
     */
    private String remark;
}
