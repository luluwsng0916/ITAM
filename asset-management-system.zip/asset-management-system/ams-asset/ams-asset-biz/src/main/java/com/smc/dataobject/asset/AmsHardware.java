package com.smc.dataobject.asset;


import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 硬件
 *
 * @author C31909
 * @since 1.0.0 2024-07-10
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "ams_hardware")
@Data
public class AmsHardware extends AbstractEntity implements Serializable {
    /**
     * 内部编号
     */
    @TableId(value = "id", type = IdType.INPUT)
    private String id;

    /**
     * 卡片别,通用代码
     */
    @TableField(value = "companyCode")
    private Integer companyCode;
    /**
     * 资产编号
     */
    @TableField(value = "assetNum")
    private String assetNum;

    /**
     * 序列号
     */
    @TableField(value = "serialNum")
    private String serialNum;

    /**
     * 资产名称
     */
    @TableField(value = "assetName")
    private String assetName;

    /**
     * 分类,通用代码
     */
    @TableField(value = "category")
    private Integer category;

    /**
     * 型号
     */
    @TableField(value = "model")
    private String model;

    /**
     * 本币原值
     */
    @TableField(value = "homeCurrencyValue")
    private String homeCurrencyValue;

    /**
     * 部门代码
     */
    @TableField(value = "deptCode")
    private String deptCode;

    /**
     * 存放地点
     */
    @TableField(value = "place")
    private String place;

    /**
     * 具体位置
     */
    @TableField(value = "detailPlace")
    private String detailPlace;

    /**
     * 是否使用
     */
    @TableField(value = "used")
    private String used;

    /**
     * 开始使用日期
     */
    @DateTimeFormat("yyyy-MM-dd")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    @TableField(value = "startDate")
    private Date startDate;

    /**
     * 供应商，供应商ID
     */
    @TableField(value = "supplierId")
    private Integer supplierId;

    /**
     * 生成厂商,通用代码
     */
    @TableField(value = "brand")
    private Integer brand;

    /**
     * 禀议号
     */
    @TableField(value = "applyId")
    private String applyId;

    /**
     * 是否报废
     */
    @TableField(value = "scrapped")
    private Boolean scrapped;

    /**
     * 报废日期
     */
    @TableField(value = "scrapDate")
    @DateTimeFormat("yyyy-MM-dd")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    private Date scrapDate;

    /**
     * 物理机IP
     */
    @TableField(value = "ip")
    private String ip;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    /**
     * 资产管理担当
     */
    @TableField(value = "manager")
    private String manager;
}