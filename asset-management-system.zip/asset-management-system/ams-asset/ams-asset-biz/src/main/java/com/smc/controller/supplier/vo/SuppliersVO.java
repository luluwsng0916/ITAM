package com.smc.controller.supplier.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.smc.convert.easyexcel.DateConverter;
import lombok.Data;

import java.util.Date;

/**
 * @program: asset-management-system
 * @ClassName SuppliersVO
 * @description:
 * @author: C31909
 * @create: 2024-07-24 14:11
 * @Version 1.0
 **/
@Data
public class SuppliersVO {

    @ExcelIgnore
    private Integer id;

    /**
     * 供应商名称
     */
    @ExcelProperty(value = "供应商名称")
    private String name;

    /**
     * 联系人
     */
    @ExcelProperty(value = "联系人")
    private String contactPerson;

    /**
     * 联系电话
     */
    @ExcelProperty(value = "联系电话")
    private String phone;

    /**
     * 电子邮箱
     */
    @ExcelProperty(value = "邮箱")
    private String email;

    /**
     * 地址
     */
    @ExcelProperty(value = "地址")
    private String address;

    /**
     * 供应商描述
     */
    @ExcelProperty(value = "备注")
    private String remark;
    @ExcelProperty(value = "有效性")
    private String activity;

    @ExcelIgnore
    private Integer version;

    @ExcelProperty(value = "创建者")
    private String createdBy;
    /**
     * 创建时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "创建时间", converter = DateConverter.class)
    @ColumnWidth(25)
    public Date createdTime;

    @ExcelProperty(value = "更新者")
    private String updatedBy;

    /**
     * 修改时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "更新时间", converter = DateConverter.class)
    @ColumnWidth(25)
    public Date updatedTime;

}
