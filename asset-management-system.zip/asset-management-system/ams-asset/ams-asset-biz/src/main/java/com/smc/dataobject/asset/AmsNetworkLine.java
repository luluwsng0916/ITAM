package com.smc.dataobject.asset;

import com.baomidou.mybatisplus.annotation.*;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;

import java.io.Serializable;

@TableName(value = "ams_network_line")
@Data
public class AmsNetworkLine extends AbstractEntity implements Serializable {

    /**
     * @description: 序号（excel手动排序序号）
     * @author: C31908
     * @date: 2025/8/21
     **/
    @TableField(value = "sort")
    private String sort;
    /**
     * 专线编号
     */
    @TableField(value = "networkLineId")
    private String networkLineId;
    /**
     * 专线名称
     */
    @TableId(value = "networkLineName", type = IdType.INPUT)
    private String networkLineName;
    /**
     * 专线类别
     */
    @TableField(value = "networkLineType")
    private String networkLineType;
    /**
     * 地点
     */
    @TableField(value = "place")
    private String place;
    /**
     * 带宽
     */
    @TableField(value = "bandwidth")
    private String bandwidth;
    /**
     * 月租费用
     */
    @TableField(value = "monthlyFee")
    private String monthlyFee;
    /**
     * 一次性施工费用
     */
    @TableField(value = "oneTimeFee")
    private String oneTimeFee;
    /**
     * 协议金额（元/年）
     */
    @TableField(value = "agreementMoney")
    private String agreementMoney;
    /**
     * 供应商名称
     */
    @TableField(value = "supplierName")
    private String supplierName;
    /**
     * 起始日期
     */
    @TableField(value = "startDate")
    private String startDate;
    /**
     * 终止日期
     */
    @TableField(value = "endDate")
    private String endDate;
    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

}
