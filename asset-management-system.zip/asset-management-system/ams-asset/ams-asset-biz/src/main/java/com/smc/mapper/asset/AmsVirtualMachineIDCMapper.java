package com.smc.mapper.asset;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smc.dataobject.asset.AmsVirtualMachineIDC;

import java.util.HashMap;
import java.util.List;

/**
 *
 * @author C31908
 * @version 1.0.0
 * @description
 */
public interface AmsVirtualMachineIDCMapper extends BaseMapper<AmsVirtualMachineIDC> {

    List<AmsVirtualMachineIDC> findAll(HashMap<String, Object> map);
}
