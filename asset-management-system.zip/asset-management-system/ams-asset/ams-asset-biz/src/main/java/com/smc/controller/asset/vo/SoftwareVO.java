package com.smc.controller.asset.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.smc.convert.easyexcel.DateConverter;
import lombok.Data;

import java.util.Date;

/**
 * @program: asset-management-system
 * @ClassName SoftwareVO
 * @description:
 * @author: C31909
 * @create: 2024-08-01 11:07
 * @Version 1.0
 **/
@Data
public class SoftwareVO {
    /**
     * 内部主键
     */
    @ExcelProperty(value = "内部主键")
    private String id;

    /**
     * 名称
     */
    @ExcelProperty(value = "名称")
    private String name;

    /**
     * 软件版本
     */
    @ExcelProperty(value = "软件版本")
    private String softVersion;

    /**
     * 软件许可证
     */
    @ExcelProperty(value = "软件许可证")
    private String licenseKey;

    /**
     * 购买日期
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "购买日期")
    @ColumnWidth(25)
    private String purchaseDate;

    /**
     * 过期日期
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "有效期")
    @ColumnWidth(25)
    private String expirationDate;

    /**
     * 有效性
     */
    @ExcelProperty(value = "有效性")
    private String activity;

    /**
     * 备注
     */
    @ExcelProperty(value = "备注")
    private String remark;

    @ExcelIgnore
    private Integer version;


    @ExcelProperty(value = "创建者")
    private String createdBy;
    /**
     * 创建时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "创建时间", converter = DateConverter.class)
    @ColumnWidth(25)
    public Date createdTime;

    @ExcelProperty(value = "更新者")
    private String updatedBy;

    /**
     * 修改时间
     */
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "更新时间", converter = DateConverter.class)
    @ColumnWidth(25)
    public Date updatedTime;
}
