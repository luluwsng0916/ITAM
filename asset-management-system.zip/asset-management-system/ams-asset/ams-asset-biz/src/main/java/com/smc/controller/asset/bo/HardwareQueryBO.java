package com.smc.controller.asset.bo;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName HardwareEditBO
 * @description:
 * @author: C31909
 * @create: 2024-07-23 09:26
 * @Version 1.0
 **/
@Data
public class HardwareQueryBO {
    /**
     * 内部编号
     */
    private String id;
    /**
     * 资产名称
     */
    private String assetName;
}
