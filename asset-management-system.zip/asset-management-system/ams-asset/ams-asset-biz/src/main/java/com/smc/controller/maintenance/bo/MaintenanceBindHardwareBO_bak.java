package com.smc.controller.maintenance.bo;

import lombok.Data;

/**
 * @program: asset-management-system
 * @ClassName VirtualPoolBindHardwareBO
 * @description:
 * @author: C31909
 * @create: 2024-07-30 09:21
 * @Version 1.0
 **/
@Data
public class MaintenanceBindHardwareBO_bak {
    private String id;
    private String assetId;
    private String updatedBy;
    private Integer version;
}
