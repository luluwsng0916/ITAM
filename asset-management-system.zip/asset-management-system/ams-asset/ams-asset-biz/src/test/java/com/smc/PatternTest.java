package com.smc;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.smc.common.constants.PatternConstant;
import org.junit.Test;

import java.util.regex.Pattern;

/**
 * @program: asset-management-system
 * @ClassName PatternTest
 * @description:
 * @author: C31909
 * @create: 2024-08-05 11:19
 * @Version 1.0
 **/

public class PatternTest {

    @Test
    public void test() {
        // String str = "127.0.0.1";
        String str = "40300.00";
        // String str = "2024-4-32";
        // Pattern compile = Pattern.compile(PatternConstant.IPV4);
        // Pattern compile = Pattern.compile("^(\\d{4})-(\\d{2})-(\\d{2})$");
        Pattern compile = Pattern.compile(PatternConstant.POSITIVE_NUMBER);
        System.out.println(compile.matcher(str).matches());
        // DateTime parse = DateUtil.parse(str, DatePattern.NORM_DATE_PATTERN);
        // System.out.println(parse);
    }

}
