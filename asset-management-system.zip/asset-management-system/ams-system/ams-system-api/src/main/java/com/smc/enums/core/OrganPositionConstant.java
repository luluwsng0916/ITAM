package com.smc.enums.core;

/**
 * @author C31909
 * @version 0.1
 */
public interface OrganPositionConstant {
    /**
     * 组织岗位树状数据redis对应KEY
     */
    String REDIS_KEY_ORGANIZATION = "mdm:orgPositionTree";
    /**
     * 一天过期时间
     */
    Long REDIS_EXPIRATION_TIME = (long) (60 * 60 * 24);
}
