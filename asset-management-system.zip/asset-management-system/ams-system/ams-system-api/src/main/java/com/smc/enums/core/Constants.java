package com.smc.enums.core;

/**
 * @Descripton: 常量类
 * @Classname: Constants
 * @Author B82561
 * @Date 2018年11月8日
 */
public class Constants extends com.smc.base.constants.Constants {

	public static final String RESOURCE = "资源";

	public static final String MENU = "菜单";

	public static final String AUTHORITY = "权限";
	
	public static final String GROUP = "用户组";

	public static final String ROLE = "角色";

	public final static int CODE_DIGIT = 3;

	public final static String USER_STAUS_NO_OPEN = "未开通";

	public final static String USER_STAUS_SUSPEND = "已暂停";

	public final static String USER_STAUS_ACTIVE = "已激活";

	/**
	 * 日期格式化yyyyMMdd
	 */
	public static final String DATE_FORMATE = "yyyyMM";
	
	/**
	 * 密码错误次数
	 */
	public static final Integer PASSWORD_ERROR_COUNT = 5;
	
	/**
	 * 密码锁定时间
	 */
	public static final Integer PASSWORD_LOCK_TIME = 30;
	
	/**
	 * 微信OPENID绑定用户有效期30天
	 */
	public static final Integer WECHAT_OPENID_BIND_USER_DAYS = 30;
	
	/**
	 * 按部门
	 */
	public static final String DATA_AUTHORITY_TYPE_BY_DEPT = "1";
	
	/**
	 * 按员工
	 */
	public static final String DATA_AUTHORITY_TYPE_BY_STAFF = "2";
	
	/**
	 * 按客户
	 */
	public static final String DATA_AUTHORITY_TYPE_BY_CUSTOMER = "3";
	
	
	/**
	 * 自定义
	 */
	public static final String DATA_AUTHORITY_TYPE_BY_CUSTOM = "4";
	
	
	/**
	 * 全部
	 */
	public static final String DATA_AUTHORITY_TYPE_ALL = "5";
	/**
	 * HOLON标记
	 */
	public static final String HOLON_LEVEL = "HL";
	
}
