package com.smc.enums.auth;

public class AdConstants {
	/**
	 * ad域错误码 525
	 */
	public static final String ERROR_CODE_525 = "525";

	/**
	 * ad域错误码 52e
	 */
	public static final String ERROR_CODE_52e = "52e";

	/**
	 * ad域错误码 530
	 */
	public static final String ERROR_CODE_530 = "530";

	/**
	 * ad域错误码 531
	 */
	public static final String ERROR_CODE_531 = "531";

	/**
	 * ad域错误码 532
	 */
	public static final String ERROR_CODE_532 = "532";

	/**
	 * ad域错误码 533
	 */
	public static final String ERROR_CODE_533 = "533";

	/**
	 * ad域错误码 701
	 */
	public static final String ERROR_CODE_701 = "701";

	/**
	 * ad域错误码773
	 */
	public static final String ERROR_CODE_773 = "773";

	/**
	 * ad域错误码 775
	 */
	public static final String ERROR_CODE_775 = "775";
}
