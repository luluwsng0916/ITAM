package com.smc.mapper.core;

import com.smc.dataobject.core.Authority;

import java.util.List;
import java.util.Set;


public interface AuthorityCommonDao{

	/**
	 * 根据用户ID获取用户对应的权限
	 * @return
	 */
	public Set<Authority> getByUserId(String userId);
	
	/**
	 * 根据组名称获取用户对应的权限
	 * @return
	 */
	public Set<Authority> getByGroupNames(List<String> list);
}
