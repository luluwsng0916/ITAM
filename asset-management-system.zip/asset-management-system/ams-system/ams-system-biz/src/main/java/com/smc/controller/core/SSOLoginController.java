package com.smc.controller.core;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

@Controller
@RequestMapping(value = "/sso")
public class SSOLoginController {

	@Value("${sso.redirectTo.url}")
	private String redirectTo;

	@Value("${sso.redirectTo.default}")
	private String defaultRedirectTo;

	@RequestMapping(value = "/manufacture", method = RequestMethod.GET)
	public ModelAndView ssoLoginCustoms(HttpServletRequest request) {
		Map<String, Object> reqParams = new HashMap<String, Object>();

		String usernumber = request.getParameter("usernumber");
		String token = request.getParameter("token");
		if (usernumber == null || token == null) {
			return new ModelAndView(new RedirectView(defaultRedirectTo), reqParams);
		} else {
			String[] usernumberArray = decodeBase64(usernumber).split("&");
			if (usernumberArray.length != 2) {
				return new ModelAndView(new RedirectView(defaultRedirectTo), reqParams);
			} else {
				reqParams.put("userId", usernumberArray[0]);
				reqParams.put("usernumber", usernumber);
				reqParams.put("redirectTo", request.getParameter("redirectTo"));
				reqParams.put("token", request.getParameter("token"));
				return new ModelAndView(new RedirectView(redirectTo), reqParams);
			}
		}
	}

	private String decodeBase64(String target) {
		try {
			Base64.Decoder decoder = Base64.getDecoder();

			return new String(decoder.decode(target), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}

}
