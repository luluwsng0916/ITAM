package com.smc.dataobject.core;

import java.io.Serializable;

import com.smc.base.TreeImpl;

public class Authority extends TreeImpl<Authority> implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8618846685650967726L;
	
	/**
	 * 类型: menu表示菜单，resource表示功能，common表示通用（默认绑定）
	 */
	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
