package com.smc.config.auth;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * @author B82443
 */
@Component
public class Start implements CommandLineRunner{
	

	@Override
	public void run(String... args) {
		String keystore;
		String os = System.getProperty("os.name");
		if (os.toLowerCase().startsWith("win")) {
			/**
			 * 如果是Windows系统
			 */
			//keystore = "C:/Program Files/Java/jdk1.8.0_131/jre/lib/security/cacerts";
			keystore = "C:/Program Files/Java/jdk1.8.0_91/jre/lib/security/cacerts_hf";
			System.setProperty("javax.net.ssl.trustStore", keystore);
		} else {
			/**
			 * linux 和mac
			 */
			keystore = "C:/Program Files/Java/jdk1.8.0_131/jre/lib/security/cacerts";
			System.setProperty("javax.net.ssl.trustStore", "");
		}
		System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
		System.out.println(os);
	}
}