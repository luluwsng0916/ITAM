package com.smc.controller.core;

import com.smc.dataobject.core.Resource;
import com.smc.service.core.ResourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping(value="/resource")
@CrossOrigin
public class ResourceController {
	
	@Autowired
	private ResourceService resourceService;
	
	/**
	 * 获取全部节点
	 * @return
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	@ResponseBody
    public List<Resource> findAll() {
		return resourceService.findAll();
    }
	
	/**
	 * 详情
	 * @return
	 */
	@RequestMapping(value = "/detail/{id}", method = RequestMethod.GET)
	@ResponseBody
    public Resource detail(@PathVariable(value = "id") String id) {
		return resourceService.detail(id);
    }
	
	/**
	 * 添加
	 * @return
	 */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
    public Resource add(@RequestBody Resource resource) {
		return resourceService.add(resource);
    }
	
	/**
	 * 更新
	 * @return
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
    public Resource update(@RequestBody Resource form) {
		return resourceService.update(form);
    }
	
	/**
	 * 删除
	 * @return
	 */
	@RequestMapping(value = "/deleteByCode/{code}", method = RequestMethod.POST)
    public void deleteByCode(@PathVariable(value = "code") String code) {
		resourceService.deleteByCode(code);
    }
	
	/**
	 * 通过角色ID获取资源
	 * @return
	 */
	@RequestMapping(value = "/findByRoleId/{roleId}", method = RequestMethod.GET)
	public List<Resource> findByRoleId(@PathVariable(value = "roleId") String roleId){
		return resourceService.findByRoleId(roleId);
	}
	
	
	/**
	 * 根据服务条件获取对应资源
	 * @return
	 */
	@RequestMapping(value = "/findByServicePattern", method = RequestMethod.GET)
    public List<String> findByServicePattern(String pattern) {
		return resourceService.findByServicePattern(pattern);
    }
}
  
