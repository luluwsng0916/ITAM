package com.smc.dataobject.core;

public class NoticeReader {

	private String id;

	private String noticeId;

	private String username;

	private String readStatus;

	public NoticeReader() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNoticeId() {
		return noticeId;
	}

	public void setNoticeId(String noticeId) {
		this.noticeId = noticeId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getReadStatus() {
		return readStatus;
	}

	public void setReadStatus(String readStatus) {
		this.readStatus = readStatus;
	}

	@Override
	public String toString() {
		return "NoticeReader [id=" + id + ", noticeId=" + noticeId + ", username=" + username + ", readStatus="
				+ readStatus + "]";
	}

}
