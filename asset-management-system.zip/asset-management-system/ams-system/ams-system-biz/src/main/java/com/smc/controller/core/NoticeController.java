package com.smc.controller.core;

import com.github.pagehelper.PageInfo;
import com.smc.base.page.Page;
import com.smc.core.condition.NoticeCondition;
import com.smc.core.condition.UnreadUserDetailCondition;
import com.smc.core.exception.CoreExceptionCode;
import com.smc.core.utils.FileDownLoad;
import com.smc.core.utils.FileUtils;
import com.smc.core.utils.ZipUtils;
import com.smc.dataobject.core.Notice;
import com.smc.dataobject.core.NoticeAttachedFile;
import com.smc.enums.core.Constants;
import com.smc.exception.BaseException;
import com.smc.log.annotation.SysLog;
import com.smc.service.core.NoticeAttachedFileService;
import com.smc.service.core.NoticeService;
import com.smc.utils.UUIDGenerator;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipException;

@RestController
@CrossOrigin
public class NoticeController {

	private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);

	@Autowired
	private NoticeService noticeService;

	@Autowired
	private NoticeAttachedFileService noticeAttachedFileService;

	/**
	 * 按用户查询-普通用户
	 * 
	 * @Author B82561
	 * @param username
	 * @return
	 */
	@RequestMapping(value = "/coreNotice/queryByReadPower")
	public PageInfo<Notice> queryByReadPower(@RequestBody NoticeCondition noticeCondition, Page page) {
		return noticeService.queryByReadPower(noticeCondition, page);
	}

	/**
	 * 按条件查询-管理员
	 * 
	 * @Author B82561
	 * @param noticeCondition
	 * @param page
	 * @return
	 */
	@RequestMapping(value = "/coreNotice/query")
	public PageInfo<Notice> query(@RequestBody NoticeCondition noticeCondition, Page page) {
		return noticeService.query(noticeCondition, page);
	}

	/**
	 * 按Id查询公告
	 * 
	 * @Author B82561
	 * @param Id
	 * @return
	 */
	@RequestMapping(value = "/coreNotice/findNoticeById")
	public Notice findNoticeById(String id) {
		return noticeService.findById(id);

	}

	/**
	 * 根据Id获取未读人明细
	 * 
	 * @Author B82561
	 * @param noticeId
	 * @return
	 */
	@RequestMapping(value = "/coreNotice/queryUnreadUserDetailByNoticeId")
	public PageInfo<UnreadUserDetailCondition> queryUnreadUserDetailByNoticeId(String noticeId, Page page) {
		return noticeService.queryUnreadUserDetailByNoticeId(noticeId, page);
	}

	/**
	 * 按公告Id、username更新读取数量 读取状态
	 * 
	 * @Author B82561
	 */
	@RequestMapping(value = "/coreNotice/updateNoticeReadById")
	@SysLog("更新公告读取数量")
	public void updateNoticeReadById(String id, String username) {
		noticeService.updateNoticeReadById(id, username);
	}

	/**
	 * 按id删除公告记录
	 */
	@RequestMapping(value = "/coreNotice/removeNoticeById")
	@SysLog("删除公告")
	public void removeNoticeById(String id) {
		noticeService.removeById(id);
	}

	/**
	 * 按照公告ID查找公告附件
	 * 
	 * @Author B82561
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/coreNotice/findFileByNoticeId")
	public List<NoticeAttachedFile> findFileByNoticeId(String noticeId) {
		return noticeAttachedFileService.findFileByNoticeId(noticeId);
	}

	/**
	 * 按Id删除公告附件
	 * 
	 * @Author B82561
	 * @param id
	 */
	@RequestMapping(value = "/coreNotice/deleteFileByNoticeId")
	@SysLog("删除公告附件")
	public void deleteFileByNoticeId(String noticeId) {
		noticeAttachedFileService.deleteFileByNoticeId(noticeId);
	}

	/**
	 * 建立公告，接收上传附件，插入公告表记录，插入附件表记录
	 * 
	 * @Author B82561
	 * @param request
	 * @param reportFile
	 * @param noticeCondition
	 */
	@RequestMapping(value = "/coreNotice/publishNotice")
	public void publishNotice(HttpServletRequest request, MultipartFile[] reportFile, NoticeCondition noticeCondition) {
		// 设置公告表、附件表关联Id
		String noticeId = UUIDGenerator.getUUID();
		noticeCondition.setId(noticeId);
		// 接收前端上传文件
		List<NoticeAttachedFile> noticeAttachedFiles = new ArrayList<NoticeAttachedFile>();
		for (MultipartFile multipartFile : reportFile) {
			String fileName = multipartFile.getOriginalFilename();
			String suffix = fileName.substring(fileName.lastIndexOf(".") + 1);// 取得真实文件名的后缀
			String randomFileName = UUIDGenerator.getUUID() + "." + suffix;// 生成随机文件名
			String nowDateTime = new DateTime().toString(Constants.DATE_FORMATE);
			String filePath = FileUtils.getPath() + "noticeAttachedFile" + File.separator + nowDateTime
					+ File.separator;
			File targetFile = new File(filePath);
			if (!targetFile.exists()) {
				targetFile.mkdirs();
			}
			File dest = new File(filePath + randomFileName);
			try {
				multipartFile.transferTo(dest);
				// 添加系统附件记录
				NoticeAttachedFile attachedFile = new NoticeAttachedFile();
				attachedFile.setId(UUIDGenerator.getUUID());
				attachedFile.setNoticeId(noticeId);
				attachedFile.setFileName(fileName);
				attachedFile.setRandomFileName(randomFileName);
				attachedFile.setFilePath(filePath);
				noticeAttachedFiles.add(attachedFile);
			} catch (IOException e) {
				logger.error(e.getMessage());
				throw new BaseException(CoreExceptionCode.文件上传错误);
			}
		}
		// 发布公告
		noticeService.publishNotice(noticeCondition, noticeAttachedFiles);
	}

	/**
	 * 文件下载
	 * 
	 * @throws FileNotFoundException
	 * @throws ZipException
	 */
	@RequestMapping(value = "/coreNotice/download")
	public void downloadFile(HttpServletRequest request, HttpServletResponse response, String noticeId) {
		String Path = FileUtils.getPath() + "noticeAttachedFileZip" + File.separator;
		FileUtils.mkdir(Path);// 创建文件夹
		String zipPath = Path + noticeId + ".zip";
		OutputStream out = null;
		try {
			out = new FileOutputStream(zipPath);
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage());
			throw new BaseException(CoreExceptionCode.下载错误);
		}
		List<File> srcFiles = new ArrayList<File>();

		List<NoticeAttachedFile> noticeAttachedFileList = noticeAttachedFileService.findFileByNoticeId(noticeId);
		for (NoticeAttachedFile noticeAttachedFile : noticeAttachedFileList) {
			File oldFile = new File(noticeAttachedFile.getFilePath() + noticeAttachedFile.getRandomFileName());
			File newFile = new File(noticeAttachedFile.getFilePath() + noticeAttachedFile.getFileName());
			oldFile.renameTo(newFile);
			srcFiles.add(newFile);
		}

		try {
			ZipUtils.toZip(srcFiles, out);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BaseException(CoreExceptionCode.下载错误);
		}
		for (NoticeAttachedFile noticeAttachedFile : noticeAttachedFileList) {
			File oldFile = new File(noticeAttachedFile.getFilePath() + noticeAttachedFile.getRandomFileName());
			File newFile = new File(noticeAttachedFile.getFilePath() + noticeAttachedFile.getFileName());
			newFile.renameTo(oldFile);
		}
		File file = new File(zipPath);

		FileDownLoad.fileDownLoading(request, response, file);

	}

}
