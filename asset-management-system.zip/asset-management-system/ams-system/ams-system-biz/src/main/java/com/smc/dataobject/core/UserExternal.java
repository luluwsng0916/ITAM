package com.smc.dataobject.core;

import com.smc.base.BaseEntity;

/**
 * 供应商用户实体类
 * @author B82443
 *
 */
public class UserExternal extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 493699642726198980L;
	
	/**
	 * 用户名
	 */
	private String userName;
	
	/**
	 * 用户密码
	 */
	private String password;
	
	/**
	 * 邮件
	 */
	private String email;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
