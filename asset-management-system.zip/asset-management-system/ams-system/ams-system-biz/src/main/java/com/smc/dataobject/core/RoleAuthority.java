package com.smc.dataobject.core;

import java.io.Serializable;

public class RoleAuthority implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1647841234351979442L;

	/**
	 * 角色ID
	 */
	private String roleId;
	
	/**
	 * 权限ID
	 */
	private String authorityId;

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getAuthorityId() {
		return authorityId;
	}

	public void setAuthorityId(String authorityId) {
		this.authorityId = authorityId;
	}
}
