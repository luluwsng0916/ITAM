package com.smc.config.auth;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 研发域服务器配置
 *
 * @author B82443
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Component
@ConfigurationProperties(prefix = "base.domain.server")
public class DevelopDomainServer extends BaseDomainServer {

    private String authentication;

    private String factoryInitial;

    private String domainName;

}
