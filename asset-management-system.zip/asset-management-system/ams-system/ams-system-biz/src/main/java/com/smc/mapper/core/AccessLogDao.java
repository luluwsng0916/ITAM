package com.smc.mapper.core;

import com.smc.dataobject.core.AccessLog;
import org.apache.ibatis.annotations.Param;

import java.util.List;

// @Mapper
public interface AccessLogDao {
    int insertAccessLog(@Param("accessLog") AccessLog accessLog);

    List<AccessLog> listByPage(@Param("serviceId") String serviceId, @Param("path") String path,
                               @Param("httpStatus") String httpStatus, @Param("beginTime") String beginTime,
                               @Param("endTime") String endTime,
                               @Param("headerId") String headerId);

    int deleteByIds(@Param("list") List<String> ids);

    int deleteByCondition(@Param("serviceId") String serviceId, @Param("path") String path,
                          @Param("httpStatus") String httpStatus, @Param("beginTime") String beginTime,
                          @Param("endTime") String endTime);
}
