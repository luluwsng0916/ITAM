package com.smc.config.auth.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsUtils;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private UserDetailsService userDetailsService;

	protected void configure(HttpSecurity http) throws Exception {
//		http.cors().and().authorizeRequests().anyRequest().authenticated()
//				.requestMatchers(CorsUtils::isPreFlightRequest).permitAll().and().headers().disable().csrf().disable()
//				.formLogin().loginPage("/login.html").loginProcessingUrl("/login").and().logout().permitAll();
		// http.addFilterBefore(authenticationTokenFilter(),UsernamePasswordAuthenticationFilter.class);
		
		http
		.cors().and()
		.headers().disable()
		.csrf().disable()
		.authorizeRequests()
		//.antMatchers(SsoAuthenticationFilter.SSO_LOGIN).permitAll()
		.requestMatchers(CorsUtils::isPreFlightRequest).permitAll()
		.anyRequest().authenticated().and()
        .formLogin()
		.loginPage("/login.html")     
		.loginProcessingUrl("/login")  
		.and().logout().permitAll();

	}

//	@Bean
//	public CorsConfigurationSource corsConfigurationSource() {
//		CorsConfiguration corsConfiguration = new CorsConfiguration();
//		corsConfiguration.addAllowedOrigin("*");
//		// 允许跨域访问的域名该字段必填。它的值要么是请求时Origin字段的具体值，要么是一个*，表示接受任意域名的请求。
//		corsConfiguration.addAllowedHeader("*"); 
//		corsConfiguration.setMaxAge(3600L);
//		// 该字段可选，用来指定本次预检请求的有效期，单位为秒。在有效期间，不用发出另一条预检请求。
//		List<String> list = new ArrayList<String>();
//		list.add("Authorization");
//		corsConfiguration.setExposedHeaders(list);
//		corsConfiguration.addExposedHeader("Authorization");
//		corsConfiguration.setAllowCredentials(false);// 是否支持cookie
//		corsConfiguration.addAllowedMethod(HttpMethod.DELETE);
//		// 它的值是逗号分隔的一个具体的字符串或者*，表明服务器支持的所有跨域请求的方法。
//		corsConfiguration.addAllowedMethod(HttpMethod.POST);
//		corsConfiguration.addAllowedMethod(HttpMethod.GET);
//		corsConfiguration.addAllowedMethod(HttpMethod.PUT);
//		corsConfiguration.addAllowedMethod(HttpMethod.DELETE);
//		corsConfiguration.addAllowedMethod(HttpMethod.OPTIONS);
//		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//		source.registerCorsConfiguration("/**", corsConfiguration);
//		return source;
//	}

	@Bean
	public CorsFilter corsFilter() {
		final UrlBasedCorsConfigurationSource urlBasedCorsConfigurationSource = new UrlBasedCorsConfigurationSource();
		final CorsConfiguration corsConfiguration = new CorsConfiguration();
		corsConfiguration.setAllowCredentials(true);
		corsConfiguration.addAllowedOrigin("*");
		corsConfiguration.addAllowedHeader("*");
		corsConfiguration.addAllowedMethod("*");
		urlBasedCorsConfigurationSource.registerCorsConfiguration("/**", corsConfiguration);
		return new CorsFilter(urlBasedCorsConfigurationSource);
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
//		web.ignoring().antMatchers("/scripts/**");
//		web.ignoring().antMatchers("/login.html");
		web.ignoring().antMatchers("/console/**");
		web.ignoring().antMatchers("/scripts/**");
		web.ignoring().antMatchers("/login.html");
		web.ignoring()
        .antMatchers(
                "/webjars/**",
                "/resources/**",
                "/swagger-ui/index.html",
                "/swagger-resources/**",
                "/**/api-docs");
	}

	@Bean
	public DaoAuthenticationProvider daoAuthenticationProvider() {
		WebDaoAuthenticationProvider daoAuthenticationProvider = new WebDaoAuthenticationProvider();
		daoAuthenticationProvider.setPasswordEncoder(passwordEncoder());
		daoAuthenticationProvider.setHideUserNotFoundExceptions(false);
		daoAuthenticationProvider.setUserDetailsService(userDetailsService);
		return daoAuthenticationProvider;
	}

	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(daoAuthenticationProvider());
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return PasswordEncoderFactories.createDelegatingPasswordEncoder();
	}

	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	/*
	 * @Bean public AuthenticationTokenFilter authenticationTokenFilter() throws
	 * Exception { return new AuthenticationTokenFilter(); }
	 */

}
