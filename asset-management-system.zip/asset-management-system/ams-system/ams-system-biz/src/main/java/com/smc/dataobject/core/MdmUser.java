package com.smc.dataobject.core;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.Date;

@ApiModel(value = "用户表", description = "")
@TableName("s_user")
@Data
public class MdmUser extends AbstractEntity implements Cloneable {
    @TableId
    private String personnelCode;
    private String personnelName;
    private Boolean sex;
    private String cellPhone;
    private String email;
    private String status;
    private Date psnJobdate;
    private Date psnQuitdate;
}
