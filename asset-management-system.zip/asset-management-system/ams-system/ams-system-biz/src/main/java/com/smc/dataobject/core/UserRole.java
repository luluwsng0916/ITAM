package com.smc.dataobject.core;

import java.io.Serializable;

public class UserRole implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1647841234351979442L;
	/**
	 * 用户ID
	 */
	private String userId;
	
	/**
	 * 角色ID
	 */
	private String roleId;
	
	/**
	 * 描述
	 */
	private String description;
	
	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
