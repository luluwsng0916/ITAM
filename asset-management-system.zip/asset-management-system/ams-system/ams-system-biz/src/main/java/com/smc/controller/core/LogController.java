package com.smc.controller.core;

import java.math.BigInteger;
import java.util.List;

import com.smc.service.core.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.smc.base.page.Page;
import com.smc.core.condition.LogCondition;
import com.smc.core.entity.SysLog;

@RestController
@RequestMapping(value="/log")
@CrossOrigin
public class LogController {
	
	@Autowired
	private LogService logService;
	
	/**
	 * 查询
	 * @return
	 */
	@RequestMapping(value = "/query", method = RequestMethod.POST)
    public PageInfo<SysLog> query(@RequestBody LogCondition condition,Page page) {
		return logService.query(condition,page);
    }
	
	/**
	 * 添加
	 * @return
	 */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@ResponseBody
	public void add(@RequestBody SysLog log) {
		logService.addOne(log);
    }
	
	/**
	 * 选中删除
	 * @param idlist
	 * @return
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public void deleteBatchById(@RequestBody List<BigInteger> idList) {
		logService.deleteBatchById(idList);
    }
	
	/**
	 * 全部清除
	 * @param condition
	 * @return
	 */
	@RequestMapping(value = "/deleteAll", method = RequestMethod.POST)
	public void deleteAll(@RequestBody LogCondition condition) {
		logService.deleteAll(condition);
	}

}
  
