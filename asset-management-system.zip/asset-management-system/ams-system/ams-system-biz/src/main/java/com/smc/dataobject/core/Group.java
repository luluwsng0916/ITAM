package com.smc.dataobject.core;

import java.io.Serializable;

import com.smc.base.TreeImpl;

public class Group  extends TreeImpl<Group> implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2087572826238518835L;

}
