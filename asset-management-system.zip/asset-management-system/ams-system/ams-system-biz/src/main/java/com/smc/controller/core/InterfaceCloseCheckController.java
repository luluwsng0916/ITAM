package com.smc.controller.core;

import com.smc.common.model.http.HttpResult;
import com.smc.common.model.page.PageRequest;
import com.smc.dataobject.core.InterfaceCloseCheck;
import com.smc.service.core.InterfaceCloseCheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value="/interfaceCloseCheck")
@CrossOrigin
public class InterfaceCloseCheckController {
	
	@Autowired
	private InterfaceCloseCheckService interfaceCloseCheckService;

	/**
	 * 详情
	 * @return
	 */
	@RequestMapping(value = "/detail/{id}")
	public HttpResult detail(@PathVariable(value = "id") Integer id) {
        return HttpResult.ok(this.interfaceCloseCheckService.getById(id));
    }
	
	/**
	 * 更新redis
	 * @return
	 */
	@RequestMapping(value = "/updateMethodRedis")
	public HttpResult updateMethodRedis() {
        return HttpResult.ok(this.interfaceCloseCheckService.updateMethodRedis());
    }

	/**
	 * 添加
	 * @param interfaceCloseCheck
	 * @return
	 */
	@RequestMapping(value = "/add")
	public HttpResult add(@RequestBody InterfaceCloseCheck interfaceCloseCheck) {
		if(interfaceCloseCheckService.isExist(interfaceCloseCheck)) {
			return HttpResult.error("方法已存在，添加失败！");
		}else {
			return HttpResult.ok(this.interfaceCloseCheckService.add(interfaceCloseCheck));
		}
    }
	
	@RequestMapping(value = "/addBatch")
	public HttpResult addBatch() {
		return HttpResult.ok(this.interfaceCloseCheckService.getAllScanMethod());
    }
	
	/**
	 * 更新
	 * 
	 * @param interfaceCloseCheck
	 * @return
	 */
	 @RequestMapping(value = "/update")
	    public HttpResult update(@RequestBody InterfaceCloseCheck interfaceCloseCheck) {
			return HttpResult.ok(this.interfaceCloseCheckService.update(interfaceCloseCheck));
	    }
	
	 /**
	  * 删除
	  * @param id
	  * @return
	  */
	@RequestMapping(value = "/deleteById/{id}")
	public HttpResult deleteById(@PathVariable(value = "id") int id) {
		this.interfaceCloseCheckService.delete(id);
		return HttpResult.ok();
    }
	
	/**
	 * 模糊查询 serviceId
	 * 
	 * @param serviceId
	 * @return
	 */
	@RequestMapping(value = "/getServiceIdByInput")
	public HttpResult getServiceIdByInput(String serviceId) {
		return HttpResult.ok(interfaceCloseCheckService.getServiceIdByInput(serviceId));
    }
	
	/**
	 * 模糊查询 className
	 * 
	 * @param serviceId
	 * @param className
	 * @return
	 */
	@RequestMapping(value = "/getClassNameByInput")
	public HttpResult getClassNameByInput(String serviceId, String className) {
		return HttpResult.ok(interfaceCloseCheckService.getClassNameByInput(serviceId, className, "className"));
    }
	
	/**
	 * 模糊查询 methodName
	 * 
	 * @param serviceId
	 * @param className
	 * @param methodName
	 * @return
	 */
	@RequestMapping(value = "/getMethodByInput")
	public HttpResult getMethodByInput(String serviceId, String className, String methodName) {
		return HttpResult.ok(interfaceCloseCheckService.getMethodByInput(serviceId, className, methodName));
    }
	/**
	 *  判断系统方法是否可用
	 * @param serviceId
	 * @param className
	 * @param methodName
	 * @return
	 */
	@RequestMapping(value = "/judgeMethodIsActive")
	public Boolean judgeMethodIsActive(String serviceId, String className, String methodName) {
		return interfaceCloseCheckService.judgeMethodIsActive(serviceId, className, methodName);
    }
	/**
     * 分页查询
     *
     * @param pageRequest
     * @return
     */
    @RequestMapping(value = "/getInterfaceCloseCheckPageData")
    public HttpResult getInterfaceCloseCheckPageData(@RequestBody PageRequest pageRequest) {
        return HttpResult.ok(this.interfaceCloseCheckService.findPage(pageRequest));
    }
}
