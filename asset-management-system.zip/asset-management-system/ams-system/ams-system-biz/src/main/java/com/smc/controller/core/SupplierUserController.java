package com.smc.controller.core;

import com.github.pagehelper.PageInfo;
import com.smc.base.page.Page;
import com.smc.core.condition.UserExternalCondition;
import com.smc.dataobject.core.UserExternal;
import com.smc.log.annotation.SysLog;
import com.smc.service.core.UserExternalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 
 * ClassName: SupplierUserController <br/>  
 * Function: TODO 供应商用户表相关接口. <br/>  
 * Reason: TODO ADD REASON(可选). <br/>  
 * date: 2018年11月8日 上午11:39:34 <br/>  
 *  
 * @author SMC892Q  
 * @version   
 * @since JDK 1.8
 */
@RestController
@RequestMapping(value="/userExternal")
@CrossOrigin
public class SupplierUserController {
	
	@Autowired
	private UserExternalService userExternalService;
	
	/**
	 * 供应商用户表-查询接口：根据【用户名】，【合同类型】，【合同期限】，【供应商类型】，
	 * 【有效类型】查询，按供应商注册时间倒叙排列
	 * @param condition
	 * @return
	 */
	/*@RequestMapping("/query")
    public PageInfo<SupplierUser> query(@RequestBody SupplierUserCondition condition,Page page) {
	    return supplierUserService.query(condition,page);
    }*/
	
	/**
	 * 供应商用户表与供应商基本表联合查询：根据供应商名称【用户名】，【合同类型】，【合同期限】，【供应商类型】，
	 * 【有效类型】查询，按供应商注册时间倒叙排列
	 * @param condition
	 * @return
	 */
	@RequestMapping("/query")
    public PageInfo<UserExternal> query(@RequestBody UserExternalCondition condition, Page page) {
	    return userExternalService.query(condition,page);
    }
	
	/**
	 * 添加接口：将供应商用户信息添加数据库
	 * @param supplierUser
	 */
	@RequestMapping("/add")
	@SysLog("添加用户")
    public void save(@RequestBody UserExternal userExternal) {
		userExternalService.add(userExternal);
    }
	
	/**
	 * 更新接口：将供应商用户信息进行更新
	 * @param supplierUser
	 */
	@RequestMapping("/update")
	@SysLog("更新供应商用户")
    public void update(@RequestBody UserExternal userExternal) {
		userExternalService.update(userExternal);
    }
	
	/**
	 * 用户详情接口：根据【用户名】查询用户详情
	 * @param userName
	 * @return
	 */
	@RequestMapping(value="/findByUserName",method = RequestMethod.GET)
    public UserExternal findByUserName(String userName) {
	    return userExternalService.findByUserName(userName);
    }
	
	/**
	 * 修改密码
	 * @param userName
	 * @return
	 */
	@RequestMapping("/changePassword")
	@SysLog("修改密码")
    public void changePassword(@RequestBody List<String> userNameList) {
		userExternalService.changePassword(userNameList);
    }
	
	/**
	 * 验证用户
	 * @param userName
	 * @return
	 */
	@RequestMapping("/verify")
    public boolean verifyUser(String userName) {
	    return userExternalService.verifyUser(userName);
    }
}
