package com.smc.dataobject.core;

import java.io.Serializable;

import com.smc.base.BaseEntity;

public class DataFilter extends BaseEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3281543465694592786L;
	
	/**
	 * 角色ID
	 */
	private String roleId;
	
	/**
	 * 权限类型，1：按部门授权，2：按员工授权，3：按客户授权
	 */
	private String filterType;
	
	/**
	 * 读权限
	 */
	private boolean readPermission;
	
	/**
	 * 编辑权限
	 */
	private boolean editPermission;
	
	/**
	 * 删除权限
	 */
	private boolean deletePermission;

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	
	public String getFilterType() {
		return filterType;
	}

	public void setFilterType(String filterType) {
		this.filterType = filterType;
	}

	public boolean isReadPermission() {
		return readPermission;
	}

	public void setReadPermission(boolean readPermission) {
		this.readPermission = readPermission;
	}

	public boolean isEditPermission() {
		return editPermission;
	}

	public void setEditPermission(boolean editPermission) {
		this.editPermission = editPermission;
	}

	public boolean isDeletePermission() {
		return deletePermission;
	}

	public void setDeletePermission(boolean deletePermission) {
		this.deletePermission = deletePermission;
	}
}
