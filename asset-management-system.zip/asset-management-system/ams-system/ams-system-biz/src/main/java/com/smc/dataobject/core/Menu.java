package com.smc.dataobject.core;

import java.io.Serializable;

import com.smc.base.TreeImpl;

public class Menu extends TreeImpl<Menu> implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8618846685650967726L;
	
	/**
	 * path
	 */
	private String path;
	
	/**
	 * component
	 */
	private String component;
	
	/**
	 * title
	 */
	private String title;
	
	/**
	 * icon
	 */
	private String icon;
	
	/**
	 * hidden: 0 显示，1 隐藏
	 */
	private String hidden;
	
	/**
	 * sort
	 */
	private Integer sort;

	private Integer keepalive;

	public Integer getKeepalive() {
		return keepalive;
	}

	public void setKeepalive(Integer keepalive) {
		this.keepalive = keepalive;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getHidden() {
		return hidden;
	}

	public void setHidden(String hidden) {
		this.hidden = hidden;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}
}
