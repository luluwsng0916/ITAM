package com.smc.controller.core;

import com.smc.common.model.result.ResultBody;
import com.smc.controller.core.vo.MdmDeptPositionVO;
import com.smc.service.core.MdmDeptPositionService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @description:
 * @author: C31909
 * @Version 1.0
 **/
@RestController
@CrossOrigin
@RequestMapping("/orgPosition")
public class MdmDeptPositionController {
    @Resource
    private MdmDeptPositionService mdmOrgPositionService;

    @GetMapping(value = "/queryOrgPosition")
    public ResultBody<List<MdmDeptPositionVO>> queryOrgPosition(@RequestParam("unitId") String unitId,
                                                                @RequestParam(value = "positionName", required = false) String positionName,
                                                                @RequestParam(value = "accurate", required = false) Boolean accurate,
                                                                @RequestParam(value = "userInfo", required = false) String userInfo) {
        return mdmOrgPositionService.queryOrgPosition(unitId, positionName, accurate, userInfo);
    }
}
