package com.smc.controller.core;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.smc.base.Depart;
import com.smc.base.Position;
import com.smc.base.RemoteUser;
import com.smc.base.UserInfo;
import com.smc.base.page.Page;
import com.smc.base.result.Result;
import com.smc.common.model.http.HttpResult;
import com.smc.common.model.page.PageRequest;
import com.smc.common.model.result.ResultBody;
import com.smc.core.condition.UserRoleCondition;
import com.smc.core.feign.service.BaseInfoService;
import com.smc.dataobject.core.Role;
import com.smc.dataobject.core.UserCompany;
import com.smc.dataobject.core.UserRole;
import com.smc.log.annotation.SysLog;
import com.smc.redis.RedisConfig;
import com.smc.redis.RedisUtil;
import com.smc.service.core.*;
import com.smc.utils.StringUtils;
import com.smc.utils.WebUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping(value="/user")
@CrossOrigin
public class UserController{
	
	@Autowired
	private RedisConfig redisConfig;
	
	@Autowired
	private RedisUtil redisUtil;
	
    @Autowired
    private UserService userService;
	
    @Autowired
    private UserRoleService userRoleService;
    
    @Autowired
    private RoleService roleService;
    
    @Autowired
    private DataFilterService dataFilterService;
    
    @Autowired
	private UserCompanyService userCompanyService;

	@Autowired
	private BaseInfoService baseInfoService;
    
	@RequestMapping(value = "/findRoleById/{id}", method = RequestMethod.GET)
    public Set<String> findRoleById(@PathVariable(value = "id") String id) {
		return userService.findByUserId(id);
    }
    
	@RequestMapping(value = "/findBindRoleById/{id}", method = RequestMethod.GET)
    public List<Role> findBindRoleById(@PathVariable(value = "id") String id) {
		return roleService.findByUserId(id);
    }
	
	@SysLog("绑定角色")
	@RequestMapping(value = "/bind/role/{id}", method = RequestMethod.POST)
    public void bind(@PathVariable(value = "id") String id, @RequestParam(value = "psnname") String psnname,  @RequestParam(value="roleIds") List<String> roleIds) {
		userRoleService.add(id, psnname, roleIds);
    }

	/**
	 * getUserInfo端，手机端都在用
	 * @author yangyd
	 * @return
	 */
    @RequestMapping("/getUserInfo")
    public Map<String,Object> getUserInfo() {
    	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String  username  = (String) authentication.getPrincipal();
		Map<String,Object> map = new HashMap<String,Object>();
		map.put(Result.CONTENT, userService.findUserByUsername(username, true));
    	map.put(Result.RESULT, Result.RESULT_SUCCESS);
    	
    	// 获取数据权限数据
    	List<HashMap<String,Object>> findDataScopes = dataFilterService.findDataScopeByUserId(username);
    	// 登录时将 用户数据放入redis备用
    	String key = "DataScope-" + username;
		redisUtil.set(key, buildDataScope(map,findDataScopes));
    	return map;
    }
    
    /**
     * B92085
     * 构建DataScoep数据结构
     * @param map
     * @param findDataScopes
     * @return
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	private HashMap buildDataScope(Map map,List<HashMap<String, Object>> findDataScopes) {
		HashMap result = new HashMap();
		UserInfo userInfo =  (UserInfo)map.get("content");
		Set<String> roles = userInfo.getRoles();
		result.put("roles", roles);
		
		
		List<String> deptCodes = new ArrayList<>();
		List<String> deptCodeChilds = new ArrayList<>();
		RemoteUser remoteUser = userInfo.getRemoteUser();
		List<Position> positions = remoteUser.getPositions();
		
		for(Position position :positions) {
			String deptCode = position.getUnitId();
			if(StringUtils.isNotEmpty(deptCode)) {
				deptCodes.add(deptCode);
			}
		}
		List<Depart> departList = baseInfoService.findAllDepts();
		// 查找部门本身代码和其子部门代码
		deptCodeChilds = departList.stream().filter(depart -> deptCodes.stream().anyMatch(ownDepart -> depart.getK3code().contains(ownDepart)))
				.map(Depart::getCode).collect(Collectors.toList());
		result.put("deptCodeChilds", deptCodeChilds);
		result.put("deptCodes", deptCodes);
		result.put("scope", findDataScopes);
		return result;
	}
    
    /**
     * 通过用户名查询用户
     * @param username
     * @return
     */
    @RequestMapping("/getUserInfo/{username}")
    public UserInfo getUserInfo(@PathVariable(value = "username") String username) {
    	return userService.findUserByUsername(username, true);
    }
    
	/**
	 * 查询
	 * @return
	 */
	@RequestMapping(value = "/findUserRoleDetail", method = RequestMethod.GET)
    public PageInfo<UserRole> findUserRoleDetail(UserRoleCondition condition, Page page) {
		return userRoleService.query(condition,page);
    }
	
	/**
	 * 员工公司配置分页查询
	 * 
	 * @param pageRequest
	 * @return
	 */
	@PostMapping(value = "/getUserCompanyInfo")
	public ResultBody<List<UserCompany>> findPageImportCustomer(@RequestBody PageRequest pageRequest) {
		return ResultBody.ok().data(userCompanyService.findPage(pageRequest));
	}

	/**
	 * 获取厂别信息
	 * 
	 * @param pageRequest
	 * @return
	 */
	@PostMapping(value = "/findPlantMark")
	public HttpResult findPlantMark() {
		List<UserCompany> userCompany = userCompanyService.findPlantMark();
		return HttpResult.ok(userCompany);
	}

	/**
	 * 通过员工编号获取关务系统配置的用户信息
	 * 
	 * @param pageRequest
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@PostMapping(value = "/findUserCompanyInfo")
	public ResultBody<List<UserCompany>> findUserCompanyInfo(@RequestBody PageRequest pageRequest) {
		String userId = pageRequest.getParam("userId").getValue();
		List<UserCompany> userCompany = userCompanyService.getUserCompany(userId);
		return ResultBody.ok().data(userCompany).path(WebUtils.getUri());
	}

	/**
	 * 获取选中员工的厂别权限信息
	 * 
	 * @param pageRequest
	 * @return
	 */
	@PostMapping(value = "/findBindPlantMarkById{userId}")
	public HttpResult findBindPlantMarkById(@PathVariable(value = "userId") String userId) {
		List<UserCompany> userCompany = userCompanyService.findBindPlantMarkById(userId);
		return HttpResult.ok(userCompany);
	}

	/**
	 * 公司管理——添加员工
	 * 
	 * @param pageRequest
	 * @return
	 */
	@PostMapping(value = "/addUser")
	public int addUser(@RequestBody PageRequest pageRequest) {
		String adduserformUserId = pageRequest.getParam("adduserformUserId").getValue();
		String adduserformUserName = pageRequest.getParam("adduserformUserName").getValue();
		String operatorUserName = pageRequest.getParam("operatorUserName").getValue();
		// 查找数据库是否存在该员工，如果存在该员工则提示该员工已经存在
		int i;
		//如果查到总记录数为零  说明不存在该员工  则可以进行插入新的员工
		i = userCompanyService.selectUserNum(adduserformUserId);
		if (i == 0) {
			//插入新的员工
			i = userCompanyService.addUser(adduserformUserId, adduserformUserName, operatorUserName);
			if (i == 6) {
				// i=1代表插入成功
				i = 1;
			} else {
				i = -1;
			}
		}
		return i;

	}

	/**
	 * 公司管理——为员工绑定公司
	 */
	@SuppressWarnings("unchecked")
	@PostMapping(value = "/bindPlankMark")
	public int bindPlankMark(@RequestBody PageRequest pageRequest) {

		String userId = pageRequest.getParam("userId").getValue();
		String operatorUserName = pageRequest.getParam("operatorUserName").getValue();
		String plantMarkIds = pageRequest.getParam("plantMarkIds").getValue();
		List<UserCompany> userCompanies = JSONObject.parseObject(plantMarkIds, List.class);
		//清空redis——开始
		// 删除redis gw_position   (调用已经初始化得哪个对象  用初始化好的对象 连接redis库 清除redis)20211222
		RedisTemplate<String, Object> redisTemplateOrgan = redisConfig.redisTemplateOrgan();
		redisTemplateOrgan.delete("gw_position::"+ userId);
		//清空redis——结束
		// 绑定公司之前要先把该员工的所有权限 属性设置为0
		userCompanyService.deletePermissionsByUserId(userId,operatorUserName);
		// 当取消所有厂别时（选中厂别信息）为空 时候 提示 已经取消该运功所有公司权限
		if (userCompanies.size() != 0) {
			int j = userCompanyService.bindPlantMark(userId, userCompanies, operatorUserName);
			return j;
		} else {
			// 返回 200 代表传进来的厂别信息为空 直接提示已经取消该运功所有公司权限
			return 200;
		}
	}
}
