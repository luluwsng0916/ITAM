package com.smc.controller.core;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.web.WebAttributes;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.smc.base.result.Result;
import com.smc.exception.BaseExceptionCode;

@RestController
@CrossOrigin
public class LoginController{
	
	/**
	 * loginSuccess:异步ajax请求，登录成功后，转向的URL
	 * 多使用于登录方式为异步请求成功后，前端自行跳转至首页面(如：手机端原生app)
	 * @author yangyd
	 * @return
	 */
	@RequestMapping(value="/loginSuccess")
	@ResponseBody
	public Map<String,Object> loginSuccess(){
		Map<String,Object> map = new HashMap<String,Object>();
		map.put(Result.RESULT, Result.RESULT_SUCCESS);
		return map;
	}
	
	/**
	 * loginFailure:异步ajax请求，登录失败后，转向的URL
	 * 多使用于登录方式为异步请求失败后，前端进行提示具体错误(如：手机端原生app)
	 * @author yangyd
	 * @return
	 */
	@RequestMapping(value="/loginFailure")
	@ResponseBody
	public Map<String,Object> loginFailure(){
		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest(); 
		Exception exception = (Exception) request.getAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);
		Map<String,Object> map = new HashMap<String,Object>();
		map.put(Result.RESULT, Result.RESULT_FAIL);
		map.put(Result.ERROR_CODE, BaseExceptionCode.登录错误);
		map.put(Result.ERROR_MESSAGE,  exception.getMessage());
	    HttpServletResponse response = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getResponse();
	    response.setStatus(500);
		return map;
	}
	
	/**
	 * logoutSuccess:退出登录成功后，转向的URL
	 * 多使用于退出方式为异步请求成功后，前端自行跳转至登录页(如：手机端原生app)
	 * @author yangyd
	 * @return
	 */
	@RequestMapping(value="/logoutSuccess")
	@ResponseBody
	public Map<String,Object> logoutSuccess(){
		Map<String,Object> map = new HashMap<String,Object>();
		map.put(Result.RESULT, Result.RESULT_SUCCESS);
		return map;
	}
}
