package com.smc.dataobject.core;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * @program: cloud-pms-parent
 * @ClassName AccessLog
 * @description:
 * @author: C31909
 * @create: 2023-12-19 12:57
 * @Version 1.0
 **/
@Data
@TableName("access_log")
public class AccessLog {
    @TableId(type = IdType.AUTO)
    private String id;
    private String ip;
    private String serviceId;
    private String method;
    private String path;
    private String headers;
    private String requestTime;
    private String userAgent;
    private String params;
    private Integer httpStatus;
    private String responseTime;
    private String callTime;
    private String error;
}
