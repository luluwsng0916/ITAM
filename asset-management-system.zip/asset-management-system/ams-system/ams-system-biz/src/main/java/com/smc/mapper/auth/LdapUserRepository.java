package com.smc.mapper.auth;

import com.smc.dataobject.auth.LdapUser;
import org.springframework.data.ldap.repository.LdapRepository;

public interface LdapUserRepository extends LdapRepository<LdapUser> {
	
	public LdapUser findByAccountName(String accountName);
	
}
