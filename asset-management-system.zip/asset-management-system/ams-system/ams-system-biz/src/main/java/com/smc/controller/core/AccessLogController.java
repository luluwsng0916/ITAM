package com.smc.controller.core;

import cn.hutool.core.collection.CollectionUtil;
import com.github.pagehelper.PageInfo;
import com.smc.common.model.result.ResultBody;
import com.smc.dataobject.core.AccessLog;
import com.smc.common.model.page.PageRequest;
import com.smc.service.core.AccessLogService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @program: cloud-pms-parent
 * @ClassName AccessLogController
 * @description:
 * @author: C31909
 * @create: 2023-12-19 13:28
 * @Version 1.0
 **/
@RestController
@RequestMapping("/accessLog")
@CrossOrigin
public class AccessLogController {
    @Resource
    private AccessLogService accessLogService;

    @PostMapping("/list")
    public ResultBody<PageInfo<AccessLog>> listByPage(@RequestBody PageRequest pageRequest) {
        return accessLogService.listByPage(pageRequest);
    }

    @PostMapping("/deleteByIds")
    public ResultBody<String> deleteByIds(@RequestBody List<String> ids) {
        if (CollectionUtil.isEmpty(ids)) {
            return ResultBody.ok();
        }
        return accessLogService.deleteByIds(ids);
    }

    @PostMapping("/deleteByCondition")
    public ResultBody<String> deleteByCondition(@RequestBody PageRequest pageRequest) {
        return accessLogService.deleteByCondition(pageRequest);
    }
}
