package com.smc.controller.core;

import com.smc.core.condition.AuthorityCondition;
import com.smc.dataobject.core.Authority;
import com.smc.dataobject.core.AuthorityMenu;
import com.smc.dataobject.core.AuthorityResource;
import com.smc.service.core.AuthorityMenuService;
import com.smc.service.core.AuthorityResourceService;
import com.smc.service.core.AuthorityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping(value="/authority")
@CrossOrigin
public class AuthorityController {
	
	@Autowired
	private AuthorityService authorityService;
	
	@Autowired
	private AuthorityResourceService authorityResourceService;
	
	@Autowired
	private AuthorityMenuService authorityMenuService;
	
	/**
	 * 获取全部节点
	 * @return
	 */
	@RequestMapping(value = "/findAll", method = RequestMethod.GET)
	@ResponseBody
    public List<Authority> findAll(AuthorityCondition condition) {
		return authorityService.findAll(condition);
    }
	
	/**
	 * 详情
	 * @return
	 */
	@RequestMapping(value = "/detail/{id}", method = RequestMethod.GET)
	@ResponseBody
    public Authority detail(@PathVariable(value = "id") String id) {
		return authorityService.detail(id);
    }
	
	/**
	 * 添加
	 * @return
	 */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@ResponseBody
	public Authority add(@RequestBody Authority authority) {
		return authorityService.add(authority);
    }
	
	/**
	 * 更新
	 * @return
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	@ResponseBody
	public Authority update(@RequestBody Authority form) {
		return authorityService.update(form);
    }
	
	/**
	 * 删除
	 * @return
	 */
	@RequestMapping(value = "/deleteByCode/{code}", method = RequestMethod.POST)
	@ResponseBody
	public void deleteByCode(@PathVariable(value = "code") String code) {
		authorityService.deleteByCode(code);
    }
	
	/**
	 * 绑定
	 * @return
	 */
	@RequestMapping(value = "/bind/menu", method = RequestMethod.POST)
	@ResponseBody
    public void bind(@RequestBody AuthorityMenu authorityMenu) {
		authorityMenuService.add(authorityMenu);
    }
    
    /**
	 * 通过权限ID获取绑定的菜单
	 * @return
	 */
	@RequestMapping(value = "/findBindMenuById/{authorityId}", method = RequestMethod.GET)
	@ResponseBody
	public AuthorityMenu findBindMenuById(@PathVariable(value = "authorityId") String authorityId) {
		return authorityMenuService.findByAuthorityId(authorityId);
    }
	
	/**
	 * 绑定
	 * @return
	 */
	@RequestMapping(value = "/bind/resource/{authorityId}", method = RequestMethod.POST)
	@ResponseBody
    public void bind(@PathVariable(value = "authorityId") String authorityId,@RequestParam(value="resourceIds") List<String> resourceIds) {
		authorityResourceService.add(authorityId, resourceIds);
    }
    
    /**
	 * 通过权限ID获取绑定的资源
	 * @return
	 */
	@RequestMapping(value = "/findBindResourceById/{authorityId}", method = RequestMethod.GET)
	@ResponseBody
	public List<AuthorityResource> findBindResourceById(@PathVariable(value = "authorityId") String authorityId) {
		return authorityResourceService.findByAuthorityId(authorityId);
    }
	
	/**
	 * 根据用户ID获取用户对应的权限
	 * @return
	 */
	@RequestMapping(value = "/findByUserId/{userId}", method = RequestMethod.GET)
    public Set<String> findByUserId(@PathVariable("userId") String userId) {
		return authorityService.findByUserId(userId);
    }
	
	/**
	 * 根据角色ID获取用户对应的权限
	 * @return
	 */
	@RequestMapping(value = "/findByRoleId/{roleId}", method = RequestMethod.GET)
	public Set<Authority> findByRoleId(@PathVariable("roleId") String roleId){
		return authorityService.findByRoleId(roleId);
	}
}
  
