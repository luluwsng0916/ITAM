package com.smc.controller.core.vo;

import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @program: cloud-pms-parent
 * @ClassName MdmDeptDTO
 * @description:
 * @author: C31909
 * @create: 2024-06-06 11:04
 * @Version 1.0
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class MdmDeptPositionTreeDTO extends AbstractEntity {
    private String deptCode;
    private String parentId;
    private String deptName;
    private String k3Code;
    private String fullName;
    private String grade;
    private String status;
    private Boolean salesCustomized;
    private String companyCode;
    private String companyName;
    private String unitCode;

    /**
     * 前端树状结构显示值
     */
    private String label;
    /**
     * 前端树状结构结果值
     */
    private String value;
    /**
     * 叶子节点
     */
    private List<MdmDeptPositionTreeDTO> children;
    /**
     * 组织下对应的岗位
     */
    private List<MdmDeptPositionVO> positions;
}
