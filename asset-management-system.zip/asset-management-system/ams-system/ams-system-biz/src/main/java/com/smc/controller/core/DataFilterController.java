package com.smc.controller.core;

import com.smc.dataobject.core.DataRole;
import com.smc.service.core.DataFilterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;


@RestController
@RequestMapping(value="/dataFilter")
@CrossOrigin
public class DataFilterController {
	
	@Autowired
	private DataFilterService dataFilterService;
	
	
	/**
	 * 通过用户ID获取授权的数据
	 * @return
	 */
	@RequestMapping(value = "/findDataByUserId", method = RequestMethod.GET)
    public Map<String, List<String>> findDataByUserId(String userId) {
		return dataFilterService.findDataByUserId(userId);
    }
	
	/**
	 * 通过用户ID获取授权的数据
	 * @return
	 */
	@RequestMapping(value = "/findDataRoleByUserId", method = RequestMethod.GET)
    public List<DataRole> findDataRoleByUserId(String userId) {
		return dataFilterService.findDataRoleByUserId(userId);
    }
}
  
