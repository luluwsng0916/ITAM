package com.smc.config.auth.security;

import java.io.IOException;
import java.util.Date;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.web.filter.OncePerRequestFilter;

import cn.hutool.core.date.DateTime;

public class AuthenticationTokenFilter extends OncePerRequestFilter{

	@Autowired
	private TokenStore tokenStore;
	
	@Autowired
	private ClientDetailsService clientDetailsService;
	
    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain chain) throws ServletException, IOException {

    	//String token = request.getHeader("Authentication");
    	String tokenValue = request.getParameter("token");
    	System.out.println(tokenValue);
    	
    	if(StringUtils.isBlank(tokenValue)) {
    		chain.doFilter(request, response);
    		return;
    	}
    	
    	OAuth2AccessToken token = tokenStore.readAccessToken(tokenValue);
    	
    	if(token == null) {
    		chain.doFilter(request, response);
    		return;
    	}
    	
    	OAuth2Authentication authentication = tokenStore.readAuthentication(token);
    	
		// 如果token没有失效  更新AccessToken过期时间
		DefaultOAuth2AccessToken oAuth2AccessToken = (DefaultOAuth2AccessToken) token;
		System.out.println(new DateTime(oAuth2AccessToken.getExpiration()).toString("yyyy-MM-dd HH:mm:ss"));
		//重新设置过期时间
		Integer validitySeconds = getAccessTokenValiditySeconds(authentication.getOAuth2Request());
		if (validitySeconds > 0) {
			oAuth2AccessToken.setExpiration(new Date(System.currentTimeMillis() + (validitySeconds)));
		}
		
		System.out.println(new DateTime(oAuth2AccessToken.getExpiration()).toString("yyyy-MM-dd HH:mm:ss"));
 
		//将重新设置过的过期时间重新存入redis, 此时会覆盖redis中原本的过期时间
		tokenStore.storeAccessToken(token, authentication);
		//tokenStore.storeRefreshToken(refreshToken, authentication);
        chain.doFilter(request, response);
    }
    
    protected int getAccessTokenValiditySeconds(OAuth2Request clientAuth) {
    	if (clientDetailsService == null) {
    		return 0;
    	}
		ClientDetails client = clientDetailsService.loadClientByClientId(clientAuth.getClientId());
		Integer validity = client.getAccessTokenValiditySeconds();
		return validity;
	}
}
