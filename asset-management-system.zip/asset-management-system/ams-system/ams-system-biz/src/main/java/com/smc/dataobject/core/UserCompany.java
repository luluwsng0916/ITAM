package com.smc.dataobject.core;

import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * 用户公司信息实体类
 *
 * @author B91715
 */
@Data
public class UserCompany {
    private String id;
    private String userId;
    private String userName;
    @TableField(value = "PlantMark")
    private String plantmark;
    private String companyPosition;
    private String isActivity;

    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "CREATED_TIME")
    private Date createdTime;

    @TableField(value = "CREATED_BY")
    private String createdBy;

    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(value = "UPDATED_TIME")
    private Date updatedTime;

    @TableField(value = "UPDATED_BY")
    private String updatedBy;

    private Integer revision;

}
