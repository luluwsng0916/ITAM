package com.smc.controller.core;

import com.github.pagehelper.PageInfo;
import com.smc.base.page.Page;
import com.smc.core.condition.GroupRoleCondition;
import com.smc.dataobject.core.Group;
import com.smc.dataobject.core.GroupRole;
import com.smc.service.core.GroupRoleService;
import com.smc.service.core.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping(value="/group")
@CrossOrigin
public class GroupController {
	
	@Autowired
	private GroupService groupService;
	
	@Autowired
	private GroupRoleService groupRoleService;
	
	/**
	 * 获取全部节点
	 * @return
	 */
	@RequestMapping(value = "/findAll", method = RequestMethod.GET)
	@ResponseBody
    public List<Group> findAll() {
		return groupService.findAll();
    }
	
	/**
	 * 详情
	 * @return
	 */
	@RequestMapping(value = "/detail/{id}", method = RequestMethod.GET)
	@ResponseBody
    public Group detail(@PathVariable(value = "id") String id) {
		return groupService.detail(id);
    }
	
	/**
	 * 添加
	 * @return
	 */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@ResponseBody
	public Group add(@RequestBody Group group) {
		return groupService.add(group);
    }
	
	/**
	 * 更新
	 * @return
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	@ResponseBody
	public Group update(@RequestBody Group form) {
		return groupService.update(form);
    }
	
	/**
	 * 删除
	 * @return
	 */
	@RequestMapping(value = "/deleteByCode/{code}", method = RequestMethod.POST)
	@ResponseBody
	public void deleteByCode(@PathVariable(value = "code") String code) {
		groupService.deleteByCode(code);
    }
	
	/**
	 * 绑定
	 * @return
	 */
	@RequestMapping(value = "/bind/role", method = RequestMethod.POST)
	@ResponseBody
    public void bind(@RequestBody Map<String,List<String>> map) {
		groupRoleService.add(map.get("groupIds"), map.get("groupNames"), map.get("roleIds"));
    }
    
    /**
	 * 通过用户组ID获取绑定的角色
	 * @return
	 */
	@RequestMapping(value = "/findBindRoleById/{groupId}", method = RequestMethod.GET)
	@ResponseBody
	public List<GroupRole> findBindRoleById(@PathVariable(value = "groupId") String groupId) {
		return groupRoleService.findByGroupId(groupId);
    }
	
	/**
	 * 根据用户ID获取用户对应的组
	 * @return
	 */
	@RequestMapping(value = "/findByUserId/{userId}", method = RequestMethod.GET)
    public Set<String> findByUserId(@PathVariable("userId") String userId) {
		return groupService.findByUserId(userId);
    }
	
	/**
	 * 查询
	 * @return
	 */
	@RequestMapping(value = "/findGroupRoleDetail", method = RequestMethod.GET)
    public PageInfo<GroupRole> findGroupRoleDetail(GroupRoleCondition condition,Page page) {
		return groupRoleService.query(condition,page);
    }
}
  
