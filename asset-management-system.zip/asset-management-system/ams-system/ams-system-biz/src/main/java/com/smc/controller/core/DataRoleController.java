package com.smc.controller.core;

import com.smc.dataobject.core.DataRole;
import com.smc.log.annotation.SysLog;
import com.smc.service.core.DataRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value="/dataRole")
@CrossOrigin
public class DataRoleController {
	
	@Autowired
	private DataRoleService dataRoleService;
	
	/**
	 * 通过角色ID获取绑定的权限
	 * @return
	 */
	@RequestMapping(value = "/findByRoleId", method = RequestMethod.GET)
    public List<DataRole> findByRoleId(String roleId) {
		return dataRoleService.findByRoleId(roleId);
    }
	
	/**
	 * 绑定
	 * @return
	 */
	@RequestMapping(value = "/add/{roleId}", method = RequestMethod.POST)
	@ResponseBody
	@SysLog("绑定权限")
    public void bind(@PathVariable(value = "roleId") String roleId, @RequestBody List<DataRole> dataRoles) {
		dataRoleService.add(roleId, dataRoles);
    }
}
  
