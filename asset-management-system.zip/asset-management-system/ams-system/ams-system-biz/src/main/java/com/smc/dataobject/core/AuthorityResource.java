package com.smc.dataobject.core;

import java.io.Serializable;

public class AuthorityResource implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1647841234351979442L;

	/**
	 * 权限ID
	 */
	private String authorityId;
	
	/**
	 * 资源ID
	 */
	private String resourceId;

	public String getAuthorityId() {
		return authorityId;
	}

	public void setAuthorityId(String authorityId) {
		this.authorityId = authorityId;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}
}
