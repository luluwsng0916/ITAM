package com.smc.controller.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.smc.service.auth.LdapService;

@RestController
@RequestMapping(value = "/ad")
public class ADController {

	@Autowired
	private LdapService ldapService;

	@RequestMapping(value = "/adDomain/{username}/{password}", method = RequestMethod.POST)
	public boolean ADDomainVerification(@PathVariable(value = "username") String username,
			@PathVariable(value = "password") String password) throws Exception {

		boolean result = ldapService.login(username, password);

		if (result) {
			System.out.println("AD域验证成功");
		} else {
			System.out.println("AD域验证失败，用户名或密码错误！");
		}
		return result;
	}

}
