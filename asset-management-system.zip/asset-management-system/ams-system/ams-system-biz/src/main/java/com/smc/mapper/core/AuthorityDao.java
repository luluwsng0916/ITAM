package com.smc.mapper.core;

import com.smc.base.BaseDao;
import com.smc.dataobject.core.Authority;

import java.util.List;
import java.util.Set;

public interface AuthorityDao extends BaseDao<Authority, String> {
	
	/**
	 * getChildsByPid:查询父节点下所有编码不为空的子节点,按编码倒叙排列
	 * @author yangyudi
	 * @param id
	 * @return
	 */
	public List<Authority> getChildsByPid(String pCode);
	
	/**
	 * 通过CODE删除
	 * @param code
	 */
	public void deleteByCode(String code);

	/**
	 * 根据用户ID获取用户对应的权限
	 * @return
	 */
	public Set<Authority> getByUserId(String userId);
	
	/**
	 * 获取通用的权限
	 * @return
	 */
	public List<String> getCommonAuthority();
	
	/**
	 * 根据组名称获取用户对应的权限
	 * @return
	 */
	//public Set<Authority> getByGroupNames(List<String> list);
	
	/**
	 * 根据组名称获取用户对应的权限
	 * @return
	 */
	public Set<Authority> getByGroupIds(List<String> list);
	
	/**
	 * 根据角色ID获取用户对应的权限
	 * @param list
	 * @return
	 */
	public Set<Authority> getByRoleId(String roleId);
}
