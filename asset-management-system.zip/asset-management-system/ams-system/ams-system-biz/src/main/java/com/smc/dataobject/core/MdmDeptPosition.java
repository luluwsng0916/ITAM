package com.smc.dataobject.core;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @program: cloud-pms-parent
 * @ClassName MdmDeptPosition
 * @description:
 * @author: C31909
 * @create: 2024-06-06 09:35
 * @Version 1.0
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("s_dept_position")
public class MdmDeptPosition extends AbstractEntity {
    @TableId(value = "deptCode", type = IdType.INPUT)
    private String deptCode;
    @TableId(value = "positionId", type = IdType.INPUT)
    private String positionId;
    private String isFuZeRen;
}
