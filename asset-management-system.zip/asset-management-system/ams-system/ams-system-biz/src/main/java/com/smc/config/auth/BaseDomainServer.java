package com.smc.config.auth;

import lombok.Data;

/**
 * 域服务器配置
 *
 * @author B82443
 */
@Data
public class BaseDomainServer {

    private String url;

    private String base;

    private String username;

    private String password;

}

