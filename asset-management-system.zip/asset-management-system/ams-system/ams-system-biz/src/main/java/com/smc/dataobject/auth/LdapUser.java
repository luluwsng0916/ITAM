package com.smc.dataobject.auth;

import javax.naming.Name;

import lombok.Data;
import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.DnAttribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;

/**
 * @author C31909
 */
@Data
@Entry(objectClasses = { "organizationalPerson", "person", "user","top" })
public class LdapUser {
	@Id
    private Name id;
 
    @Attribute(name = "sAMAccountName")
    private String accountName;
 
    @Attribute(name = "cn")
    private String commonName;
 
    @Attribute(name = "sn")
    private String surName;
    
    @Attribute(name = "mail")
    private String email;
    
    @DnAttribute(value = "ou",index=0)
    private String ou;

}