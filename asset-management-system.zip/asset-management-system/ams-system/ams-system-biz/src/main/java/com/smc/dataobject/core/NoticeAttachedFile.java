package com.smc.dataobject.core;

/**
 * @Descripton: 公告附件表
 * @Classname: NoticeAttachedFile
 * @Author B82561
 * @Date 2019年3月21日
 */
public class NoticeAttachedFile {

	private String id;

	private String noticeId;

	private String fileName;

	private String randomFileName;

	private String filePath;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNoticeId() {
		return noticeId;
	}

	public void setNoticeId(String noticeId) {
		this.noticeId = noticeId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getRandomFileName() {
		return randomFileName;
	}

	public void setRandomFileName(String randomFileName) {
		this.randomFileName = randomFileName;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public NoticeAttachedFile() {
		super();
	}

	@Override
	public String toString() {
		return "NoticeAttachedFile [id=" + id + ", noticeId=" + noticeId + ", fileName=" + fileName
				+ ", randomFileName=" + randomFileName + ", filePath=" + filePath + "]";
	}

}
