package com.smc.dataobject.core;

import java.io.Serializable;

public class GroupRole implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1647841234351979442L;

	/**
	 * 用户组ID
	 */
	private String groupId;
	
	/**
	 * 角色ID
	 */
	private String roleId;
	
	/**
	 * 描述
	 */
	private String description;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
