package com.smc.dataobject.core;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @program: cloud-pms-parent
 * @ClassName MdmPosition
 * @description:
 * @author: C31909
 * @create: 2024-06-06 09:28
 * @Version 1.0
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("s_position")
public class MdmPosition extends AbstractEntity {
    @TableId
    private String id;
    private String name;
    private String parentId;
    private String typeId;
    private String description;
}
