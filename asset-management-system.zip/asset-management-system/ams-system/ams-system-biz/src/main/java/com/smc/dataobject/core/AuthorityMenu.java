package com.smc.dataobject.core;

import java.io.Serializable;

public class AuthorityMenu implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1647841234351979442L;

	/**
	 * 权限ID
	 */
	private String authorityId;
	
	/**
	 * 菜单ID
	 */
	private String menuId;

	public String getAuthorityId() {
		return authorityId;
	}

	public void setAuthorityId(String authorityId) {
		this.authorityId = authorityId;
	}

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}
}
