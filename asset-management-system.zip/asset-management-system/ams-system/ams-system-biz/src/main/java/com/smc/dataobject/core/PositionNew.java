package com.smc.dataobject.core;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.smc.base.Position;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PositionNew extends Position {
	private static final long serialVersionUID = 1L;
	private String plantMark;//用于去重时候的厂别
}
