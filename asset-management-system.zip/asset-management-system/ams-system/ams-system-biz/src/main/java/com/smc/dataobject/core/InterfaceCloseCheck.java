package com.smc.dataobject.core;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;

import lombok.Data;

@Data
@TableName("s_interface_close_check")
public class InterfaceCloseCheck extends AbstractEntity{
	
	private static final long serialVersionUID = 1264407597106541226L;
	@TableId(type = IdType.AUTO)
    private Integer id; 
	
	@TableField("serviceId")
	private String serviceId;
	
	@TableField("className")
	private String className;
	
	/**
	 * 方法名
	 */
	@TableField("methodName")
	private String methodName;
	
	/**
	 * 是否使用
	 */
	@TableField("active")
	private boolean active;
}
