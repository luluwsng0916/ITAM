package com.smc.controller.core.vo;

import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @program: cloud-pms-parent
 * @ClassName MdmDeptPosition
 * @description:
 * @author: C31909
 * @create: 2024-06-06 09:35
 * @Version 1.0
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class MdmDeptPositionVO extends AbstractEntity {
    private String deptCode;
    private String fullName;
    private String positionId;
    private String name;
    // 在岗人数
    private String onPositionCount;
    // 在岗人员信息
    private String userInfo;
}
