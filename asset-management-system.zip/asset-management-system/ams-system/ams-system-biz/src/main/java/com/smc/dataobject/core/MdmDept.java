package com.smc.dataobject.core;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.smc.common.mybatis.entity.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@TableName("s_dept")
@Data
public class MdmDept extends AbstractEntity{

    @TableId
    @TableField(value = "deptCode")
    private String deptCode;
    @TableField(value = "parentId")
    private String parentId;
    @TableField(value = "deptName")
    private String deptName;
    @TableField(value = "k3Code")
    private String k3Code;
    @TableField(value = "fullName")
    private String fullName;
    @TableField(value = "unitLevel")
    private String unitLevel;
    @TableField(value = "status")
    private String status;
    @TableField(value = "salesCustomized")
    private Boolean salesCustomized;
    @TableField(value = "companyCode")
    private String companyCode;
    @TableField(value = "companyName")
    private String companyName;
    @TableField(value = "unitCode")
    private String unitCode;

}
