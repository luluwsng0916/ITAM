package com.smc.dataobject.core;

import com.baomidou.mybatisplus.annotation.TableName;

import java.util.Date;

@TableName("S_VALIDATELOGIN")
public class UserLoginInfo {
 /**
  * 用户id
  */
  private String userId;
  /**
   * 登录失败次数
   */
  private Integer failureCount;
  /**
   * 最后登录时间
   */
  private Date loginTime;
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}

public Integer getFailureCount() {
	return failureCount;
}
public void setFailureCount(Integer failureCount) {
	this.failureCount = failureCount;
}
public Date getLoginTime() {
	return loginTime;
}
public void setLoginTime(Date loginTime) {
	this.loginTime = loginTime;
}
public UserLoginInfo(String userId, Integer failureCount, Date loginTime) {
	super();
	this.userId = userId;
	this.failureCount = failureCount;
	this.loginTime = loginTime;
}
public UserLoginInfo() {
	super();
}
  
  
}
