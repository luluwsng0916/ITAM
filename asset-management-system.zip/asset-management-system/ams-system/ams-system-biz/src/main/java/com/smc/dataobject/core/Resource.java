package com.smc.dataobject.core;

import java.io.Serializable;

import com.smc.base.TreeImpl;

public class Resource extends TreeImpl<Resource> implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8618846685650967726L;
	
	/**
	 * 模式
	 */
	private String pattern;

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
}
