package com.smc.dataobject.core;

import java.io.Serializable;

public class UserGroup implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7641277001453585670L;

	/**
	 * 用户ID
	 */
	private String userId;
	
	/**
	 * 用户组ID
	 */
	private String groupId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
}
