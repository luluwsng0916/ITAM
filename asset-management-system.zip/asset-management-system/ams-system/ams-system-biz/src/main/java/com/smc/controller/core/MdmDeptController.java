package com.smc.controller.core;

import com.smc.common.model.result.ResultBody;
import com.smc.controller.core.vo.MdmDeptPositionTreeDTO;
import com.smc.service.core.MdmDeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @description:
 * @author: C31909
 * @Version 1.0
 **/
@RestController
@CrossOrigin
@RequestMapping("/org")
public class MdmDeptController {
    @Autowired
    private MdmDeptService mdmOrganizationService;

    @PostMapping("/getAllOrganizationTree")
    public ResultBody<MdmDeptPositionTreeDTO> getAllOrganizationTree() {
        return mdmOrganizationService.getAllOrganizationTree();
    }
}
