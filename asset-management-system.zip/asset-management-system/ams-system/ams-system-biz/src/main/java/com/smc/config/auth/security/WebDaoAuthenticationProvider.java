package com.smc.config.auth.security;

import java.util.Map;

import com.smc.service.auth.LdapService;
import com.smc.service.auth.SingleSignOnService;
import com.smc.service.core.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;

import com.smc.exception.BaseException;
import com.smc.exception.BaseExceptionCode;

import com.smc.utils.SpringContextUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class WebDaoAuthenticationProvider extends DaoAuthenticationProvider {

	@Autowired
	private UserService userService;

	@Autowired
	private LdapService ldapService;

	@Autowired
	private SingleSignOnService singleSignOnService;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		try {
			userService.validateUserUnLock(authentication.getName());
			Authentication auth = super.authenticate(authentication);
			userService.resetFailureCount(authentication.getName());
			return auth;
		} catch (BadCredentialsException e) {
			Integer params[] = userService.updateFailureCount(authentication.getName());
			if (params[0] >= 4) {
				throw new BadCredentialsException(SpringContextUtil.getMessage(BaseExceptionCode.用户管理_密码错误次数, params));
			}
			throw e;
		} catch (BaseException e) {
			throw new BadCredentialsException(e.getMessage());
		}
	}


	// 重写additionalAuthenticationChecks方法，获取前台页面参数（用户名和密码），调用调用LdapService方法，验证用户名密码
	@Override
	protected void additionalAuthenticationChecks(UserDetails userDetails,
			UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
		if (authentication.getDetails() != null) {
			@SuppressWarnings("rawtypes")
			Map authDetails = (Map) authentication.getDetails();
			if (authDetails.get("usernumber") != null && authDetails.get("ssotoken") != null) {
				if (singleSignOnService.validateSSOLogin((String) authDetails.get("usernumber"),
						(String) authDetails.get("ssotoken"))) {
					return;
				} else {
					throw new InsufficientAuthenticationException("统一门户跳转登录失败");
				}
			}
		}

		if (authentication.getCredentials() == null || "".equals(authentication.getCredentials())) {
			logger.debug("Authentication failed: no credentials provided");
			throw new AuthenticationCredentialsNotFoundException(
					messages.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
		}

		// 获取登录页面传来的用户名和密码
		String username = authentication.getPrincipal().toString();
		String presentedPassword = authentication.getCredentials().toString();

		// 调用LdapService方法，验证用户名密码
		// 验证失败则抛出异常，验证成功则继续执行登陆
		try {
			boolean result = ldapService.login(username, presentedPassword);
			log.info("用户【{}】正在登录【资产管理系统】，AD域验证结果【{}】", username, result);
		} catch (Exception e) {
			log.error("用户【{}】登录【资产管理系统】，AD域验证异常：{}", username, e.getMessage());
			logger.debug("Authentication failed: password does not match stored value");
			// 将验证失败信息抛出
			throw new BadCredentialsException(e.getMessage());
		}
	}
}
