package com.smc.dataobject.core;

import java.io.Serializable;

import com.smc.base.BaseEntity;
import com.smc.enums.core.Constants;

public class Role extends BaseEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8618846685650967726L;
	
	/**
	 * 名称
	 */
	private String name;
	
	/**
	 * status:状态
	 */
	private String status = Constants.VALID;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
