package com.smc.controller.core;

import com.github.pagehelper.PageInfo;
import com.smc.base.page.Page;
import com.smc.core.condition.RoleCondition;
import com.smc.dataobject.core.DataFilter;
import com.smc.dataobject.core.DataRole;
import com.smc.dataobject.core.Role;
import com.smc.dataobject.core.RoleAuthority;
import com.smc.log.annotation.SysLog;
import com.smc.service.core.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value="/role")
@CrossOrigin
public class RoleController {

	@Autowired
	private RoleService roleService;

	@Autowired
	private RoleAuthorityService roleAuthorityService;

	@Autowired
	private ResourceCommonService resourceCommonService;

	@Autowired
	private DataFilterService dataFilterService;

	@Autowired
	private DataRoleService dataRoleService;

	/**
	 * 查询
	 * @return
	 */
	@RequestMapping(value = "/query", method = RequestMethod.GET)
    public PageInfo<Role> query(RoleCondition condition, Page page) {
		return roleService.query(condition,page);
    }

	/**
	 * 所有角色
	 * @return
	 */
	@RequestMapping(value = "/findAll", method = RequestMethod.GET)
    public List<Role> findAll() {
		return roleService.findAll();
    }

	/**
	 * 详情
	 * @return
	 */
	@RequestMapping(value = "/detail/{id}", method = RequestMethod.GET)
	@ResponseBody
    public Role detail(@PathVariable(value = "id") String id) {
		return roleService.detail(id);
    }

	/**
	 * 添加
	 * @return
	 */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@ResponseBody
	@SysLog("添加角色")
	public void add(@RequestBody Role role) {
		roleService.add(role);
    }

	/**
	 * 更新
	 * @return
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	@ResponseBody
	@SysLog("更新角色")
	public Role update(@RequestBody Role form) {
		return roleService.update(form);
    }

	/**
	 * 删除
	 * @return
	 */
	@RequestMapping(value = "/delete/{id}", method = RequestMethod.POST)
	@ResponseBody
	@SysLog("删除角色")
	public void delete(@PathVariable(value = "id") String id) {
		roleService.delete(id);
    }

	/**
	 * 绑定
	 * @return
	 */
	@RequestMapping(value = "/bind/authority/{id}", method = RequestMethod.POST)
	@ResponseBody
	@SysLog("绑定权限")
    public void bind(@PathVariable(value = "id") String id, @RequestBody List<String> authorityIds) {
		roleAuthorityService.add(id, authorityIds);
    }

    /**
	 * 通过角色ID获取绑定的权限
	 * @return
	 */
	@RequestMapping(value = "/findBindAuthorityById/{id}", method = RequestMethod.GET)
	@ResponseBody
	public List<RoleAuthority> findBindAuthorityById(@PathVariable(value = "id") String id) {
		return roleAuthorityService.findByRoleId(id);
    }


	/**
	 * 通过角色与资源的对应关系
	 * @return
	 */
	@RequestMapping(value = "/findRoleAndResource", method = RequestMethod.GET)
	public List<Map<String,String>> findRoleAndResource(){
		return resourceCommonService.findRoleAndResource();
	}


	/**
	 * 通过角色ID获取绑定的权限
	 * @return
	 */
	@RequestMapping(value = "/findDataFilterByRoleId", method = RequestMethod.GET)
    public DataFilter findByRoleId(String id) {
		return dataFilterService.findByRoleId(id);
    }

	/**
	 * 通过角色ID获取
	 * @return
	 */
	@RequestMapping(value = "/findDataRoleByRoleId", method = RequestMethod.GET)
    public List<DataRole> findDataRoleByRoleId(String id) {
		return dataRoleService.findByRoleId(id);
    }

	/**
	 * 绑定
	 * @return
	 */
	@RequestMapping(value = "/bind/dataFilter", method = RequestMethod.POST)
	@ResponseBody
	@SysLog("绑定数据权限")
    public void bindDataFilter(@RequestBody DataFilter dataFilter, @RequestParam(value="depts") List<String> depts) {
		dataFilterService.bindDataFilter(dataFilter, depts);
    }
}
  
